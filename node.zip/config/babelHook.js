require('@babel/register')

module.exports = require('./database.js')
