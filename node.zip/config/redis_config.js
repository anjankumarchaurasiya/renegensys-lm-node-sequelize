module.exports = {
  development: {
    server: {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
    },
    servers: [
      {
        host: 'lms-dev-redis-0001-001.rxtn0l.0001.use1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
      {
        host: 'lms-dev-redis-0001-002.rxtn0l.0001.use1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
      {
        host: 'lms-dev-redis-0001-003.rxtn0l.0001.use1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
    ],
    defaultExpiryInMillis: 5 * 60 * 1000, // 5 minutes
    isRedisClusterEnable: process.env.IS_REDIS_CLUSTER_ENABLE,
  },
  local: {
    server: {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
    },
    defaultExpiryInMillis: 5 * 60 * 1000, // 5 minutes
    isRedisClusterEnable: process.env.IS_REDIS_CLUSTER_ENABLE,
  },
  staging: {
    server: {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
    },
    servers: [
      {
        host: 'lms-stage-redis-0001-001.ft0b2k.0001.aps1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
      {
        host: 'lms-stage-redis-0001-002.ft0b2k.0001.aps1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
      {
        host: 'lms-stage-redis-0001-003.ft0b2k.0001.aps1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
    ],
    defaultExpiryInMillis: 5 * 60 * 1000, // 5 minutes
    isRedisClusterEnable: process.env.IS_REDIS_CLUSTER_ENABLE,
  },
  production: {
    server: {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
    },
    servers: [
      {
        host: 'redis-prod-cluster-0001-001.12eumf.0001.aps1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
      {
        host: 'redis-prod-cluster-0001-002.12eumf.0001.aps1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
      {
        host: 'redis-prod-cluster-0001-003.12eumf.0001.aps1.cache.amazonaws.com',
        port: process.env.REDIS_PORT,
      },
    ],
    defaultExpiryInMillis: 5 * 60 * 1000, // 5 minutes
    isRedisClusterEnable: process.env.IS_REDIS_CLUSTER_ENABLE,
  },
  test: {
    server: {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
    },
    defaultExpiryInMillis: 5 * 60 * 1000, // 5 minutes
    isRedisClusterEnable: process.env.IS_REDIS_CLUSTER_ENABLE,
  },
};
