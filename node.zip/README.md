# Creative Galileo Content API

> RESTful API.

## Overview

- uses Node.js > v12
- written using ES6
- uses yarn for package dependency management
- uses [JavaScript Standard Style](http://standardjs.com/)
- uses `sequelize` as ORM for relational database
- uses `mongoose` as ORM for non realtional database
- uses `redis` as ORM for cache
- Event module with sqs backed up
- uses `mocha` for test cases
- uses `eslint` for linting and `prettier` for formatting.
- Filename convention are `underscore`

## Development Environment Setup

Make sure you have `yarn` or `npm`, and at least `node v14.x`

## Setup

1. Clone the repository with `git clone`
2. Install the dependencies with YARN or NPM.
3. Install mysql,redis and mongo.
4. Create an empty database according to your preference.
5. Create .env and populate it with the correct credentials and settings of your preferred database. Take reference from .env-sample.
6. Run database migrations using mocha with test case name `Database Migration`.
7. Run seed data using mocha with test case name `Seed data`.
7. Run the application in development mode with `npm start`.
8. Access `http://localhost:<PORT>` and you're ready to go!

### VSCODE Plugins

1. Mocha Test Explorer for running test cases.

### Swagger url
http://localhost:5002/docs/

### Migration process
step  1- npm run create-migration 'add_option_column_in_question_table'
 
    Generated a file migration file in src/infra/sequelize/migration/add_option_column_in_question_table
     
stpe -2 
 
    module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.addColumn('Users', 'address', {
        type: Sequelize.STRING,
        allowNull: true,  
        });
    },
    
    down: async (queryInterface, Sequelize) => {
        await queryInterface.removeColumn('Users', 'address');
    },
    };
 
step 3 - then run 'npm run migrate-db'


