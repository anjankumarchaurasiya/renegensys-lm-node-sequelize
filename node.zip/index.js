const tracer = require('dd-trace').init();
const { resolve } = require('src/container');
const moment = require('moment');

moment.tz.setDefault('UTC');
moment.tz.link('Asia/Calcutta|Asia/Kolkata');
const app = resolve('app');

const environment = process.env.NODE_ENV || 'local';
// if (environment.indexOf('staging') >= 0 || environment.indexOf('development') >= 0 || environment.indexOf('production') >= 0) {
tracer.init({
  analytics: true,
  runtimeMetrics: true,
  logInjection: true,
});
// }
app.start().catch(error => {
  app.logger.error(error.stack);
  process.exit();
});
