require('@babel/register')

require('./index')
