module.exports = {
  TRACK_USER_URL: 'track/users/',
  TRACK_EVENT_URL: 'track/events/',
};
