const { OK, BAD_REQUEST, UNAUTHORIZED, FORBIDDEN, NOT_FOUND, CONFLICT, NOT_ACCEPTABLE } = require('http-status');

module.exports = {
  RUNTIME_ERROR: {
    code: 400,
    status: BAD_REQUEST,
  },
  ENTITY_NOT_FOUND: {
    code: 'ENTITY_NOT_FOUND',
    status: BAD_REQUEST,
  },
  RESOURCE_NOT_FOUND: {
    code: 404,
    status: NOT_FOUND,
  },
  INVALID_REQUEST: {
    code: 'Invalid_Request',
    status: BAD_REQUEST,
  },
  RESOURCE_CONFLICT: {
    code: 409,
    status: CONFLICT,
  },
  RESOURCE_FORBIDDEN: {
    code: 'access_forbidden',
    status: FORBIDDEN,
  },
  UNAUTHORIZED_REQUEST: {
    code: 'unauthorized',
    status: UNAUTHORIZED,
  },
  INVALID_OTP: {
    code: 'Invalid OTP',
    status: UNAUTHORIZED,
  },
  RESOURCE_FORBIDDEN: {
    code: 'RESOURCE_FORBIDDEN',
    status: FORBIDDEN,
  },
  AUTHENTICATION_FAILED: {
    code: 'AUTHENTICATION_FAILED',
    status: UNAUTHORIZED,
  },
  AUTHORIZATION_FAILED: {
    code: 'AUTHORIZATION_FAILED',
    status: UNAUTHORIZED,
  },
  USER_ALREADY_EXISTS: {
    code: 'USER_ALREADY_EXISTS',
    status: BAD_REQUEST,
  },
  ROLE_DOES_NOT_EXISTS: {
    code: 'ROLE_DOES_NOT_EXISTS',
    status: BAD_REQUEST,
  },
  ENTITY_ALREADY_EXISTS: {
    code: 'ENTITY_ALREADY_EXISTS',
    status: BAD_REQUEST,
  },
  CRM_API_ERROR: {
    code: 'CRM_API_ERROR',
    status: BAD_REQUEST,
  },
  MSG_91_ERROR: {
    code: 'MSG_91_ERROR',
    status: BAD_REQUEST,
  },
  PLUGIN_ERROR: {
    code: 'PLUGIN_ERROR',
    status: BAD_REQUEST,
  },
  INTERAKT_API_ERROR: {
    code: 'INTERAKT_API_ERROR',
    status: BAD_REQUEST,
  },
  VENISO_API_ERROR: {
    code: 'VENISO_API_ERROR',
    status: BAD_REQUEST,
  },
  ENTITY_NOT_ACCEPTABLE: {
    code: 'ENTITY_NOT_ACCEPTABLE',
    status: NOT_ACCEPTABLE,
  },
  PROVIDE_VALID_DATA: {
    code: 'PROVIDE_VALID_DATA',
    status: BAD_REQUEST,
  },
  PROVIDE_VALID_MOBILE_NUMBER: {
    code: 'PROVIDE_VALID_MOBILE_NUMBER',
    status: BAD_REQUEST,
  },
};
