module.exports = {
  GET_TOKEN_URL: 'CG/GetToken',
  ASSIGNMENT_UPDATE_URL: 'PlayLearn/UpdateGameStatus',
  DOMAIN_MASTER_UPDATE_URL: 'CG/SaveDomain',
  PID_CONTENT_SAVE_URL: 'CG/SavePIDContent',
  PLAYLIST_SAVE_URL: 'CG/SaveSyncCall',
  VIDEO_DEEPLINK_URL: 'https://toondemy.sng.link/A80j4/nxtw?_ios_dl=toondemy%3A%2F%2Fgame&_android_dl=toondemy%3A%2F%2Fonboarding&_p=',
  GAME_DEEPLINK_URL: 'https://toondemy.sng.link/A80j4/nxtw?_ios_dl=toondemy%3A%2F%2Fgame&_android_dl=toondemy%3A%2F%2Fgame&_p=',
  CONTENT_TYPES: {
    VIDEO: 1,
    GAME: 2,
  },
  GAME_UPDATE_STATUS_URL: {
    GA: 'https://tdlearning.logthis.in/api/',
    shiksha: 'https://tdacademy.logthis.in/api/',
  },
  remarks: {
    1: 'D',
    2: 'D',
    3: 'D',
    4: 'C',
    5: 'C',
    6: 'B',
    7: 'B',
    8: 'A',
    9: 'A',
    10: 'A',
  },
};
