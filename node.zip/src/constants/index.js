const errorCodes = require('./error_codes');
const eventConstants = require('./event_constants');
const notificationConstants = require('./notification');
const goPhygitalConstants = require('./go_phygital_constants');
const awsConstants = require('./aws_constants');
const redisConstants = require('./redis_constants');
const interaktConstants = require('./interakt_constants');
const attributeConstants = require('./attribute_constants');
const venisoConstants = require('./veniso_constants');
const magicbookConstants = require('./magicbook_constants');
const crmConstants = require('./crm_constants');

const environments = {
  DEVELOPMENT: 'development',
  TEST: 'test',
  PRODUCTION: 'production',
};

const OTP_PROVIDERS = {
  KARIX: 'karix',
  MSG91: 'msg91',
  PLUGIN: 'plugin',
};

const ENTITY_TYPE = {
  CUSTOMER: 'customer',
  GUEST: 'guest',
  USER: 'user',
};

const USER_ROLES = {
  ADMIN: 'ADMIN',
  TEACHER: 'TEACHER',
  STUDENT: 'STUDENT',
  SRM: 'SRM',
};
const HASH_ROUND = 10;

const TOKEN_EXPIRATION = {
  ACCESS: {
    CUSTOMER: '7d',
    GUEST: '7d',
    USER: '7d',
  },
  REFRESH: {
    CUSTOMER: '1y',
    GUEST: '1y',
    USER: '1y',
  },
};

const EMAIL_STRATEGY = {
  NODEMAILER: 'nodemailer',
  SENDGRID: 'sendgrid',
};

const OTP_TYPE = {
  USER_LOGIN: 'User Login',
  RESEND_OTP: 'Resend Otp',
};

const KID_DEFAULT_AGE = {
  DEFAULT_MIN_AGE: 3,
  DEFAULT_MAX_AGE: 17,
};

const KID_DEFAULT_NAME = 'NoName_NoName';

const CONTENT_TYPE = ['THUMBNAIL', 'PDF', 'EXCEL', 'IMAGE', 'VIDEO', 'PROFILEPIC'];
const APP_VARIANT_ABBREVIATION = {
  littleSingham: 'ls',
  toondemy: 'td',
};

const APP_VARIANT_CAPITAL_VERSION = {
  littleSingham: 'LITTLE_SINGHAM',
  toondemy: 'TOONDEMY',
};

const cloneScope = {
  PARENT_ONLY: 'PARENT_ONLY',
  PARENT_WITH_CHILD_COPY: 'PARENT_WITH_CHILD_COPY',
  PARENT_WITH_SAME_CHILD_REFERENCE: 'PARENT_WITH_SAME_CHILD_REFERENCE',
};

const TOKEN_TYPE = {
  REFRESH: 'refresh',
  ACCESS: 'access',
};
const NOTIFICATION_TYPES = {
  SMS: 'SMS',
  EMAIL: 'EMAIL',
  WHATSAPP: 'WHATSAPP',
};

const MEETING_PLATFORM = {
  default: 'zoom',
};

const MEETING_TYPE = {
  type_1: 1, //- An instant meeting.
  type_2: 2, //- A scheduled meeting.
  type_3: 3, //- A recurring meeting with no fixed time.
  type_8: 8, //- A recurring meeting with fixed time.
};

const SESSION_CONTENT_TYPE = { PRE_SESSION: 'Pre Session', POST_SESSION: 'Post Session' };
const SESSION_STATUS_TYPE = {
  COMPLETED: 'COMPLETED',
  SCHEDULED: 'SCHEDULED',
  CANCELLED: 'CANCELLED',
  INPROGRESS: 'INPROGRESS',
};
const SESSION_STATE = {
  INPROGRESS: 'INPROGRESS',
};

const QUESTION_RESULT_TYPE = {
  WRONG: 'WRONG',
  CORRECT: 'CORRECT',
  UNATTEMPTED: 'UNATTEMPTED',
};

const REPORT_TYPE = {
  BEST_PERFPORMANCE: 'BEST_PERFPORMANCE',
  LAST_ATTEMPT: 'LAST_ATTEMPT',
};

const ASSESMENT_STATUS = {
  PENDING: 'PENDING',
  COMPLETED: 'COMPLETED',
};
module.exports = {
  eventConstants,
  ...errorCodes,
  ...environments,
  OTP_PROVIDERS,
  KID_DEFAULT_AGE,
  KID_DEFAULT_NAME,
  ENTITY_TYPE,
  CONTENT_TYPE,
  USER_ROLES,
  HASH_ROUND,
  TOKEN_EXPIRATION,
  notificationConstants,
  goPhygitalConstants,
  awsConstants,
  redisConstants,
  interaktConstants,
  APP_VARIANT_ABBREVIATION,
  APP_VARIANT_CAPITAL_VERSION,
  attributeConstants,
  cloneScope,
  ...venisoConstants,
  magicbookConstants,
  TOKEN_TYPE,
  EMAIL_STRATEGY,
  OTP_TYPE,
  NOTIFICATION_TYPES,
  MEETING_PLATFORM,
  MEETING_TYPE,
  SESSION_CONTENT_TYPE,
  SESSION_STATUS_TYPE,
  SESSION_STATE,
  QUESTION_RESULT_TYPE,
  ...crmConstants,
  REPORT_TYPE,
  ASSESMENT_STATUS,
};
