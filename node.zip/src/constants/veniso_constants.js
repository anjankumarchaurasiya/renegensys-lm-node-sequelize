module.exports = {
  SUBSCRIPTION_API_URL: '3rdparty/',
  CLEAR_SUBSCRIPTION_API_URL: 'req.php',
  ADD_SUBSCRIPTION_ACTION: 9,
  CLEAR_SUBSCRIPTION_ACTION: 7,
  CHECK_SUBSCRIPTION_ACTION: 5,
  VENISO_DEVICE_ATTRIBUTES: {
    os: 'crm',
    ua: 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0',
    type: 'mobile',
  },
  VENISO_SUBSCRIPTION_MODE: '3RDPARTY',
  VENISO_DEFAULT_APPID: '2',
  VENISO_SCHOOL_PLANS: {
    '3': {
      months: 3,
      planid: 'MDAwNC0wMTI5LTAxMzM=',
      order_id: 'SH_3M',
      amt: '3_MONTHS_SCHOOL_PLAN',
      status: 'success',
    },
    '6': {
      months: 6,
      planid: 'MDAwNC0wMTMwLTAxMzQ=',
      order_id: 'SH_6M',
      amt: '6_MONTHS_SCHOOL_PLAN',
      status: 'success',
    },
    '9': {
      months: 9,
      planid: 'MDAwNC0wMTMxLTAxMzU=',
      order_id: 'SH_9M',
      amt: '9_MONTHS_SCHOOL_PLAN',
      status: 'success',
    },
    '12': {
      months: 12,
      planid: 'MDAwNC0wMTMyLTAxMzY=',
      order_id: 'SH_12M',
      amt: '12_MONTHS_SCHOOL_PLAN',
      status: 'success',
    },
  },
};
