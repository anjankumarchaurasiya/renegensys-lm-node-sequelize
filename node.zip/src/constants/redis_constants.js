module.exports = {
  SECTION_CARDS: 'section_cards',
  TTA_ASSIGNMENT_BULK: 'tta_assignment_bulk',
  TTA_KID_BULK: 'tta_kid_bulk',
  TTA_PARENT_BULK: 'tta_parent_bulk',
  JOB_KEY_FOR_ENTITY: {
    assignments: 'tta_assignment_bulk',
    kids: 'tta_kid_bulk',
    parents: 'tta_parent_bulk',
  },
};
