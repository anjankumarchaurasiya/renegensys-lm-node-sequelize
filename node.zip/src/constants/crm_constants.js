module.exports = {
  /** Batch */
  BATCH_CREATED_SUCCESSFULLY: 'Batch created successfully',
  BATCH_DEACTIVATED_SUCCESSFULLY: 'Batch deactivated successfully',
  BATCH_UPDATED_SUCCESSFULLY: 'Batch updated successfully',
  BATCH_MAPPED_WITH_USER_SUCCESSFULLY: 'Batch mapped with user successfully',
  BATCH_MAPPED_WITH_QUIZ_SUCCESSFULLY: 'Batch mapped with quiz successfully',
  BATCH_WITH_USER_MAPPING_UPDATED_SUCCESSFULLY: 'Batch with user mapping updated successfully',
  BATCH_WITH_QUIZ_ALREADY_EXIST_SAME_CATEGORY: 'Can not Add Multiple Batch with Quiz for same category',
  BATCH_NOT_FOUND: 'Batch not found',
  /** Common */
  SEND_MESSAGE_TO_QUEUE_SUCCESS: 'Successfully message send to Queue',
  FILE_UPLOAD_SUCCESS: 'File uploaded successfully',
  FILE_DOWNLOAD_SUCCESS: 'File downloaded successfully',
  LOG_ROTATOR_SUCCESS: 'Log rotation completed successfully',
  ENCRYPT_DECRYPT_SUCCESS: 'Encryption and decryption completed successfully',

  /** Config */
  CONFIG_CREATED_SUCCESSFULLY: 'Config created successfully',
  CONFIG_UPDATED_SUCCESSFULLY: 'Config updated successfully',
  CONFIG_DEACTIVATED_SUCCESSFULLY: 'Config deactivated successfully',

  /** Content */
  CONTENT_CREATED_SUCCESSFULLY: 'Content created successfully',
  CONTENT_UPDATED_SUCCESSFULLY: 'Content updated successfully',

  /** Course */
  COURSE_CREATED_SUCCESSFULLY: 'Course created successfully',
  COURSE_UPDATED_SUCCESSFULLY: 'Course updated successfully',
  COURSE_MODULE_MAPPING_SUCCESSFULLY: 'Course with module mapping successfully',
  COURSE_MODULE_MAPPING_UPDATED_SUCCESSFULLY: 'Course with module mapping updated successfully',
  COURSE_DEACTIVATED_SUCCESSFULLY: 'Course deactivated successfully',
  COURSE_FAQ_CREATED_SUCCESSFULLY: 'Course FAQ created successfully',
  COURSE_FAQ_UPDATED_SUCCESSFULLY: 'Course FAQ updated successfully',
  COURSE_FAQ_DELETED_SUCCESSFULLY: 'Course FAQ deleted successfully',
  COURSE_STATUS_CHANGED_SUCCESSFULLY: 'Course status changed successfully',

  /** Module */
  MODULE_CREATED_SUCCESSFULLY: 'Module created successfully',
  MODULE_UPDATED_SUCCESSFULLY: 'Module updated successfully',
  MODULE_DELETED_SUCCESSFULLY: 'Module deleted successfully',
  MODULE_TOPIC_MAPPING_CREATED_SUCCESSFULLY: 'Module with topic mapping created successfully',
  MODULE_TOPIC_MAPPING_UPDATED_SUCCESSFULLY: 'Module with topic mapping updated successfully',
  MODULE_ACTIVATED_SUCCESSFULLY: 'Module activated successfully',

  /** Topic */
  TOPIC_CREATED_SUCCESSFULLY: 'Topic created successfully',
  TOPIC_UPDATED_SUCCESSFULLY: 'Topic updated successfully',
  TOPIC_DELETED_SUCCESSFULLY: 'Topic deleted successfully',
  TOPIC_ACTIVATED_SUCCESSFULLY: 'Topic activated successfully',

  /** Cron job */
  CRON_JOB_CREATED_SUCCESSFULLY: 'Cronjob created successfully',
  CRON_JOB_UPDATED_SUCCESSFULLY: 'CronFrameworkConfig updated successfully',
  CRON_JOB_DEACTIVATED_SUCCESSFULLY: 'CronFrameworkConfig deactivated successfully',
  CRON_JOB_INITIATED_SUCCESSFULLY: 'Cron job Initiated successfully',

  /** Discussion Forum */
  DISCUSSION_THREAD_CREATED_SUCCESSFULLY: 'Discussion Forum Thread created successfully',

  /** Event */
  EVENT_CREATED_SUCCESSFULLY: 'Event created successfully',
  EVENT_UPDATED_SUCCESSFULLY: 'Event updated successfully',
  EVENT_MESSAGE_SENT_SUCCESSFULLY: 'Event message sent successfully',
  EVENT_DEACTIVATED_SUCCESSFULLY: 'Event deactivated successfully',

  /** Country */
  COUNTRY_CREATED_SUCCESSFULLY: 'Country created successfully',
  COUNTRY_UPDATED_SUCCESSFULLY: 'Country updated successfully',
  COUNTRY_DEACTIVATED_SUCCESSFULLY: 'Country deactivated successfully',

  /** Language */
  LANGUAGE_CREATED_SUCCESSFULLY: 'Language created successfully',
  LANGUAGE_UPDATED_SUCCESSFULLY: 'Language updated successfully',
  LANGUAGE_DEACTIVATED_SUCCESSFULLY: 'Language deactivated successfully',

  /** Learning session */
  LEARNING_SESSION_CREATED_SUCCESSFULLY: 'Learning session created successfully',
  LEARNING_SESSION_DELETED_SUCCESSFULLY: 'Learning session deleted successfully',
  LEARNING_SESSION_UPDATED_SUCCESSFULLY: 'Learning session updated successfully',
  LEARNING_SESSION_QUIZ_CREATED_SUCCESSFULLY: 'Learning session with quiz mapping created successfully',
  LEARNING_SESSION_QUIZ_DELETED_SUCCESSFULLY: 'Learning session quiz deleted successfully',
  LEARNING_SESSION_QUIZ_UPDATED_SUCCESSFULLY: 'Learning session quiz updated successfully',
  LEARNING_SESSION_SPAM_CREATED_SUCCESSFULLY: 'Learning session spam created successfully',
  LEARNING_SESSION_ATTENDANCE_CREATED_SUCCESSFULLY: 'Learning session attendance created successfully',
  LEARNING_SESSION_ATTENDANCE_UPDATED_SUCCESSFULLY: 'Learning session attendance updated successfully',
  LEARNING_SESSION_PROGRESS_CREATED_SUCCESSFULLY: 'Learning session progress created successfully',
  LEARNING_SESSION_PROGRESS_UPDATED_SUCCESSFULLY: 'Learning session progress updated successfully',
  LEARNING_SESSION_FEEDBACK_CREATED_SUCCESSFULLY: 'Learning session feedback created successfully',
  LEARNING_SESSION_ACTIVATED_SUCCESSFULLY: 'Learning session activated successfully',
  LEARNING_SESSION_SPAM_UPDATED_SUCCESSFULLY: 'Learning session spam updated successfully',

  /** Meeting */
  MEETING_CREATED_SUCCESSFULLY: 'Meeting created successfully',

  /** Category */
  CATEGORY_CREATED_SUCCESSFULLY: 'Category created successfully',
  CATEGORY_UPDATED_SUCCESSFULLY: 'Category updated successfully',
  CATEGORY_DELETED_SUCCESSFULLY: 'Category deleted successfully',
  CATEGORY_NOT_EXIST: 'Category did not exist',

  /** User */
  USER_NOTIFICATION_CREATED_SUCCESSFULLY: 'User notification created successfully',
  USER_NOTIFICATION_UPDATED_SUCCESSFULLY: 'User notification updated successfully',

  /** Question */
  QUESTION_CREATED_SUCCESSFULLY: 'Question created successfully',

  /** Question option */
  QUESTION_OPTION_CREATED_SUCCESSFULLY: 'Question option created successfully',

  /** Retest request */
  RETEST_REQUEST_CREATED_SUCCESSFULLY: 'Retest request created successfully',

  /** Quiz */
  QUIZ_CREATED_SUCCESSFULLY: 'Quiz created successfully',
  QUIZ_UPDATED_SUCCESSFULLY: 'Quiz updated successfully',
  QUIZ_PROGRESS_CREATED_SUCCESSFULLY: 'Quiz progress created successfully',
  CAPSTONE_CREATED_SUCCESSFULLY: 'Capstone created successfully',
  USER_RESPONSE_CREATED_SUCCESSFULLY: 'User response created successfully',
  USER_QUIZ_DETAILS_CREATED_SUCCESSFULLY: 'User quiz created successfully',
  QUIZ_TITLE_EXISTS_ERROR: 'Quiz already exists with Title',
  CAPSTONE_TITLE_EXISTS_ERROR: 'Capstone already exists with Title',
  OPTION_REQUIRED_ERROR: 'Option is required',
  DURATION_REQUIRED_ERROR: 'Duration is required',
  CAPSTONE_SUBMITED_SUCCESSFULLY: 'Capstone project successfully submited',
  ERROR_CAPSTONE_NOT_CHECKED: 'Your previous capstone project has not been checked yet. Please wait for review before submitting a new one.',
  ERROR_CAPSTONE_SUBMIT_FAILED: 'Error submitting capstone project. Please try again later.',
  /** User quiz progress */
  USER_QUIZ_PROGRESS_CREATED_SUCCESSFULLY: 'User quiz progress created successfully',

  /** User response */
  USER_RESPONSE_CREATED_SUCCESSFULLY: 'User response created successfully',

  /** Role*/
  ROLE_CREATED_SUCCESSFULLY: 'Role created successfully',
  ROLE_UPDATED_SUCCESSFULLY: 'Role updated successfully',
  ROLE_DEACTIVATED_SUCCESSFULLY: 'Role deactivated successfully',
  ROLE_ADDED_WITH_ACTION_SUCCESSFULLY: 'Role added with action successfully',
  RESOURCES_ASSIGNED_SUCCESSFULLY: 'Resources assigned successfully',

  /** Resource action*/
  RESOURCE_ACTION_CREATED_SUCCESSFULLY: 'Resource action created successfully',
  RESOURCE_ACTION_UPDATED_SUCCESSFULLY: 'Resource action updated successfully',
  RESOURCE_ACTION_DEACTIVATED_SUCCESSFULLY: 'Resource action deactivated successfully',

  /** Resource*/
  RESOURCE_CREATED_SUCCESSFULLY: 'Resource created successfully',
  RESOURCE_UPDATED_SUCCESSFULLY: 'Resource updated successfully',
  RESOURCE_DEACTIVATED_SUCCESSFULLY: 'Resource deactivated successfully',

  /** User*/
  USER_CREATED_SUCCESSFULLY: 'User created successfully',
  OTP_SENT_SUCCESSFULLY: 'OTP sent successfully for login',
  USER_UPDATED_SUCCESSFULLY: 'User updated successfully',
  USER_DEACTIVATED_SUCCESSFULLY: 'User deactivated successfully',
  OTP_VERIFIED_SUCCESSFULLY: 'OTP verified successfully',
  LOGGED_OUT_SUCCESSFULLY: 'User logged out successfully',
  OTP_RESENT_SUCCESSFULLY: 'OTP resent successfully',

  /** Feedback */
  FEEDBACK_CREATED_SUCCESSFULLY: 'Feedback created successfully',
  FEEDBACK_TITLE_EXISTS_ERROR: 'Feedback already exists with Title',
  FEEDBACK_NOT_EXISTS_ERROR: 'Feedback does not exist',
  USER_FEEDBACK_RESPONSE_CREATED_SUCCESSFULLY: 'Feedback successfully submitted',
  FEEDBACK_LINKED_WITH_SESSIONS_SUCCESSFULLY: 'Feedback linked  with sessions successfully',
  FEEDBACK_UNLINKED_WITH_SESSIONS_SUCCESSFULLY: 'Feedback unlinked with sessions successfully',

  /** Learning session */
  LEARNING_SESSION_START_BEFORE_TIME: 'Learning sessions can not begin earlier than 5 minutes before the scheduled start time',
  LEARNING_SESSION_START_BEFORE_DATE: 'This Session Is Not Scheduled For Today',
  LEARNING_SESSION_START: 'Learning session start successfully',
  LEARNING_SESSION_JOINED_SUCCESSFULLY: "Welcome to the session! We're glad to have you join us",
  LEARNING_SESSION_LEFT_SUCCESSFULLY: 'You have left the Learning Session Succefully',
  LEARNING_SESSION_NOT_STARTED: 'Thank you for your interest in joining the session. However, the session has not started yet.',
  LEARNING_SESSION_COMPLETED: 'Learning session end successfully',
  LEARNING_SESSION_NOT_FOUND: 'Learning session not found',
  LEARNING_SESSION_NOT_JOINED: 'You attempted to leave the Learning Session before joining it.',
  ALREADY_JOINED_SESSION: 'You have already joined the Learning Session.',

  /** Spam report */
  SPAM_REPORT_CREATED_SUCCSSFULLY: 'Spam report submitted successfully',

  /** site content */
  SITE_CONTENT_SUBMITED_SUCCESSFULLY: 'Site content created successfully',
  SITE_CONTENT_ALREADY_EXIST_WITH_SAME_NAME: 'Content already exist with same name',
  SITE_CONTENT_DEACTIVATED_SUCCESSFULLY: 'Site content deactivated successfully',
  SITE_CONTENT_NOT_FOUND: 'Site content not found',
  SITE_CONTENT_UPDATED_SUCCESSFULLY: 'Site content updated successfully',
};
