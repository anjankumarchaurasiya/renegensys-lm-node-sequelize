module.exports = {
  wordsToRemove: ['the', 'and', 'in', 'of', 'example', 'text', 'is', 'www', 'toondemy', 'com', 'this', 'to', 'Roll No.:', 'Name:', 'No.:'],
};
