const passport = require('passport');
const { ExtractJwt, Strategy } = require('passport-jwt');

module.exports = ({ config, CustomError, constants: { UNAUTHORIZED_REQUEST, ENTITY_TYPE }, userSessionService, userService }) => {
  const params = {
    secretOrKey: config.authAccessSecret,
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  };

  const deactiveSession = async ({ entityType, jwtToken }) => {
    let sessionDeactivated;
    switch (entityType) {
      case ENTITY_TYPE.USER:
        const userSession = await userSessionService.updateUserSession({ recordStatus: 0 }, { jwtToken });
        if (userSession) {
          sessionDeactivated = true;
        } else {
          sessionDeactivated = false;
        }
        break;
      default:
        sessionDeactivated = false;
    }

    return sessionDeactivated;
  };

  const checkSession = async ({ entityType, jwtToken }) => {
    let session;
    let sessionDeactivated;

    session = await userSessionService.getUserSession({ accessToken: jwtToken });

    if (session) {
      sessionDeactivated = false;
    } else {
      sessionDeactivated = true;
    }
    return sessionDeactivated;
  };

  const JWTStrategy = new Strategy(params, async (payload, done) => {
    const { entityType, userId } = payload;
    try {
      let res;

      switch (entityType) {
        case ENTITY_TYPE.USER:
          // Call user service
          res = await userService.getUserByIdForAuthenticate(userId);
          break;
      }

      if (res) {
        done(null, { ...res, entityType });
      } else {
        done(new Error('Token expired'), null);
      }
    } catch (error) {
      // Handle errors thrown by userService.getUserById(userId)
      if (error instanceof CustomError) {
        done(error, null);
      } else {
        done(new Error('Internal Server Error'), null);
      }
    }
  });

  passport.use(JWTStrategy);

  passport.serializeUser(function(user, done) {
    done(null, user);
  });

  passport.deserializeUser(function(user, done) {
    done(null, user);
  });
  return {
    initialize: () => {
      return passport.initialize();
    },
    authenticate: () => {
      return (req, res, next) =>
        passport.authenticate('jwt', null, async (error, result, info) => {
          const jwtToken = req.headers['authorization'];
          if (!jwtToken) {
            return next(new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'JWT token is required in request'));
          }
          req.jwtToken = jwtToken.split(' ')[1];
          if (error || !result) {
            if (error?.description?.name === 'TokenExpiredError') {
              const sessionDeactivated = await deactiveSession({ jwtToken: req.jwtToken });
              if (!sessionDeactivated) {
                return next(new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Something wrong with current session'));
              }
            }
            return next(new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, info));
          }
          const sessionDeactivated = await checkSession({ jwtToken: req.jwtToken });
          if (sessionDeactivated) {
            return next(new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Current session is not active'));
          }
          req.user = result;
          next();
        })(req, res, next);
    },
  };
};
