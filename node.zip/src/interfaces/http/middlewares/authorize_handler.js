/* eslint-disable consistent-return */
const { UNAUTHORIZED } = require('http-status');

module.exports = ({
  roleManagementService,
  constants: { ENTITY_TYPE, RESOURCE_FORBIDDEN, AUTHORIZATION_FAILED },
  response: { Fail },
  generalUtilService,
  logger,
}) => async (req, res, next) => {
  try {
    const roleIds = req.user.user_roles.map(role => role.roleId);
    const resourcePermissionsPromises = roleIds.map(roleId => roleManagementService.getAllResourcesOfGivenRole(roleId));
    const resourcePermissionsList = await Promise.all(resourcePermissionsPromises);

    // Flatten and merge all permissions into a single array
    const allResourcePermissions = resourcePermissionsList.reduce((accumulator, currentMap) => {
      return accumulator.concat(Array.from(currentMap.values()));
    }, []);

    let hasAccess = false;

    // Manually iterate over permissions to check access
    for (const permission of allResourcePermissions) {
      if (permission.actionName === req.resource.actionName && permission.resource === req.resource.module) {
        console.log(permission);
        hasAccess = true;
        break;
      }
    }

    // If no access to the requested resource and action, return forbidden
    if (!hasAccess) {
      return res.status(RESOURCE_FORBIDDEN.status).send({
        code: RESOURCE_FORBIDDEN.code,
        status: RESOURCE_FORBIDDEN.status,
        data: 'You are not allowed to access the resource',
      });
    }

    // Proceed with permission rules evaluation if necessary
    if (req.resource.permissionRules) {
      const evalExpressionContextData = {};
      const contextDataList = req.resource.permissionRulesContextData;

      if (contextDataList) {
        for (const contextData of contextDataList) {
          for (const [ruleKey, expression] of Object.entries(contextData)) {
            evalExpressionContextData[ruleKey] = generalUtilService.evalExprAndReturnVal(expression, {
              user: req.user,
              body: req.body,
              params: req.params,
              query: req.query,
            });
          }
        }
      } else {
        logger.error(`Please define rule context for action Name :: ${req.resource.actionName}`);
      }

      const isNotAllowed = utils.hasPermission(req.resource.permissionRules, evalExpressionContextData);
      if (isNotAllowed) {
        return res.status(UNAUTHORIZED).send({
          code: AUTHORIZATION_FAILED.code,
          status: AUTHORIZATION_FAILED.status,
          data: 'You are not eligible to access the resource',
        });
      }
    }

    next();
  } catch (error) {
    logger.error('Error occurred while checking permissions:', error);
    return res.status(500).send({
      code: 500,
      status: 'Internal Server Error',
      data: 'An error occurred while checking permissions',
    });
  }
};
