const { create, get, update, deleteBulk, getAll } = require('../validators/schemas/topic');
const MODULE = 'TOPIC';

module.exports = {
  patch: {
    '/V1/topic/:topicId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_TOPIC',
      description: 'Update Topic',
    },
    '/V1/topic/bulk/activate': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ACTIVATE_BULK_TOPIC',
      description: 'Activate Bulk Topic',
    },
  },
  post: {
    '/V1/topic': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_TOPIC',
      description: 'Create Topic',
    },
  },
  get: {
    '/V1/topic/:topicId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_TOPIC',
      description: 'Get Topic',
    },
    '/V1/topic': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_TOPIC',
      description: 'Get All Topic',
    },
  },
  delete: {
    '/V1/topic/:topicId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_TOPIC',
      description: 'Delete TOPIC',
    },
    '/V1/topic/bulk': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_TOPIC_BULK',
      description: 'Deactivate Topic Bulk',
    },
  },
};
