const { create, update, get } = require('../validators/schemas/resource');
const MODULE = 'RESOURCE';

module.exports = {
  get: {
    '/V1/resource': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_RESOURCE',
      description: 'Get resource',
    },
  },
  post: {
    '/V1/resource': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ADD_RESOURCE',
      description: 'Add resource',
    },
  },
  patch: {
    '/V1/resource/:resourceId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_RESOURCE',
      description: 'Update resource',
    },
  },
  delete: {
    '/V1/resource/:resourceId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_RESOURCE',
      description: 'Deactivate resource',
    },
  },
};
