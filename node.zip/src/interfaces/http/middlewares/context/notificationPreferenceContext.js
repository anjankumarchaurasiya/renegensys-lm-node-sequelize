const { createOrUpdate, get } = require('../validators/schemas/notification_preference');

const MODULE = 'USER_NOTIFICATION_PREFERENCE';

module.exports = {
  get: {
    '/V1/user-notification-preference/:userId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_NOTIFICATION_PREFERENCE',
      description: 'Get Notification Preference',
    },
  },
  post: {
    '/V1/user-notification-preference': {
      schema: createOrUpdate,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_NOTIFICATION_PREFERENCE',
      description: 'Create Notification Preference',
    },
  },
  patch: {
    '/V1/user-notification-preference': {
      schema: createOrUpdate,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_NOTIFICATION_PREFERENCE',
      description: 'Update Notification Preference',
    },
  },
};
