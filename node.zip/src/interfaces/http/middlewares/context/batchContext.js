const {
  create,
  deleteBulk,
  update,
  getAll,
  createBatcheUser,
  getAllBatchUser,
  batchQuiz,
  updateBatchUsers,
  getExamResult,
  getExamResultOfStudent,
} = require('../validators/schemas/batch');
const MODULE = 'BATCH';

module.exports = {
  post: {
    '/V1/batch': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_BATCH',
      description: 'Create Batch',
    },
    '/V1/batch/:batchId/user': {
      schema: createBatcheUser,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_BATCH_USER',
      description: 'Create Batch User',
    },
    '/V1/batch/:batchId/quiz/:quizId': {
      schema: batchQuiz,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_BATCH_QUIZ',
      description: 'Create Batch Quiz',
    },
  },
  delete: {
    '/V1/batch/:batchId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_BATCH',
      description: 'Delete Batch',
    },
    '/V1/batch/bulk': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_BULK_BATCH',
      description: 'Delete Bulk Batch',
    },
    '/V1/batch/:batchId/quiz/:quizId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_BATCH_QUIZ',
      description: 'Deactivate Batch Quiz',
    },
  },
  get: {
    '/V1/batch/:batchId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_BATCH',
      description: 'Get batch',
    },
    '/V1/batch/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_BATCH_LIST',
      description: 'Get Batch List',
    },
    '/V1/batch/:batchId/user': {
      schema: getAllBatchUser,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_BATCH_USER_LIST',
      description: 'Get Batch User List',
    },
    '/V1/batch/:batchId/exam-result': {
      schema: getExamResult,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_EXAM_RESULT',
      description: 'Get All Exam Result',
    },
    '/V1/batch/student-exam-result/:quizId/:userId': {
      schema: getExamResultOfStudent,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_EXAM_RESULT_OF_STUDENT',
      description: 'Get All Exam Result Of Student',
    },
  },
  patch: {
    '/V1/batch/:batchId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_BATCH',
      description: 'Update Batch',
    },
    '/V1/batch/:batchId/user': {
      schema: updateBatchUsers,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_BATCH_USER',
      description: 'Update Batch User',
    },
  },
};
