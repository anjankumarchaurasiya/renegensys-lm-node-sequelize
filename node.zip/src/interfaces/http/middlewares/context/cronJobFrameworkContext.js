const { create, update, getAll } = require('../validators/schemas/cron_job_framework');
const MODULE = 'CRON_JOB_FRAMEWORK';

module.exports = {
  get: {
    '/V1/cron-job-framework/:cronFrameworkConfigId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'Get_Cron_Framework_config',
      description: 'Get Specific Cron Framework config',
    },
    '/V1/cron-job-framework': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_Cron_Framework_configS',
      description: 'Get All Cron Framework config',
    },
    '/V1/cron-job-framework/test/cron-job': {
      // schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_Cron_Framework_configS',
      description: 'Get All Cron Framework config',
    },
  },
  post: {
    '/V1/cron-job-framework': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_Cron_Framework_config',
      description: 'Create New Cron Framework config',
    },
  },
  patch: {
    '/V1/cron-job-framework/:cronFrameworkConfigId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_Cron_Framework_config',
      description: 'Update Specific Cron Framework config',
    },
  },
  put: {},
  delete: {
    '/V1/cron-job-framework/:cronFrameworkConfigId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_Cron_Framework_config',
      description: 'Deactivate Specific Cron Framework config',
    },
  },
};
