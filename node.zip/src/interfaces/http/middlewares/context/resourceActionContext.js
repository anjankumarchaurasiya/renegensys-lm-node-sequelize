const { create, update, get } = require('../validators/schemas/resource_action');
const MODULE = 'RESOURCE_ACTION';

module.exports = {
  get: {
    '/V1/resource-action': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_RESOURCE_ACTION',
      description: 'Get resource action',
    },
  },
  post: {
    '/V1/resource-action': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ADD_RESOURCE_ACTION',
      description: 'Add resource action',
    },
  },
  patch: {
    '/V1/resource-action/:resourceActionId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_RESOURCE_ACTION',
      description: 'Update resource action',
    },
  },
  delete: {
    '/V1/resource-action/:resourceActionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_RESOURCE_ACTION',
      description: 'Deactivate resource action',
    },
  },
};
