const { create, update, getAll } = require('../validators/schemas/domain');
const MODULE = 'DOMAIN';

module.exports = {
  get: {
    '/V1/domain/:domainId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'Get_DOMAIN',
      description: 'Get Specific Domain',
    },
    '/V1/domain': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_DOMAINS',
      description: 'Get All Domains',
    },
  },
  post: {
    '/V1/domain': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_DOMAIN',
      description: 'Create New Domain',
    },
  },
  patch: {
    '/V1/domain/:domainId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_DOMAIN',
      description: 'Update Specific Domain',
    },
  },
  delete: {
    '/V1/domain/:domainId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_DOMAIN',
      description: 'Deactivate Specific Domain',
    },
  },
};
