const { create, login, verifyOtp, get, update } = require('../validators/schemas/user');
const MODULE = 'USER';

module.exports = {
  get: {
    '/V1/user/logout': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'LOGOUT',
      description: 'Logout user',
    },

    '/V1/user/filter/list': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_USER_LIST',
      description: 'Get User List',
    },

    '/V1/user/:userId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_USER',
      description: 'Get User',
    },
  },
  post: {
    '/V1/user/resend-otp': {
      module: MODULE,
      schema: login,
      isApplicationHeadersRequired: false,
      actionName: 'USER_RESEND_OTP',
      description: 'User resend otp',
    },
    '/V1/user': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_USER',
      //permissionRules: ["loggedInUserId!= '884bac56-11c3-406f-b703-ab6b3ad7f1d3'"],
      //permissionRulesContextData: [{ loggedInUserId: 'user.id' }],
      description: 'Create User',
    },
    '/V1/user/login': {
      schema: login,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'USER_LOGIN',
      description: 'User login',
    },
    '/V1/user/verify-otp': {
      module: MODULE,
      schema: verifyOtp,
      isApplicationHeadersRequired: false,
      actionName: 'USER_VERIFY_OTP',
      description: 'User verify otp',
    },
  },
  patch: {
    '/V1/user/:userId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_USER',
      description: 'Update User',
    },
  },
  delete: {
    '/V1/user/:userId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_USER',
      description: 'Deactivate User',
    },
  },
};
