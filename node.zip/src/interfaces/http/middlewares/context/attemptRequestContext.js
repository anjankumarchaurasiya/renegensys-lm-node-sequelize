const { create, retest, retestAttemptAccept } = require('../validators/schemas/attempt_request');
const MODULE = 'QUIZ';

module.exports = {
  post: {
    '/V1/quiz/attempt-request/retest': {
      schema: retest,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'RETEST_REQUEST',
      description: 'Retest Request',
    },
  },
  patch: {
    '/V1/quiz/attempt-request/accept-retest-attempt/:attemptRequestId': {
      schema: retestAttemptAccept,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'RETEST_REQUEST_ACCEPT',
      description: 'Retest Request Accept',
    },
  },
};
