const { getCapstone, getUserCapstoneResult } = require('../validators/schemas/capstone');
const MODULE = 'CAPSTONE';

module.exports = {
  get: {
    '/V1/quiz/capstone/capstone-project/:batchId/:quizId': {
      schema: getCapstone,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_CAPSTONE_BY_BATCH',
      description: 'Get Capstone Project By BatchId',
    },
    '/V1/quiz/capstone/user-capstone-details/:quizId': {
      schema: getUserCapstoneResult,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_USER_CAPSTONE_DETAILS',
      description: 'Get User Capstone Details',
    },
    '/V1/quiz/capstone/draft-capstone/:quizId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_DRAFT_CAPSTONE_OF_STUDENT',
      description: 'Get Draft capstone of student',
    },
  },
};
