const { fileUpload, fileDownload, planActivation, planDeactivation } = require('../validators/schemas/common');

const MODULE = 'COMMON';

module.exports = {
  post: {
    '/V1/common/send-message': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SEND_MESSAGE_IN_AWS_QUEUE',
      description: 'Send message in aws queue',
    },
    '/V1/common/s3/file-upload': {
      schema: fileUpload,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'S3_FILE_UPLOAD',
      description: 'S3 file upload',
    },
  },
  get: {
    '/V1/common/file-download': {
      schema: fileDownload,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'FILE_DOWNLOAD',
      description: 'file download',
    },
    '/V1/common/log-rotator': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ROTATE_LOG',
      description: 'Rotate log',
    },
    '/V1/common/encrypt-decrypt': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ENCRYPT_DECRYPT',
      description: 'Encypt Decrypt',
    },
  },
};
