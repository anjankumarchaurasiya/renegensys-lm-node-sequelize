const MODULE = 'APP_VARIANT';

module.exports = {
  get: {
    '/V1/app-variant/:appVariantId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_APP_VARIANT',
      description: 'Get appVariant',
    },
    '/V1/app-variant': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LIST_OF_APP_VARIANT',
      description: 'Get list of appVariant',
    },
  },
  post: {
    '/V1/app-variant': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_APP_VARIANT',
      description: 'Create appVariant',
    },
  },
  patch: {
    '/V1/app-variant/:appVariantId': {
      // schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_APP_VARIANT',
      description: 'Update appVariant',
    },
  },
  delete: {
    '/V1/app-variant/:appVariantId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_APP_VARIANT',
      description: 'Deactivate appVariant',
    },
  },
};
