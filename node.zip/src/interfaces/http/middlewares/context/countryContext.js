const MODULE = 'COUNTRY';

module.exports = {
  get: {
    '/V1/country/:countryId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_COUNTRY',
      description: 'Get country',
    },
    '/V1/country': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LIST_OF_COUNTRY',
      description: 'Get list of country',
    },
  },
  post: {
    '/V1/country': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_COUNTRY',
      description: 'Create country',
    },
  },
  patch: {
    '/V1/country/:countryId': {
      // schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_COUNTRY',
      description: 'Update country',
    },
  },
  delete: {
    '/V1/country/:countryId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_COUNTRY',
      description: 'Deactivate country',
    },
  },
};
