const { create, update, get, getAll } = require('../validators/schemas/category');
const MODULE = 'CATEGORY';

module.exports = {
  post: {
    '/V1/category': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_CATEGORY',
      description: 'Create Category',
    },
  },
  patch: {
    '/V1/category/:categoryId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_CATEGORY',
      description: 'Update Category',
    },
  },
  get: {
    '/V1/category/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_CATEGORY',
      description: 'Get Category',
    },
    '/V1/category/:categoryId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SPECIFIC_CATEGORY',
      description: 'Get Soecific Category',
    },
  },
  delete: {
    '/V1/category/:categoryId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_SPECIFIC_CATEGORY',
      description: 'Deactivate Soecific Category',
    },
  },
};
