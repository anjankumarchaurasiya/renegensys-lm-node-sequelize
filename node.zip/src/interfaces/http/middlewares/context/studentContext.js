const { capstoneSubmit, get } = require('../validators/schemas/stduent');

const MODULE = 'STUDENT';

module.exports = {
  get: {
    '/V1/student/course': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_COURSE_OF_STUDENT',
      description: 'Get Courses of stduent Module',
    },
    '/V1/student/course/:courseId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SPECIFIC_COURSE_OF_STUDENT',
      description: 'Get Specific Course of stduent',
    },
    '/V1/student/session/:batchId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SESSION_LIST_OF_STUDENT',
      description: 'Get Session list of student',
    },
    '/V1/student/capstone-report/:userQuizProgressId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_CAPSTONE_REPORT_OF_STUDENT',
      description: 'Get Capstone Report of student',
    },
  },
  post: {
    '/V1/student/capstone': {
      schema: capstoneSubmit,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SUBMIT_CAPSTONE_PROJECT_BY_STUDENT',
      description: 'Submit capstone by student',
    },
    '/V1/student/session/join/:sessionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'LEARNING_SESSION_JOIN_BY_STUDENT',
      description: 'Learning Session Join By Student',
    },
    '/V1/student/session/left/:sessionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'LEARNING_SESSION_LEFT_BY_STUDENT',
      description: 'Learning Session Left By Student',
    },
  },
};
