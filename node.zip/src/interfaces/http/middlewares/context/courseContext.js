const {
  create,
  getAll,
  update,
  deleteBulk,
  get,
  createCourseModule,
  updateCourseModule,
  createFaq,
  updateFaq,
} = require('../validators/schemas/course');
const MODULE = 'COURSE';

module.exports = {
  get: {
    '/V1/course/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_COURSE',
      description: 'Get Course',
    },
    '/V1/course/:courseId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SPECIFIC_COURSE',
      description: 'Get Soecific Course',
    },
    '/V1/course/:courseId/faq': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_FREQUENTLY_ASKED_QUESTION',
      description: 'Get All Frequently Asked Question',
    },
    '/V1/course/:courseId/faq/filter/list': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_FREQUENTLY_ASKED_QUESTION_LIST',
      description: 'Get All Frequently Asked Question List',
    },
  },
  post: {
    '/V1/course': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_COURSE',
      description: 'Create Course',
    },
    '/V1/course/:courseId/module': {
      schema: createCourseModule,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_COURSE_MODULE',
      description: 'Create Course Module',
    },
    '/V1/course/:courseId/faq': {
      schema: createFaq,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_FREQUENTLY_ASKED_QUESTION',
      description: 'Create Frequently Asked Question',
    },
  },
  patch: {
    '/V1/course/:courseId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_COURSE',
      description: 'Update Course',
    },
    '/V1/course/:courseId/module': {
      schema: updateCourseModule,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_COURSE_MODULE',
      description: 'Update Course Module',
    },
    '/V1/course/:courseId/faq/:faqId': {
      schema: updateFaq,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_FREQUENTLY_ASKED_QUESTION',
      description: 'Update Frequently Asked Question',
    },
    '/V1/course/bulk/activate': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ACTIVATE_BULK_COURSE',
      description: 'Activate Bulk Course',
    },
  },
  delete: {
    '/V1/course/:courseId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_COURSE',
      description: 'Delete Course',
    },
    '/V1/course/bulk': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_BULK_COURSE',
      description: 'Delete Bulk Course',
    },
    '/V1/course/:courseId/faq/:faqId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_FREQUENTLY_ASKED_QUESTION',
      description: 'Delete Frequently Asked Question',
    },
  },
};
