const { create, update, getList } = require('../validators/schemas/subdomain');
const MODULE = 'SUBDOMAIN';

module.exports = {
  get: {
    '/V1/subdomain/:subdomainId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'Get_SUBDOMAIN',
      description: 'Get Specific Subdomain',
    },
    '/V1/subdomain/list/filter': {
      module: MODULE,
      // schema: getList,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_SUBDOMAINS',
      description: 'Get All Subdomains',
    },
  },
  post: {
    '/V1/subdomain': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_SUBDOMAIN',
      description: 'Create New Subdomain',
    },
  },
  patch: {
    '/V1/subdomain/:subdomainId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_SUBDOMAIN',
      description: 'Update Specific Subdomain',
    },
  },
  delete: {
    '/V1/subdomain/:subdomainId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_SUBDOMAIN',
      description: 'Deactivate Specific Subdomain',
    },
  },
};
