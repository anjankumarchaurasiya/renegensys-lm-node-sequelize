const { getAll, create, get, submitFeedback, updateSessionFeedback } = require('../validators/schemas/feedback');
const MODULE = 'FEEDBACK';
module.exports = {
  post: {
    '/V1/feedback': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_FEEDBACK',
      description: 'Create Feedback',
    },
    '/V1/feedback/user-response': {
      schema: submitFeedback,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SUBMIT_FEEDBACK_RESPONSE',
      description: 'Submit Feedback Response',
    },
  },

  patch: {
    '/V1/feedback/:feedbackId/session': {
      schema: updateSessionFeedback,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'LINKING_FEEDBACK_WITH_SESSION',
      description: 'Linking Feedback with Session',
    },
  },

  get: {
    '/V1/feedback/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_FEEDBACK',
      description: 'Get All Feedback',
    },

    '/V1/feedback/:feedbackId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_FEEDBACK',
      description: 'Get Feedback',
    },
  },
};
