const { get: healthCheckGetContext, put: healthCheckPutContext } = require('./healthCheckContext');
const { get: configGetContext, post: configPostContext, patch: configPatchContext, delete: configDeleteContext } = require('./configContext');
const { post: userPostContext, get: userGetContext, patch: userPatchContext, delete: userDeleteContext } = require('./userContext');
const { get: eventGetContext, post: eventPostContext, patch: eventPatchContext, delete: eventDeleteContext } = require('./eventContext');
const { post: commonPostContext, get: commonGetContext } = require('./commonContext');
const {
  get: rolePermissionGetContext,
  post: rolePermissionPostContext,
  patch: rolePermissionPatchContext,
  delete: rolePermissionDeleteContext,
} = require('./rolePermissionContext');
const { post: webhookPostContext, get: webhookGetContext } = require('./webhookContext');
const { get: domainGetContext, post: domainPostContext, patch: domainPatchContext, delete: domainDeleteContext } = require('./domainContext');
const {
  get: subdomainGetContext,
  post: subdomainPostContext,
  patch: subdomainPatchContext,
  delete: subdomainDeleteContext,
} = require('./subdomainContext');
const {
  get: domainSubdomainGetContext,
  post: domainSubdomainPostContext,
  patch: domainSubdomainPatchContext,
  delete: domainSubdomainDeleteContext,
  put: domainSubdomainPutContext,
} = require('./domainSubdomainContext');
const {
  get: countryGetContext,
  post: countryPostContext,
  patch: countryPatchContext,
  delete: countryDeleteContext,
  put: countryPutContext,
} = require('./countryContext');
const {
  get: languageGetContext,
  post: languagePostContext,
  patch: languagePatchContext,
  delete: languageDeleteContext,
  put: languagePutContext,
} = require('./languageContext');
const {
  get: appVariantGetContext,
  post: appVariantPostContext,
  patch: appVariantPatchContext,
  delete: appVariantDeleteContext,
  put: appVariantPutContext,
} = require('./appVariantContext');
const {
  get: userLogGetContext,
  post: userLogPostContext,
  patch: userLogPatchContext,
  delete: userLogDeleteContext,
  put: userLogPutContext,
} = require('./userLogContext');
const {
  get: appVersionGetContext,
  post: appVersionPostContext,
  patch: appVersionPatchContext,
  delete: appVersionDeleteContext,
  put: appVersionPutContext,
} = require('./appVersionContext');
const { put: profilePutContext, post: profilePostContext, patch: profilePatchContext, get: profileGetContext } = require('./profileContext');
const { get: sessionGetContext } = require('./sessionContext');
const {
  get: cronJobFrameworkGetContext,
  post: cronJobFrameworkPostContext,
  patch: cronJobFrameworkPatchContext,
  delete: cronJobFrameworkDeleteContext,
  put: cronJobFrameworkPutContext,
} = require('./cronJobFrameworkContext');
const {
  get: resourceGetContext,
  post: resourcePostContext,
  patch: resourcePatchContext,
  delete: resourceDeleteContext,
} = require('./resourceContext');
const {
  get: resourceActionGetContext,
  post: resourceActionPostContext,
  patch: resourceActionPatchContext,
  delete: resourceActionDeleteContext,
} = require('./resourceActionContext');
const {
  get: notificationPreferencesGetContext,
  post: notificationPreferencesPostContext,
  patch: notificationPreferencesPatchContext,
} = require('./notificationPreferenceContext');
const { post: coursePostContext, get: courseGetContext, patch: coursePatchContext, delete: courseDeleteContext } = require('./courseContext');
const { post: modulePostContext, get: moduleGetContext, patch: modulePatchContext, delete: moduleDeleteContext } = require('./moduleContext');
const { get: topicGetContext, post: topicPostContext, patch: topicPatchContext, delete: topicDeleteContext } = require('./topicContext');
const { post: contentPostContext, patch: contentPatchContext } = require('./contentContext');
const {
  post: categoryPostContext,
  patch: categoryPatchContext,
  get: categoryGetContext,
  delete: categoryDeleteContext,
} = require('./categoryContext');
const { post: quizPostContext, get: quizGetContext, patch: quizPatchContext } = require('./quizContext');
const { post: questionPostContext } = require('./questionContext');
const { post: questionOptionPostContext } = require('./questionOptionContext');

const {
  post: learningSessionPostContext,
  delete: learningSessionDeleteContext,
  patch: learningSessionUpdateContext,
  get: learningSessionGetContext,
} = require('./learningSessionContext');
const { post: batchPostContext, get: batchGetContext, delete: batchDeleteContext, patch: batchPatchContext } = require('./batchContext');
const { post: discussionForumThreadPostContext } = require('./discussionForumThreadContext');
const { post: meetingPostContext } = require('./meetingContext');
const { get: feedbackGetContext, post: feedbackPostContext, patch: feedbackPatchContext } = require('./feedbackContext');
const { get: studentContext, post: studentPostContext } = require('./studentContext');
const { get: teacherContext, post: teacherPostContext, patch: teacherPatchContext } = require('./teacherContext');
const { post: attemptRequestPostContext, patch: attemptRequestUpdateContext } = require('./attemptRequestContext');
const { get: capstoneContext } = require('./capstoneContext');
const {
  get: siteContentContext,
  post: siteContentPostContext,
  patch: siteContentPatchContext,
  delete: siteContentDeleteContext,
} = require('./siteContentContext');
module.exports = {
  post: {
    ...configPostContext,
    ...userPostContext,
    ...rolePermissionPostContext,
    ...eventPostContext,
    ...commonPostContext,
    ...webhookPostContext,
    ...domainPostContext,
    ...subdomainPostContext,
    ...domainSubdomainPostContext,
    ...countryPostContext,
    ...languagePostContext,
    ...appVariantPostContext,
    ...appVersionPostContext,
    ...profilePostContext,
    ...userLogPostContext,
    ...cronJobFrameworkPostContext,
    ...resourcePostContext,
    ...resourceActionPostContext,
    ...resourceActionPostContext,
    ...notificationPreferencesPostContext,
    ...coursePostContext,
    ...modulePostContext,
    ...topicPostContext,
    ...contentPostContext,
    ...categoryPostContext,
    ...quizPostContext,
    ...questionPostContext,
    ...questionOptionPostContext,
    ...batchPostContext,
    ...learningSessionPostContext,
    ...discussionForumThreadPostContext,
    ...attemptRequestPostContext,
    ...meetingPostContext,
    ...feedbackPostContext,
    ...studentPostContext,
    ...teacherPostContext,
    ...siteContentPostContext,
  },
  get: {
    ...healthCheckGetContext,
    ...configGetContext,
    ...rolePermissionGetContext,
    ...userGetContext,
    ...domainGetContext,
    ...subdomainGetContext,
    ...domainSubdomainGetContext,
    ...countryGetContext,
    ...languageGetContext,
    ...appVariantGetContext,
    ...appVersionGetContext,
    ...profileGetContext,
    ...userLogGetContext,
    ...webhookGetContext,
    ...commonGetContext,
    ...cronJobFrameworkGetContext,
    ...eventGetContext,
    ...resourceGetContext,
    ...resourceActionGetContext,
    ...notificationPreferencesGetContext,
    ...moduleGetContext,
    ...courseGetContext,
    ...topicGetContext,
    ...categoryGetContext,
    ...batchGetContext,
    ...quizGetContext,
    ...learningSessionGetContext,
    ...feedbackGetContext,
    ...sessionGetContext,
    ...studentContext,
    ...teacherContext,
    ...capstoneContext,
    ...siteContentContext,
  },
  put: {
    ...healthCheckPutContext,
    ...domainSubdomainPutContext,
    ...countryPutContext,
    ...languagePutContext,
    ...appVariantPutContext,
    ...appVersionPutContext,
    ...profilePutContext,
    ...userLogPutContext,
    ...cronJobFrameworkPutContext,
  },
  patch: {
    ...domainPatchContext,
    ...subdomainPatchContext,
    ...domainSubdomainPatchContext,
    ...countryPatchContext,
    ...languagePatchContext,
    ...appVariantPatchContext,
    ...appVersionPatchContext,
    ...userLogPatchContext,
    ...profilePatchContext,
    ...cronJobFrameworkPatchContext,
    ...configPatchContext,
    ...rolePermissionPatchContext,
    ...eventPatchContext,
    ...resourcePatchContext,
    ...resourceActionPatchContext,
    ...userPatchContext,
    ...notificationPreferencesPatchContext,
    ...modulePatchContext,
    ...coursePatchContext,
    ...topicPatchContext,
    ...categoryPatchContext,
    ...batchPatchContext,
    ...learningSessionUpdateContext,
    ...contentPatchContext,
    ...quizPatchContext,
    ...attemptRequestUpdateContext,
    ...feedbackPatchContext,
    ...teacherPatchContext,
    ...siteContentPatchContext,
  },
  delete: {
    ...domainDeleteContext,
    ...subdomainDeleteContext,
    ...domainSubdomainDeleteContext,
    ...countryDeleteContext,
    ...languageDeleteContext,
    ...appVariantDeleteContext,
    ...appVersionDeleteContext,
    ...userLogDeleteContext,
    ...cronJobFrameworkDeleteContext,
    ...resourceDeleteContext,
    ...resourceActionDeleteContext,
    ...eventDeleteContext,
    ...configDeleteContext,
    ...userDeleteContext,
    ...rolePermissionDeleteContext,
    ...moduleDeleteContext,
    ...courseDeleteContext,
    ...batchDeleteContext,
    ...learningSessionDeleteContext,
    ...topicDeleteContext,
    ...categoryDeleteContext,
    ...siteContentDeleteContext,
  },
};
