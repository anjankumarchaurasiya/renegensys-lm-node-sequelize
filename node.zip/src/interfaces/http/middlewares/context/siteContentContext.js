const { getSiteContent, getAll, submitSiteContent, updateSiteContent } = require('../validators/schemas/site_content');

const MODULE = 'SITE_CONTENT';

module.exports = {
  get: {
    '/V1/site-content/type/:type/name/:name': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SITE_CONTENT',
      description: 'Get site content',
    },
    '/V1/site-content': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_All_SITE_CONTENT',
      description: 'Get all site content',
    },
  },
  post: {
    '/V1/site-content': {
      schema: submitSiteContent,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SUBMIT_SITE_CONTENT',
      description: 'Submit site content',
    },
  },
  patch: {
    '/V1/site-content/:id': {
      schema: updateSiteContent,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_SITE_CONTENT',
      description: 'Update site content',
    },
  },
  delete: {
    '/V1/site-content/:id': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_SITE_CONTENT',
      description: 'Deactivate site content',
    },
  },
};
