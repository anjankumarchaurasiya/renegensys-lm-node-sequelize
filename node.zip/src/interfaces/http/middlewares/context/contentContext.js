const { create, update } = require('../validators/schemas/content');
const MODULE = 'CONTENT';

module.exports = {
  post: {
    '/V1/content': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_CONTENT',
      description: 'Create Content',
    },
  },
  patch: {
    '/V1/content/:contentId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_CONTENT',
      description: 'Update Content',
    },
  },
};
