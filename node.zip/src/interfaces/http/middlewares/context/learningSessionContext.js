const {
  create,
  createSessionQuiz,
  updateSessionQuiz,
  deleteBulk,
  getAll,
  update,
  createSessionSpam,
  createSessionAttendance,
  getAllSessionAttendance,
  updateSessionSpam,
  createSessionProgress,
  updateSessionProgress,
  getAllLearningSessionFeedbackUser,
} = require('../validators/schemas/learning_session');
const MODULE = 'LEARNING_SESSION';

module.exports = {
  post: {
    '/V1/learning-session': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_LEARNING_SESSION',
      description: 'Create Learning Session',
    },
    '/V1/learning-session/:learningSessionId/quiz': {
      schema: createSessionQuiz,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_LEARNING_SESSION_QUIZ',
      description: 'Create Learning Session Quiz',
    },
    '/V1/learning-session/:learningSessionId/spam': {
      schema: createSessionSpam,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_LEARNING_SESSION_SPAM',
      description: 'Create Learning Session spam',
    },
    '/V1/learning-session/:learningSessionId/attendance': {
      schema: createSessionAttendance,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_LEARNING_SESSION_ATTENDANCE',
      description: 'Create Learning Session attendance',
    },
    '/V1/learning-session/:learningSessionId/progress': {
      schema: createSessionProgress,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_LEARNING_SESSION_PROGRESS',
      description: 'Create Learning Session progress',
    },
  },
  patch: {
    '/V1/learning-session/:learningSessionId/quiz': {
      schema: updateSessionQuiz,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_LEARNING_SESSION_QUIZ',
      description: 'Update Learning Session Quiz',
    },
    '/V1/learning-session/:learningSessionId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_LEARNING_SESSION',
      description: 'Update Learning Session',
    },
    '/V1/learning-session/:learningSessionId/attendance/:userId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_LEARNING_SESSION_ATTENDANCE',
      description: 'Update Learning Session Attendance',
    },
    '/V1/learning-session/:learningSessionId/spam/:spamId': {
      schema: updateSessionSpam,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_LEARNING_SESSION_SPAM',
      description: 'Update Learning Session spam',
    },
    '/V1/learning-session/:learningSessionId/progress/:progressId': {
      schema: updateSessionProgress,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_LEARNING_SESSION_PROGRESS',
      description: 'Update Learning Session progress',
    },
    '/V1/learning-session/bulk/activate': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ACTIVATE_BULK_LEARNING_SESSION',
      description: 'Activate Bulk Learning Session',
    },
  },

  delete: {
    '/V1/learning-session/bulk': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_LEARNING_SESSION_BULK',
      description: 'Deactivate Learning Session Bulk',
    },
    '/V1/learning-session/:learningSessionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_LEARNING_SESSION',
      description: 'Deactivate Learning Session',
    },
    '/V1/learning-session/:learningSessionId/quiz': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_LEARNING_SESSION_QUIZ',
      description: 'Delete Learning Session Quiz',
    },
  },

  get: {
    '/V1/learning-session/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_LEARNING_SESSION',
      description: 'Get All Learning Session',
    },
    '/V1/learning-session/:learningSessionId/attendance/filter/list': {
      schema: getAllSessionAttendance,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_LEARNING_SESSION_ATTENDANCE',
      description: 'Get All Learning Attendance Session ',
    },
    '/V1/learning-session/:learningSessionId/spam': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LEARNING_SESSION_SPAM',
      description: 'Get Learning Session spam',
    },
    '/V1/learning-session/:learningSessionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LEARNING_SESSION',
      description: 'Get Learning Session',
    },
    '/V1/learning-session/:learningSessionId/progress/': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LEARNING_SESSION_PROGRESS',
      description: 'Get Learning Session progress',
    },
    '/V1/learning-session/:learningSessionId/feedback': {
      module: MODULE,
      schema: getAllLearningSessionFeedbackUser,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LEARNING_SESSION_FEEDBACK_USER_RESPONSE',
      description: 'Get Learning Session Feedback User Response',
    },
  },
};
