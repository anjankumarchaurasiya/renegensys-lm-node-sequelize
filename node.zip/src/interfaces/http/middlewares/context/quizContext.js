const {
  create,
  getAll,
  get,
  updateQuizSession,
  getAllLearningSession,
  startQuiz,
  submitQuiz,
  getUserQuizResult,
} = require('../validators/schemas/quiz');

const MODULE = 'QUIZ';

module.exports = {
  post: {
    '/V1/quiz': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_QUIZ',
      description: 'Create Quiz',
    },

    '/V1/quiz/start': {
      schema: startQuiz,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'START_QUIZ',
      description: 'Start Quiz',
    },

    '/V1/quiz/submit': {
      schema: submitQuiz,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SUBMIT_QUIZ',
      description: 'Submit Quiz',
    },
    '/V1/quiz/user-quiz-details': {
      schema: getUserQuizResult,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_USER_QUIZ_DETAILS',
      description: 'Get User Quiz Details',
    },
  },
  get: {
    '/V1/quiz/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_QUIZ',
      description: 'Get All Quiz',
    },
    '/V1/quiz/:quizId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SPECIFIC_QUIZ',
      description: 'Get Specific Quiz',
    },
    '/V1/quiz/:quizId/learning-session': {
      schema: getAllLearningSession,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_QUIZ_LEARNING_SESSION',
      description: 'Get All Quiz Learning Session',
    },
    '/V1/quiz/report/get-report/:quizId/:userId/:userQuizProgressId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_REPORT',
      description: 'Get Report',
    },
  },
  patch: {
    '/V1/quiz/:quizId/learning-session': {
      schema: updateQuizSession,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_QUIZ_SESSIONS',
      description: 'Update Quiz Sessions',
    },
  },
};
