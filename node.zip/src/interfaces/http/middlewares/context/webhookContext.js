const MODULE = 'WEBHOOK';
const { tagUpdate } = require('../validators/schemas/webhook');

module.exports = {
  post: {
    '/V1/webhook/sns': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'WEBHOOK_FOR_SNS',
      description: 'Webhook for SNS',
    },
  },
  get: {
    '/V1/webhook/veniso/tag-status-update': {
      module: MODULE,
      schema: tagUpdate,
      isApplicationHeadersRequired: false,
      actionName: 'WEBHOOK_FOR_TAGS_SENT_FROM_VENISO',
      description: 'Webhook for tag sent from veniso',
    },
  },
};
