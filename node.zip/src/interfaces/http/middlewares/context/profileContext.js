const MODULE = 'PROFILE';
const { update, create, getProgress, getList } = require('../validators/schemas/profile');

module.exports = {
  patch: {
    '/V1/profile/:id': {
      module: MODULE,
      schema: update,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_PROFILE',
      description: 'Update profile',
    },
  },
  post: {
    '/V1/profile': {
      module: MODULE,
      schema: create,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_PROFILE',
      description: 'create profile',
    },
  },
  get: {
    '/V1/profile/:id/progress': {
      module: MODULE,
      schema: getProgress,
      isApplicationHeadersRequired: false,
      actionName: 'PROGRESS_PROFILE',
      description: 'Progress profile',
    },
    '/V1/profile/list/filter': {
      module: MODULE,
      schema: getList,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_PROGRESS_PROFILE',
      description: 'Get All Progress profile',
    },
  },
};
