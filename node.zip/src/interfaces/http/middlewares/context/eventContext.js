const MODULE = 'EVENT';
const { create, update, get } = require('../validators/schemas/event');
module.exports = {
  get: {
    '/V1/event': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_EVENT',
      description: 'Get event',
    },
  },
  post: {
    '/V1/event/send-message': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'TEST_EVENT',
      description: 'Test event',
    },
    '/V1/event': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_EVENT',
      description: 'Create event',
    },
  },
  patch: {
    '/V1/event/:eventId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_EVENT',
      description: 'Update event',
    },
  },
  delete: {
    '/V1/event/:eventId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_EVENT',
      description: 'Deactivate event',
    },
  },
};
