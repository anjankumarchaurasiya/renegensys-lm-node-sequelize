const MODULE = 'CONFIG';
const { create, update, get } = require('../validators/schemas/config');

module.exports = {
  get: {
    '/V1/config': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_CONFIG',
      description: 'Get config',
    },
    '/V1/config/filter': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_CONFIG',
      description: 'Get all config',
    },
  },
  post: {
    '/V1/config': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_CONFIG',
      description: 'create config',
    },
  },
  patch: {
    '/V1/config/:id': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_CONFIG',
      description: 'Update config',
    },
  },
  delete: {
    '/V1/config/:id': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_CONFIG',
      description: 'Deactivate Config',
    },
  },
};
