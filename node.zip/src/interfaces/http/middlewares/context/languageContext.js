const MODULE = 'LANGUAGE';

module.exports = {
  get: {
    '/V1/language/:languageId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LANGUAGE',
      description: 'Get language',
    },
    '/V1/language': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LIST_OF_LANGUAGE',
      description: 'Get list of language',
    },
  },
  post: {
    '/V1/language': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_LANGUAGE',
      description: 'Create language',
    },
  },
  patch: {
    '/V1/language/:languageId': {
      // schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_LANGUAGE',
      description: 'Update language',
    },
  },
  delete: {
    '/V1/language/:languageId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_LANGUAGE',
      description: 'Deactivate language',
    },
  },
};
