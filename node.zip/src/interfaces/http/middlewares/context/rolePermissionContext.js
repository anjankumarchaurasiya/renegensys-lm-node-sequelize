const { create, update, get } = require('../validators/schemas/role');
const MODULE = 'ROLE_PERMISSION';

module.exports = {
  get: {
    '/V1/roles': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'LIST_ROLE',
      description: 'List all roles',
    },
    '/V1/roles/resources': {
      module: MODULE,
      actionName: 'LIST_RESOURCES',
      description: 'List all resources of given role',
    },
    '/V1/roles/:roleId/resources/actions': {
      module: MODULE,
      actionName: 'LIST_RESOURCES_ACTIONS',
      description: 'List all actions of given role',
    },
  },
  post: {
    '/V1/roles/resources/bulk': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'BULK_INSERT_RESOURCES',
      description: 'Bulk upload role',
    },
    '/V1/roles/:roleId/resources/assign': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'BULK_ASSIGN_RESOURCES_TO_ROLE',
      description: 'Assign role to user',
    },
    '/V1/roles': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_ROLE',
      description: 'Create role',
    },
  },
  patch: {
    '/V1/roles/:roleId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_ROLE',
      description: 'Update role',
    },
  },
  delete: {
    '/V1/roles/:roleId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_ROLE',
      description: 'Deactivate Role',
    },
  },
};
