const { create } = require('../validators/schemas/question_option');
const MODULE = 'QUESTION_OPTION';

module.exports = {
  post: {
    '/V1/question-option': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_QUESTION_OPTION',
      description: 'Create Question option',
    },
  },
};
