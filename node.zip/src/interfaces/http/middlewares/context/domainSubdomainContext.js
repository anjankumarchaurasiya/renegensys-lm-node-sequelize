const { create, update, getAll } = require('../validators/schemas/domain_subdomain');
const MODULE = 'DOMAIN-SUBDOMAIN';

module.exports = {
  get: {
    '/V1/domain/:domainId/subdomain': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_DOMAIN_SUBDOMAINS',
      description: 'Get All Domain-Subdoamins',
    },
  },
  post: {
    '/V1/domain/subdomain/': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_DOMAIN_SUBDOMAIN',
      description: 'Create New Domain-Subdomain',
    },
  },
  put: {
    '/V1/domain/:domainId/subdomain/:subdomainId': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_UPDATE_DOMAIN_SUBDOMAIN',
      description: 'Create Or Update Domain-Subdomain',
    },
  },
  patch: {
    '/V1/domain/:domainId/subdomain/:subdomainId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_DOMAIN_SUBDOMAIN',
      description: 'Update Specific Domain-Subdomain',
    },
  },
  delete: {
    '/V1/domain/:domainId/subdomain/:subdomainId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DELETE_DOMAIN_SUBDOMAIN',
      description: 'Deactivate Specific Domain-Subdomain',
    },
  },
};
