const { create } = require('../validators/schemas/meeting');
const MODULE = 'MEETING';

module.exports = {
  post: {
    '/V1/meeting/create-meeting': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_MEETING',
      description: 'Create Meeting ',
    },
  },
};
