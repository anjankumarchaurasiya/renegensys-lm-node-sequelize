const MODULE = 'USER_LOG';
const { update } = require('../validators/schemas/user_log');

module.exports = {
  get: {
    '/V1/user-log/:userLogId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_USER_LOG',
      description: 'Get userLog',
    },
    '/V1/user-log': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LIST_OF_USER_LOG',
      description: 'Get list of userLog',
    },
  },
  post: {
    '/V1/user-log': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_USER_LOG',
      description: 'Create userLog',
    },
    '/V1/user-log/ingest-new-content-id': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'INGEST_NEW_CONTENT_ID',
      description: 'Ingest New Content Id',
    },

    '/V1/user-log/ingest-new-profile': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'INGEST_NEW_PROFILE',
      description: 'Ingest New Profile',
    },
  },
  patch: {
    '/V1/user-log': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_USER_LOG',
      description: 'Update userLog',
    },
  },
  delete: {
    '/V1/user-log/:userLogId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_USER_LOG',
      description: 'Deactivate userLog',
    },
  },
};
