const { create } = require('../validators/schemas/question');
const MODULE = 'QUESTION';

module.exports = {
  post: {
    '/V1/question': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_QUESTION',
      description: 'Create Question',
    },
  },
};
