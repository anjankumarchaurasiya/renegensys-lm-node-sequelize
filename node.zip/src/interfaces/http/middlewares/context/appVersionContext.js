const MODULE = 'APP_VERSION';

module.exports = {
  get: {
    '/V1/app-version/:appVersionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_APP_VERSION',
      description: 'Get app version',
    },
    '/V1/app-version': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_LIST_OF_APP_VERSION',
      description: 'Get list of app version',
    },
  },
  post: {
    '/V1/app-version': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_APP_VERSION',
      description: 'Create app version',
    },
  },
  put: {},
  patch: {
    '/V1/app-version/:appVersionId': {
      // schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_APP_VERSION',
      description: 'Update app version',
    },
  },
  delete: {
    '/V1/app-version/:appVersionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_APP_VERSION',
      description: 'Deactivate app version',
    },
  },
};
