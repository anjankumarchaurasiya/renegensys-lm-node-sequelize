const MODULE = 'PAGE_SECTION';
const { create: createPageSection, bulk } = require('../validators/schemas/page_section');

module.exports = {
  get: {},
  post: {
    '/V1/page/:pageId/section': {
      module: MODULE,
      schema: createPageSection,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_PAGE_SECTION',
      description: 'Create page section',
    },
    '/V1/page/:pageId/section/bulk': {
      module: MODULE,
      schema: bulk,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_PAGE_SECTION_bulk',
      description: 'Create page section bulk',
    },
  },
  put: {
    '/V1/page/:pageId/section/:sectionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_PAGE__SECTION_MAPPING',
      description: 'Create page section mapping',
    },
  },
  delete: {
    '/V1/page/:pageId/section/:sectionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_PAGE_SECTION',
      description: 'Deactivate Page Section',
    },
  },
};
