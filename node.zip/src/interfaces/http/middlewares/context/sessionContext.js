const { userSession } = require('../validators/schemas/userSession');

const MODULE = 'USER_SESSION';

module.exports = {
  get: {
    '/V1/session/token': {
      schema: userSession,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'REFRESH_TOKEN',
      description: 'Refresh Token',
    },
  },
};
