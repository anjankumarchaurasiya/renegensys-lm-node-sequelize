const { create } = require('../validators/schemas/discussion_forum_thread');
const MODULE = 'DISCUSSION_FORUM_THREAD';

module.exports = {
  post: {
    '/V1/discussion-forum-thread': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_DISCUSSION_FORUM_THREAD',
      description: 'Create Discussion Forum Thread',
    },
  },
};
