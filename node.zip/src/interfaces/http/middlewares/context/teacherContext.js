const {
  get,
  getBatches,
  getCourses,
  getSessions,
  getTeacherSessionList,
  getQuizResult,
  getStudentReport,
  getCapstoneResult,
  updateLearningSession,
  capstoneSubmit,
  spamReportSubmit,
  getCapstoneForReview,
} = require('../validators/schemas/teacher');

const MODULE = 'TEACHER';

module.exports = {
  get: {
    '/V1/teacher/session/:batchId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SESSION_LIST_OF_TEACHER',
      description: 'Get Session list of teacher',
    },
    '/V1/teacher/:teacherId/batches': {
      schema: getBatches,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_BATCH_LIST_OF_TEACHER',
      description: 'Get Batch list of teacher',
    },
    '/V1/teacher/:teacherId/courses': {
      schema: getCourses,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_COURSE_LIST_OF_TEACHER',
      description: 'Get Batch list of teacher',
    },
    '/V1/teacher/:teacherId/sessions': {
      schema: getSessions,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_SESSIONS_LIST_OF_TEACHER',
      description: 'Get All SESSIONS list of teacher',
    },
    '/V1/teacher/session-list/:sessionId': {
      schema: getTeacherSessionList,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SESSION_LIST_OF_TEACHER_BY_SESSIONID_TEACHERID',
      description: 'Get Session List Of Teacher By SessionId TeacherId',
    },
    '/V1/teacher/session-details/:sessionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_SESSION_FOR_TEACHER',
      description: 'Get Session For Teacher',
    },
    '/V1/teacher/session/result/:sessonId/:quizId': {
      schema: getQuizResult,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_QUIZ_SESSION_RESULT_FOR_TEACHER',
      description: 'Get All Quiz Session Result For Teacher',
    },
    '/V1/teacher/student-quiz-report/:quizId/:studentId': {
      schema: getStudentReport,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_STUDENT_REPORT_OF_QUIZ_SUBMISSION',
      description: 'Get Student Report Of Quiz Submission',
    },
    '/V1/teacher/capstone/result/:quizId/:batchId': {
      schema: getCapstoneResult,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_CAPSTONE_RESULT_FOR_TEACHER',
      description: 'Get All Capstone Result For Teacher',
    },
    '/V1/teacher/capstone/capstone-list/:status': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_CAPSTONE_LIST_FOR_TEACHER',
      description: 'Get All Capstone List For Teacher',
    },
    '/V1/teacher/capstone/review/:userQuizProgressId': {
      schema: getCapstoneForReview,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_CAPSTONE_FOR_REVIEW_FOR_TEACHER',
      description: 'Get capstone for review For Teacher',
    },
    '/V1/teacher/getParticipants/:batchId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_PARTICIPANTS_OF_BATCH_FOR_TEACHER',
      description: 'Get All Participants of Batch For Teacher',
    },
    '/V1/teacher/getAttendees/:sessionId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_ALL_ATTENDEES_OF_SESSION_FOR_TEACHER',
      description: 'Get All Attendees of Session For Teacher',
    },
  },

  patch: {
    '/V1/teacher/session/:sessionId': {
      schema: updateLearningSession,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_SESSION_STATUS_TO_INPROGRESS',
      description: 'Update Session Status To InProgress',
    },
  },

  post: {
    '/V1/teacher/submit-capstone': {
      schema: capstoneSubmit,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SUBMIT_CAPSTONE_PROJECT_BY_TEACHER',
      description: 'Submit capstone by teacher',
    },
    '/V1/teacher/spam-report': {
      schema: spamReportSubmit,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'SUBMIT_SPAM_REPORT_BY_TEACHER',
      description: 'Submit spam report by teacher',
    },
  },
};
