const { create, update, deleteBulk, getAll, createModuleTopic, updateModuleTopic, get } = require('../validators/schemas/module');
const MODULE = 'MODULE';

module.exports = {
  post: {
    '/V1/module': {
      schema: create,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_MODULE',
      description: 'Create Module',
    },
    '/V1/module/:moduleId/topic': {
      schema: createModuleTopic,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'CREATE_MODULE_TOPIC',
      description: 'Create Module Topic',
    },
  },

  patch: {
    '/V1/module/:moduleId': {
      schema: update,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_MODULE',
      description: 'Update Module',
    },
    '/V1/module/:moduleId/topic': {
      schema: updateModuleTopic,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'UPDATE_MODULE_TOPIC',
      description: 'Update Module Topic',
    },
    '/V1/module/bulk/activate': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'ACTIVATE_BULK_MODULE',
      description: 'Activate Bulk Module',
    },
  },

  get: {
    '/V1/module/:moduleId': {
      schema: get,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_MODULE',
      description: 'Get Module',
    },

    '/V1/module/filter/list': {
      schema: getAll,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'GET_MODULE_LIST',
      description: 'Get Module List',
    },
  },

  delete: {
    '/V1/module/:moduleId': {
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_MODULE',
      description: 'Deactivate Module',
    },

    '/V1/module/bulk': {
      schema: deleteBulk,
      module: MODULE,
      isApplicationHeadersRequired: false,
      actionName: 'DEACTIVATE_MODULE_BULK',
      description: 'Deactivate Module Bulk',
    },
  },
};
