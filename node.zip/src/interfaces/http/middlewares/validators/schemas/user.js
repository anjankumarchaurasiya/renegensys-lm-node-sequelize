const Joi = require('joi');
const { USER_ROLES } = require('src/constants');
const userRoles = Object.keys(USER_ROLES);

module.exports = {
  create: Joi.object().keys({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    roles: Joi.array().items(
      Joi.string()
        .valid(...userRoles) // Spread the elements of the array
        .required()
    ),
    mobile: Joi.string().required(),
    dialCode: Joi.string().required(),
    email: Joi.string()
      .email()
      .required(),
    countryCode: Joi.string().optional(),
    dregNo: Joi.string().required(),
    timezone: Joi.string().required(),
  }),

  login: Joi.object().keys({
    mobile: Joi.string().optional(),
    dialCode: Joi.string().optional(),
    email: Joi.string()
      .email()
      .optional(),
  }),

  verifyOtp: Joi.object().keys({
    mobile: Joi.string().optional(),
    dialCode: Joi.string().optional(),
    email: Joi.string()
      .email()
      .optional(),
    otp: Joi.string().required(),
  }),
  get: Joi.object().keys({
    firstName: Joi.string().optional(),
    lastName: Joi.string().optional(),
    roles: Joi.string().optional(),
    mobile: Joi.string().optional(),
    email: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    dialCode: Joi.string().optional(),
    paginated: Joi.boolean().optional(),
    dregNo: Joi.string().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
  update: Joi.object().keys({
    firstName: Joi.string().optional(),
    lastName: Joi.string().optional(),
    mobile: Joi.string().optional(),
    dialCode: Joi.string().optional(),
    email: Joi.string()
      .email()
      .optional(),
    recordStatus: Joi.boolean().optional(),
    countryCode: Joi.string().optional(),
    city: Joi.string().optional(),
    state: Joi.string().optional(),
    socialMediaLinks: Joi.object({
      twitter: Joi.string().uri(),
      facebook: Joi.string().uri(),
      linkedIn: Joi.string().uri(),
    }).optional(),
    address: Joi.string().optional(),
    bio: Joi.string().optional(),
    profileUrl: Joi.string().optional(),
    timezone: Joi.string().optional(),
  }),
};
