const Joi = require('joi');
const { CONTENT_TYPE } = require('src/constants');
module.exports = {
  create: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().optional(),
    url: Joi.string().optional(),
    type: Joi.string()
      .valid(...CONTENT_TYPE)
      .when('url', {
        is: Joi.exist(),
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    file: Joi.object({
      filename: Joi.string().required(),
      size: Joi.number().required(),
      mimeType: Joi.string().required(),
      content: Joi.binary().required(),
    }),
    entityName: Joi.string().optional(),
    entityType: Joi.string().optional(),
  }),

  update: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().optional(),
  }),
};
