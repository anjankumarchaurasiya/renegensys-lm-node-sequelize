const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string()
      .allow('')
      .required(),
    schema: Joi.string()
      .allow('')
      .optional(),
    config: Joi.object().optional(),
    desc: Joi.string().optional(),
  }),
  update: Joi.object().keys({
    name: Joi.string().optional(),
    schema: Joi.string().optional(),
    config: Joi.object().optional(),
    desc: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  get: Joi.object().keys({
    name: Joi.string().optional(),
    desc: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
};
