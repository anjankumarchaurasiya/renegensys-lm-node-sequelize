const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    title: Joi.string().required(),
    topic: Joi.string().required(),
    description: Joi.string().optional(),
    content: Joi.string().optional(),
  }),
};
