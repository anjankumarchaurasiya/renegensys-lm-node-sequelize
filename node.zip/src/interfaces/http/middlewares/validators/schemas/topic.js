const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    title: Joi.string().required(),
    thumbnail: Joi.string().required(),
    resources: Joi.array()
      .items(Joi.string().uuid())
      .required(),
  }),
  get: Joi.object().keys({
    usages: Joi.boolean().required(),
  }),
  update: Joi.object().keys({
    title: Joi.string().optional(),
    thumbnail: Joi.string().optional(),
    addResources: Joi.array()
      .items(Joi.string().guid({ version: ['uuidv4'] }))
      .optional(),
    removeResources: Joi.array()
      .items(Joi.string().guid({ version: ['uuidv4'] }))
      .optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  deleteBulk: Joi.object().keys({
    topicIds: Joi.array()
      .items(Joi.string().required())
      .min(1)
      .required(),
  }),
  getAll: Joi.object().keys({
    title: Joi.string().optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    slug: Joi.string().optional(),
    moduleId: Joi.string()
      .guid()
      .optional(),
    linked: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
};
