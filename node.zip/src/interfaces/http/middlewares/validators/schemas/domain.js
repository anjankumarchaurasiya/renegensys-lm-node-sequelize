const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string()
      .allow('')
      .required(),
  }),

  update: Joi.object().keys({
    name: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),

  getAll: Joi.object().keys({
    paginated: Joi.boolean(),
    pageNo: Joi.number(),
    pageSize: Joi.number(),
  }),
};
