const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    actionName: Joi.string().optional(),
    actionType: Joi.string().optional(),
    allowedFields: Joi.object().optional(),
    resourceId: Joi.string().optional(),
  }),
  update: Joi.object().keys({
    actionName: Joi.string().optional(),
    actionType: Joi.string().optional(),
    allowedFields: Joi.object().optional(),
    resourceId: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  get: Joi.object().keys({
    actionName: Joi.string().optional(),
    actionType: Joi.string().optional(),
    resourceId: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
};
