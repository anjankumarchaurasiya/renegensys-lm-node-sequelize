const Joi = require('joi');

module.exports = {
  retest: Joi.object().keys({
    quizType: Joi.string()
      .valid('PRE_SESSION', 'POST_SESSION', 'EXAM', 'CAPSTONE_PROJECT')
      .required(),
    quizId: Joi.string()
      .uuid()
      .required(),
  }),
  retestAttemptAccept: Joi.object().keys({
    status: Joi.string()
      .valid('PENDING', 'APPROVED', 'REJECTED')
      .required(),
  }),
};
