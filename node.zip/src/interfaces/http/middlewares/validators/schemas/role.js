const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string()
      .allow('')
      .required(),
    description: Joi.string()
      .allow('')
      .required(),
    resourceActionIds: Joi.array()
      .items()
      .optional(),
  }),
  update: Joi.object().keys({
    name: Joi.string()
      .allow('')
      .optional(),
    description: Joi.string()
      .allow('')
      .optional(),
    resourceActionIds: Joi.array()
      .items()
      .optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  get: Joi.object().keys({
    name: Joi.string().optional(),
    description: Joi.string().optional(),
    resourceActionId: Joi.string().optional(),
    resourceId: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
};
