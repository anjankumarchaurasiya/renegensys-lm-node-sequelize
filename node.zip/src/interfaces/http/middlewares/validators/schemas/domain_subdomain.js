const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    domainId: Joi.string()
      .allow('')
      .required(),
    subdomainId: Joi.string()
      .allow('')
      .required(),
    order: Joi.number().required(),
  }),

  update: Joi.object().keys({
    domainId: Joi.string()
      .allow('')
      .required(),
    subdomainId: Joi.string()
      .allow('')
      .required(),
    order: Joi.number().required(),
  }),

  getAll: Joi.object().keys({
    paginated: Joi.boolean(),
    pageNo: Joi.number(),
    pageSize: Joi.number(),
  }),
};
