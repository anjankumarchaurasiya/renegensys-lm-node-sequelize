const Joi = require('joi');

module.exports = {
  tagUpdate: Joi.object().keys({
    cgId: Joi.number().optional(),
    appVariant: Joi.string().optional(),
    tag: Joi.string().optional(),
  }),
};
