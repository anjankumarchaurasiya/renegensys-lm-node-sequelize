const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    type: Joi.string()
      .valid('PRE_SESSION', 'POST_SESSION', 'EXAM', 'CAPSTONE')
      .required(),
    quizData: Joi.object({
      title: Joi.string().required(),
      duration: Joi.string().optional(),
      description: Joi.string().optional(),
      categoryId: Joi.string()
        .uuid()
        .required(),
      questionToSelect: Joi.number()
        .integer()
        .optional(),
      passingPercentage: Joi.number()
        .min(0)
        .max(100)
        .optional(),
    }).required(),

    questionData: Joi.array()
      .items(
        Joi.object({
          question: Joi.string().required(),
          categoryId: Joi.string().required(),
          content: Joi.array()
            .items(Joi.string().uuid())
            .optional(),
          point: Joi.number().required(),
          options: Joi.array()
            .items(
              Joi.object({
                option: Joi.string().required(),
                isCorrectOption: Joi.boolean().required(),
                description: Joi.string().optional(),
                order: Joi.string().required(),
              })
            )
            .min(2)
            .optional(),
        })
      )
      .required(),
  }),

  get: Joi.object().keys({
    viewTree: Joi.boolean().optional(),
    studentView: Joi.boolean().optional(),
    viewSession: Joi.boolean().optional(),
    linked: Joi.boolean().optional(),
    sessionTitle: Joi.string().optional(),
    batchId: Joi.string().optional(),
    courseId: Joi.string().optional(),
  }),
  getUserQuizResult: Joi.object().keys({
    quizId: Joi.string().required(),
    quizType: Joi.string()
      .valid('PRE_SESSION', 'POST_SESSION', 'EXAM')
      .required(),
  }),
  getAll: Joi.object().keys({
    categoryIds: Joi.array()
      .items(Joi.string().optional())
      .optional(),
    title: Joi.string().optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    examDate: Joi.date()
      .iso()
      .min(new Date().toISOString().substring(0, 10))
      .message('Start date must be today or in the future')
      .optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
  updateQuizSession: Joi.object({
    linked: Joi.array()
      .items(
        Joi.string()
          .guid({ version: 'uuidv4' })
          .required()
      )
      .optional(),
    unLinked: Joi.array()
      .items(
        Joi.string()
          .guid({ version: 'uuidv4' })
          .required()
      )
      .optional(),
  }),

  getAllLearningSession: Joi.object().keys({
    recordStatus: Joi.boolean().optional(),
    title: Joi.string().optional(),
    batchId: Joi.string().optional(),
    courseId: Joi.string().optional(),
  }),

  startQuiz: Joi.object().keys({
    userId: Joi.string()
      .uuid()
      .required(),
    quizId: Joi.string()
      .uuid()
      .required(),
    attemptRequestId: Joi.string()
      .uuid()
      .optional(),
  }),

  submitQuiz: Joi.object().keys({
    userId: Joi.string()
      .uuid()
      .required(),
    quizId: Joi.string()
      .uuid()
      .required(),
    userQuizProgressId: Joi.string()
      .uuid()
      .required(),
    attemptRequestId: Joi.string()
      .uuid()
      .optional(),
    questionData: Joi.array()
      .items(
        Joi.object().keys({
          questionId: Joi.string().required(),
          questionOptionId: Joi.string().optional(),
          response: Joi.string(),
        })
      )
      .required(),
  }),
};
