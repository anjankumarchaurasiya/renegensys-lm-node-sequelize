const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string().required(),
    type: Joi.string().optional(),
  }),
  update: Joi.object().keys({
    name: Joi.string().optional(),
    type: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  get: Joi.object().keys({
    name: Joi.string().optional(),
    type: Joi.string().optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  getAll: Joi.object().keys({
    name: Joi.string().optional(),
    type: Joi.string().optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
};
