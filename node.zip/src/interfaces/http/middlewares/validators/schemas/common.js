const Joi = require('joi');

module.exports = {
  fileUpload: Joi.object().keys({
    file: Joi.binary(),
    entityName: Joi.string().required(),
    entityType: Joi.string().required(),
  }),
  fileDownload: Joi.object().keys({
    entityName: Joi.string().required(),
  }),
  planActivation: Joi.object().keys({
    cgId: Joi.string().required(),
    appId: Joi.string().required(),
    dialCode: Joi.string().required(),
    mobile: Joi.number().required(),
    source: Joi.string().optional(),
    venisoPlan: Joi.object().keys({
      planid: Joi.string().required(),
      order_id: Joi.string().required(),
      amt: Joi.string().required(),
      status: Joi.string()
        .required()
        .valid('success'),
    }),
  }),
  planDeactivation: Joi.object().keys({
    cgId: Joi.string().required(),
    appId: Joi.string().required(),
  }),
};
