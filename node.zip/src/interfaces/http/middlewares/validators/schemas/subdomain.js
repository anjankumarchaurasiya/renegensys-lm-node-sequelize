const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string().required(),
    domainIds: Joi.array()
      .items()
      .optional(),
  }),

  update: Joi.object().keys({
    name: Joi.string().optional(),
    domainIds: Joi.array()
      .items()
      .optional(),
  }),

  getList: Joi.object().keys({
    recordStatus: Joi.string()
      .allow('')
      .optional(),
    status: Joi.string()
      .allow('')
      .optional(),
  }),
};
