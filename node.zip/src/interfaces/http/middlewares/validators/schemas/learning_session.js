const Joi = require('joi');

const { SESSION_STATUS_TYPE, SESSION_STATE } = require('src/constants');
const sessionStatusTypes = Object.keys(SESSION_STATUS_TYPE);
const sessionStateTypes = Object.keys(SESSION_STATE);
const { SESSION_CONTENT_TYPE } = require('src/constants');
const sessionContentTypes = Object.keys(SESSION_CONTENT_TYPE);

module.exports = {
  create: Joi.object().keys({
    title: Joi.string().required(),
    status: Joi.string()
      .valid(...sessionStatusTypes)
      .required(),
    courseId: Joi.string()
      .uuid()
      .required(),
    batchId: Joi.string()
      .uuid()
      .required(),
    srmId: Joi.string()
      .uuid()
      .required(),
    primaryFacultyId: Joi.string()
      .uuid()
      .required(),
    secondaryFacultyId: Joi.string()
      .uuid()
      .required(),
    moduleIds: Joi.array()
      .items(Joi.string().uuid())
      .min(1)
      .required(),
    meetingPlatform: Joi.string().required(),
    date: Joi.string()
      .pattern(/^(\d{4})-(\d{2})-(\d{2})$/, { name: 'date format' })
      .message('Date must be in the format YYYY-MM-DD')
      .custom((value, helpers) => {
        const selectedDate = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (selectedDate < today) {
          return helpers.error('any.invalid', { message: 'Date cannot be in the past' });
        }
        return value;
      }, 'Date validation')
      .required(),
    startTime: Joi.string()
      .pattern(/^([0-1]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .message('Start time must be in the format HH:mm:ss')
      .required(),

    endTime: Joi.string()
      .pattern(/^([0-1]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .message('End time must be in the format HH:mm:ss')
      .custom((value, helpers) => {
        const [endHours, endMinutes, endSeconds] = value.split(':').map(Number);
        const endTimeInSeconds = endHours * 3600 + endMinutes * 60 + endSeconds;

        const startTimeValue = helpers.state.ancestors[0].startTime;
        const [startHours, startMinutes, startSeconds] = startTimeValue.split(':').map(Number);
        const startTimeInSeconds = startHours * 3600 + startMinutes * 60 + startSeconds;

        if (endTimeInSeconds <= startTimeInSeconds) {
          return helpers.message('End time must be after start time');
        }

        return value;
      }, 'End time validation')
      .required(),

    meetingStartUrl: Joi.string().required(),
    meetingUrl: Joi.string().required(),
    feedbackId: Joi.string()
      .uuid()
      .required(),

    content: Joi.array()
      .items(
        Joi.object({
          contentType: Joi.string()
            .valid(...sessionContentTypes)
            .required(),
          contentIds: Joi.array()
            .items(Joi.string().uuid())
            .min(1)
            .required(),
        })
      )
      .optional(),
  }),

  createSessionQuiz: Joi.object({
    quizes: Joi.array()
      .items(
        Joi.object({
          quizId: Joi.string().required(),
        })
      )
      .min(1)
      .required(),
  }),

  deleteBulk: Joi.object().keys({
    learningSessionIds: Joi.array()
      .items(Joi.string().required())
      .min(1)
      .required(),
  }),

  updateSessionQuiz: Joi.object({
    quizes: Joi.array()
      .items(
        Joi.object({
          quizId: Joi.string().required(),
          recordStatus: Joi.boolean().optional(),
        })
      )
      .min(1)
      .required(),
  }),

  getAll: Joi.object({
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),

    title: Joi.string().optional(),
    primaryFacultyId: Joi.string()
      .uuid()
      .optional(),
    secondaryFacultyId: Joi.string()
      .uuid()
      .optional(),
    srmId: Joi.string()
      .uuid()
      .optional(),
    courseId: Joi.string()
      .uuid()
      .optional(),
    batchId: Joi.string()
      .uuid()
      .optional(),
    state: Joi.string()
      .valid(...sessionStateTypes)
      .optional(),
    status: Joi.string()
      .valid(...sessionStatusTypes)
      .optional(),
    recordStatus: Joi.boolean().optional(),
    date: Joi.date()
      .iso()
      .optional(),
    createdAt: Joi.string().optional(),
  }),
  update: Joi.object().keys({
    title: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    srmId: Joi.string()
      .uuid()
      .optional(),

    primaryFacultyId: Joi.string()
      .uuid()
      .optional(),
    secondaryFacultyId: Joi.string()
      .uuid()
      .optional(),
    moduleIds: Joi.array()
      .items(Joi.string().uuid())
      .optional(),
    deletedModuleIds: Joi.array()
      .items(Joi.string().uuid())
      .optional(),
    date: Joi.string()
      .pattern(/^(\d{4})-(\d{2})-(\d{2})$/, { name: 'date format' })
      .message('Date must be in the format YYYY-MM-DD')
      .custom((value, helpers) => {
        const selectedDate = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (selectedDate < today) {
          return helpers.error('any.invalid', { message: 'Date cannot be in the past' });
        }
        return value;
      }, 'Date validation')
      .optional(),
    startTime: Joi.string()
      .pattern(/^([0-1]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .message('Start time must be in the format HH:mm:ss')
      .optional(),

    endTime: Joi.string()
      .pattern(/^([0-1]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .message('End time must be in the format HH:mm:ss')
      .custom((value, helpers) => {
        const [endHours, endMinutes, endSeconds] = value.split(':').map(Number);
        const endTimeInSeconds = endHours * 3600 + endMinutes * 60 + endSeconds;

        const startTimeValue = helpers.state.ancestors[0].startTime;
        const [startHours, startMinutes, startSeconds] = startTimeValue.split(':').map(Number);
        const startTimeInSeconds = startHours * 3600 + startMinutes * 60 + startSeconds;

        if (endTimeInSeconds <= startTimeInSeconds) {
          return helpers.message('End time must be after start time');
        }

        return value;
      }, 'End time validation')
      .optional(),
    meetingStartUrl: Joi.string().optional(),
    meetingUrl: Joi.string().optional(),
    feedbackId: Joi.string()
      .uuid()
      .optional(),
    status: Joi.string()
      .valid(...sessionStatusTypes)
      .optional(),
    reason: Joi.string().when('status', {
      is: SESSION_STATUS_TYPE.CANCELLED,
      then: Joi.string().required(),
      otherwise: Joi.string().optional(),
    }),
    cancelledBy: Joi.string()
      .uuid()
      .optional(),

    content: Joi.array()
      .items(
        Joi.object({
          contentType: Joi.string()
            .valid(...sessionContentTypes)
            .required(),
          contentIds: Joi.array()
            .items(Joi.string().uuid())
            .min(1)
            .required(),
          deletedContentIds: Joi.array()
            .items(Joi.string().uuid())
            .min(1)
            .optional(),
        })
      )
      .optional(),
  }),
  createSessionSpam: Joi.object().keys({
    reportedBy: Joi.string()
      .uuid()
      .required(),
    spamReason: Joi.string().required(),
    warningGiven: Joi.boolean().optional(),
  }),

  createSessionAttendance: Joi.object().keys({
    userId: Joi.string()
      .uuid()
      .required(),
    roleId: Joi.string()
      .uuid()
      .required(),
  }),
  getAllSessionAttendance: Joi.object().keys({
    roleId: Joi.string()
      .uuid()
      .optional(),
  }),

  updateSessionSpam: Joi.object().keys({
    warningGiven: Joi.boolean().required(),
  }),

  createSessionProgress: Joi.object().keys({
    moduleId: Joi.string()
      .uuid()
      .required(),
    topicId: Joi.string()
      .uuid()
      .required(),
    batchId: Joi.string()
      .uuid()
      .required(),
  }),

  updateSessionProgress: Joi.object().keys({
    recordStatus: Joi.boolean().required(),
  }),

  getAllLearningSessionFeedbackUser: Joi.object({
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    name: Joi.string().optional(),
    primaryFacultyId: Joi.string()
      .uuid()
      .optional(),
    feedbackCategoryId: Joi.string()
      .uuid()
      .optional(),
  }),
};
