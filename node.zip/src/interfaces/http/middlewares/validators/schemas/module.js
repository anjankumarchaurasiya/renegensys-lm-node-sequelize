const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().optional(),
  }),

  update: Joi.object().keys({
    title: Joi.string().optional(),
    description: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),

  get: Joi.object()
    .keys({
      viewTree: Joi.boolean().optional(),
      usages: Joi.boolean().optional(),
    })
    .custom((obj, helpers) => {
      if (obj.viewTree === true && obj.usages === true) {
        return helpers.message({
          custom: "Either 'viewTree' or 'usages' can be true, but not both.",
        });
      }
      return obj;
    }, 'Exclusive OR validation'),

  getAll: Joi.object().keys({
    courseId: Joi.string()
      .guid()
      .optional(),
    title: Joi.string().optional(),
    description: Joi.string().optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    slug: Joi.string().optional(),
    linked: Joi.boolean().optional(),
  }),

  deleteBulk: Joi.object().keys({
    moduleIds: Joi.array()
      .items(Joi.string().required())
      .min(1)
      .required(),
  }),

  createModuleTopic: Joi.object({
    topics: Joi.array()
      .items(
        Joi.object({
          topic_id: Joi.string()
            .guid({ version: 'uuidv4' })
            .required(),
          order: Joi.number()
            .integer()
            .min(1)
            .required(),
        })
      )
      .min(1)
      .required(),
  }),
  updateModuleTopic: Joi.object({
    unLinked: Joi.array().items(
      Joi.object({
        topic_id: Joi.string()
          .guid({ version: 'uuidv4' })
          .required(),
        recordStatus: Joi.boolean().required(),
      })
    ),
    order: Joi.array().items(
      Joi.object({
        topic_id: Joi.string()
          .guid({ version: 'uuidv4' })
          .required(),
        order: Joi.number()
          .integer()
          .required(),
      })
    ),
  }),
};
