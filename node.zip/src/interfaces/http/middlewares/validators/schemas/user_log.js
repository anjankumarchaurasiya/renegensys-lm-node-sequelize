const Joi = require('joi');

module.exports = {
  update: Joi.object().keys({
    contentType: Joi.string()
      .allow('')
      .required(),
    oldContentId: Joi.number()
      .allow('')
      .required(),
    newContentId: Joi.string().required(),
  }),
};
