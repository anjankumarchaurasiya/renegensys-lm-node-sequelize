const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().optional(),
    slug: Joi.string().optional(),
    thumbnail: Joi.string().required(),
  }),
  get: Joi.object()
    .keys({
      viewTree: Joi.boolean().optional(),
      viewStudent: Joi.boolean().optional(),
    })
    .custom((obj, helpers) => {
      if (obj.viewTree === true && obj.viewStudent === true) {
        return helpers.message({
          custom: "Either 'viewTree' or 'viewStudent' can be true, but not both.",
        });
      }
      return obj;
    }, 'Exclusive OR validation'),
  getAll: Joi.object().keys({
    moduleId: Joi.string()
      .guid()
      .optional(),
    title: Joi.string().optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    slug: Joi.string().optional(),
  }),
  update: Joi.object().keys({
    title: Joi.string().optional(),
    description: Joi.string().optional(),
    slug: Joi.string().optional(),
    thumbnail: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  deleteBulk: Joi.object().keys({
    courseIds: Joi.array()
      .items(Joi.string().required())
      .min(1)
      .required(),
  }),
  createCourseModule: Joi.object({
    modules: Joi.array()
      .items(
        Joi.object({
          module_id: Joi.string()
            .guid({ version: 'uuidv4' })
            .required(),
          order: Joi.number()
            .integer()
            .min(1)
            .required(),
        })
      )
      .min(1)
      .required(),
  }),
  updateCourseModule: Joi.object({
    unLinked: Joi.array().items(
      Joi.object({
        module_id: Joi.string()
          .guid({ version: 'uuidv4' })
          .required(),
        recordStatus: Joi.boolean().required(),
      })
    ),
    order: Joi.array().items(
      Joi.object({
        module_id: Joi.string()
          .guid({ version: 'uuidv4' })
          .required(),
        order: Joi.number()
          .integer()
          .required(),
      })
    ),
  }),

  createFaq: Joi.object().keys({
    question: Joi.string().required(),
    answer: Joi.string().required(),
    order: Joi.number()
      .integer()
      .min(1)
      .required(),
  }),

  updateFaq: Joi.object().keys({
    question: Joi.string().optional(),
    answer: Joi.string().optional(),
    order: Joi.number()
      .integer()
      .min(1)
      .optional(),
  }),

  getAllFaq: Joi.object().keys({
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
};
