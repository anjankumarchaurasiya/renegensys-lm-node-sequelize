const Joi = require('joi');
const { NOTIFICATION_TYPES } = require('src/constants');
const notificationTypes = Object.values(NOTIFICATION_TYPES);
module.exports = {
  createOrUpdate: Joi.object().keys({
    userId: Joi.string().required(),
    notificationPreferences: Joi.array().items(
      Joi.object().keys({
        notificationType: Joi.string()
          .valid(...notificationTypes)
          .required(),
        recordStatus: Joi.boolean().required(),
      })
    ),
  }),
  get: Joi.object().keys({ userId: Joi.string().required() }),
};
