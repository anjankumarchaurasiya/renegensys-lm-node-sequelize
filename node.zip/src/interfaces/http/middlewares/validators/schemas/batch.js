const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    batchNumber: Joi.string().required(),
    courseId: Joi.string()
      .uuid()
      .required(),
    startDate: Joi.date()
      .iso()
      .min(new Date().toISOString().substring(0, 10))
      .message('Start date must be today or in the future')
      .required(),

    endDate: Joi.date()
      .iso()
      .min(Joi.ref('startDate')) // Ensures the end date is after the start date
      .message('End date must be after start date')
      .required(),
    classMode: Joi.string()
      .valid('WEEK_DAYS', 'WEEK_ENDS')
      .required(),
    feedbackId: Joi.string().required(),
  }),
  deleteBulk: Joi.object().keys({
    batchIds: Joi.array()
      .items(Joi.string().required())
      .min(1)
      .required(),
  }),
  update: Joi.object().keys({
    batchNumber: Joi.string().optional(),
    courseId: Joi.string()
      .uuid()
      .optional(),
    startDate: Joi.date()
      .iso()
      .min(new Date().toISOString().substring(0, 10))
      .message('Start date must be today or in the future')
      .optional(),
    feedbackId: Joi.string()
      .uuid()
      .optional(),
    endDate: Joi.date()
      .iso()
      .min(Joi.ref('startDate')) // Ensures the end date is after the start date
      .message('End date must be after start date')
      .optional(),
    classMode: Joi.string()
      .valid('WEEK_DAYS', 'WEEK_ENDS')
      .optional(),
  }),
  getAll: Joi.object().keys({
    courseId: Joi.string()
      .guid()
      .optional(),
    batchNumber: Joi.string().optional(),
    classMode: Joi.string()
      .valid('WEEK_DAYS', 'WEEK_ENDS')
      .optional(),
    startDate: Joi.date()
      .iso()
      .min(new Date().toISOString().substring(0, 10))
      .message('Start date must be today or in the future')
      .optional(),

    endDate: Joi.date()
      .iso()
      .min(Joi.ref('startDate')) // Ensures the end date is after the start date
      .message('End date must be after start date')
      .optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
  createBatcheUser: Joi.object({
    users: Joi.array()
      .items(Joi.string().required())
      .min(1)
      .required(),
  }),
  getAllBatchUser: Joi.object({
    createdAt: Joi.string().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    name: Joi.string().optional(),
    mobile: Joi.string().optional(),
    dregNo: Joi.string().optional(),
    email: Joi.string().optional(),
    linked: Joi.boolean().optional(),
    userCreatedAt: Joi.string().optional(),
    roleId: Joi.string()
      .guid()
      .optional(),
  }),
  batchQuiz: Joi.object({
    startTime: Joi.string()
      .pattern(/^([0-1]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .message('Start time must be in the format HH:mm:ss')
      .optional(),

    examDate: Joi.date()
      .iso()
      .min(new Date().toISOString().substring(0, 10))
      .message('Start date must be today or in the future')
      .optional(),
    categoryId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
  }),
  updateBatchUsers: Joi.object({
    linked: Joi.array()
      .items(
        Joi.string()
          .guid({ version: 'uuidv4' })
          .required()
      )
      .optional(),
    unLinked: Joi.array()
      .items(
        Joi.string()
          .guid({ version: 'uuidv4' })
          .required()
      )
      .optional(),
  }),
  getExamResult: Joi.object({
    isPassed: Joi.boolean().optional(),
    status: Joi.string().optional(),
    name: Joi.string().optional(),
    dregNo: Joi.string().optional(),
    earnPoint: Joi.string().optional(),
    paginated: Joi.boolean().optional(),
    categoryId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),

  getExamResultOfStudent: Joi.object({
    isPassed: Joi.boolean().optional(),
    attemptNo: Joi.string().optional(),
    earnPoint: Joi.string().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
};
