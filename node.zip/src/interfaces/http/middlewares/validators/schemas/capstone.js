const Joi = require('joi');

module.exports = {
  getCapstone: Joi.object().keys({
    batchId: Joi.string()
      .guid({ version: 'uuidv4' })
      .optional(),
    quizId: Joi.string()
      .guid({ version: 'uuidv4' })
      .optional(),
  }),
  getUserCapstoneResult: Joi.object().keys({
    quizId: Joi.string().optional(),
  }),
};
