const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    questionId: Joi.string().required(),
    option: Joi.string().required(),
    isCorrectOption: Joi.boolean().required(),
  }),
};
