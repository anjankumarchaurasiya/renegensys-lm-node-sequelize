const Joi = require('joi');
const { SESSION_STATUS_TYPE, REPORT_TYPE, ASSESMENT_STATUS } = require('src/constants');
const sessionStatusTypes = Object.keys(SESSION_STATUS_TYPE);
const reportTypes = Object.keys(REPORT_TYPE);
const assesmentStatus = Object.keys(ASSESMENT_STATUS);

module.exports = {
  get: Joi.object({
    batchId: Joi.string()
      .guid({ version: 'uuidv4' })
      .optional(),
  }),
  getCapstoneForReview: Joi.object({
    quizProgressId: Joi.string()
      .guid({ version: 'uuidv4' })
      .optional(),
  }),
  getBatches: Joi.object().keys({
    courseId: Joi.string()
      .guid()
      .optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),

  getCourses: Joi.object().keys({
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),

  getSessions: Joi.object().keys({
    batchId: Joi.string()
      .uuid()
      .optional(),
    status: Joi.string()
      .valid(...sessionStatusTypes)
      .optional(),
    teacherId: Joi.string()
      .uuid()
      .optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),

  getTeacherSessionList: Joi.object({
    sessionId: Joi.string()
      .guid({ version: 'uuidv4' })
      .optional(),
  }),

  getQuizResult: Joi.object({
    isPassed: Joi.boolean().optional(),
    name: Joi.string().optional(),
    dregNo: Joi.string().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),

  getStudentReport: Joi.object({
    reportType: Joi.string()
      .valid(...reportTypes)
      .required(),
  }),

  getCapstoneResult: Joi.object({
    isPassed: Joi.boolean().optional(),
    name: Joi.string().optional(),
    dregNo: Joi.string().optional(),
    status: Joi.string()
      .valid(...assesmentStatus)
      .optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
  capstoneSubmit: Joi.object({
    quizId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
    quizProgressId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
    capstoneResponse: Joi.array()
      .items(
        Joi.object({
          responseId: Joi.string()
            .guid({ version: 'uuidv4' })
            .required(),
          teacherFeedback: Joi.string().optional(),
          earnPoint: Joi.number()
            .required()
            .min(0),
        })
      )
      .required(),
  }),
  updateLearningSession: Joi.object({
    status: Joi.string()
      .valid(...sessionStatusTypes)
      .required(),
  }),
  spamReportSubmit: Joi.object({
    learningSessionId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
    studentId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
    spamReason: Joi.string().required(),
    warningGiven: Joi.boolean().required(),
  }),
};
