const Joi = require('joi');

module.exports = {
  capstoneSubmit: Joi.object({
    isSubmit: Joi.boolean()
      .valid(true, false)
      .required(),
    quizId: Joi.string()
      .guid({ version: 'uuidv4' })
      .required(),
    capstoneResponse: Joi.array()
      .items(
        Joi.object({
          questionId: Joi.string()
            .guid({ version: 'uuidv4' })
            .required(),
          answerDescription: Joi.string().optional(),
          contentIds: Joi.array()
            .items(Joi.string().guid({ version: 'uuidv4' }))
            .required(),
        })
      )
      .required(),
  }),
};
