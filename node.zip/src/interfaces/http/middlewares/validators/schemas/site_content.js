const Joi = require('joi');

module.exports = {
  getSiteContent: Joi.object({
    name: Joi.string().required(),
    type: Joi.string()
      .valid('PAGE_CONTENT', 'FOOTER_LINK')
      .required(),
  }),
  submitSiteContent: Joi.object({
    name: Joi.string().required(),
    type: Joi.string()
      .valid('PAGE_CONTENT', 'FOOTER_LINK')
      .required(),
    title: Joi.string().required(),
    siteContent: Joi.string()
      .optional()
      .allow('', null),
    url: Joi.string()
      .optional()
      .allow(''),
  }),
  updateSiteContent: Joi.object({
    name: Joi.string().optional(),
    type: Joi.string()
      .valid('PAGE_CONTENT', 'FOOTER_LINK')
      .optional(),
    title: Joi.string().optional(),
    siteContent: Joi.string()
      .optional()
      .allow('', null),
    url: Joi.string()
      .optional()
      .allow(''),
  }),
  getAll: Joi.object().keys({
    title: Joi.string().optional(),
    name: Joi.string().optional(),
    type: Joi.string()
      .valid('PAGE_CONTENT', 'FOOTER_LINK')
      .optional(),
    createdAt: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),
};
