const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string().optional(),
    type: Joi.string().optional(),
    serviceName: Joi.string().optional(),
    methodName: Joi.string().optional(),
    config: Joi.object().optional(),
  }),
  update: Joi.object().keys({
    name: Joi.string().optional(),
    type: Joi.string().optional(),
    serviceName: Joi.string().optional(),
    methodName: Joi.string().optional(),
    config: Joi.object().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
  get: Joi.object().keys({
    name: Joi.string().optional(),
    type: Joi.string().optional(),
    serviceName: Joi.string().optional(),
    methodName: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number().optional(),
    pageSize: Joi.number().optional(),
  }),
};
