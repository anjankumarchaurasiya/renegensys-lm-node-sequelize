const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    resourceName: Joi.string().optional(),
  }),
  update: Joi.object().keys({
    resourceName: Joi.string().optional(),
  }),
  get: Joi.object().keys({
    resourceName: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
  }),
};
