const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string().optional(),
    serviceName: Joi.string().optional(),
    methodName: Joi.string().optional(),
    cron: Joi.string().optional(),
    params: Joi.object().optional(),
  }),

  update: Joi.object().keys({
    name: Joi.string().optional(),
    serviceName: Joi.string().optional(),
    methodName: Joi.string().optional(),
    cron: Joi.string().optional(),
    params: Joi.object().optional(),
    recordStatus: Joi.boolean().optional(),
  }),

  getAll: Joi.object().keys({
    name: Joi.string().optional(),
    serviceName: Joi.string().optional(),
    methodName: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number().optional(),
    pageSize: Joi.number().optional(),
  }),
};
