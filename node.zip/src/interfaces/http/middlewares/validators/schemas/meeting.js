const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    topic: Joi.string().required(),
    date: Joi.string()
      .pattern(/^(\d{4})-(\d{2})-(\d{2})$/, { name: 'date format' })
      .message('Date must be in the format YYYY-MM-DD')
      .custom((value, helpers) => {
        const selectedDate = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (selectedDate < today) {
          return helpers.error('any.invalid', { message: 'Date cannot be in the past' });
        }
        return value;
      }, 'Date validation')
      .required(),
    startTime: Joi.string()
      .pattern(/^([0-1]\d|2[0-3]):([0-5]\d):([0-5]\d)$/)
      .message('Start time must be in the format HH:mm:ss')
      .required(),
    duration: Joi.number()
      .integer()
      .min(1)
      .required(),
    timezone: Joi.string().required(),
    platform: Joi.string().optional(),
  }),
};
