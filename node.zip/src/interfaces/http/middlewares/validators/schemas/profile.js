const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    name: Joi.string()
      .allow('')
      .required(),
    profilePic: Joi.string()
      .allow('')
      .optional(),
    gender: Joi.string()
      .allow('')
      .optional(),
    age: Joi.number().required(),
    cgId: Joi.number().required(),
  }),
  update: Joi.object().keys({
    name: Joi.string()
      .allow('')
      .optional(),
    profilePic: Joi.string()
      .allow('')
      .optional(),
    gender: Joi.string()
      .allow('')
      .optional(),
    age: Joi.number().optional(),
  }),

  getProgress: Joi.object().keys({
    days: Joi.number().required(),
  }),

  getList: Joi.object().keys({
    recordStatus: Joi.boolean().optional(),
    name: Joi.string()
      .allow('')
      .optional(),
    cgId: Joi.number().optional(),
    gender: Joi.string().optional(),
    age: Joi.number().optional(),
    id: Joi.string().optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number().optional(),
    pageSize: Joi.number().optional(),
  }),
};
