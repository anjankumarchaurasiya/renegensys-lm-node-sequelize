const Joi = require('joi');

module.exports = {
  getAll: Joi.object().keys({
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    categoryId: Joi.string()
      .uuid()
      .optional(),

    categoryIds: Joi.array()
      .items(Joi.string().optional())
      .optional(),
    title: Joi.string().optional(),
    description: Joi.string().optional(),
    recordStatus: Joi.boolean().optional(),
    createdAt: Joi.string().optional(),
  }),

  create: Joi.object().keys({
    feedbackData: Joi.object({
      title: Joi.string().required(),
      description: Joi.string().optional(),
      categoryId: Joi.string()
        .uuid()
        .required(),
    }).required(),

    questionData: Joi.array()
      .items(
        Joi.object({
          question: Joi.string().required(),
          questionType: Joi.string().required(),
          questionCategoryId: Joi.string()
            .uuid()
            .required(),
          order: Joi.number()
            .integer()
            .required(),
          options: Joi.array()
            .items(
              Joi.object({
                option: Joi.string().required(),
                order: Joi.number()
                  .integer()
                  .required(),
              })
            )
            .optional(),
          wordLimit: Joi.number()
            .integer()
            .min(0)
            .optional(),
        })
      )
      .required(),
  }),

  get: Joi.object().keys({
    viewQuestions: Joi.boolean().optional(),
    viewSessions: Joi.boolean().optional(),
    viewBatches: Joi.boolean().optional(),
    batchNumber: Joi.string().optional(),
    linked: Joi.boolean().optional(),
    sessionTitle: Joi.string().optional(),
    courseId: Joi.string()
      .uuid()
      .optional(),
    paginated: Joi.boolean().optional(),
    pageNo: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    pageSize: Joi.number()
      .integer()
      .min(1)
      .when('paginated', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
  }),

  submitFeedback: Joi.object().keys({
    userId: Joi.string()
      .uuid()
      .required(),
    isSessionFeedback: Joi.boolean().required(),
    learningSessionId: Joi.when('isSessionFeedback', {
      is: true,
      then: Joi.string()
        .uuid()
        .required(),
    }),
    batchId: Joi.when('isSessionFeedback', {
      is: false,
      then: Joi.string()
        .uuid()
        .required(),
    }),
    feedbackId: Joi.string()
      .uuid()
      .required(),
    questionData: Joi.array()
      .items(
        Joi.object().keys({
          questionId: Joi.string().required(),
          questionOptionId: Joi.string().optional(),
          response: Joi.string().optional(),
        })
      )
      .required(),
  }),

  updateSessionFeedback: Joi.object({
    isLinked: Joi.boolean().required(),
    sessions: Joi.array()
      .items(
        Joi.string()
          .guid({ version: 'uuidv4' })
          .required()
      )
      .min(1)
      .required(),
  }),
};
