const Joi = require('joi');

module.exports = {
  create: Joi.object().keys({
    question: Joi.string().required(),
  }),
};
