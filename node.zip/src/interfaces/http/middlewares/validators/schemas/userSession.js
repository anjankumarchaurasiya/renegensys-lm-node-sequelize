const Joi = require('joi');

module.exports = {
  refresh: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};
