const httpContext = require('express-cls-hooked');
const uuidv4 = require('uuid/v4');
module.exports = () => {
  return (req, res, next) => {
    httpContext.set('loggedInUser', req?.user);
    //httpContext.set('currentCgEntityType', req?.cgEntityType);
    req.request_id = uuidv4();
    httpContext.set('request_id', req.request_id);
    httpContext.set('apiName', req.baseUrl);
    httpContext.set('reqBody', req.body);
    httpContext.set('reqQuery', req.query);
    httpContext.set('jwtToken', req.jwtToken);
    httpContext.set('resource', req.resource);
    httpContext.set(
      'clientIP',
      (req.headers['x-forwarded-for'] || '')
        .split(',')
        .pop()
        .trim() || req.connection.remoteAddress
    );
    httpContext.set('userAgent', req.userAgent);
    httpContext.set('appVariant', req.headers['x-app-variant']);
    httpContext.set('clientName', req.headers['x-app-client']);
    httpContext.set('appVersion', req.headers['x-app-version']);
    httpContext.set('deviceId', req.headers['x-device-id']);
    httpContext.set('reqIp', req.ip);
    next();
  };
};
