const path = require('path');

module.exports = (moduleName, controllerUri) => {
  const controllerPath = path.join(__dirname, '..', '..', '..', 'modules', moduleName, 'controller', controllerUri);
  const Controller = require(controllerPath);
  return Controller();
};
