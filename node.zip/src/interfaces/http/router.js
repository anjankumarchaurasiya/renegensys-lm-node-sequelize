const cors = require('cors');
const bodyparser = require('body-parser');
const { json, urlencoded } = require('body-parser');
const compression = require('compression');
const { Router } = require('express');
const httpContext = require('express-cls-hooked');
const swaggerUi = require('swagger-ui-express');
const controller = require('./utils/create_controller');
const mongoSanitize = require('express-mongo-sanitize');
const helmet = require('helmet');
const statusMonitor = require('express-status-monitor');
const { generateSwaggerDoc } = require('./swagger');

module.exports = ({ config, containerMiddleware, loggerMiddleware, errorHandlerMiddleware, validatorMiddleware, routeContextMiddleware }) => {
  const router = Router();
  if (config.env === 'development') {
    router.use(statusMonitor());
  }

  if (config.DD_HTTP_LOGS_ENABLED === true) {
    router.use(loggerMiddleware);
  }
  // Create Main Router
  const apiRouter = Router();

  // Register Middleware
  apiRouter
    .use(
      cors({
        // origin: 'https://webonboarding-v2.littlesingham.me',
        origin: [
          'https://webonboarding-v2.littlesingham.me/',
          'https://learningjourney-v2.littlesingham.me/',
          'https://dev-cms-v2.creativegalileo.com',
        ],
        methods: ['GET', 'POST', 'PUT', 'PATCH', 'OPTIONS', 'DELETE'],
        allowedHeaders: ['Content-Type', 'Authorization', 'x-app-variant', 'x-user-type', 'x-app-client', 'x-app-version'],
      })
    )
    .use(
      urlencoded({
        extended: false,
      })
    )
    .use(json())
    .use(compression())
    .use(helmet())
    .use(mongoSanitize())
    .use(httpContext.middleware)
    .use(containerMiddleware);

  apiRouter.use(routeContextMiddleware());
  apiRouter.use(validatorMiddleware());

  /**
   * Health Controller
   */

  apiRouter.use(`/api/V1/health`, controller('health_check', 'index'));

  /**
   * Event Controller
   */

  apiRouter.use(`/api/V1/event`, controller('event', 'index'));

  /**
   * Common Controller
   */
  apiRouter.use(`/api/V1/common`, controller('common', 'index'));

  /**
   * Config Controller
   */
  apiRouter.use(`/api/V1/config`, controller('config', 'index'));

  /**
   * User Controller
   */
  apiRouter.use(`/api/V1/user`, controller('user', 'user_controller'));

  /**
   * Role Controller
   */
  apiRouter.use(`/api/V1/roles`, controller('role_permission', 'index'));

  /**
   * Resource Controller
   */
  apiRouter.use(`/api/V1/resource`, controller('role_permission', 'resource_controller'));

  /**
   * Resource Action Controller
   */
  apiRouter.use(`/api/V1/resource-action`, controller('role_permission', 'resource_action_controller'));

  /**
   * Webhook Controller
   */
  apiRouter.use(`/api/V1/webhook`, controller('webhook', 'webhook_controller'));

  /**
   * Country Controller
   */
  apiRouter.use(`/api/V1/country`, controller('geo', 'country_controller'));

  /**
   * Session Controller
   */
  apiRouter.use(`/api/V1/session`, controller('session', 'user_session_controller'));

  /**
   * Cron Framework Config Controller
   */
  apiRouter.use(`/api/V1/cron-job-framework`, controller('cron_job_framework', 'cron_framework_config_controller'));

  /**
   * User Notification Preference Controller
   */
  apiRouter.use(`/api/V1/user-notification-preference`, controller('notification', 'user_notification_preference_controller'));

  /**
   * Course Controller
   */
  apiRouter.use(`/api/V1/course`, controller('course', 'course_controller'));

  /**
   * Batch Controller
   */
  apiRouter.use(`/api/V1/batch`, controller('batch', 'batch_controller'));

  /**
   * Module Controller
   */
  apiRouter.use(`/api/V1/module`, controller('course', 'module_controller'));

  /**
   * Topic Controller
   */
  apiRouter.use(`/api/V1/topic`, controller('course', 'topic_controller'));

  /**
   * Content Controller
   */
  apiRouter.use(`/api/V1/content`, controller('content', 'content_controller'));

  /**
   * Category Controller
   */
  apiRouter.use(`/api/V1/category`, controller('meta_entities', 'category_controller'));

  /**
   * Quiz Controller
   */
  apiRouter.use(`/api/V1/quiz`, controller('quiz', 'quiz_controller'));

  /**
   * Question Controller
   */
  apiRouter.use(`/api/V1/question`, controller('question', 'question_controller'));

  /**
   * Question Option Controller
   */
  apiRouter.use(`/api/V1/question-option`, controller('question', 'question_option_controller'));

  /**
   *  Meeting Controller
   */
  apiRouter.use(`/api/V1/meeting`, controller('meeting', 'meeting_controller'));

  /**
   * Create Learning Session Controller
   */
  apiRouter.use(`/api/V1/learning-session`, controller('learning_session', 'learning_session_controller'));
  /**
   *  Discussion Forum  Controller
   */
  apiRouter.use(`/api/V1/discussion-forum-thread`, controller('discussion_forum', 'discssion_forum_controller'));
  /**
   * Create Feedback Controller
   */
  apiRouter.use(`/api/V1/feedback`, controller('learning_session', 'feedback_controller'));

  /**
   * Student Controller
   */
  apiRouter.use(`/api/V1/student`, controller('student', 'student_controller'));

  /**
   * Teacher Controller
   */
  apiRouter.use(`/api/V1/teacher`, controller('teacher', 'teacher_controller'));
  /**
   * Site content Controller
   */
  apiRouter.use(`/api/V1/site-content`, controller('site_content', 'site_content_controller'));
  /**
   * Attempt Request Controller
   */
  apiRouter.use(`/api/V1/quiz/attempt-request`, controller('quiz', 'attempt_request_controller'));
  /**
   * Capstone project Controller
   */
  apiRouter.use(`/api/V1/quiz/capstone`, controller('quiz', 'capstone_controller'));

  router.use(`/`, apiRouter);

  // Register Error Handler
  router.use(errorHandlerMiddleware);
  process.env.NODE_ENV && process.env.NODE_ENV !== 'production' && router.use('/docs', swaggerUi.serve, swaggerUi.setup(generateSwaggerDoc(router)));
  return router;
};
