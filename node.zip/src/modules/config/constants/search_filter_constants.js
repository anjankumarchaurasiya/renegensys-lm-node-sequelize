module.exports = Object.freeze({
  config: {
    recordStatus: {
      op: '$eq',
      alias: 'recordStatus',
    },
    name: {
      op: '$like',
      alias: 'name',
    },
    desc: {
      op: '$like',
      alias: 'desc',
    },
  },
});
