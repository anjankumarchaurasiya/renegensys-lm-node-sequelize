const { define } = require('src/containerHelper');

module.exports = define('configMasterRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('config_master');
  const configMaster = database['config_master'];

  const getAllConfig = async (attributes, whereClause, limit, offset) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: [['created_at', 'DESC']],
    };
    if (limit && offset) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return configMaster.findAndCountAll(finalClause);
  };

  const getConfig = async whereClause =>
    configMaster.findOne({
      where: {
        recordStatus: 1,
        ...whereClause,
      },
    });

  const createConfig = async configMasterEntity => configMaster.create(configMasterEntity);

  const updateConfig = (configMasterEntity, id) => configMaster.update(configMasterEntity, { where: { id } });

  const bulkCreate = data => configMaster.bulkCreate(data, { ignoreDuplicates: true });

  return {
    getAllConfig,
    getConfig,
    createConfig,
    updateConfig,
    bulkCreate,
    ...baseRepo,
  };
});
