const { define } = require('src/containerHelper');
const _ = require('lodash');
const searchFilters = require('../constants/search_filter_constants');
module.exports = define('configMasterService', ({
  CustomError,
  generalUtilService,
  constants,
  configMasterRepository,
  logger,
  configUtilService,
  configEnrichmentService,
  constants: { CONTENT_TYPE, ENTITY_NOT_FOUND },
}) => {
  const createConfig = async configMasterEntity => {
    const loggedInCgEntity = generalUtilService.getContextCgEntity();
    const result = await configMasterRepository.createConfig({ ...configMasterEntity, createdBy: loggedInCgEntity?.id });
    return result;
  };

  const updateConfig = async (configMasterEntity, id) => {
    const configObj = await getConfigById({ id: id });
    const loggedInCgEntity = generalUtilService.getContextCgEntity();
    if (_.isEmpty(configObj)) throw new CustomError(constants.RUNTIME_ERROR.code, constants.RUNTIME_ERROR.status, `Config not found !`);
    logger.info(`Config with name : ${configObj.name} updted with the body ${JSON.stringify(configMasterEntity)} by ${loggedInCgEntity.id}`);
    const result = await configMasterRepository.updateConfig({ ...configMasterEntity, updatedBy: loggedInCgEntity?.id }, id);
    return result;
  };

  const getConfigByName = async (configName, schema = 'default') => {
    const res = await configMasterRepository.getConfig({
      name: configName,
      schema,
    });
    return res;
  };
  const getConfigById = async whereClause => {
    const res = await configMasterRepository.findOne(whereClause);
    return res;
  };
  const getAllConfigs = async queryParams => {
    let configResponse;
    if (queryParams.paginated) {
      // Generate search attributes for paginated query
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.config);
      configResponse = await configMasterRepository.getAllConfig(
        ['id', 'schema', 'country_code', 'name', 'config', 'value', 'desc', 'record_status'],
        whereClause,
        limit,
        offset
      );
    } else {
      // Generate search attributes for non-paginated query
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.config);
      configResponse = await configMasterRepository.getAllConfig(
        ['id', 'schema', 'country_code', 'name', 'config', 'value', 'desc', 'record_status'],
        whereClause
      );
    }
    return { count: configResponse.count, configs: configResponse.rows };
  };

  const getConfig = async queryParams => {
    const { configName } = queryParams;
    let enrichedData;
    const config = await configMasterRepository.getConfig({
      name: configName,
    });
    if (config) {
      const parsedEventConfig = await configUtilService.parseConfig(config, queryParams);

      if (parsedEventConfig.variables.configType == 'enrichConfig') {
        const variableConfig = parsedEventConfig.variables;
        enrichedData = await configEnrichmentService.configDataEnrichment(variableConfig);
      }
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `config not found `);
    }

    return enrichedData;
  };

  const bulkCreateConfig = data => configMasterRepository.bulkCreate(data);

  const deactivateConfig = id => configMasterRepository.deactivate({ id: id });
  return {
    createConfig,
    updateConfig,
    getConfigById,
    getConfigByName,
    bulkCreateConfig,
    getConfig,
    getAllConfigs,
    deactivateConfig,
  };
});
