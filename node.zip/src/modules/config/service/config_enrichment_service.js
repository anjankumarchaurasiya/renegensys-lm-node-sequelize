const { define } = require('src/containerHelper');
const _ = require('lodash');

module.exports = define('configEnrichmentService', ({}) => {
  const ENRICH_HANDLER = {};
  const configDataEnrichment = async dataObj => {
    // const enrichedObj = {};

    return dataObj;
  };

  return {
    configDataEnrichment,
  };
});
