const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { CONFIG_CREATED_SUCCESSFULLY, CONFIG_UPDATED_SUCCESSFULLY, CONFIG_DEACTIVATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
    authorizeMiddleware,
  } = container.cradle;
  const { configMasterService, logger } = container.cradle;

  // router.use(auth.authenticate(true));
  //router.use(userContextMiddleware);
  router.post('/', auth.authenticate(), userContextMiddleware, async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create config route');
      let data = await configMasterService.createConfig(body);
      res.status(Status.OK).json(await Success(data, CONFIG_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:id', auth.authenticate(), userContextMiddleware, async (req, res, next) => {
    try {
      const {
        body,
        params: { id },
      } = req;
      logger.info('Update config route');
      let data = await configMasterService.updateConfig(body, id);
      res.status(Status.OK).json(await Success(data, CONFIG_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info('get  config route');
      const result = await configMasterService.getConfig(query);
      res.status(Status.OK).json(await Success(result));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter', auth.authenticate(), userContextMiddleware, async (req, res, next) => {
    try {
      const { query } = req;
      logger.info('get all config route');
      const result = await configMasterService.getAllConfigs(query);
      res.status(Status.OK).json(await Success(result));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:id', async (req, res, next) => {
    try {
      const {
        params: { id },
      } = req;
      await configMasterService.deactivateConfig(id);
      let data;
      res.status(Status.OK).json(await Success(data, CONFIG_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
