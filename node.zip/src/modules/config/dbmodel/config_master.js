'use strict';
module.exports = (sequelize, DataTypes) => {
  const ConfigMaster = sequelize.define(
    'config_master',
    {
      id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        autoIncrement: false,
      },
      schema: {
        type: DataTypes.STRING,
        default: 'default',
        allowNull: false,
      },
      countryCode: {
        type: DataTypes.STRING,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      config: {
        type: DataTypes.JSON, //  config like { subject: from: , to_expr: }
      },
      value: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      desc: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      updatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  ConfigMaster.associate = function(models) {};
  return ConfigMaster;
};
