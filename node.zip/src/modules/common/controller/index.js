const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
var multer = require('multer');
var upload = multer({ dest: 'resources/output/' });
const {
  SEND_MESSAGE_TO_QUEUE_SUCCESS,
  FILE_UPLOAD_SUCCESS,
  FILE_DOWNLOAD_SUCCESS,
  LOG_ROTATOR_SUCCESS,
  ENCRYPT_DECRYPT_SUCCESS,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
    authorizeMiddleware,
  } = container.cradle;
  const { commonUtilService, logger, generalUtilService, encryptDecryptService } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/send-message', async (req, res, next) => {
    try {
      logger.info(`Common controller Send message to Queue`);
      await commonUtilService.sendMessageToQueue(req.body);
      let data;
      res.status(Status.OK).json(await Success(data, SEND_MESSAGE_TO_QUEUE_SUCCESS));
    } catch (e) {
      next(e);
    }
  });

  router.post('/s3/file-upload', auth.authenticate(), userContextMiddleware, async (req, res, next) => {
    try {
      logger.info(`Common controller Upload File`);
      const {
        files,
        body: { uniqueId, folderName, bucketName, fileName, entityName, entityType },
      } = req;
      await generalUtilService.validateInputForFile(files);

      let data = await generalUtilService.uploadFile({
        files,
        bucketName,
        folderName,
        overWriteFileName: fileName,
        uniqueId,
        entityName,
        entityType,
      });
      res.status(Status.OK).json(await Success(data, FILE_UPLOAD_SUCCESS));
    } catch (e) {
      next(e);
    }
  });

  router.get('/file-download', async (req, res, next) => {
    try {
      logger.info(`Common controller to download file`);
      const { query } = req;
      const result = await commonUtilService.downloadFile(query);
      res.setHeader('Content-Disposition', 'attachment; filename="data.xlsx"');
      res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.send(result);
      // res.status(Status.OK).json(await Success('OK'));
      // res.send(result);
    } catch (e) {
      next(e);
    }
  });

  router.get('/log-rotator', async (req, res, next) => {
    try {
      logger.info(`Log rotator API`);
      const result = await commonUtilService.logRotate();
      res.status(Status.OK).json(await Success('OK'));
    } catch (e) {
      next(e);
    }
  });
  router.get('/encrypt-decrypt', async (req, res, next) => {
    try {
      logger.info(`Encrypt Decrypt API`);
      const result = await encryptDecryptService.encrypt();
      res.status(Status.OK).json(await Success('OK'));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
