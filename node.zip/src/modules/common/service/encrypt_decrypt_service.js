const crypto = require('crypto');
const fs = require('fs');
const { define } = require('src/containerHelper');

module.exports = define('encryptDecryptService', ({ logger, redisClient }) => {
  const vectorValue = 'D5CEC9DBA5FCE18B1F7D2F6BD5CD6E1E';
  const saltValue = 'C718C685CD7C3D1EAC3C571AE6FE8886';
  const strKey = 'eRcsdE5hW';
  const iterations = 1000;
  const salt = Buffer.from(saltValue, 'utf-8');
  const generateKey = async (strPassword, salt, iterations) => {
    return crypto.pbkdf2Sync(strPassword, salt, iterations, 16, 'sha1');
  };

  // Encryption function
  const encrypt = async (strPassword, vector) => {
    const key = await generateKey(strKey, salt, iterations);
    const cipher = crypto.createCipheriv('aes-128-cbc', key, Buffer.from(vector, 'hex'));
    let encrypted = cipher.update(strPassword, 'utf-8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
  };

  // Decryption function
  const decrypt = async (encryptedText, vector) => {
    const key = await generateKey(strKey, salt, iterations);
    const decipher = crypto.createDecipheriv('aes-128-cbc', key, Buffer.from(vector, 'hex'));
    let decrypted = decipher.update(encryptedText, 'base64', 'utf-8');
    decrypted += decipher.final('utf-8');
    return decrypted;
  };

  return {
    decrypt,
    encrypt,
  };
});
