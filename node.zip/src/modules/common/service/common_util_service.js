const { define, getService } = require('src/containerHelper');
const fs = require('fs');
const path = require('path');
const util = require('util');
module.exports = define('commonUtilService', ({ awsService, config, logger, fileUtilService, configMasterService }) => {
  const sendMessageToQueue = body => {
    const queueName = config.AWS.SQS.APP_EVENT_SQS_NAME;
    const { eventName, eventType, data } = body;
    awsService.sendToQueue(queueName, { eventName, eventType, data });
  };

  const downloadFile = async queryParams => {
    const { entityName } = queryParams;
    const configName = `FILE_EXPORT_CONFIG`;
    const configFound = await configMasterService.getConfigByName(configName);
    if (configFound) {
      if (configFound.config && configFound.config[entityName]) {
        const fileExportConfig = configFound.config[entityName];
        if (fileExportConfig) {
          const { serviceName, methodName } = fileExportConfig;
          if (serviceName && methodName) {
            let serviceCls = getService(serviceName);
            let methodObj = serviceCls[methodName];
            if (typeof methodObj === 'function') {
              try {
                const foundList = await methodObj(fileExportConfig.attributes);
                if (fileExportConfig.fileType == 'xlsx') {
                  const excelBuffer = fileUtilService.covertDatatoXlsFile(foundList);
                  return excelBuffer;
                }
              } catch (e) {
                logger.error(`some thing went wrong while calling ${methodName} in ${serviceName}`, e);
              }
            } else {
              logger.error(`Method not found : ${methodName} of service: ${serviceName}`);
            }
          } else {
            logger.error(`Service Name and Method Name not found in config `);
          }
        }
      } else {
        logger.error(`file export config not found for ${entityName}`);
      }
    }
  };

  const jsonParse = data => {
    try {
      if (typeof data != 'string') return null;
      return JSON.parse(data);
    } catch (e) {
      logger.error(`unable to parse json data ${data}`);
      return null;
    }
  };

  const logRotate = async () => {
    const logDirectory = path.join(__dirname, '../../../../logs');
    const daysToKeepLogs = 14; // Adjust as needed
    const now = new Date();
    const cutoffDate = new Date(now - daysToKeepLogs * 24 * 60 * 60 * 1000);
    try {
      fs.readdirSync(logDirectory).forEach(file => {
        const filePath = path.join(logDirectory, file);
        const fileStat = fs.statSync(filePath);
        if (fileStat.isFile() && fileStat.mtime < cutoffDate) {
          fs.unlinkSync(filePath);
          logger.info(`Deleted log file: ${filePath}`);
        }
      });
    } catch (e) {
      logger.error(`Something went wrong while deleting log file`, e);
    }
  };

  const generateOTP = (n = config.otpLength) => String(Math.floor(Math.random() * 10 ** n)).padStart(n, '0');

  const toLsUnderScore = data =>
    data
      .toLowerCase()
      .split(' ')
      .join('_');

  return {
    sendMessageToQueue,
    downloadFile,
    jsonParse,
    logRotate,
    generateOTP,
    toLsUnderScore,
  };
});
