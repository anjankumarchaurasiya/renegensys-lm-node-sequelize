const moment = require('moment');
const { define } = require('src/containerHelper');

module.exports = define('rateLimiterService', ({ logger, redisClient }) => {
  const checkRateLimit = async (cacheName, entityName, windowSeconds, maxQueueLength) => {
    const key = parseInt(moment().valueOf() / (1000 * windowSeconds));
    let data = await redisClient.incr(cacheName, key);
    if (data) {
      if (parseInt(data) === 1) {
        await redisClient.expire(cacheName, key, windowSeconds);
      }
      if (data < maxQueueLength) {
        return { result: true, data, key };
      } else {
        return { result: false, data, key };
      }
    } else {
      logger.info('redis client incr should not happen');
    }
  };

  return {
    checkRateLimit,
  };
});
