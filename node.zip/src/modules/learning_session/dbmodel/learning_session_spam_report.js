'use strict';

module.exports = (sequelize, DataTypes) => {
  const learningSessionSpamReport = sequelize.define(
    'learning_session_spam_report',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      reportedBy: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      spamReason: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      warningGiven: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  learningSessionSpamReport.associate = function(models) {
    learningSessionSpamReport.belongsTo(models.learning_session, {
      as: 'LearningSession',
      foreignKey: 'learningSessionId',
      targetKey: 'id',
    });
    learningSessionSpamReport.belongsTo(models.user, {
      as: 'User',
      foreignKey: 'userId',
      targetKey: 'id',
    });
    learningSessionSpamReport.belongsTo(models.user, {
      as: 'ReportedBy',
      foreignKey: 'reportedBy',
      targetKey: 'id',
    });
  };
  return learningSessionSpamReport;
};
