'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSessionFeedback = sequelize.define(
    'learning_session_feedback',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      feedbackId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  LearningSessionFeedback.associate = function(models) {
    LearningSessionFeedback.belongsTo(models.learning_session, {
      foreignKey: 'learningSessionId',
      targetKey: 'id',
    });
    LearningSessionFeedback.belongsTo(models.feedback, {
      foreignKey: 'feedbackId',
      targetKey: 'id',
    });
  };
  return LearningSessionFeedback;
};
