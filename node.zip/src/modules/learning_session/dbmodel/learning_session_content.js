'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSessionContent = sequelize.define(
    'learning_session_content',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      contentId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      type: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  LearningSessionContent.associate = function(models) {
    LearningSessionContent.belongsTo(models.learning_session, {
      foreignKey: 'learningSessionId',
      targetKey: 'id',
      allowNull: false,
    });
    LearningSessionContent.belongsTo(models.content, {
      foreignKey: 'contentId',
      targetKey: 'id',
      allowNull: false,
    });
  };
  return LearningSessionContent;
};
