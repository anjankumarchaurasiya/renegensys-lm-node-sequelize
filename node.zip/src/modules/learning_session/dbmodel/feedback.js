'use strict';

module.exports = (sequelize, DataTypes) => {
  const Feedback = sequelize.define(
    'feedback',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.STRING,
      },
      categoryId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },

      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  Feedback.associate = function(models) {
    Feedback.hasMany(models.learning_session_feedback_user_response, {
      foreignKey: 'feedbackId',
      sourceKey: 'id',
    });
    Feedback.hasMany(models.learning_session_feedback, {
      foreignKey: 'feedbackId',
      sourceKey: 'id',
    });
    Feedback.belongsTo(models.category, {
      foreignKey: 'categoryId',
      targetKey: 'id',
    });
    Feedback.belongsToMany(models.learning_session, {
      through: models.learning_session_feedback,
      foreignKey: 'feedbackId',
      otherKey: 'learningSessionId',
    });
    Feedback.hasMany(models.feedback_question, {
      foreignKey: 'feedbackId',
      sourceKey: 'id',
    });
  };
  return Feedback;
};
