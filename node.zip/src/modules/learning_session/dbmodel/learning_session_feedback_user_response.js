'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSessionFeedbackUserResponse = sequelize.define(
    'learning_session_feedback_user_response',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      feedbackId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      questionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      questionOptionId: {
        type: DataTypes.UUID,
      },
      response: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  LearningSessionFeedbackUserResponse.associate = function(models) {
    LearningSessionFeedbackUserResponse.belongsTo(models.question, {
      foreignKey: 'questionId',
      id: 'id',
    });
    LearningSessionFeedbackUserResponse.belongsTo(models.question_option, {
      foreignKey: 'questionOptionId',
      id: 'id',
    });
    LearningSessionFeedbackUserResponse.belongsTo(models.learning_session, {
      foreignKey: 'learningSessionId',
      targetKey: 'id',
    });
    LearningSessionFeedbackUserResponse.belongsTo(models.user, {
      foreignKey: 'userId',
      targetKey: 'id',
    });
    LearningSessionFeedbackUserResponse.belongsTo(models.feedback, {
      foreignKey: 'feedbackId',
      targetKey: 'id',
    });
  };
  return LearningSessionFeedbackUserResponse;
};
