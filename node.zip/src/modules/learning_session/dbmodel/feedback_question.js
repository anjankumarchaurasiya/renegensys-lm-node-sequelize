'use strict';

module.exports = (sequelize, DataTypes) => {
  const FeedbackQuestion = sequelize.define(
    'feedback_question',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      questionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      feedbackId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      wordLimit: {
        type: DataTypes.INTEGER,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  FeedbackQuestion.associate = function(models) {
    FeedbackQuestion.belongsTo(models.question, {
      foreignKey: 'questionId',
      targetKey: 'id',
    });
    FeedbackQuestion.belongsTo(models.feedback, {
      foreignKey: 'feedbackId',
      targetKey: 'id',
    });
  };
  return FeedbackQuestion;
};
