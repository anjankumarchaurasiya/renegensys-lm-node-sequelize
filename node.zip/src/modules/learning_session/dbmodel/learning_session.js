'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSession = sequelize.define(
    'learning_session',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      courseId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      srmId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      primaryFacultyId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      secondaryFacultyId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      startTime: {
        type: DataTypes.TIME,
        allowNull: false,
      },
      actualStartTime: {
        type: DataTypes.TIME,
      },
      actualEndTime: {
        type: DataTypes.TIME,
      },
      endTime: {
        type: DataTypes.TIME,
        allowNull: false,
      },
      meetingStartUrl: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      meetingUrl: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      status: {
        type: DataTypes.STRING,
        defaultValue: false,
      },
      reason: {
        type: DataTypes.STRING,
      },
      cancelledBy: {
        type: DataTypes.UUID,
      },
      meetingPlatform: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  LearningSession.associate = function(models) {
    LearningSession.belongsTo(models.course, {
      foreignKey: 'courseId',
      targetKey: 'id',
    });
    LearningSession.belongsTo(models.batch, {
      foreignKey: 'batchId',
      targetKey: 'id',
    });

    LearningSession.belongsTo(models.user, {
      as: 'PrimaryFaculty',
      foreignKey: 'primaryFacultyId',
      targetKey: 'id',
    });
    LearningSession.belongsTo(models.user, {
      as: 'SecondaryFaculty',
      foreignKey: 'secondaryFacultyId',
      targetKey: 'id',
    });
    LearningSession.belongsTo(models.user, {
      as: 'SRM',
      foreignKey: 'srmId',
      targetKey: 'id',
    });

    LearningSession.hasMany(models.learning_session_quiz, {
      foreignKey: 'learningSessionId',
      sourceKey: 'id',
    });
    LearningSession.belongsToMany(models.quiz, {
      through: models.learning_session_quiz,
      foreignKey: 'learningSessionId',
      otherKey: 'quizId',
    });
    LearningSession.belongsToMany(models.module, {
      through: models.learning_session_module,
      foreignKey: 'learningSessionId',
      uniqueKey: 'learning_session_module_unique',
    });
    LearningSession.hasMany(models.learning_session_module, {
      foreignKey: 'learningSessionId',
      sourceKey: 'id',
    });
    LearningSession.belongsToMany(models.learning_session_content, {
      through: models.learning_session_content,
      foreignKey: 'learningSessionId',
      uniqueKey: 'learning_session_content_unique',
    });
    LearningSession.hasMany(models.learning_session_content, {
      foreignKey: 'learningSessionId',
      sourceKey: 'id',
    });
    LearningSession.hasMany(models.learning_session_feedback, {
      foreignKey: 'learningSessionId',
      sourceKey: 'id',
    });
    LearningSession.belongsToMany(models.feedback, {
      through: models.learning_session_feedback,
      foreignKey: 'learningSessionId',
      other: 'feedbackId',
    });
    LearningSession.hasMany(models.batch_quiz, {
      foreignKey: 'batchId',
      sourceKey: 'batchId',
    });
  };

  return LearningSession;
};
