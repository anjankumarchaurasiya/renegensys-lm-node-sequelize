'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSessionProgress = sequelize.define(
    'learning_session_progress',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      moduleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      topicId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  LearningSessionProgress.associate = function(models) {
    LearningSessionProgress.belongsTo(models.learning_session, {
      foreignKey: 'learningSessionId',
      targetKey: 'id',
    });
    LearningSessionProgress.belongsTo(models.module, {
      foreignKey: 'moduleId',
      targetKey: 'id',
    });
    LearningSessionProgress.belongsTo(models.user, {
      foreignKey: 'userId',
      targetKey: 'id',
    });
    LearningSessionProgress.belongsTo(models.topic, {
      foreignKey: 'topicId',
      targetKey: 'id',
    });
    LearningSessionProgress.belongsTo(models.batch, {
      foreignKey: 'batchId',
      targetKey: 'id',
    });
  };
  return LearningSessionProgress;
};
