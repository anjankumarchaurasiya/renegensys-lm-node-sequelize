'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSessionModule = sequelize.define(
    'learning_session_module',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      moduleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },

      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  LearningSessionModule.associate = function(models) {
    LearningSessionModule.belongsTo(models.learning_session, {
      foreignKey: 'learningSessionId',
      targetKey: 'id',
    });
    LearningSessionModule.belongsTo(models.module, {
      foreignKey: 'moduleId',
      targetKey: 'id',
    });
  };
  return LearningSessionModule;
};
