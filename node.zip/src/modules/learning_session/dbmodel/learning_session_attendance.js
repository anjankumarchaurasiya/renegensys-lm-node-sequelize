'use strict';

module.exports = (sequelize, DataTypes) => {
  const LearningSessionAttendance = sequelize.define(
    'learning_session_attendance',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      learningSessionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      roleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      inTime: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      outTime: {
        type: DataTypes.DATE,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  LearningSessionAttendance.associate = function(models) {
    LearningSessionAttendance.belongsTo(models.learning_session, {
      foreignKey: 'learningSessionId',
      targetKey: 'id',
    });
    LearningSessionAttendance.belongsTo(models.user, {
      foreignKey: 'userId',
      targetKey: 'id',
    });
    LearningSessionAttendance.hasMany(models.role, {
      foreignKey: 'roleId',
      id: 'id',
    });
  };
  return LearningSessionAttendance;
};
