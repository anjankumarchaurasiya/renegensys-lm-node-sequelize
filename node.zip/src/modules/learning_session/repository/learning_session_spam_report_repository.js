const { define } = require('src/containerHelper');
const { Op } = require('sequelize');

module.exports = define('learningSessionSpamReportRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_spam_report');
  const learningSessionSpamReportModel = database['learning_session_spam_report'];
  const userModel = database['user'];
  const learningSessionModel = database['learning_session'];

  const bulkCreate = data =>
    learningSessionSpamReportModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getLearningSessionSpamFind = async (learningSessionId, attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForUser, whereClauseForReportedBy;
    const whereClauseForSpamReport = {};
    if (whereClause?.srmId) {
      whereClauseForSpamReport[`$LearningSession.SRM.id$`] = whereClause.srmId;
      delete whereClause.srmId;
    }

    if (whereClause?.userName) {
      whereClauseForUser = {
        [Op.or]: [{ firstName: whereClause.userName }, { lastName: whereClause.userName }],
      };
      delete whereClause.userName;
    }

    if (whereClause?.reportedByName) {
      whereClauseForReportedBy = {
        [Op.or]: [{ firstName: whereClause.reportedByName }, { lastName: whereClause.reportedByName }],
      };
      delete whereClause.reportedByName;
    }

    if (whereClause.date) {
      whereClauseForSpamReport['$LearningSession.date$'] = whereClause.date;
      delete whereClause.date;
    }

    if (learningSessionId) {
      whereClauseForSpamReport.learningSessionId = learningSessionId;
    }

    const finalClause = {
      attributes: attributes,
      where: whereClauseForSpamReport,
      order: orderBy,
      include: [
        {
          model: userModel,
          as: 'User',
          attributes: ['firstName', 'lastName'],
          where: whereClauseForUser,
        },
        {
          model: userModel,
          as: 'ReportedBy',
          attributes: ['firstName', 'lastName'],
          where: whereClauseForReportedBy,
        },
        {
          model: learningSessionModel,
          as: 'LearningSession',
          attributes: ['id', 'startTime', 'endTime', 'date'],
          include: [
            {
              model: userModel,
              as: 'SRM',
              attributes: ['firstName', 'lastName'],
            },
          ],
        },
      ],
    };

    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }
    return learningSessionSpamReportModel.findAndCountAll(finalClause);
  };
  return {
    ...baseRepo,
    bulkCreate,
    getLearningSessionSpamFind,
  };
});
