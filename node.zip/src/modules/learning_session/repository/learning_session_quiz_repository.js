const { define } = require('src/containerHelper');

module.exports = define('learningSessionQuizRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_quiz');
  const learningSessionQuizModel = database['learning_session_quiz'];
  const learningSessionModel = database['learning_session'];
  const batchModel = database['batch'];
  const courseModel = database['course'];

  const bulkCreate = data => learningSessionQuizModel.bulkCreate(data, { ignoreDuplicates: true });

  const getlearningSessionOfQuiz = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForLearningSession = {};

    if (whereClause.title) {
      whereClauseForLearningSession.title = whereClause.title;
      delete whereClause.title;
    }
    if (whereClause.batch_id) {
      whereClauseForLearningSession.batch_id = whereClause.batch_id;
      delete whereClause.batch_id;
    }

    if (whereClause.course_id) {
      whereClauseForLearningSession.course_id = whereClause.course_id;
      delete whereClause.course_id;
    }
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      required: false,
      include: [
        {
          model: learningSessionModel,
          attributes: ['id', 'title', 'batchId', 'courseId', 'date', 'startTime', 'endTime', 'status'],
          where: whereClauseForLearningSession,
          required: false,
          include: [
            {
              model: courseModel,
              attributes: ['id', 'title'],
            },
            {
              model: batchModel,
              attributes: ['id', 'batchNumber'],
            },
          ],
        },
      ],
    };
    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return learningSessionQuizModel.findAndCountAll(finalClause);
  };
  return {
    ...baseRepo,
    bulkCreate,
    getlearningSessionOfQuiz,
  };
});
