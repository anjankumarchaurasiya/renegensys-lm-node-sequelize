const { define } = require('src/containerHelper');

module.exports = define('learningSessionProgressRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_progress');
  const learningSessionProgressModel = database['learning_session_progress'];

  const bulkCreate = data =>
    learningSessionProgressModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getSessionProgress = async learningSessionId => {
    try {
      const sessionProgress = await learningSessionProgressModel.findAll({
        where: {
          learningSessionId,
          recordStatus: true,
        },
      });

      return sessionProgress;
    } catch (error) {
      throw new Error(error);
    }
  };

  return {
    ...baseRepo,
    bulkCreate,
    getSessionProgress,
  };
});
