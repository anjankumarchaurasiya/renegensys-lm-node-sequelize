const { define } = require('src/containerHelper');

const { Sequelize, Op } = require('sequelize');

module.exports = define('feedbackRepository', ({ database, baseRepositoryV2, logger }) => {
  const baseRepo = baseRepositoryV2('feedback');
  const feedbackModel = database['feedback'];
  const questionModel = database['question'];
  const questionOptionModel = database['question_option'];
  const feedbackQuestionModel = database['feedback_question'];
  const categoryModel = database['category'];
  const learningSessionModel = database['learning_session'];
  const batchModel = database['batch'];
  const courseModel = database['course'];

  const learningSessionFeedbackModel = database['learning_session_feedback'];

  const bulkCreate = data =>
    feedbackModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getAllFeedbacks = async (attributes, whereClause, orderBy, limit, offset) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: feedbackQuestionModel,
          attributes: ['id'],
        },
        {
          model: categoryModel,
          attributes: ['id', 'name'],
        },
      ],
    };

    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }

    const result = await feedbackModel.findAndCountAll(finalClause);

    result.rows = result.rows.map(feedback => {
      const numQuestions = feedback.feedback_questions.length;
      delete feedback.dataValues.feedback_questions;
      return {
        ...feedback.toJSON(),
        numQuestions: numQuestions,
      };
    });
    return result;
  };

  const getFeedback = async (feedBackId, viewQuestions) => {
    try {
      const queryOptions = {
        where: { id: feedBackId },
      };

      if (viewQuestions) {
        queryOptions.include = [
          {
            model: feedbackQuestionModel,
            attributes: ['id'],
            include: [
              {
                model: questionModel,
                attributes: ['id', 'question', 'question_type', 'created_at'],
                include: [
                  {
                    model: questionOptionModel,
                    attributes: ['id', 'option'],
                  },
                ],
              },
            ],
          },
        ];
      }

      return await feedbackModel.findOne(queryOptions);
    } catch (error) {
      logger.error('Error in get Specific Quiz:', error);
      throw error;
    }
  };

  const getFeedbackWithSession = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForSession = {};
    let whereClauseForBatch = {};
    let whereClauseForCourse = {};

    if (whereClause.title) {
      whereClauseForSession.title = whereClause.title;
      delete whereClause.title;
    }

    if (whereClause.batch_number) {
      whereClauseForBatch.batch_number = whereClause.batch_number;
      delete whereClause.batch_number;
    }

    if (whereClause.course_id) {
      whereClauseForCourse.id = whereClause.course_id;
      delete whereClause.course_id;
    }
    if (whereClause.linked) {
      whereClause.record_status = whereClause.linked;
      delete whereClause.linked;
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: learningSessionModel,
          attributes: ['id', 'title', 'date', 'startTime', 'endTime', 'status'],
          where: whereClauseForSession,
          include: [
            {
              model: batchModel,
              where: whereClauseForBatch,
              attributes: ['id', 'batchNumber', 'courseId'],
              include: [
                {
                  model: courseModel,
                  where: whereClauseForCourse,
                  attributes: ['id', 'title'],
                },
              ],
            },
          ],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return learningSessionFeedbackModel.findAndCountAll(finalClause);
  };

  const getFeedbackWithBatch = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForCourse = {};

    if (whereClause.title) {
      delete whereClause.title;
    }
    if (whereClause.linked) {
      delete whereClause.linked;
    }

    if (whereClause.course_id) {
      whereClauseForCourse.id = whereClause.course_id;
      delete whereClause.course_id;
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: courseModel,
          where: whereClauseForCourse,
          attributes: ['id', 'title'],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return batchModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    getAllFeedbacks,
    getFeedback,
    getFeedbackWithSession,
    getFeedbackWithBatch,
  };
});
