const { define } = require('src/containerHelper');

module.exports = define('feedbackQuestionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('feedback_question');
  const feedbackQuestionModel = database['feedback_question'];

  const bulkCreate = data =>
    feedbackQuestionModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
