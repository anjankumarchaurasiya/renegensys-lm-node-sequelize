const { define } = require('src/containerHelper');

const Sequelize = require('sequelize');

module.exports = define('learningSessionModuleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_module');
  const learningSessionModuleModel = database['learning_session_module'];

  const getUniqueModuleIds = async (learningSessionId, moduleIds = []) => {
    try {
      const whereCondition = { learningSessionId };
      if (moduleIds.length > 0) {
        whereCondition.moduleId = { [Sequelize.Op.in]: moduleIds };
      }

      const uniqueModuleIds = await learningSessionModuleModel.findAll({
        where: whereCondition,
        attributes: ['moduleId'],
        distinct: true,
      });

      const moduleIdsToUpdate = uniqueModuleIds.map(item => item.moduleId);

      await learningSessionModuleModel.update(
        { recordStatus: true },
        {
          where: {
            learningSessionId,
            moduleId: { [Sequelize.Op.in]: moduleIdsToUpdate },
            recordStatus: false,
          },
        }
      );

      return uniqueModuleIds.map(module => module.moduleId);
    } catch (error) {
      throw new Error(`Error fetching unique module IDs: ${error.message}`);
    }
  };

  const bulkCreate = data => learningSessionModuleModel.bulkCreate(data, { ignoreDuplicates: true });

  return {
    ...baseRepo,
    bulkCreate,
    getUniqueModuleIds,
  };
});
