const { define } = require('src/containerHelper');

module.exports = define('learningSessionFeedbackRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_feedback');
  const learningSessionFeedbackModel = database['learning_session_feedback'];

  const bulkCreate = data =>
    learningSessionFeedbackModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
