const { define } = require('src/containerHelper');
const { Op, fn, col, where } = require('sequelize');
module.exports = define('learningSessionFeedbackUserResponseRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_feedback_user_response');
  const learningSessionFeedbackUserResponseModel = database['learning_session_feedback_user_response'];
  const userModel = database['user'];
  const feedbackModel = database['feedback'];
  const learningSessionModel = database['learning_session'];
  const categoryModel = database['category'];
  const bulkCreate = data =>
    learningSessionFeedbackUserResponseModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getLearningSessionFeedbackUserResponse = async (learningSessionId, attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForUser = {},
      whereClauseForFeedback = {},
      whereClauseForLearningSession = {};
    const whereClauseForLearningSessionFeedBackUser = {};

    whereClauseForUser[Op.and] = [];
    if (whereClause?.name) {
      let searchPattern = whereClause.name['$like'].replace(/%/g, '');
      searchPattern = `%${searchPattern.split(' ').join('%')}%`;
      whereClauseForUser[Op.and].push(where(fn('concat', col('first_name'), ' ', col('last_name')), { [Op.like]: searchPattern }));
      delete whereClause.name;
    }

    if (learningSessionId) {
      whereClauseForLearningSessionFeedBackUser.learning_session_id = learningSessionId;
    }
    if (whereClause?.primary_faculty_id) {
      whereClauseForLearningSession.primary_faculty_id = whereClause.primary_faculty_id;
      delete whereClause.primary_faculty_id;
    }

    if (whereClause?.feedback_category_id) {
      whereClauseForFeedback.category_id = whereClause.feedback_category_id;
      delete whereClause.feedback_category_id;
    }
    const finalClause = {
      attributes: attributes,
      where: whereClauseForLearningSessionFeedBackUser,
      order: orderBy,
      include: [
        {
          model: feedbackModel,
          attributes: ['id', 'title', 'description', 'categoryId'],
          where: whereClauseForFeedback,
          include: [
            {
              model: categoryModel,
              attributes: ['id', 'name', 'type'],
            },
          ],
        },
        {
          model: userModel,
          attributes: ['firstName', 'lastName'],
          where: whereClauseForUser,
        },
        {
          model: learningSessionModel,
          attributes: ['id', 'title', 'batchId', 'courseId', 'srmId', 'primaryFacultyId', 'secondaryFacultyId'],
          where: whereClauseForLearningSession,
          include: [
            {
              model: userModel,
              as: 'PrimaryFaculty',
              attributes: ['firstName', 'lastName'],
            },
          ],
        },
      ],
    };

    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }
    return learningSessionFeedbackUserResponseModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    getLearningSessionFeedbackUserResponse,
  };
});
