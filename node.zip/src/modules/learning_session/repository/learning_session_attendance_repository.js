const { define } = require('src/containerHelper');

module.exports = define('learningSessionAttendanceRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_attendance');
  const learningSessionAttendanceModel = database['learning_session_attendance'];
  const userModel = database['user'];

  const bulkCreate = data =>
    learningSessionAttendanceModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getAllLearningSessionsAttendance = async (attributes, whereClause, orderBy, limit, offset) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      include: [
        {
          model: userModel,
          attributes: ['firstName', 'lastName'],
        },
      ],
    };

    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }
    return learningSessionAttendanceModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    getAllLearningSessionsAttendance,
  };
});
