const { define } = require('src/containerHelper');
const { Op } = require('sequelize');
const { SESSION_STATE } = require('src/constants');

module.exports = define('learningSessionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session');
  const learningSessionModel = database['learning_session'];
  const userModel = database['user'];
  const courseModel = database['course'];
  const batchModel = database['batch'];
  const moduleModel = database['module'];
  const contentModel = database['content'];
  const feedbackModel = database['feedback'];
  const learningSessionFeedbackModel = database['learning_session_feedback'];
  const learningSessionModuleModel = database['learning_session_module'];
  const topicModel = database['topic'];
  const learningSessionContentModel = database['learning_session_content'];

  const bulkCreate = data => learningSessionModel.bulkCreate(data, { ignoreDuplicate: true });

  const getAllLearningSessions = async (attributes, whereClause, orderBy, state, limit, offset) => {
    if (state == SESSION_STATE.INPROGRESS) {
      const currentDate = new Date();
      const currentDateStr = currentDate.toISOString().split('T')[0]; // YYYY-MM-DD format
      const currentTimeStr = currentDate
        .toISOString()
        .split('T')[1]
        .substring(0, 8);

      const fifteenMinutesFromNow = new Date(currentDate.getTime() + 15 * 60000);
      const fifteenMinutesFromNowStr = fifteenMinutesFromNow
        .toISOString()
        .split('T')[1]
        .substring(0, 8);

      whereClause = {
        ...whereClause,
        [Op.or]: [
          {
            date: currentDateStr,
            [Op.and]: [{ startTime: { [Op.lte]: currentTimeStr } }, { endTime: { [Op.gte]: currentTimeStr } }],
          },
          {
            date: currentDateStr, // Assuming sessions can't span multiple days
            [Op.and]: [{ startTime: { [Op.lte]: fifteenMinutesFromNowStr } }, { endTime: { [Op.gte]: currentTimeStr } }],
          },
        ],
      };
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: userModel,
          as: 'PrimaryFaculty',
          attributes: ['firstName', 'lastName'],
        },
        {
          model: userModel,
          as: 'SecondaryFaculty',
          attributes: ['firstName', 'lastName'],
        },
        {
          model: userModel,
          as: 'SRM',
          attributes: ['firstName', 'lastName'],
        },
        {
          model: courseModel,
          attributes: ['title'],
        },
        {
          model: batchModel,
          attributes: ['batchNumber', 'id', 'startDate', 'endDate', 'classMode'],
        },
        {
          model: feedbackModel,
          attributes: ['id', 'title', 'description', 'categoryId', 'recordStatus'],
          through: {
            model: learningSessionFeedbackModel,
            attributes: ['id', 'recordStatus', 'createdAt'],
          },
        },
        {
          model: learningSessionModuleModel,
          attributes: ['id'],
          include: [
            {
              model: moduleModel,
              attributes: ['title'],
            },
          ],
        },
      ],
    };

    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }
    return learningSessionModel.findAndCountAll(finalClause);
  };

  const getLearningSessionById = async learningSessionId => {
    try {
      const queryOptions = {
        where: { id: learningSessionId },
        attributes: [
          'id',
          'title',
          'date',
          'recordStatus',
          'startTime',
          'endTime',
          'meetingStartUrl',
          'meetingUrl',
          'status',
          'reason',
          'cancelledBy',
          'recordStatus',
        ],
        include: [
          {
            model: userModel,
            as: 'PrimaryFaculty',
            attributes: ['firstName', 'lastName'],
          },
          {
            model: userModel,
            as: 'SecondaryFaculty',
            attributes: ['firstName', 'lastName'],
          },
          {
            model: userModel,
            as: 'SRM',
            attributes: ['firstName', 'lastName'],
          },
          {
            model: courseModel,
            attributes: ['title'],
          },
          {
            model: batchModel,
            attributes: ['batchNumber', 'id'],
          },
          {
            model: learningSessionModuleModel,
            attributes: ['id'],
            include: [
              {
                model: moduleModel,
                attributes: ['title'],
              },
            ],
          },
          {
            model: learningSessionContentModel,
            attributes: ['id'],
            include: [
              {
                model: contentModel,
                attributes: ['title'],
              },
            ],
          },
        ],
      };

      return await learningSessionModel.findOne(queryOptions);
    } catch (error) {
      console.error('Error in getCourseTree:', error);
      throw error;
    }
  };

  const getLearningSessionModuleTopic = async learningSessionId => {
    const finalClause = {
      where: { id: learningSessionId },
      include: [
        {
          model: learningSessionModuleModel,
          attributes: ['id'],
          include: [
            {
              model: moduleModel,
              include: [
                {
                  model: topicModel,
                  attributes: ['id', 'title', 'thumbnail'],
                },
              ],
            },
          ],
        },
      ],
    };
    const learningSessionModule = await learningSessionModel.findOne(finalClause);
    return learningSessionModule;
  };

  return {
    ...baseRepo,
    bulkCreate,
    getAllLearningSessions,
    getLearningSessionModuleTopic,
    getLearningSessionById,
  };
});
