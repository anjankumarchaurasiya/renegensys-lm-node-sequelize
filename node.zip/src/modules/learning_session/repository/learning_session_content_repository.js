const { define } = require('src/containerHelper');

module.exports = define('learningSessionContentRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('learning_session_content');
  const learningSessionContentModel = database['learning_session_content'];

  const bulkCreate = data =>
    learningSessionContentModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
