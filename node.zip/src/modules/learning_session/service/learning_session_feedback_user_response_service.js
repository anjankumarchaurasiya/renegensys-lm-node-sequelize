const { define } = require('src/containerHelper');
const searchFilters = require('../constants/feedback_search_filter_constants');

module.exports = define('learningSessionFeedbackUserResponseService', ({
  learningSessionFeedbackUserResponseRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
  logger,
}) => {
  const bulkCreateLearningSessionFeedbackUserResponse = learningSessionFeedbackUserResponse =>
    learningSessionFeedbackUserResponseRepository.bulkCreate(learningSessionFeedbackUserResponse);

  const getSessionFeedbackWithUserResponse = async (learningSessionId, queryParams) => {
    try {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
        queryParams,
        searchFilters.learningSessionfeedbackUser
      );

      let learningSessionFeedbackUserResponse;
      if (queryParams.paginated) {
        learningSessionFeedbackUserResponse = learningSessionFeedbackUserResponseRepository.getLearningSessionFeedbackUserResponse(
          learningSessionId,
          ['id', 'learningSessionId', 'userId', 'feedbackId', 'questionId', 'questionOptionId', 'created_at'],
          whereClause,
          [['created_at', 'DESC']],
          limit,
          offset
        );
      } else {
        learningSessionFeedbackUserResponse = learningSessionFeedbackUserResponseRepository.getLearningSessionFeedbackUserResponse(
          learningSessionId,
          ['id', 'learningSessionId', 'userId', 'feedbackId', 'questionId', 'questionOptionId', 'created_at'],
          whereClause,
          [['created_at', 'DESC']]
        );
      }

      return learningSessionFeedbackUserResponse;
    } catch (error) {
      logger.error(`error occur in get learning session spam: ${error}`);
      throw new Error(error);
    }
  };

  const createLearningSessionUserFeedbackResponse = async data => {
    const { userId, learningSessionId, feedbackId, questionData } = data;

    const userResponseObjects = questionData.map(({ questionId, questionOptionId, response }) => {
      return {
        learningSessionId,
        userId,
        feedbackId,
        response,
        questionId,
        questionOptionId,
      };
    });

    try {
      bulkCreateLearningSessionFeedbackUserResponse(userResponseObjects);
      logger.info('User feedback responses created successfully.');
    } catch (error) {
      logger.error('Error creating user feedback responses:', error);
    }
  };
  return { bulkCreateLearningSessionFeedbackUserResponse, getSessionFeedbackWithUserResponse, createLearningSessionUserFeedbackResponse };
});
