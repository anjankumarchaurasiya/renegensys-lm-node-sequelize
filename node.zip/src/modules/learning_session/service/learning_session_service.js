const { define } = require('src/containerHelper');
const searchFilters = require('../constants/larning_session_search_filter_constants');
const { USER_ROLES, SESSION_STATE } = require('src/constants');

module.exports = define('learningSessionService', ({
  learningSessionRepository,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND, SESSION_STATUS_TYPE },
  commonUtilService,
  feedbackRepository,
  courseRepository,
  batchRepository,
  userRepository,
  userRoleService,
  contentRepository,
  learningSessionModuleRepository,
  learningSessionContentRepository,
  learningSessionModuleService,
  learningSessionFeedbackRepository,
  learningSessionAttendanceService,
  logger,
  generalUtilService,
}) => {
  const createLearningSession = async (data, timezone) => {
    const { title, batchId, courseId, srmId, primaryFacultyId, secondaryFacultyId, feedbackId, content, moduleIds, date, startTime, endTime } = data;

    if (primaryFacultyId === secondaryFacultyId) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Primary Faculty and Secondary Faculty must be different');
    }
    const [
      isLearningSessionExist,
      isBatchExist,
      isCourseExist,
      isSrmExist,
      isPrimaryFacultyExist,
      isSecondaryFacultyExist,
      isFeedBackExist,
    ] = await Promise.all([
      learningSessionRepository.findOne({ title }),
      batchRepository.findOne({ id: batchId }),
      courseRepository.findOne({ id: courseId }),
      userRepository.findOne({ id: srmId }),
      userRepository.findOne({ id: primaryFacultyId }),
      userRepository.findOne({ id: secondaryFacultyId }),
      feedbackRepository.findOne({ id: feedbackId }),
    ]);

    if (isLearningSessionExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, 'Learning Session already exists with title');
    }
    if (isLearningSessionExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, 'Learning Session already exists with title');
    }
    if (!isBatchExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Batch not found');
    }
    if (!isCourseExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Course not found');
    }
    if (!isSrmExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'SRM not found');
    }
    if (!isPrimaryFacultyExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Primary Faculty not found');
    }
    if (!isSecondaryFacultyExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Secondary Faculty not found');
    }

    if (!isFeedBackExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'FeedBack  not found');
    }

    await Promise.all([
      userRoleService.fetchAndValidateRoles(srmId, USER_ROLES.SRM),
      userRoleService.fetchAndValidateRoles(primaryFacultyId, USER_ROLES.TEACHER),
      userRoleService.fetchAndValidateRoles(secondaryFacultyId, USER_ROLES.TEACHER),
    ]);

    const { utcStartDate, utcStartTime, utcEndTime } = generalUtilService.convertLocalTimeToUTC(date, startTime, endTime, timezone);

    data.date = utcStartDate;
    data.startTime = utcStartTime;
    data.endTime = utcEndTime;

    const learningSession = await learningSessionRepository.create(data);

    const learningSessionModules = moduleIds.map(moduleId => {
      return {
        learningSessionId: learningSession.id,
        moduleId: moduleId,
      };
    });

    try {
      await learningSessionModuleService.bulkCreate(learningSessionModules);
    } catch (err) {
      logger.error('Error while Adding Multiple LearningSession Modules', err);
    }

    try {
      await learningSessionFeedbackRepository.create({ learningSessionId: learningSession.id, feedbackId });
    } catch (err) {
      logger.error('Error while adding LearningSessionFeedback ', err);
    }

    if (content) {
      let learningSessionContents = [];

      for (const contentItem of content) {
        const { contentType, contentIds } = contentItem;

        for (const contentId of contentIds) {
          const existingContent = await contentRepository.findOne({ id: contentId });
          if (!existingContent) {
            logger.error(`Content with id ${contentId} does not exist. Skipping.`);
            continue;
          }
          let contentData = {
            learningSessionId: learningSession.id,
            type: contentType,
            contentId: contentId,
          };
          learningSessionContents.push(contentData);
        }
      }
      await learningSessionContentRepository.bulkCreate(learningSessionContents);
    }

    return learningSession;
  };

  const deactivateBulk = async body => {
    const { learningSessionIds } = body;
    const succesfullDeactivations = [];
    const unsuccesfullDeactivations = [];
    await Promise.all(
      learningSessionIds.map(async learningSessionId => {
        const learningSessionDetail = await learningSessionRepository.findOne({ id: learningSessionId });
        if (!learningSessionDetail) {
          unsuccesfullDeactivations.push(learningSessionId);
          return null;
        }
        succesfullDeactivations.push(learningSessionId);
        return learningSessionRepository.deactivate({ id: learningSessionId });
      })
    );
    return {
      succesfullDeactivations,
      unsuccesfullDeactivations,
    };
  };

  const getLearningSessionList = async (queryParams, timeZone) => {
    let learningSessionListResponse;

    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.learningSession);

      learningSessionListResponse = await learningSessionRepository.getAllLearningSessions(
        [
          'id',
          'title',
          'date',
          'startTime',
          'batchId',
          'courseId',
          'srmId',
          'secondaryFacultyId',
          'primaryFacultyId',
          'endTime',
          'created_at',
          'status',
          'reason',
          'cancelledBy',
          'meetingStartUrl',
          'meetingUrl',
        ],
        whereClause,
        [['created_at', 'DESC']],
        queryParams.state,
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.learningSession);
      learningSessionListResponse = await learningSessionRepository.getAllLearningSessions(
        [
          'id',
          'title',
          'date',
          'startTime',
          'endTime',
          'batchId',
          'courseId',
          'srmId',
          'secondaryFacultyId',
          'primaryFacultyId',
          'created_at',
          'status',
          'reason',
          'cancelledBy',
          'meetingStartUrl',
          'meetingUrl',
        ],
        whereClause,
        [['created_at', 'DESC']],
        queryParams.state
      );
    }
    const updatedRows = learningSessionListResponse.rows.map(row => {
      row = row.get({ plain: true });
      const { date, startTime, endTime } = row;
      const { localStartDate, localStartTime, localEndTime } = generalUtilService.convertUTCToLocalTime(date, startTime, endTime, timeZone);

      return {
        ...row,
        date: localStartDate,
        startTime: localStartTime,
        endTime: localEndTime,
      };
    });
    const loggableResponse = {
      count: learningSessionListResponse.count,
      learningSession: updatedRows.map(row => {
        const { sequelize, ...filteredRow } = row;
        return filteredRow;
      }),
    };

    return loggableResponse;
  };

  const updateLearningSession = async data => {
    const { title, moduleIds, deletedModuleIds, srmId, primaryFacultyId, secondaryFacultyId, feedbackId, content, status } = data.body;

    const existingLearningSession = await learningSessionRepository.findOne({ id: data.learningSessionId });
    if (!existingLearningSession) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
    }

    if (title) {
      const isTitleExist = await learningSessionRepository.findOne({ title });
      if (isTitleExist) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, 'Learning Session already exists with the updated title');
      }
    }
    if (status === SESSION_STATUS_TYPE.CANCELLED) {
      data.cancelledBy = data.userId;
    }

    if (srmId) {
      const isSrmExist = await userRepository.findOne({ id: srmId });
      if (!isSrmExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'SRM not found');
      }
    }

    if (primaryFacultyId) {
      const isPrimaryFacultyExist = await userRepository.findOne({ id: primaryFacultyId });
      if (!isPrimaryFacultyExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Primary Faculty not found');
      }
    }

    if (secondaryFacultyId) {
      const isSecondaryFacultyExist = await userRepository.findOne({ id: secondaryFacultyId });
      if (!isSecondaryFacultyExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Secondary Faculty not found');
      }
    }

    if (feedbackId) {
      const isFeedBackExist = await feedbackRepository.findOne({ id: feedbackId });
      if (!isFeedBackExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Feedback  not found');
      }
    }

    if (primaryFacultyId || secondaryFacultyId) {
      if (primaryFacultyId && secondaryFacultyId && primaryFacultyId === secondaryFacultyId) {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Primary Faculty and Secondary Faculty must be different');
      }

      if (
        primaryFacultyId &&
        primaryFacultyId === existingLearningSession.primaryFacultyId &&
        primaryFacultyId === existingLearningSession.secondaryFacultyId
      ) {
        throw new CustomError(
          UNAUTHORIZED_REQUEST.code,
          UNAUTHORIZED_REQUEST.status,
          'Primary Faculty must be different from existing Primary Faculty and existing Secondary Faculty'
        );
      }

      if (
        secondaryFacultyId &&
        secondaryFacultyId === existingLearningSession.secondaryFacultyId &&
        secondaryFacultyId === existingLearningSession.primaryFacultyId
      ) {
        throw new CustomError(
          UNAUTHORIZED_REQUEST.code,
          UNAUTHORIZED_REQUEST.status,
          'Secondary Faculty must be different from existing Secondary Faculty and existing Primary Faculty'
        );
      }
    }

    if (srmId || primaryFacultyId || secondaryFacultyId) {
      const roleChecks = [];
      if (srmId) {
        roleChecks.push(userRoleService.fetchAndValidateRoles(srmId, USER_ROLES.SRM));
      }
      if (primaryFacultyId) {
        roleChecks.push(userRoleService.fetchAndValidateRoles(primaryFacultyId, USER_ROLES.TEACHER));
      }
      if (secondaryFacultyId) {
        roleChecks.push(userRoleService.fetchAndValidateRoles(secondaryFacultyId, USER_ROLES.TEACHER));
      }
      await Promise.all(roleChecks);
    }

    const updatedLearningSession = await learningSessionRepository.update(data.body, { id: data.learningSessionId });

    if (moduleIds && moduleIds.length > 0) {
      const uniqueModuleIds = await learningSessionModuleService.getUniqueModuleIds(data.learningSessionId, moduleIds);

      const learningSessionModules = moduleIds
        .filter(moduleId => !uniqueModuleIds.includes(moduleId))
        .map(moduleId => ({
          learningSessionId: data.learningSessionId,
          moduleId: moduleId,
        }));

      await learningSessionModuleRepository.bulkCreate(learningSessionModules);
    }

    if (deletedModuleIds && deletedModuleIds.length > 0) {
      for (const deletedModuleId of deletedModuleIds) {
        await learningSessionModuleRepository.update(
          { recordStatus: false },
          { learningSessionId: data.learningSessionId, moduleId: deletedModuleId }
        );
      }
    }

    if (feedbackId) {
      try {
        await learningSessionFeedbackRepository.update({ feedbackId: feedbackId }, { learningSessionId: data.learningSessionId });
      } catch (err) {
        logger.error('Error while adding LearningSessionFeedback ', err);
      }
    }

    if (content) {
      let learningSessionContents = [];

      try {
        for (const contentItem of content) {
          const { contentType, contentIds, deletedContentIds } = contentItem;

          for (const contentId of contentIds) {
            const existingContent = await contentRepository.findOne({ id: contentId });
            if (!existingContent) {
              logger.error(`Content with id ${contentId} does not exist. Skipping.`);
              continue;
            }
            let contentData = {
              learningSessionId: existingLearningSession.id,
              type: contentType,
              contentId: contentId,
            };
            learningSessionContents.push(contentData);
          }

          if (deletedContentIds && Array.isArray(deletedContentIds)) {
            const deletePromises = deletedContentIds.map(async deletedContentId => {
              contentRepository.update({ recordStatus: false }, { id: deletedContentId });
              learningSessionContentRepository.update({ recordStatus: false }, { contentId: deletedContentId });
            });
            await Promise.all(deletePromises);
          }
        }

        await learningSessionContentRepository.bulkCreate(learningSessionContents);
      } catch (error) {
        logger.error('An error occurred during content processing:', error);
      }
    }

    return updatedLearningSession;
  };

  const getLearningSession = async (learningSessionId, timeZone) => {
    let learningSessionDetail = await learningSessionRepository.getLearningSessionById(learningSessionId);
    if (learningSessionDetail) {
      const { date, startTime, endTime } = learningSessionDetail;
      const { localStartDate, localStartTime, localEndTime } = generalUtilService.convertUTCToLocalTime(date, startTime, endTime, timeZone);

      learningSessionDetail.date = localStartDate;
      learningSessionDetail.startTime = localStartTime;
      learningSessionDetail.endTime = localEndTime;

      return learningSessionDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `learningSession not found `);
    }
  };

  const bulkCreateLearningSession = learningSession => learningSessionRepository.bulkCreate(learningSession);
  const deactivateLearningSessioncById = whereClause => {
    learningSessionRepository.deactivate(whereClause);
  };

  const bulkActivateLearningSession = async learningSessionIds => {
    const succesfullActivations = [];
    const unsuccesfullActivations = [];

    await Promise.all(
      learningSessionIds.map(async learningSessionId => {
        const learningSessionDetail = await learningSessionRepository.findOne({ id: learningSessionId });
        if (!learningSessionDetail) {
          unsuccesfullActivations.push(learningSessionId);
          return null;
        }
        succesfullActivations.push(learningSessionId);
        return learningSessionRepository.update({ recordStatus: 1 }, { id: learningSessionId });
      })
    );

    return {
      succesfullActivations,
      unsuccesfullActivations,
    };
  };
  return {
    getLearningSession,
    createLearningSession,
    deactivateBulk,
    getLearningSessionList,
    updateLearningSession,
    bulkCreateLearningSession,
    deactivateLearningSessioncById,
    bulkActivateLearningSession,
  };
});
