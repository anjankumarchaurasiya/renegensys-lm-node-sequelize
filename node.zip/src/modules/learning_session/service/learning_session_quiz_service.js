const { define } = require('src/containerHelper');
const { Op } = require('sequelize');

const searchFilters = require('../constants/larning_session_search_filter_constants');
module.exports = define('learningSessionQuizService', ({
  learningSessionQuizRepository,
  learningSessionRepository,
  CustomError,
  generalUtilService,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND },
}) => {
  const createLearningSessionQuiz = async (learningSessionId, quizes) => {
    let newQuizes = (quizes = quizes.map(entry => ({
      ...entry,
      learningSessionId: learningSessionId,
    })));
    const existingEntries = await learningSessionQuizRepository.findAll({
      [Op.or]: newQuizes.map(({ quizId, learningSessionId }) => ({ quizId, learningSessionId })),
    });
    const existingPairs = existingEntries.map(({ learningSessionId, quizId }) => ({ learningSessionId, quizId }));
    const quizesToBeAdded = newQuizes
      .map(({ quizId, learningSessionId }) => ({
        quizId: quizId,
        learningSessionId: learningSessionId,
      }))
      .filter(({ quizId, learningSessionId }) => !existingPairs.find(pair => pair.quizId === quizId && pair.learningSessionId === learningSessionId));

    if (quizesToBeAdded.length > 0) {
      return learningSessionQuizRepository.bulkCreate(quizesToBeAdded);
    } else {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `No new data to add`);
    }
  };

  const deactivateLearningSessionQuiz = async (learningSessionId, quizId) => {
    const isSessionExits = await learningSessionRepository.findOne({ id: learningSessionId });
    if (!isSessionExits) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Learning Session not found `);
    }
    const isQuizExist = await learningSessionQuizRepository.findBy({ quizId: quizId });
    if (!isQuizExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Quiz not found `);
    }
    const sessionQuiz = await learningSessionQuizRepository.findBy({ learningSessionId: learningSessionId, quizId: quizId });

    await learningSessionQuizRepository.findAndDeactivate({ id: sessionQuiz.id });
  };

  const toggleLearningSessionQuizStatus = async (learningSessionId, quizId) => {
    const isSessionExists = await learningSessionRepository.findOne({ id: learningSessionId });
    if (!isSessionExists) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Learning Session not found`);
    }

    const isQuizExist = await learningSessionQuizRepository.findBy({ quizId: quizId });
    if (!isQuizExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Quiz not found`);
    }

    const sessionQuiz = await learningSessionQuizRepository.findBy({
      learningSessionId: learningSessionId,
      quizId: quizId,
    });
    const newStatus = sessionQuiz.recordStatus === true ? false : true;
    await learningSessionQuizRepository.update({ recordStatus: newStatus }, { id: sessionQuiz.id });
  };

  const getAlllearningSessionOfQuiz = async (quizId, queryParams) => {
    let quizLearningSessionListResponse;
    queryParams.quizId = quizId;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
        queryParams,
        searchFilters.learningSessionQuiz
      );
      quizLearningSessionListResponse = await learningSessionQuizRepository.getlearningSessionOfQuiz(
        ['id', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.learningSessionQuiz);
      quizLearningSessionListResponse = await learningSessionQuizRepository.getlearningSessionOfQuiz(['id', 'recordStatus'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }
    return { count: quizLearningSessionListResponse.count, quizLearningSession: quizLearningSessionListResponse.rows };
  };
  return {
    createLearningSessionQuiz,
    deactivateLearningSessionQuiz,
    toggleLearningSessionQuizStatus,
    getAlllearningSessionOfQuiz,
  };
});
