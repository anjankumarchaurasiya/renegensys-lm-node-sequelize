const { define } = require('src/containerHelper');
const searchFilters = require('../constants/learning_session_spam_search_filter_constants');

module.exports = define('learningSessionSpamReportService', ({
  learningSessionSpamReportRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
  logger,
  learningSessionRepository,
}) => {
  const createSessionSpam = async ({ learningSessionId, userId, body }) => {
    logger.info(`create session spam data: ${body}`);
    try {
      const learningsessionspam = await learningSessionSpamReportRepository.create({
        learningSessionId,
        userId,
        ...body,
      });
      return learningsessionspam;
    } catch (error) {
      logger.error(`error occur in learning session spam: ${error}`);
    }
  };

  const getSessionSpam = async (learningSessionId, queryParams) => {
    try {
      logger.info('get learning session spam');
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
        queryParams,
        searchFilters.learningSessionSpam
      );

      let learningSessionspam;
      if (queryParams.paginated) {
        learningSessionspam = learningSessionSpamReportRepository.getLearningSessionSpamFind(
          learningSessionId,
          ['id', 'spam_reason', 'warning_given', 'record_status', 'created_at'],
          whereClause,
          [['created_at', 'DESC']],
          limit,
          offset
        );
      } else {
        learningSessionspam = learningSessionSpamReportRepository.getLearningSessionSpamFind(
          learningSessionId,
          ['id', 'spam_reason', 'warning_given', 'record_status', 'created_at'],
          whereClause,
          [['created_at', 'DESC']]
        );
      }

      return learningSessionspam;
    } catch (error) {
      logger.error(`error occur in get learning session spam: ${error}`);
      throw new Error(error);
    }
  };

  const updateSessionSpam = async (learningSessionId, spamId, warningGiven) => {
    try {
      logger.info('update learning session spam');

      const [isLearningSessionExist, isSpamExist] = await Promise.all([
        learningSessionRepository.findOne({ id: learningSessionId }),
        learningSessionSpamReportRepository.findOne({ id: spamId }),
      ]);

      if (!isLearningSessionExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
      }

      if (!isSpamExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session Spam not found');
      }

      await isSpamExist.update({ warningGiven });
    } catch (error) {
      logger.error(`error occured in update learning session spam`);
      throw new Error(error);
    }
  };
  return {
    createSessionSpam,
    getSessionSpam,
    updateSessionSpam,
  };
});
