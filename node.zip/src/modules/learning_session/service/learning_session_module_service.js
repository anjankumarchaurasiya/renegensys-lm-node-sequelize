const { define } = require('src/containerHelper');

module.exports = define('learningSessionModuleService', ({ learningSessionModuleRepository }) => {
  const getUniqueModuleIds = (learningSessionId, moduleIds = []) => {
    try {
      const uniqueModuleIds = learningSessionModuleRepository.getUniqueModuleIds(learningSessionId, moduleIds);
      return uniqueModuleIds;
    } catch (error) {
      throw new Error(`Error fetching unique module IDs: ${error.message}`);
    }
  };
  const bulkCreate = data => {
    learningSessionModuleRepository.bulkCreate(data);
  };

  return { getUniqueModuleIds, bulkCreate };
});
