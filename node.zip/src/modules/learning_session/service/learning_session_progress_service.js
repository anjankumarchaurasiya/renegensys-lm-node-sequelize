const { define } = require('src/containerHelper');

module.exports = define('learningSessionProgressService', ({
  learningSessionProgressRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
  learningSessionRepository,
  moduleRepository,
  topicRepository,
  batchRepository,
  logger,
}) => {
  const createSessionProgress = async (learningSessionId, userId, moduleId, topicId, batchId) => {
    try {
      logger.info(`create session progress service`);
      const [existingLearningSession, existingModule, existingTopic, existingBatch] = await Promise.all([
        learningSessionRepository.findOne({ id: learningSessionId }),
        moduleRepository.findOne({ id: moduleId }),
        topicRepository.findOne({ id: topicId }),
        batchRepository.findOne({ id: batchId }),
      ]);

      if (!existingLearningSession) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
      }

      if (!existingModule) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Module not found');
      }

      if (!existingTopic) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Topic not found');
      }

      if (!existingBatch) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Batch not found');
      }

      const sessionProgress = learningSessionProgressRepository.create({
        learningSessionId,
        userId,
        moduleId,
        topicId,
        batchId,
      });
      return sessionProgress;
    } catch (error) {
      throw new Error(error);
    }
  };

  const updateSessionProgress = async (learningSessionId, progressId, recordStatus) => {
    try {
      const [existingLearningSession, existingProgress] = await Promise.all([
        learningSessionRepository.findOne({ id: learningSessionId }),
        learningSessionProgressRepository.findOne({ id: progressId }),
      ]);

      if (!existingLearningSession) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
      }

      if (!existingProgress) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session Progress not found');
      }
      await existingProgress.update({ recordStatus: recordStatus });
    } catch (error) {
      throw new Error(error);
    }
  };

  const getSessionProgress = async learningSessionId => {
    try {
      const existingLearningSession = await learningSessionRepository.findOne({ id: learningSessionId });

      if (!existingLearningSession) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
      }

      const [learningSessionProgress, learningSession] = await Promise.all([
        learningSessionProgressRepository.getSessionProgress(learningSessionId),
        learningSessionRepository.getLearningSessionModuleTopic(learningSessionId),
      ]);
      const flagsMap = new Map();
      for (const session of learningSessionProgress) {
        const moduleId = session.moduleId;
        const topicId = session.topicId;
        if (!flagsMap.has(moduleId)) {
          flagsMap.set(moduleId, {});
        }
        flagsMap.get(moduleId).moduleFlag = true;
        if (!flagsMap.has(topicId)) {
          flagsMap.set(topicId, {});
        }
        flagsMap.get(topicId).topicFlag = true;
      }

      const sessionProgressResult = {
        id: learningSession.id,
        title: learningSession.title,
        batchId: learningSession.batchId,
        courseId: learningSession.courseId,
        srmId: learningSession.srmId,
        primaryFacultyId: learningSession.primaryFacultyId,
        secondaryFacultyId: learningSession.secondaryFacultyId,
        feedbackId: learningSession.feedbackId,
        date: learningSession.date,
        startTime: learningSession.startTime,
        endTime: learningSession.endTime,
        meetingStartUrl: learningSession.meetingStartUrl,
        meetingUrl: learningSession.meetingUrl,
        status: learningSession.status,
        reason: learningSession.reason,
        learning_module: learningSession.learning_session_modules.map(moduleData => {
          const moduleClean = {
            module: {
              id: moduleData.module.id,
              title: moduleData.module.title,
              description: moduleData.module.description,
              slug: moduleData.module.slug,
              thumbnail: moduleData.module.thumbnail,
              recordStatus: moduleData.module.recordStatus,
              isCompleted: flagsMap.has(moduleData.module.id) ? flagsMap.get(moduleData.module.id).moduleFlag : false,
              topics: moduleData.module.topics.map(topicData => ({
                id: topicData.id,
                title: topicData.title,
                thumbnail: topicData.thumbnail,
                isCompleted: flagsMap.has(topicData.id) ? flagsMap.get(topicData.id).topicFlag : false,
              })),
            },
          };
          return moduleClean;
        }),
      };

      return sessionProgressResult;
    } catch (error) {
      throw new Error(error);
    }
  };
  return {
    createSessionProgress,
    updateSessionProgress,
    getSessionProgress,
  };
});
