const { define } = require('src/containerHelper');

module.exports = define('learningSessionFeedbackService', ({
  learningSessionFeedbackRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
}) => {
  const bulkCreateLearningSessionFeedback = learningSessionFeedback => learningSessionFeedbackRepository.bulkCreate(learningSessionFeedback);

  return { bulkCreateLearningSessionFeedback };
});
