const { define } = require('src/containerHelper');

const searchFilters = require('../constants/larning_session_search_filter_constants');

module.exports = define('learningSessionAttendanceService', ({
  learningSessionAttendanceRepository,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  learningSessionRepository,
  userRepository,
  roleRepository,
  generalUtilService,
}) => {
  const createLearningSessionAttendance = async (learningSessionId, body) => {
    const { userId, roleId } = body;
    const [isLearningSessionExist, isUserExist, isRoleExist, attendanceRecord] = await Promise.all([
      learningSessionRepository.findOne({ id: learningSessionId }),
      userRepository.findOne({ id: userId }),
      roleRepository.findOne({ id: roleId }),
      learningSessionAttendanceRepository.findOne({ learningSessionId, userId }),
    ]);

    if (!isLearningSessionExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
    }
    if (!isUserExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'User not found');
    }
    if (!isRoleExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Role not found');
    }
    if (attendanceRecord) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, 'Attendance record already exist for same learningSession');
    }

    const inTime = Date.now();
    const learningSessionAttendanceData = { learningSessionId, userId, roleId, inTime };

    learningSessionAttendanceRepository.create(learningSessionAttendanceData);
  };

  const updateLearningSessionAttendance = async (learningSessionId, userId) => {
    // Validate learningSessionId and userId
    const [attendanceRecord, isLearningSessionExist, isUserExist] = await Promise.all([
      learningSessionAttendanceRepository.findOne({ learningSessionId, userId }),
      learningSessionRepository.findOne({ id: learningSessionId }),
      userRepository.findOne({ id: userId }),
    ]);

    if (!isLearningSessionExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Learning Session not found');
    }

    if (!isUserExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'User not found');
    }

    if (!attendanceRecord) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Attendance record not found');
    }

    const outTime = Date.now();

    await attendanceRecord.update({ outTime }); // Update the outTime field
  };

  const getLearningSessionAttendanceList = async (learningSessionId, queryParams) => {
    let learningSessionAttendanceListResponse;
    queryParams.learningSessionId = learningSessionId;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
        queryParams,
        searchFilters.learningSessionAttendance
      );
      learningSessionAttendanceListResponse = await learningSessionAttendanceRepository.getAllLearningSessionsAttendance(
        ['id', 'inTime', 'outTime', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.learningSessionAttendance);
      learningSessionAttendanceListResponse = await learningSessionAttendanceRepository.getAllLearningSessionsAttendance(
        ['id', 'inTime', 'outTime', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: learningSessionAttendanceListResponse.count, learningSession: learningSessionAttendanceListResponse.rows };
  };

  return { createLearningSessionAttendance, updateLearningSessionAttendance, getLearningSessionAttendanceList };
});
