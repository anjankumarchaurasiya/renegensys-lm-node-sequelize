const { define } = require('src/containerHelper');

module.exports = define('learningSessionContentService', ({
  learningSessionContentRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
}) => {
  return {};
});
