const { define } = require('src/containerHelper');
const searchFilters = require('../constants/feedback_search_filter_constants');
module.exports = define('feedbackService', ({
  feedbackRepository,
  categoryRepository,
  questionRepository,
  questionOptionRepository,
  feedbackQuestionRepository,
  learningSessionFeedbackRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND, FEEDBACK_TITLE_EXISTS_ERROR, CATEGORY_NOT_EXIST, FEEDBACK_NOT_EXISTS_ERROR },
  logger,
}) => {
  const bulkCreateFeedback = feedBack => feedbackRepository.bulkCreate(feedBack);
  const getFeedbackList = async queryParams => {
    let getFeedbackListResponse;

    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.feedback);
      getFeedbackListResponse = await feedbackRepository.getAllFeedbacks(
        ['id', 'title', 'description', 'categoryId', 'recordStatus', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.feedback);
      getFeedbackListResponse = await feedbackRepository.getAllFeedbacks(
        ['id', 'title', 'description', 'categoryId', 'recordStatus', 'created_at'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: getFeedbackListResponse.count, feedbacks: getFeedbackListResponse.rows };
  };

  const createFeedback = async (feedbackData, questionData) => {
    try {
      const { title, categoryId } = feedbackData;
      const isFeedbackExist = await feedbackRepository.findOne({ title: title });
      const isCategoryExist = categoryRepository.findOne({ id: categoryId });

      if (isFeedbackExist) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, FEEDBACK_TITLE_EXISTS_ERROR);
      }
      if (!isCategoryExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, CATEGORY_NOT_EXIST);
      }

      const feedback = await feedbackRepository.create(feedbackData);
      const createdQuestionIds = [];

      await Promise.all(
        questionData.map(async question => {
          const { questionCategoryId, options, ...restQuestionData } = question;
          const createQuestion = await questionRepository.create({
            ...restQuestionData,
            categoryId: questionCategoryId,
          });
          createdQuestionIds.push(createQuestion.id);

          if (options && options.length > 0) {
            await Promise.all(
              options.map(async option => {
                await questionOptionRepository.create({
                  questionId: createQuestion.id,
                  option: option.option,
                  order: option.order,
                });
              })
            );
          }

          await feedbackQuestionRepository.create({
            feedbackId: feedback.id,
            questionId: createQuestion.id,
            wordLimit: question.wordLimit || null,
          });
        })
      );

      return feedback;
    } catch (error) {
      logger.error('Error While Creating Feedback with Questions');
    }
  };

  const getFeedback = async (feedBackId, queryParams) => {
    const parsedparams = generalUtilService.parseQueryParam(queryParams);
    let feedBackDetail;
    if (parsedparams.viewQuestions) {
      return feedbackRepository.getFeedback(feedBackId, parsedparams.viewQuestions);
    }
    if (parsedparams.viewSessions) {
      queryParams.feedbackId = feedBackId;
      if (queryParams.paginated) {
        const { whereClause, orderBy, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
          queryParams,
          searchFilters.learningSessionfeedback
        );
        feedBackDetail = await feedbackRepository.getFeedbackWithSession(['id', 'recordStatus'], whereClause, orderBy, limit, offset);
      } else {
        const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.learningSessionfeedback);
        feedBackDetail = await feedbackRepository.getFeedbackWithSession(['id', 'recordStatus'], whereClause);
      }
      if (feedBackDetail) {
        return { count: feedBackDetail.count, learningSessionfeedback: feedBackDetail.rows };
      }
    }

    if (parsedparams.viewBatches) {
      queryParams.feedbackId = feedBackId;
      if (queryParams.paginated) {
        const { whereClause, orderBy, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
          queryParams,
          searchFilters.learningSessionfeedback
        );
        feedBackDetail = await feedbackRepository.getFeedbackWithBatch(
          ['id', 'batchNumber', 'start_date', 'end_date'],
          whereClause,
          orderBy,
          limit,
          offset
        );
      } else {
        const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.learningSessionfeedback);
        feedBackDetail = await feedbackRepository.getFeedbackWithBatch(['id', 'batchNumber', 'start_date', 'end_date'], whereClause);
      }
      if (feedBackDetail) {
        return { count: feedBackDetail.count, learningSessionfeedback: feedBackDetail.rows };
      }
    }
    throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, FEEDBACK_NOT_EXISTS_ERROR);
  };

  const updateFeedbackSessions = async (isLinked, sessions = [], feedbackId) => {
    const updatePromises = sessions.map(sessionId =>
      learningSessionFeedbackRepository.update({ recordStatus: isLinked ? 1 : 0 }, { learningSessionId: sessionId, feedbackId: feedbackId })
    );

    return Promise.all(updatePromises);
  };

  return { bulkCreateFeedback, getFeedbackList, createFeedback, getFeedback, updateFeedbackSessions };
});
