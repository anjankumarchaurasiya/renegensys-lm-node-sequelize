module.exports = Object.freeze({
  learningSessionSpam: {
    srmId: {
      op: '$eq',
      alias: 'srmId',
      dataType: 'UUID',
    },
    userName: {
      op: '$like',
      alias: 'userName',
      dataType: 'STRING',
    },
    reportedBy: {
      op: '$like',
      alias: 'reportedByName',
      dataType: 'STRING',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    date: {
      op: '$eq',
      alias: 'date',
      dataType: 'DATEONLY',
    },
  },
});
