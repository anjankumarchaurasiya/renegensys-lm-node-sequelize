module.exports = Object.freeze({
  learningSession: {
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    courseId: {
      op: '$eq',
      alias: 'course_id',
      dataType: 'UUID',
    },
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
    srmId: {
      op: '$eq',
      alias: 'srm_id',
      dataType: 'UUID',
    },
    primaryFacultyId: {
      op: '$eq',
      alias: 'primary_faculty_id',
      dataType: 'UUID',
    },
    secondaryFacultyId: {
      op: '$eq',
      alias: 'secondary_faculty_id',
      dataType: 'UUID',
    },
    date: {
      op: '$eq',
      alias: 'date',
      dataType: 'DATEONLY',
    },
    status: {
      op: '$like',
      alias: 'status',
      dataType: 'STRING',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
  },
  learningSessionAttendance: {
    roleId: {
      op: '$eq',
      alias: 'role_id',
      dataType: 'UUID',
    },

    learningSessionId: {
      op: '$eq',
      alias: 'learning_session_id',
      dataType: 'UUID',
    },
  },
  learningSessionQuiz: {
    quizId: {
      op: '$eq',
      alias: 'quiz_id',
      dataType: 'UUID',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    courseId: {
      op: '$eq',
      alias: 'course_id',
      dataType: 'UUID',
    },
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
  },
});
