module.exports = Object.freeze({
  feedback: {
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    description: {
      op: '$like',
      alias: 'description',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    categoryId: {
      op: '$eq',
      alias: 'category_id',
      dataType: 'UUID',
    },
    categoryIds: {
      op: '$in',
      alias: 'category_id',
      dataType: 'UUID',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
  },
  learningSessionfeedbackUser: {
    name: {
      op: '$like',
      alias: 'name',
      dataType: 'STRING',
    },
    primaryFacultyId: {
      op: '$eq',
      alias: 'primary_faculty_id',
      dataType: 'UUID',
    },
    feedbackCategoryId: {
      op: '$eq',
      alias: 'feedback_category_id',
      dataType: 'UUID',
    },
  },

  learningSessionfeedback: {
    feedbackId: {
      op: '$eq',
      alias: 'feedback_id',
      dataType: 'UUID',
    },
    linked: {
      op: '$eq',
      alias: 'linked',
      dataType: 'BOOLEAN',
    },
    sessionTitle: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    batchNumber: {
      op: '$like',
      alias: 'batch_number',
      dataType: 'STRING',
    },
    courseId: {
      op: '$eq',
      alias: 'course_id',
      dataType: 'UUID',
    },
  },
});
