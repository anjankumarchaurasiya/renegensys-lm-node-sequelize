const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');

const {
  FEEDBACK_CREATED_SUCCESSFULLY,
  USER_FEEDBACK_RESPONSE_CREATED_SUCCESSFULLY,
  FEEDBACK_LINKED_WITH_SESSIONS_SUCCESSFULLY,
  FEEDBACK_UNLINKED_WITH_SESSIONS_SUCCESSFULLY,
} = require('src/constants');

module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const {
    feedbackService,
    learningSessionFeedbackUserResponseService,
    batchFeedbackUserResponseService,
    logger,
    authorizeMiddleware,
  } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      const { feedbackData, questionData } = body;
      logger.info('Create Feedback with question');
      await feedbackService.createFeedback(feedbackData, questionData);
      let data;
      res.status(Status.OK).json(await Success(data, FEEDBACK_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter/list', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info('Get All Feedbacks');
      const feedbackList = await feedbackService.getFeedbackList(query);
      res.status(Status.OK).json(await Success(feedbackList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:feedbackId', async (req, res, next) => {
    try {
      const {
        params: { feedbackId },
        query,
      } = req;
      let feedBackDetail = await feedbackService.getFeedback(feedbackId, query);
      res.status(Status.OK).json(await Success(feedBackDetail));
    } catch (e) {
      next(e);
    }
  });

  router.post('/user-response', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create user feedback response');

      const { isSessionFeedback } = body;
      if (isSessionFeedback) {
        await learningSessionFeedbackUserResponseService.createLearningSessionUserFeedbackResponse(body);
      } else {
        await batchFeedbackUserResponseService.createBatchUserFeedbackResponse(body);
      }
      let data;
      res.status(Status.OK).json(await Success(data, USER_FEEDBACK_RESPONSE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:feedbackId/session', async (req, res, next) => {
    try {
      const {
        params: { feedbackId },
        body: { isLinked, sessions },
      } = req;
      logger.info('Create Linking with Sessions');
      await feedbackService.updateFeedbackSessions(isLinked, sessions, feedbackId);
      let data;
      const msg = isLinked ? FEEDBACK_LINKED_WITH_SESSIONS_SUCCESSFULLY : FEEDBACK_UNLINKED_WITH_SESSIONS_SUCCESSFULLY;
      res.status(Status.OK).json(await Success(data, msg));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
