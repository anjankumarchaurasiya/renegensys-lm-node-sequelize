const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  LEARNING_SESSION_CREATED_SUCCESSFULLY,
  LEARNING_SESSION_DELETED_SUCCESSFULLY,
  LEARNING_SESSION_UPDATED_SUCCESSFULLY,
  LEARNING_SESSION_QUIZ_CREATED_SUCCESSFULLY,
  LEARNING_SESSION_QUIZ_DELETED_SUCCESSFULLY,
  LEARNING_SESSION_QUIZ_UPDATED_SUCCESSFULLY,
  LEARNING_SESSION_SPAM_CREATED_SUCCESSFULLY,
  LEARNING_SESSION_ACTIVATED_SUCCESSFULLY,
  LEARNING_SESSION_ATTENDANCE_CREATED_SUCCESSFULLY,
  LEARNING_SESSION_ATTENDANCE_UPDATED_SUCCESSFULLY,
  LEARNING_SESSION_PROGRESS_CREATED_SUCCESSFULLY,
  LEARNING_SESSION_SPAM_UPDATED_SUCCESSFULLY,
  LEARNING_SESSION_PROGRESS_UPDATED_SUCCESSFULLY,
  LEARNING_SESSION_FEEDBACK_CREATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const {
    learningSessionService,
    learningSessionQuizService,
    learningSessionSpamReportService,
    learningSessionAttendanceService,
    learningSessionProgressService,
    learningSessionFeedbackUserResponseService,
    logger,
    authorizeMiddleware,
  } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const {
        body,
        user: { timezone },
      } = req;
      logger.info('Create learning session route');
      await learningSessionService.createLearningSession(body, timezone);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter/list', async (req, res, next) => {
    try {
      const {
        query,
        user: { timezone },
      } = req;
      const learningSessionList = await learningSessionService.getLearningSessionList(query, timezone);
      res.status(Status.OK).json(await Success(learningSessionList));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/bulk', async (req, res, next) => {
    try {
      const { body } = req;
      let data = await learningSessionService.deactivateBulk(body);
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:learningSessionId', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
      } = req;
      await learningSessionService.deactivateLearningSessioncById({ id: learningSessionId });
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/:learningSessionId/quiz', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        body: { quizes },
      } = req;
      logger.info('Create learning session quiz mapping');
      await learningSessionQuizService.createLearningSessionQuiz(learningSessionId, quizes);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_QUIZ_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:learningSessionId/quiz', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        body: { quizes },
      } = req;
      logger.info('delete learning session quiz mapping');
      await learningSessionQuizService.deactivateLearningSessionQuiz(learningSessionId, quizes);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_QUIZ_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:learningSessionId/quiz', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        body: { quizes },
      } = req;
      logger.info('delete learning session quiz mapping');
      await learningSessionQuizService.toggleLearningSessionQuizStatus(learningSessionId, quizes);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_QUIZ_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:learningSessionId', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        user: { id },
        body,
      } = req;
      await learningSessionService.updateLearningSession({ learningSessionId, userId: id, body });
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/bulk/activate', async (req, res, next) => {
    try {
      const {
        body: { learningSessionIds },
      } = req;

      let data = await learningSessionService.bulkActivateLearningSession(learningSessionIds);
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_ACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/:learningSessionId/spam', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        user: { id },
        body,
      } = req;
      logger.info('create learning session spam');
      await learningSessionSpamReportService.createSessionSpam({ learningSessionId, userId: id, body });
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_SPAM_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/:learningSessionId/attendance', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        body,
      } = req;
      logger.info('create learning session attendance ');
      await learningSessionAttendanceService.createLearningSessionAttendance(learningSessionId, body);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_ATTENDANCE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:learningSessionId/attendance/:userId', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId, userId },
      } = req;
      logger.info('Update learning session attendance ');
      await learningSessionAttendanceService.updateLearningSessionAttendance(learningSessionId, userId);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_ATTENDANCE_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:learningSessionId/attendance/filter/list', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        query,
      } = req;
      logger.info('Get All learning session attendance ');
      const learningSessionAttendanceList = await learningSessionAttendanceService.getLearningSessionAttendanceList(learningSessionId, query);
      res.status(Status.OK).json(await Success(learningSessionAttendanceList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:learningSessionId/spam', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        query,
      } = req;
      logger.info('get learning session spams');
      const sessionSpamList = await learningSessionSpamReportService.getSessionSpam(learningSessionId, query);
      res.status(Status.OK).json(await Success(sessionSpamList));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:learningSessionId/spam/:spamId', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId, spamId },
        body: { warningGiven },
      } = req;
      logger.info(`update learning session spams: ${spamId}`);
      await learningSessionSpamReportService.updateSessionSpam(learningSessionId, spamId, warningGiven);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_SPAM_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/:learningSessionId/progress', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        user: { id: userId },
        body: { moduleId, topicId, batchId },
      } = req;
      logger.info(`create learning session progress`);
      await learningSessionProgressService.createSessionProgress(learningSessionId, userId, moduleId, topicId, batchId);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_PROGRESS_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:learningSessionId/progress/:progressId', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId, progressId },
        body: { recordStatus },
      } = req;
      logger.info(`update learning session progress`);
      await learningSessionProgressService.updateSessionProgress(learningSessionId, progressId, recordStatus);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_PROGRESS_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:learningSessionId', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        user: { timezone },
      } = req;
      let learningSessionDetail = await learningSessionService.getLearningSession(learningSessionId, timezone);
      res.status(Status.OK).json(await Success(learningSessionDetail));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:learningSessionId/progress/', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
      } = req;

      const getSessionProgress = await learningSessionProgressService.getSessionProgress(learningSessionId);
      res.status(Status.OK).json(await Success(getSessionProgress));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:learningSessionId/feedback', async (req, res, next) => {
    try {
      const {
        params: { learningSessionId },
        query,
      } = req;
      logger.info('Get learning session feedbacks with user response');
      const sessionSpamList = await learningSessionFeedbackUserResponseService.getSessionFeedbackWithUserResponse(learningSessionId, query);
      res.status(Status.OK).json(await Success(sessionSpamList));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
