const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  CRON_JOB_CREATED_SUCCESSFULLY,
  CRON_JOB_UPDATED_SUCCESSFULLY,
  CRON_JOB_DEACTIVATED_SUCCESSFULLY,
  CRON_JOB_INITIATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    auth,
    userContextMiddleware,
    response: { Success, Fail },
  } = container.cradle;
  const { cronFrameworkConfigService, logger, cronJobService } = container.cradle;
  //   router.use(auth.authenticate(true));
  //   router.use(userContextMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Create cronFrameworkConfig ::`);
      const cronFrameworkConfig = await cronFrameworkConfigService.createCronFrameworkConfig(body);
      let data = await Success(cronFrameworkConfig.get({ plain: true }));
      res.status(Status.OK).json(await Success(data, CRON_JOB_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:cronFrameworkConfigId', async (req, res, next) => {
    try {
      const {
        params: { cronFrameworkConfigId },
      } = req;
      logger.info(`Get cronFrameworkConfig ::`);
      const cronFrameworkConfig = await cronFrameworkConfigService.getCronFrameworkConfig(cronFrameworkConfigId);
      res.status(Status.OK).json(await Success(cronFrameworkConfig.get({ plain: true })));
    } catch (e) {
      next(e);
    }
  });

  // to get list of cronFrameworkConfigs
  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get cronFrameworkConfig List ::`);
      const cronFrameworkConfigList = await cronFrameworkConfigService.getCronFrameworkConfigList(query);
      res.status(Status.OK).json(await Success(cronFrameworkConfigList));
    } catch (e) {
      next(e);
    }
  });

  // to update specific cronFrameworkConfig of cronFrameworkConfig Id
  router.patch('/:cronFrameworkConfigId', async (req, res, next) => {
    try {
      const {
        params: { cronFrameworkConfigId },
        body,
      } = req;
      await cronFrameworkConfigService.updateCronFrameworkConfig({ ...body, id: cronFrameworkConfigId });
      let data;
      res.status(Status.OK).json(await Success(data, CRON_JOB_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  // to deactivate cronFrameworkConfig by cronFrameworkConfig Id
  router.delete('/:cronFrameworkConfigId', async (req, res, next) => {
    try {
      const {
        params: { cronFrameworkConfigId },
      } = req;
      await cronFrameworkConfigService.deactivateCronFrameworkConfig(cronFrameworkConfigId);
      let data;
      res.status(Status.OK).json(await Success(data, CRON_JOB_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  // to deactivate cronFrameworkConfig by cronFrameworkConfig Id
  router.get('/test/cron-job', async (req, res, next) => {
    try {
      await cronJobService.init();
      res.status(Status.OK).json(await Success(CRON_JOB_INITIATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
