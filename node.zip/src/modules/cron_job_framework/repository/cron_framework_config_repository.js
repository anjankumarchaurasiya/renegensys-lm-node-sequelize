const { define } = require('src/containerHelper');

module.exports = define('cronFrameworkConfigRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('cron_framework_config');
  const cronFrameworkConfigModel = database['cron_framework_config'];

  const getCronFrameworkConfig = async whereClause =>
    cronFrameworkConfigModel.findOne({
      where: {
        recordStatus: 1,
        ...whereClause,
      },
    });

  const bulkCreate = data => cronFrameworkConfigModel.bulkCreate(data, { ignoreDuplicates: true });

  const findAllCronFrameworkConfigs = async (attributes, whereClause, orderBy, limit, offset) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
    };
    if (limit && offset) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }

    return cronFrameworkConfigModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    getCronFrameworkConfig,
    bulkCreate,
    findAllCronFrameworkConfigs,
  };
});
