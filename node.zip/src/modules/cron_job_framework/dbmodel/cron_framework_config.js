'use strict';

module.exports = (sequelize, DataTypes) => {
  const CronFrameworkConfig = sequelize.define(
    'cron_framework_config',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: DataTypes.TEXT,
      },
      serviceName: {
        type: DataTypes.TEXT,
      },
      methodName: {
        type: DataTypes.TEXT,
      },
      cron: {
        type: DataTypes.TEXT,
      },
      status: {
        type: DataTypes.TEXT,
      },
      params: {
        type: DataTypes.JSON,
      },
      recordStatus: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
      },
      createdBy: {
        type: DataTypes.UUID,
      },
      createdAt: {
        type: DataTypes.DATE,
      },
      updatedAt: {
        type: DataTypes.DATE,
      },
    },
    {
      freezeTableName: true,
    }
  );
  CronFrameworkConfig.associate = function(models) {};
  return CronFrameworkConfig;
};
