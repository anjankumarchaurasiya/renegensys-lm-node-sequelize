const { define } = require('src/containerHelper');
const CronJob = require('cron').CronJob;
const cronJobMap = {};
let masterJob = null;

module.exports = define('cronJobService', ({ jobInstanceService, cronFrameworkConfigService, logger, config }) => {
  const init = async () => {
    if (config.IS_CRON_JOB_ENABLED !== 'false') {
      try {
        logger.info(`Cron job scheduled on this instance`);
        masterJob = new CronJob(
          '*/1 * * * *',
          async () => {
            try {
              logger.info(`Cron master called, reloading all cron configs`);
              await reloadCronJobs();
            } catch (e) {
              logger.error(`Cron job reload error`, e);
            }
          },
          null,
          true,
          null
        );
        await reloadCronJobs();
      } catch (e) {
        logger.error(`Cron service init error`, e);
      }
    } else {
      logger.info(`================Cron job not scheduled on this instance================`);
    }
  };

  const getMasterJob = () => masterJob;

  const reloadCronJobs = async () => {
    logger.info(`reload cron job`);
    const cronConfigs = await cronFrameworkConfigService.getCronFrameworkConfigList();
    const currentTime = new Date().getTime();
    for (let i in cronConfigs) {
      const existingConfig = cronJobMap[cronConfigs[i].name];
      let updateJob = false;
      if (existingConfig && cronConfigs[i].updated_at.getTime() !== existingConfig.cronConfig.updated_at.getTime()) {
        existingConfig.job.stop();
        updateJob = true;
      }
      if (!existingConfig) {
        updateJob = true;
      }
      if (updateJob) {
        const cronJ = new CronJob(
          cronConfigs[i].cron,
          async () => {
            logger.info(`Cron job started ${cronConfigs[i].name}`);
            await jobInstanceService.runMethodJob(cronConfigs[i]);
          },
          null,
          true,
          null
        );
        cronJobMap[cronConfigs[i].name] = { job: cronJ, cronConfig: cronConfigs[i].get({ plain: true }), lastUpdatedAt: currentTime };
      } else {
        cronJobMap[cronConfigs[i].name].lastUpdatedAt = currentTime;
      }
    }
    for (let k in cronJobMap) {
      if (cronJobMap[k].lastUpdatedAt !== currentTime) {
        cronJobMap[k].job.stop();
        delete cronJobMap[k];
      }
    }
  };

  return {
    reloadCronJobs,
    init,
    getMasterJob,
  };
});
