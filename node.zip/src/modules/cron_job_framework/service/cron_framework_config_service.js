const { define } = require('src/containerHelper');
const searchFilters = require('../constants/search_filter_constants');
module.exports = define('cronFrameworkConfigService', ({ cronFrameworkConfigRepository, generalUtilService }) => {
  const createCronFrameworkConfig = data => cronFrameworkConfigRepository.create(data);

  const createOrUpdateCronFrameworkConfig = async ({ cronFrameworkConfigId, data }) => {
    const cronFrameworkConfig = await cronFrameworkConfigRepository.findOne({ cronFrameworkConfigId, characterId });
    if (!cronFrameworkConfig) {
      return cronFrameworkConfigRepository.create(data);
    } else if (!cronFrameworkConfig.recordStatus) {
      await updateCronFrameworkConfig({ id: cronFrameworkConfig.id, recordStatus: 1 });
    }
    return cronFrameworkConfig;
  };

  const updateCronFrameworkConfig = async data => {
    return cronFrameworkConfigRepository.update(data, { id: data.id });
  };

  const bulkCreateCronFrameworkConfig = data => cronFrameworkConfigRepository.bulkCreate(data);

  const deactivateCronFrameworkConfig = cronFrameworkConfigId => cronFrameworkConfigRepository.deactivate({ id: cronFrameworkConfigId });

  const getCronFrameworkConfigList = async queryParams => {
    let cronFrameworkConfigResponse;
    if (queryParams?.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.cronFrameworkConfig);
      cronFrameworkConfigResponse = await cronFrameworkConfigRepository.findAllCronFrameworkConfigs(
        ['id', 'name', 'serviceName', 'methodName', 'params', 'cron', 'status', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.cronFrameworkConfig);
      cronFrameworkConfigResponse = await cronFrameworkConfigRepository.findAllCronFrameworkConfigs(
        ['id', 'name', 'serviceName', 'methodName', 'params', 'cron', 'status', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: cronFrameworkConfigResponse.count, cronFrameworkConfig: cronFrameworkConfigResponse.rows };
  };

  return {
    createCronFrameworkConfig,
    deactivateCronFrameworkConfig,
    bulkCreateCronFrameworkConfig,
    createOrUpdateCronFrameworkConfig,
    updateCronFrameworkConfig,
    getCronFrameworkConfigList,
  };
});
