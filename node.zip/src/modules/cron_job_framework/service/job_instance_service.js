const { define, getService } = require('src/containerHelper');
// const rp = require('request-promise');
const expr = require('expression-eval');
const uuidv4 = require('uuid/v4');

module.exports = define('jobInstanceService', ({ config, logger }) => {
  const runHTTPJob = async cronFrameworkConfig => {
    let params;
    try {
      if (!cronFrameworkConfig.params) {
        params = {};
      } else {
        try {
          params = typeof cronFrameworkConfig.params === 'string' ? JSON.parse(cronFrameworkConfig.params) : cronFrameworkConfig.params;
        } catch (e) {
          params = {};
        }
      }

      params.jobId = uuidv4();
      // const options = {
      //   uri: parseUrl(cronFrameworkConfig.url),
      //   method: 'POST',
      //   body: params,
      //   json: true,
      // };

      logger.info(`job instance starting with option ${JSON.stringify(options)}`);
      await axiosWrapper.post({
        url: parseUrl(cronFrameworkConfig.url),
        data: params,
        headers: {
          'Content-Type': 'application/json',
        },
      });
      // const result = await rp(options);
      logger.info(`job instance result with option ${JSON.stringify(options)} is ${JSON.stringify(result)}`);
    } catch (e) {
      logger.error(`job instance failed for job ${JSON.stringify(jobConfig)}`, e);
    }
  };

  const parseUrl = url => {
    const ast = expr.parse(url);
    return expr.eval(ast, {
      JOB_URL: config['JOB_URL'],
    });
  };

  const runMethodJob = async cronFrameworkConfig => {
    if (cronFrameworkConfig) {
      const serviceName = cronFrameworkConfig.serviceName;
      const methodName = cronFrameworkConfig.methodName;
      const params = typeof cronFrameworkConfig.params === 'string' ? JSON.parse(cronFrameworkConfig.params) : cronFrameworkConfig.params;
      const paramList = Object.keys(params).map(key => params[key]);
      let serviceCls = getService(serviceName);
      let methodObj = serviceCls[methodName];
      if (typeof methodObj === 'function') {
        try {
          await methodObj(...paramList);
        } catch (e) {
          logger.error(`some thing went wron while executing the job`, e);
        }
      } else {
        logger.error(`Method not found : ${methodName} of service: ${serviceName}`);
      }
    }
  };

  const handleEventAppJobQueue = async messageObj => {
    logger.info('Job queue listener ' + JSON.stringify(messageObj));
    return runHTTPJob(messageObj.data);
  };

  return {
    runHTTPJob,
    runMethodJob,
    parseUrl,
    handleEventAppJobQueue,
  };
});
