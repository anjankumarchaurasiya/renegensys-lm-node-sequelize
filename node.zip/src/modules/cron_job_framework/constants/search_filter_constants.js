module.exports = Object.freeze({
  cronFrameworkConfig: {
    recordStatus: {
      op: '$eq',
      alias: 'recordStatus',
    },
    name: {
      op: '$like',
      alias: 'name',
    },
    serviceName: {
      op: '$like',
      alias: 'serviceName',
    },
    methodName: {
      op: '$like',
      alias: 'methodName',
    },
  },
});
