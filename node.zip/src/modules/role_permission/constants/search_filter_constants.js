module.exports = Object.freeze({
  role: {
    name: {
      op: '$like',
      alias: 'name',
    },
    description: {
      op: '$like',
      alias: 'description',
    },
    resourceId: {
      op: '$eq',
      alias: 'resourceId',
    },
    resourceActionId: {
      op: '$eq',
      alias: 'resourceActionId',
    },
    recordStatus: {
      op: '$eq',
      alias: 'recordStatus',
    },
  },
  resource: {
    resourceName: {
      op: '$like',
      alias: 'resourceName',
    },
    recordStatus: {
      op: '$eq',
      alias: 'recordStatus',
    },
  },
  resourceAction: {
    actionName: {
      op: '$like',
      alias: 'actionName',
    },
    actionType: {
      op: '$like',
      alias: 'actionType',
    },
    resourceId: {
      op: '$eq',
      alias: 'id',
    },
    recordStatus: {
      op: '$eq',
      alias: 'recordStatus',
    },
  },
});
