const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { RESOURCE_CREATED_SUCCESSFULLY, RESOURCE_UPDATED_SUCCESSFULLY, RESOURCE_DEACTIVATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
  } = container.cradle;
  const { resourceService, logger, authorizeMiddleware } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      const resources = await resourceService.getResourceList(query);
      res.status(Status.OK).json(await Success(resources));
    } catch (e) {
      next(e);
    }
  });

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Add resource ::`);
      const resource = await resourceService.createResource(body);
      let data = resource.get({ plain: true });
      res.status(Status.CREATED).json(await Success(data, RESOURCE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:resourceId', async (req, res, next) => {
    try {
      const {
        params: { resourceId },
        body,
      } = req;
      logger.info(`Update role ::`);
      await resourceService.updateResource({ ...body, id: resourceId });
      let data;
      res.status(Status.CREATED).json(await Success(data, RESOURCE_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:resourceId', async (req, res, next) => {
    try {
      const {
        params: { resourceId },
      } = req;
      await resourceService.deactivateResource({ id: resourceId });
      let data;
      res.status(Status.CREATED).json(await Success(data, RESOURCE_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
