const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  RESOURCE_ACTION_CREATED_SUCCESSFULLY,
  RESOURCE_ACTION_UPDATED_SUCCESSFULLY,
  RESOURCE_ACTION_DEACTIVATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
  } = container.cradle;
  const { resourceActionService, logger, authorizeMiddleware } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      const resourceActions = await resourceActionService.getResourceActionList(query);
      res.status(Status.OK).json(await Success(resourceActions));
    } catch (e) {
      next(e);
    }
  });

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Add resource action ::`);
      const resourceAction = await resourceActionService.createResourceAction(body);
      let data = resourceAction.get({ plain: true });
      res.status(Status.CREATED).json(await Success(data, RESOURCE_ACTION_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:resourceActionId', async (req, res, next) => {
    try {
      const {
        params: { resourceActionId },
        body,
      } = req;
      logger.info(`Update resource action ::`);
      await resourceActionService.updateResourceAction({ ...body, id: resourceActionId });
      let data;
      res.status(Status.CREATED).json(await Success(data, RESOURCE_ACTION_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:resourceActionId', async (req, res, next) => {
    try {
      const {
        params: { resourceActionId },
      } = req;
      await resourceActionService.deactivateResourceAction({ id: resourceActionId });
      let data;
      res.status(Status.OK).json(await Success(data, RESOURCE_ACTION_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
