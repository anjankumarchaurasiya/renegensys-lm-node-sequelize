const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  ROLE_CREATED_SUCCESSFULLY,
  ROLE_UPDATED_SUCCESSFULLY,
  ROLE_DEACTIVATED_SUCCESSFULLY,
  ROLE_ADDED_WITH_ACTION_SUCCESSFULLY,
  RESOURCES_ASSIGNED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
  } = container.cradle;
  const { roleManagementService, logger, authorizeMiddleware } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Add role ::`);
      const roles = await roleManagementService.createRole(body);
      let data = roles.get({ plain: true });
      res.status(Status.CREATED).json(await Success(data, ROLE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:roleId', async (req, res, next) => {
    try {
      const {
        params: { roleId },
        body,
      } = req;
      logger.info(`Update role ::`);
      await roleManagementService.updateRole(body, roleId);
      let data;
      res.status(Status.CREATED).json(await Success(data, ROLE_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      const roles = await roleManagementService.getAllRoles(query);
      res.status(Status.OK).json(await Success(roles));
    } catch (e) {
      next(e);
    }
  });

  router.post('/resources/bulk', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Add Resources with actions :: ${JSON.stringify(body)}`);
      let data = await roleManagementService.addResources(body);
      res.status(Status.CREATED).json(await Success(data, ROLE_ADDED_WITH_ACTION_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/resources', async (req, res, next) => {
    try {
      logger.info(`Get All Resource`);
      const resources = await roleManagementService.getResources();
      res.status(Status.OK).json(Success(resources));
    } catch (e) {
      next(e);
    }
  });

  router.post('/:roleId/resources/assign', async (req, res, next) => {
    try {
      const {
        params: { roleId },
        body: { resources },
      } = req;
      logger.info(`Assign resources to role`);
      await roleManagementService.assignResourceToRole({ roleId, resources });
      let data;
      res.status(Status.CREATED).json(await Success(data, RESOURCES_ASSIGNED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:roleId/resources/actions', async (req, res, next) => {
    try {
      const {
        params: { roleId },
      } = req;
      logger.info(`Assign resources to role`);
      const resourcesActions = await roleManagementService.getAllResourcesOfGivenRole(roleId);
      res.status(Status.OK).json(Success(Array.from(resourcesActions.values())));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:roleId', async (req, res, next) => {
    try {
      const {
        params: { roleId },
      } = req;
      await roleManagementService.deactivateRole({ id: roleId });
      let data;
      res.status(Status.OK).json(await Success(data, ROLE_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
