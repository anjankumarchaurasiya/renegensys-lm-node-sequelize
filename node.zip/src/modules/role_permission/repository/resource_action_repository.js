const { define } = require('src/containerHelper');

module.exports = define('resourceActionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('resource_action');
  const resourceActionModel = database['resource_action'];
  const resourceModel = database['resource'];

  const findOrCreate = (whereClause, data) => resourceActionModel.findOrCreate({ where: whereClause, defaults: data });

  const findAllResourceActions = (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForResource;
    let requiredValue = false;
    if (whereClause.id) {
      whereClauseForResource = whereClause.id;
      requiredValue = true;
      delete whereClause.id;
    }
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      include: [
        {
          model: resourceModel,
          attributes: ['resourceName'],
          where: whereClauseForResource ? { id: whereClauseForResource } : {},
          required: requiredValue,
        },
      ],
    };
    if (orderBy) {
      finalClause.order = orderBy;
    }
    if (limit && offset) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return resourceActionModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    findOrCreate,
    findAllResourceActions,
  };
});
