const { define } = require('src/containerHelper');

module.exports = define('userRoleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_role');
  const userRoleModel = database['user_role'];
  const roleModel = database['role'];
  const adminPanelPermissionModel = database['admin_panel_permission'];
  const adminModuleModel = database['admin_module'];
  const adminSubmoduleModel = database['admin_submodule'];
  const bulkCreate = data =>
    userRoleModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getUserRoles = async userId => {
    try {
      const userRoles = await userRoleModel.findAll({
        attributes: ['role_id'],
        where: { user_id: userId, recordStatus: 1 },
        include: [
          {
            model: roleModel,
            as: 'roles',
            attributes: ['id', 'name'],
          },
        ],
      });
      return userRoles;
    } catch (error) {
      throw error;
    }
  };
  const getUserRolesWithPermission = async userId => {
    try {
      const userRoles = await userRoleModel.findAll({
        attributes: ['id', 'userId', 'recordStatus'],
        include: [
          {
            model: roleModel,
            attributes: ['id', 'name', 'recordStatus'],
            as: 'roles',
            include: [
              {
                model: adminPanelPermissionModel,
                attributes: ['id', 'canView', 'canCreate', 'canUpdate', 'canDelete', 'recordStatus'],
                include: [
                  {
                    model: adminModuleModel,
                    attributes: ['id', 'name', 'order', 'icon', 'redirectLink', 'recordStatus'],
                    where: { recordStatus: true },
                  },
                  {
                    model: adminSubmoduleModel,
                    attributes: ['id', 'name', 'icon', 'redirectLink', 'recordStatus'],
                    where: { recordStatus: true },
                    required: false,
                  },
                ],
                where: { recordStatus: true },
              },
            ],
            where: { recordStatus: true },
          },
        ],
        where: { recordStatus: true, userId },
      });

      return userRoles;
    } catch (error) {
      throw error;
    }
  };

  return {
    ...baseRepo,
    bulkCreate,
    getUserRoles,
    getUserRolesWithPermission,
  };
});
