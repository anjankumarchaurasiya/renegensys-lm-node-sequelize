const { define } = require('src/containerHelper');

module.exports = define('resourceRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('resource');
  const resourceModel = database['resource'];

  const findOrCreate = whereClause => resourceModel.findOrCreate({ where: whereClause, defaults: whereClause });

  const findAllResources = (attributes, whereClause, orderBy, limit, offset) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
    };
    if (orderBy) {
      finalClause.order = orderBy;
    }
    if (limit && offset) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return resourceModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    findOrCreate,
    findAllResources,
  };
});
