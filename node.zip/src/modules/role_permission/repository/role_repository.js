const { define } = require('src/containerHelper');

module.exports = define('roleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('role');
  const roleModel = database['role'];
  const roleResourceAction = database['role_resource_action'];
  const resourceAction = database['resource_action'];
  const resource = database['resource'];

  const bulkCreate = data =>
    roleModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const findAllRoles = (attributes, whereClause, limit, offset) => {
    let whereClauseForResource;
    let whereClauseForResourceAction;
    let resourceRequired = false;
    let resourceActionRequired = false;
    if (whereClause.resourceActionId) {
      whereClauseForResourceAction = whereClause.resourceActionId;
      resourceActionRequired = true;
      delete whereClause.resourceActionId;
    }
    if (whereClause.resourceId) {
      whereClauseForResource = whereClause.resourceId;
      resourceRequired = true;
      delete whereClause.resourceId;
    }
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: roleResourceAction,
          attributes: ['id'],
          where: whereClauseForResourceAction ? { recordStatus: true, resourceActionId: whereClauseForResourceAction } : { recordStatus: true },
          required: resourceActionRequired,
          include: [
            {
              model: resourceAction,
              attributes: ['id', 'action_name'],
              where: whereClauseForResource ? { resourceId: whereClauseForResource } : {},
              required: resourceRequired,
              include: [
                {
                  model: resource,
                  attributes: ['id', 'resource_name'],
                },
              ],
            },
          ],
        },
      ],
    };
    if (limit && offset) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return roleModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    findAllRoles,
  };
});
