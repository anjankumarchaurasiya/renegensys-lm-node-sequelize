const { define } = require('src/containerHelper');

module.exports = define('roleResourceActionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('role_resource_action');

  const roleResourceActionModel = database['role_resource_action'];
  const resourceModel = database['resource'];
  const roleModel = database['role'];
  const resourceActionModel = database['resource_action'];

  const findAllResourceByRoleId = roleId => {
    return roleResourceActionModel.findAll({
      where: { roleId },
      include: [
        {
          model: roleModel,
        },
        {
          model: resourceActionModel,
          include: {
            model: resourceModel,
          },
        },
      ],
    });
  };
  const bulkCreate = data => roleResourceActionModel.bulkCreate(data);

  return {
    ...baseRepo,
    findAllResourceByRoleId,
    bulkCreate,
  };
});
