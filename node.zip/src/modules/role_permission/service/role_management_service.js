const { define } = require('src/containerHelper');
const searchFilters = require('../constants/search_filter_constants');
module.exports = define('roleManagementService', ({
  roleRepository,
  roleResourceActionRepository,
  resourceActionRepository,
  userRoleRepository,
  resourceRepository,
  roleResourceActionService,
  generalUtilService,
  constants: { ROLES },
  transactionDecorator: { transaction },
}) => {
  const getAllRoles = async queryParams => {
    let roleListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.role);
      roleListResponse = await roleRepository.findAllRoles(
        ['id', 'name', 'description', 'recordStatus', 'createdBy', 'lastUpdatedBy'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.role);
      roleListResponse = await roleRepository.findAllRoles(['id', 'name', 'description', 'recordStatus', 'createdBy', 'lastUpdatedBy'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }
    return { count: roleListResponse.count, roles: roleListResponse.rows };
  };

  const getRoleByRoleName = async roleName => {
    const foundRole = await roleRepository.findBy(['id', 'name'], { name: roleName });
    return foundRole;
  };

  const addResources = async data => {
    for (const resource of data) {
      // await transaction(async () => {
      const resourceInstance = await resourceRepository.findOrCreate({ resourceName: resource.resourceName });
      const resourceId = resourceInstance?.[0]?.id;
      if (resourceId) {
        for (const resourceAction of resource.resourceActions) {
          await resourceActionRepository.findOrCreate(
            { resourceId, actionName: resourceAction.actionName, actionType: resourceAction.actionType },
            {
              resourceId,
              actionName: resourceAction.actionName,
              actionType: resourceAction.actionType,
              allowedFields: resourceAction.allowedFields,
            }
          );
        }
      }
      // })();
    }
  };

  const getResources = async () => {
    const resourceActionMap = new Map();
    const resourceActions = await resourceRepository.findAllBy(['id', 'resourceName', 'recordStatus'], {});
    for (const resourceAction of resourceActions) {
      const action = {
        id: resourceAction.resource_action.id,
        actionName: resourceAction.resource_action.actionName,
        actionType: resourceAction.resource_action.actionType,
        recordStatus: resourceAction.resource_action.recordStatus,
      };
      if (!resourceActionMap.has(resourceAction.id)) {
        resourceActionMap.set(resourceAction.id, {
          id: resourceAction.id,
          resourceName: resourceAction.resourceName,
          recordStatus: resourceAction.recordStatus,
          actions: [action],
        });
      } else {
        resourceActionMap.get(resourceAction.id).actions.push(action);
      }
    }
    return Array.from(resourceActionMap.values());
  };

  const assignResourceToRole = async data => {
    const { roleId, resources } = data;
    const roleResources = [];
    for (const resource of resources) {
      roleResources.push({ roleId, resourceActionId: resource });
    }
    await roleResourceActionRepository.bulkCreate(roleResources);
  };

  const getAllResourcesOfGivenRole = async roleId => {
    const formatResp = new Map();
    const result = await roleResourceActionRepository.findAllResourceByRoleId(roleId);
    for (const role of result) {
      formatResp.set(`${role.resource_action.resource.resourceName}_${role.resource_action.actionName}`, {
        actionId: role.resource_action.id,
        resource: role.resource_action.resource.resourceName,
        resourceId: role.resource_action.resourceId,
        actionName: role.resource_action.actionName,
        actionType: role.resource_action.actionType,
        allowedFields: role.resource_action.allowedFields,
      });
    }
    return formatResp;
  };

  const createRole = async data => {
    const roleCreated = await roleRepository.create(data);
    if (roleCreated) {
      const { resourceActionIds } = data;
      if (resourceActionIds && resourceActionIds.length > 0) {
        for (let resourceActionId of resourceActionIds) {
          await roleResourceActionService.createOrUpdateRoleResourceAction({ resourceActionId: resourceActionId, roleId: roleCreated.id });
        }
      }
    }
    return roleCreated;
  };
  const updateRole = async (data, id) => {
    await roleRepository.update(data, { id: id });

    if (data.resourceActionIds) {
      const roleResourceActionInList = await roleResourceActionService.getRoleResourceAction({
        roleId: id,
        recordStatus: 1,
      });
      const allMappedDomainSubdomain = roleResourceActionInList.map(mappedObj => {
        return { id: mappedObj.resourceActionId };
      });
      const mappedAndUnmappedIds = generalUtilService.getDifferenceBetweenMappedAndUnmappedIds(data.resourceActionIds, allMappedDomainSubdomain);
      for (const addedId of mappedAndUnmappedIds.addedIds) {
        const addedRoleResourceAction = {
          resourceActionId: addedId,
          roleId: id,
        };
        await roleResourceActionService.createOrUpdateRoleResourceAction(addedRoleResourceAction);
      }
      for (const deletedId of mappedAndUnmappedIds.deletedIds) {
        await roleResourceActionService.deactivateRoleResourceAction({ resourceActionId: deletedId, roleId: id });
      }
    }
  };

  const bulkCreateRoles = roles => roleRepository.bulkCreate(roles);
  const bulkCreateUserRoles = roles => userRoleRepository.bulkCreate(roles);

  return {
    createRole,
    getAllResourcesOfGivenRole,
    assignResourceToRole,
    getResources,
    getAllRoles,
    getRoleByRoleName,
    addResources,
    bulkCreateRoles,
    bulkCreateUserRoles,
    updateRole,
  };
});
