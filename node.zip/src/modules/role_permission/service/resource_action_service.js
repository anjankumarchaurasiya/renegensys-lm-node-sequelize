const { define } = require('src/containerHelper');
const searchFilters = require('../constants/search_filter_constants');
module.exports = define('resourceActionService', ({ resourceActionRepository, generalUtilService }) => {
  const getResourceActionList = async queryParams => {
    let resourceActionListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.resourceAction);
      resourceActionListResponse = await resourceActionRepository.findAllResourceActions(
        ['id', 'actionName', 'actionType', 'allowedFields', 'recordStatus', ['created_at', 'createdAt']],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.resourceAction);
      resourceActionListResponse = await resourceActionRepository.findAllResourceActions(
        ['id', 'actionName', 'actionType', 'allowedFields', 'recordStatus', ['created_at', 'createdAt']],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: resourceActionListResponse.count, resourceActions: resourceActionListResponse.rows };
  };

  const createResourceAction = data => resourceActionRepository.create(data);
  const updateResourceAction = data => resourceActionRepository.update(data, { id: data.id });
  const deactivateResourceAction = whereClause => resourceActionRepository.deactivate(whereClause);
  return {
    getResourceActionList,
    createResourceAction,
    updateResourceAction,
    deactivateResourceAction,
  };
});
