const { define } = require('src/containerHelper');
const searchFilters = require('../constants/search_filter_constants');
module.exports = define('resourceService', ({ resourceRepository, generalUtilService }) => {
  const getResourceList = async queryParams => {
    let resourceListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.resource);
      resourceListResponse = await resourceRepository.findAllResources(
        ['id', 'resourceName', 'recordStatus', ['created_at', 'createdAt']],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.resource);
      resourceListResponse = await resourceRepository.findAllResources(
        ['id', 'resourceName', 'recordStatus', ['created_at', 'createdAt']],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: resourceListResponse.count, resources: resourceListResponse.rows };
  };

  const createResource = data => resourceRepository.create(data);
  const updateResource = data => resourceRepository.update(data, { id: data.id });
  const deactivateResource = whereClause => resourceRepository.deactivate(whereClause);
  return {
    getResourceList,
    createResource,
    updateResource,
    deactivateResource,
  };
});
