const { define } = require('src/containerHelper');
const role_repository = require('../repository/role_repository');
module.exports = define('userRoleService', ({
  userRoleRepository,
  roleManagementService,
  CustomError,
  roleRepository,
  constants: { UNAUTHORIZED_REQUEST },
}) => {
  const assignRoleByName = async (userId, roleArray) => {
    for (const role of roleArray) {
      const foundRole = await roleManagementService.getRoleByRoleName(role);
      if (foundRole) {
        const roleId = foundRole.id;
        const existingRole = await userRoleRepository.findOne({ userId, roleId });
        if (existingRole) {
          await userRoleRepository.update({ recordStatus: 1 }, { id: existingRole.id });
        } else {
          await userRoleRepository.create({ userId, roleId });
        }
      } else {
        throw new CustomError(ROLE_DOES_NOT_EXISTS.code, ROLE_DOES_NOT_EXISTS.status, `Role does not exists with provided Email `);
      }
    }
  };

  const assignRoleById = async (userId, roleArray) => {
    for (const roleId of roleArray) {
      const existingRole = await userRoleRepository.findOne({ userId, roleId });
      if (existingRole) {
        await userRoleRepository.update({ recordStatus: 1 }, { id: existingRole.id });
      } else {
        await userRoleRepository.create({ userId, roleId });
      }
    }
  };

  const getUserRole = async whereClause => {
    return userRoleRepository.findAll(whereClause);
  };

  const getUserRolesWithNames = async userId => {
    const userRoles = await userRoleRepository.getUserRoles(userId);
    return userRoles;
  };
  const deactivateUserRole = async whereClause => await userRoleRepository.findAndDeactivate(whereClause);

  const fetchAndValidateRoles = async (userId, expectedRole) => {
    const roles = await getUserRolesWithNames(userId);
    const roleNames = roles.map(userRole => userRole.roles.dataValues.name);
    if (!roleNames.includes(expectedRole)) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `${expectedRole} role not found for user`);
    }
    return roleNames;
  };
  const fetchAndValidateAdminRolesPermission = async (userId, expectedRole) => {
    try {
      const originalData = await userRoleRepository.getUserRolesWithPermission(userId);

      if (!originalData || originalData.length === 0) {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `No role permissions found for user: ${userId}`);
      }

      const rolePermissions = {};
      originalData.forEach(item => {
        const roleName = item.roles.name;

        if (!rolePermissions[roleName]) {
          rolePermissions[roleName] = { modules: new Map() };
        }

        const modules = item.roles.admin_panel_permissions.map(permission => ({
          name: permission.admin_module.name,
          order: permission.admin_module.order,
          redirectLink: permission.admin_module.redirectLink,
          icon: permission.admin_module.icon,
          submenus: permission.admin_submodule
            ? [
                {
                  name: permission.admin_submodule.name,
                  redirectLink: permission.admin_submodule.redirectLink,
                  icon: permission.admin_submodule.icon,
                  can_view: permission.canView,
                  can_create: permission.canCreate,
                  can_update: permission.canUpdate,
                  can_delete: permission.canDelete,
                },
              ]
            : [],
        }));

        modules.forEach(module => {
          const existingModule = rolePermissions[roleName].modules.get(module.name);

          if (!existingModule) {
            rolePermissions[roleName].modules.set(module.name, { ...module, submenus: new Set(module.submenus) });
          } else {
            module.submenus.forEach(submenu => {
              existingModule.submenus.add(submenu);
            });
          }
        });
      });

      const rolePermissionsArray = [];
      for (const roleName in rolePermissions) {
        rolePermissions[roleName].modules.forEach(module => {
          rolePermissionsArray.push(module);
        });
      }

      if (rolePermissionsArray.length === 0) {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `${expectedRole} permission not found for user: ${userId}`);
      }

      const sortedData = rolePermissionsArray.sort((a, b) => a.order - b.order);

      const transformedData = sortedData.map(item => ({
        order: item.order,
        name: item.name,
        redirectLink: item.redirectLink,
        icon: item.icon,
        submenus: [...item.submenus],
      }));

      const uniqueModules = {};
      const uniqueTransformedData = [];
      transformedData.forEach(item => {
        if (!uniqueModules[item.name]) {
          uniqueModules[item.name] = true;
          uniqueTransformedData.push(item);
        } else {
          const existingItem = uniqueTransformedData.find(uniqueItem => uniqueItem.name === item.name);
          item.submenus.forEach(submenu => {
            if (!existingItem.submenus.some(existingSubmenu => existingSubmenu.name === submenu.name)) {
              existingItem.submenus.push(submenu);
            }
          });
        }
      });

      const sortedUniqueTransformedData = uniqueTransformedData.sort((a, b) => a.order - b.order);

      return sortedUniqueTransformedData;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  };

  return {
    getUserRole,
    deactivateUserRole,
    assignRoleByName,
    assignRoleById,
    getUserRolesWithNames,
    fetchAndValidateRoles,
    fetchAndValidateAdminRolesPermission,
  };
});
