const { define } = require('src/containerHelper');
module.exports = define('roleResourceActionService', ({ roleResourceActionRepository }) => {
  const createOrUpdateRoleResourceAction = async data => {
    const recordExists = await roleResourceActionRepository.findOne({ resourceActionId: data.resourceActionId, roleId: data.roleId });
    if (!recordExists) {
      return await roleResourceActionRepository.create(data);
    } else if (!recordExists.recordStatus) {
      await roleResourceActionRepository.update({ recordStatus: 1 }, { id: recordExists.id });
    }
    return recordExists;
  };
  const getRoleResourceAction = async whereClause => {
    return roleResourceActionRepository.findAll(whereClause);
  };
  const deactivateRoleResourceAction = async whereClause => await roleResourceActionRepository.findAndDeactivate(whereClause);

  return {
    createOrUpdateRoleResourceAction,
    deactivateRoleResourceAction,
    getRoleResourceAction,
  };
});
