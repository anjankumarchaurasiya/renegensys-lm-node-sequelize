'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserRole = sequelize.define(
    'user_role',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.STRING,
      },
      roleId: {
        type: DataTypes.STRING,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      updatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  UserRole.associate = function(models) {
    UserRole.belongsTo(models.user, {
      as: 'user_roles',
      foreignKey: 'userId',
      sourceKey: 'id',
      allowNull: false,
    });
    UserRole.belongsTo(models.role, {
      as: 'roles',
      foreignKey: 'roleId',
      targetKey: 'id',
      allowNull: false,
    });
  };
  return UserRole;
};
