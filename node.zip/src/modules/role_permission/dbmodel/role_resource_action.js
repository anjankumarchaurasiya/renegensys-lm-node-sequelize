module.exports = (sequelize, DataTypes) => {
  const RoleResource = sequelize.define(
    'role_resource_action',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      roleId: {
        type: DataTypes.UUID,
        allowNull: false,
        unique: 'role_resource_action',
      },
      resourceActionId: {
        type: DataTypes.UUID,
        allowNull: false,
        unique: 'role_resource_action',
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      lastUpdatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  RoleResource.associate = function(models) {
    RoleResource.belongsTo(models.resource_action, { sourceKey: 'resourceActionId' });
    RoleResource.belongsTo(models.role, { sourceKey: 'roleId' });
  };

  return RoleResource;
};
