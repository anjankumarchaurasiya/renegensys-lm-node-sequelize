module.exports = (sequelize, DataTypes) => {
  const Resource = sequelize.define(
    'resource',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      resourceName: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      status: {
        type: DataTypes.STRING,
        defaultValue: 'active',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      lastUpdatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  Resource.associate = function(models) {
    Resource.hasOne(models.resource_action, {
      sourceKey: 'id',
    });
  };

  return Resource;
};
