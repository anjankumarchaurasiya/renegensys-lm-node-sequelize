'use strict';

module.exports = (sequelize, DataTypes) => {
  const Role = sequelize.define(
    'role',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: 'role_name',
      },
      order: {
        type: DataTypes.INTEGER,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      description: {
        type: DataTypes.STRING,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      lastUpdatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Role.associate = function(models) {
    Role.belongsToMany(models.user, {
      through: models.user_role,
      foreignKey: 'roleId',
      otherKey: 'userId',
    });
    Role.hasMany(models.role_resource_action, { foreignKey: 'roleId' });
    Role.hasMany(models.admin_panel_permission, { foreignKey: 'roleId' });
  };
  return Role;
};
