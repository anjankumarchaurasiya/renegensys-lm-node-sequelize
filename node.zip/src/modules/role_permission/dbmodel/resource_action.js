module.exports = (sequelize, DataTypes) => {
  const ResourceAction = sequelize.define(
    'resource_action',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      resourceId: {
        type: DataTypes.UUID,
        allowNull: false,
        unique: 'resource_action_type',
      },
      actionName: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: 'resource_action_type',
      },
      actionType: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: 'resource_action_type',
      },
      allowedFields: {
        type: DataTypes.JSON,
        allowNull: false,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      lastUpdatedBy: {
        type: DataTypes.UUID,
        allowNull: true,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );
  ResourceAction.associate = function(models) {
    ResourceAction.belongsTo(models.resource, {
      foreignKey: 'resourceId',
    });
  };

  return ResourceAction;
};
