const { define } = require('src/containerHelper');
const siteContentFilter = require('../constants/sitecontent_search_filter_constant');

module.exports = define('siteContentService', ({
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, INVALID_REQUEST, ENTITY_NOT_FOUND, SITE_CONTENT_ALREADY_EXIST_WITH_SAME_NAME, SITE_CONTENT_NOT_FOUND },
  siteContentRepository,
  logger,
}) => {
  const getSiteContent = async (type, name) => {
    let siteContentDetails = await siteContentRepository.getSiteContent(type, name);
    if (siteContentDetails) {
      return siteContentDetails;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, SITE_CONTENT_NOT_FOUND);
    }
  };

  const getAllSiteContent = async queryParams => {
    let batchListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, siteContentFilter.sitecontent);
      batchListResponse = await siteContentRepository.getAllSiteContent(
        ['id', 'title', 'name', ['content', 'siteContent'], 'type', 'created_at', 'url', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, siteContentFilter.sitecontent);
      batchListResponse = await siteContentRepository.getAllSiteContent(
        ['id', 'title', 'name', 'type', ['content', 'siteContent'], 'url', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }

    return { count: batchListResponse.count, sitecontent: batchListResponse.rows };
  };

  const submitSiteContent = async (name, url, siteContent, type, title, createdBy) => {
    const isSiteContextExist = await siteContentRepository.findOne({ name });
    if (isSiteContextExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, SITE_CONTENT_ALREADY_EXIST_WITH_SAME_NAME);
    } else {
      const sieContentData = { name, url, content: siteContent, type, title, createdBy };
      await siteContentRepository.create(sieContentData);
    }
  };

  const deactivateSiteContent = async function(id) {
    const isSiteContentExist = await siteContentRepository.findOne({ id: id });
    if (!isSiteContentExist) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, SITE_CONTENT_NOT_FOUND);
    }
    await siteContentRepository.deactivate({ id });
  };
  const updateSiteContent = async (siteData, id) => {
    const isSiteContentExist = await siteContentRepository.findOne({ id: id });
    if (!isSiteContentExist) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, SITE_CONTENT_NOT_FOUND);
    }
    await siteContentRepository.update(siteData, { id: id });
  };

  return {
    getSiteContent,
    submitSiteContent,
    deactivateSiteContent,
    updateSiteContent,
    getAllSiteContent,
  };
});
