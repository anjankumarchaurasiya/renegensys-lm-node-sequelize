const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');

const { SITE_CONTENT_SUBMITED_SUCCESSFULLY, SITE_CONTENT_DEACTIVATED_SUCCESSFULLY, SITE_CONTENT_UPDATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
    logger,
  } = container.cradle;
  const { authorizeMiddleware, siteContentService } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.get('/type/:type/name/:name', async (req, res, next) => {
    try {
      const {
        params: { type, name },
      } = req;
      const userId = req.user.id;
      logger.info('Get site content by id');
      let siteContent = await siteContentService.getSiteContent(type, name);
      res.status(Status.OK).json(await Success(siteContent));
    } catch (e) {
      next(e);
    }
  });
  router.get('/', async (req, res, next) => {
    try {
      const userId = req.user.id;
      logger.info('Get all site content');
      const { query } = req;
      let siteContent = await siteContentService.getAllSiteContent(query);
      res.status(Status.OK).json(await Success(siteContent));
    } catch (e) {
      next(e);
    }
  });
  router.post('/', async (req, res, next) => {
    try {
      const { user } = req;
      const { name, url, siteContent, type, title } = req.body;
      const createdBy = user.id;
      logger.info('Submit site content');
      let data = await siteContentService.submitSiteContent(name, url, siteContent, type, title, createdBy);
      res.status(Status.OK).json(await Success(data, SITE_CONTENT_SUBMITED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.patch('/:id', async (req, res, next) => {
    try {
      const {
        params: { id },
        body: { url, siteContent, type, title },
        user,
      } = req;
      const updatedBy = user.id;
      logger.info('Update site content');
      await siteContentService.updateSiteContent({ url, content: siteContent, type, title, updatedBy }, id);
      let data;
      res.status(Status.OK).json(await Success(data, SITE_CONTENT_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.delete('/:id', async (req, res, next) => {
    try {
      const {
        params: { id },
        user,
      } = req;
      const updatedBy = user.id;
      logger.info('Delete site content');
      let data = await siteContentService.deactivateSiteContent(id, updatedBy);
      res.status(Status.OK).json(await Success(data, SITE_CONTENT_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
