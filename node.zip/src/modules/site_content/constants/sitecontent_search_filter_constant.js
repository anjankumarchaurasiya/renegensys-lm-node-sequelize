module.exports = Object.freeze({
  sitecontent: {
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    name: {
      op: '$like',
      alias: 'name',
      dataType: 'STRING',
    },
    type: {
      op: '$like',
      alias: 'type',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
  },
});
