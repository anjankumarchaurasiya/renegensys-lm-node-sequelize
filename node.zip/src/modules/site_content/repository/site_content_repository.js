const { define } = require('src/containerHelper');
const { Sequelize, Op } = require('sequelize');
module.exports = define('siteContentRepository', ({ database, baseRepositoryV2, logger, constants: { ASSESMENT_STATUS } }) => {
  const baseRepo = baseRepositoryV2('site_content');
  const siteContentModel = database['site_content'];
  const bulkCreate = data => siteContentModel.bulkCreate(data, { ignoreDuplicate: true });

  const getSiteContent = async (type, name) => {
    try {
      return siteContentModel.findOne({
        where: {
          type,
          name,
          recordStatus: true,
        },
        attributes: ['id', 'title', 'name', 'url', ['content', 'siteContent'], 'recordStatus'],
      });
    } catch (error) {
      logger.error('Error fetching content:', error);
    }
  };

  const getAllSiteContent = async (attributes, whereClause, orderBy, limit, offset) => {
    // Define the final clause
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
    };

    // Handle limit and offset
    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }

    try {
      return await siteContentModel.findAndCountAll(finalClause);
    } catch (error) {
      console.error('Error executing query:', error);
      throw error;
    }
  };
  return {
    ...baseRepo,
    bulkCreate,
    getSiteContent,
    getAllSiteContent,
  };
});
