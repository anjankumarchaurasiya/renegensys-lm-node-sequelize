const { define } = require('src/containerHelper');
const moment = require('moment');

module.exports = define('dateTimeUtilService', ({}) => {
  const getNowTimeStamp = () => {
    return moment(new Date()).format('YYYY-MM-DD');
  };

  const getNowUnixTimeStamp = () => {
    return moment(new Date()).unix();
  };

  const getNowFullTimeStamp = () => {
    return moment(new Date()).format('YYYY-MM-DD HH:mm:ss UTC+00:00');
  };

  const addDateTimeStamp = (date, value, unit) => {
    return moment(new Date(date))
      .add(value, unit)
      .format('YYYY-MM-DD HH:mm:ss');
  };

  const subtractDateTimeStamp = (date, value, unit) => {
    return moment(new Date(date))
      .subtract(value, unit)
      .format('YYYY-MM-DD');
  };

  const getDateFromUnixTimeStamp = unixTimeStamp => {
    return moment.unix(unixTimeStamp).format('YYYY-MM-DD HH:mm:ss');
  };

  return {
    getNowTimeStamp,
    addDateTimeStamp,
    subtractDateTimeStamp,
    getNowUnixTimeStamp,
    getNowFullTimeStamp,
    getDateFromUnixTimeStamp,
  };
});
