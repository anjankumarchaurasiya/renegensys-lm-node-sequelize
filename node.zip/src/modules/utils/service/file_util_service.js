const { define } = require('src/containerHelper');
const { isEmpty, omit, difference } = require('ramda');
const fs = require('fs');
const { promises: fsPromise } = require('fs');
const httpContext = require('express-cls-hooked');
const _ = require('lodash');
const sanitize = require('mongo-sanitize');
const xlsx = require('xlsx');
const util = require('util');
const path = require('path');
const fsPromises = require('fs/promises');
// const poppler = require('pdf-poppler');
const { S3_FOLDER_BY_ENTITY_TYPE, S3_CONFIG_BY_ENTITIES } = require('../../../constants/aws_constants');
const recursiveFs = require('recursive-fs');
const mime = require('mime-types');
module.exports = define('fileUtilService', ({ logger, awsService, CustomError, constants: { RUNTIME_ERROR }, config }) => {
  /* -------------------------------------------------------------------------- */
  /*                               Utility Methods                              */
  /* -------------------------------------------------------------------------- */

  const validateInputForFile = async (data, size = 600000000) => {
    const fileName = data?.file?.name;
    const ALLOWED_FILE_TYPE = ['jpg', 'jpeg', 'png', 'pdf', 'mp4', 'gif', 'docx', 'doc', 'zip'];
    let fileType = null;
    if (data?.file?.type) {
      fileType = String(data?.file?.type)
        .split('/')
        ?.pop()
        ?.toLowerCase();
    }
    const fileExtension = fileName
      ?.split('.')
      ?.pop()
      ?.toLowerCase();

    if (fileType || fileExtension) {
      let extention = fileType || fileExtension;
      if (!extention || !ALLOWED_FILE_TYPE.includes(extention)) {
        throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, `Please upload file with .jpeg, .jpg, .png, .pdf, .doc, .docx extension`);
      }
    }
    const fileSize = data?.file?.size;
    if (!fileSize || fileSize > size) {
      throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, `Please upload file less than ${size / (1000 * 1000)} MB`);
    }
  };

  const uploadFile = async ({ files, bucketName, folderName, overWriteFileName, uniqueId, entityName, entityType }) => {
    try {
      if (entityName) {
        bucketName = S3_CONFIG_BY_ENTITIES[entityName].BUCKET_NAME;
      }
      const filePath = path.join(__dirname, '/../../../../resources/' + files.file.name);
      const writeFileAsync = util.promisify(fs.writeFile);
      await writeFileAsync(filePath, files.file.data);

      const fileStream = fs.createReadStream(filePath);
      const fileExtension = files.file.name.split('.')[1];
      const nameFromUniqId = uniqueId ? uniqueId + '.' + fileExtension : undefined;
      const fileName = overWriteFileName || nameFromUniqId || files.file.name;
      if (!folderName && entityType) {
        folderName = `${S3_FOLDER_BY_ENTITY_TYPE[entityName][entityType]}`;
      }
      const fileNameAndPath = `${folderName}/${fileName}`;
      const contentType = files.file.mimetype || files.file?.headers?.['content-type'];

      const fileUploadResponse = await awsService.uploadFileOnS3(bucketName, fileNameAndPath, fileStream, contentType);
      deleteFile(filePath);
      return fileUploadResponse;
    } catch (error) {
      logger.error(`Error while uploading file`, error);
      throw error;
    }
  };

  const uploadFolder = async ({ bucketName, folderPath, entityName, folderName, mimetype }) => {
    if (entityName) {
      bucketName = S3_CONFIG_BY_ENTITIES[entityName].BUCKET_NAME;
    }
    const uploadPromises = [];
    await recursiveFs.readdirr(folderPath, async (err, dirs, files) => {
      if (err) throw err;
      for (const file of files) {
        const mimetype = mime.lookup(file);
        const fileStream = fs.createReadStream(file);
        const key = file.replace(folderPath, '').substr(1);
        const fileKey = `${folderName}/${key}`;
        uploadPromises.push(awsService.createFolder(bucketName, fileKey, fileStream, true, mimetype));
        // await awsService.createFolder(bucketName, fileKey, fileStream, false);
      }
      await Promise.all(uploadPromises);
    });
    const gameUrl = getGameUrl(folderName + '/index.html');
    return gameUrl;
  };

  const getGameUrl = async folderName => {
    return `${config.GAME_URL}/${folderName}`;
  };

  // recursion used to return unique number to avoid data repetition in array
  const readXlsFile = async (file, sheetName) => {
    const filePath = path.join(__dirname, '/../../../../resources/' + file.name);
    const writeFileAsync = util.promisify(fs.writeFile);
    await writeFileAsync(filePath, file.data);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
    const worksheet = workbook.Sheets[sheetName];
    // const range = xlsx.utils.decode_range(worksheet['!ref']);
    return { sheetData, filePath, worksheet };
  };

  const deleteFile = fileName => {
    return fs.unlink(fileName, function(err) {
      if (err) {
        logger.error(`Error while deleting file`, err);
      }
    });
  };

  const removeDirectory = async dirPath => {
    try {
      await fsPromises.rm(dirPath, { recursive: true });
      logger.info('Directory removed!');
    } catch (err) {
      logger.error(`Error while deleting directory`, err);
    }
  };

  const createAvcFolder = async (bucketName, folderName) => {
    const folderKey = `${folderName}/${folderName}_avc`;
    const folderCreateResponse = await awsService.createFolder(bucketName, folderKey);
    return folderCreateResponse;
  };

  const getExtensionOfFile = files => {
    const fileName = files?.file?.name;
    const fileExtension = fileName
      ?.split('.')
      ?.pop()
      ?.toLowerCase();
    return fileExtension;
  };

  const covertDatatoXlsFile = async data => {
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(data);
    xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    return buffer;
  };

  // const convertPDFToBase64 = async (pdfPath, outputFolder) => {
  //   if (!fs.existsSync(outputFolder)) {
  //     fs.mkdirSync(outputFolder);
  //   }
  //   // Convert PDF pages to images
  //   const opts = {
  //     format: 'png',
  //     out_dir: outputFolder,
  //     out_prefix: 'page',
  //   };

  //   try {
  //     return poppler.convert(pdfPath, opts);
  //   } catch (error) {
  //     logger.error('Error converting PDF to images:', error);
  //     return;
  //   }
  // };

  const writeFileAsync = (pdfPath, data) => {
    const writeFileAsync = util.promisify(fs.writeFile);
    return writeFileAsync(pdfPath, data);
  };

  const readFilesInFolder = async folderPath => {
    return fs.readdirSync(folderPath);
  };

  const readFileFromPath = async filePath => {
    return fs.readFileSync(filePath);
  };

  const deleteContentsInsideFolder = async path => {
    try {
      await fsPromise.readdir(path, err => {}).then(files => Promise.all(files.map(file => fs.unlink(`${path}/${file}`, err => {}))));
    } catch (err) {
      logger.error('error in deleting files in folder', err);
    }
  };

  return {
    covertDatatoXlsFile,
    uploadFolder,
    removeDirectory,
    readXlsFile,
    deleteFile,
    createAvcFolder,
    getExtensionOfFile,
    uploadFile,
    validateInputForFile,
    getGameUrl,
    writeFileAsync,
    readFilesInFolder,
    readFileFromPath,
    deleteContentsInsideFolder,
  };
});
