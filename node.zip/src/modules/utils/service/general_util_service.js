const parsePhoneNumber = require('libphonenumber-js');
const { define } = require('src/containerHelper');
const { isEmpty, omit, difference } = require('ramda');
const fs = require('fs');
const httpContext = require('express-cls-hooked');
const _ = require('lodash');
const sanitize = require('mongo-sanitize');
const xlsx = require('xlsx');
const util = require('util');
const path = require('path');
const fsPromises = require('fs/promises');
const { S3_FOLDER_BY_ENTITY_TYPE, S3_CONFIG_BY_ENTITIES } = require('../../../constants/aws_constants');
const recursiveFs = require('recursive-fs');
const mime = require('mime-types');
const moment = require('moment');
const { expression } = require('joi');
const jexl = require('jexl');
const momentTimezone = require('moment-timezone');

module.exports = define('generalUtilService', ({ logger, awsService, CustomError, constants: { RUNTIME_ERROR }, config }) => {
  /* -------------------------------------------------------------------------- */
  /*                               Utility Methods                              */
  /* -------------------------------------------------------------------------- */

  const getContextCgEntity = () => {
    const cgEntity = httpContext.get('currentCgEntity');
    return cgEntity;
  };
  const getContextAppVariant = () => {
    const appVariant = httpContext.get('appVariant');
    return appVariant;
  };

  const getContextCgEntityType = () => {
    const cgEntityType = httpContext.get('currentCgEntityType');
    return cgEntityType;
  };

  const getCurrentJWTtoken = () => {
    const jwtToken = httpContext.get('jwtToken');
    return jwtToken;
  };

  const getAppVariant = () => {
    const appVariant = httpContext.get('appVariant');
    return appVariant;
  };

  const checkAllKeysHaveTruthyAndAddIsCompleteKey = (object = {}) => {
    object.isCompleted = true;
    for (const key in object) {
      if (Object.hasOwnProperty.call(object, key)) {
        const element = object[key];
        if (element === null || element === undefined || isEmpty(element)) {
          object.isCompleted = false;
          break;
        }
      }
    }
    return object;
  };

  const hasProp = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);

  const getPlainObject = modelObj => {
    if (!modelObj) {
      return modelObj;
    }
    if (modelObj.dataValues && modelObj.get) {
      return modelObj.get({ plain: true });
    }
    return modelObj;
  };
  const getPlainObjects = modelObjs => {
    if (!modelObjs) {
      return modelObjs;
    }
    if (_.isArray(modelObjs)) {
      return _.map(modelObjs, modelObj => getPlainObject(modelObj));
    } else {
      return getPlainObject(modelObjs);
    }
  };

  const parseToJSON = val => {
    try {
      const res = JSON.parse(val);
      return res;
    } catch (e) {
      return val;
    }
  };

  const sanitizeIntValue = (int, defaultNumber = 10) => (!int || int <= 0 || int > Number.MAX_SAFE_INTEGER ? defaultNumber : parseInt(int, 10));

  const formPaginationObj = (page, pageSize) => {
    const limit = sanitizeIntValue(pageSize);
    const offset = page ? sanitizeIntValue((parseInt(page, 10) - 1) * parseInt(limit, 10), 0) : 0;
    return { limit, offset };
  };
  const mapQueryToSearchAttributes = (query, attributes) => {
    const { limit, offset } = formPaginationObj(query?.pageNo, query?.pageSize);
    let filters = {};
    const omittedQuery = omit(['limit', 'offset'], query);
    for (const key in attributes) {
      if (omittedQuery[key] != undefined && omittedQuery[key] != null) {
        const { op, alias } = attributes[key];
        filters[alias] = {
          [op]: op === '$like' ? `%${sanitize(omittedQuery[key])}%` : sanitize(omittedQuery[key]),
        };
      }
    }
    return { whereClause: filters, limit, offset };
  };

  const mapQueryToSearchAttributesMultpleOperator = (query, attributes) => {
    const { limit, offset } = formPaginationObj(query?.pageNo, query?.pageSize);
    let filters = {};
    const omittedQuery = omit(['limit', 'offset'], query);

    for (const key in attributes) {
      if (omittedQuery[key] != undefined && omittedQuery[key] != null) {
        const queryValue = sanitize(omittedQuery[key]);
        const { op, alias, dataType } = attributes[key];
        if (Array.isArray(attributes[key].op) && dataType === 'DATETIME') {
          let filterObj = {};
          op.forEach(operator => {
            // Handling datetime dataType
            if (dataType === 'DATETIME') {
              const [day, month, year] = queryValue.split('/').map(num => parseInt(num, 10));
              if (operator === '$gte') {
                const startDate = new Date(year, month - 1, day);
                filterObj.$gte = startDate;
              } else if (operator === '$lt') {
                const endDate = new Date(year, month - 1, day + 1);
                filterObj.$lt = endDate;
              }
            }
          });
          filters[attributes[key].alias] = { ...filterObj };
        } else {
          filters[alias] = {
            [op]: op === '$like' ? `%${sanitize(omittedQuery[key])}%` : queryValue,
          };
        }
      }
    }
    return { whereClause: filters, limit, offset };
  };

  const validateInputForFile = async (data, size = 600000000) => {
    const fileName = data?.file?.name;
    const ALLOWED_FILE_TYPE = ['jpg', 'jpeg', 'png', 'pdf', 'mp4', 'gif', 'docx', 'doc', 'zip', 'excel'];
    let fileType = null;
    if (data?.file?.type) {
      fileType = String(data?.file?.type)
        .split('/')
        ?.pop()
        ?.toLowerCase();
    }
    const fileExtension = fileName
      ?.split('.')
      ?.pop()
      ?.toLowerCase();

    if (fileType || fileExtension) {
      let extention = fileType || fileExtension;
      if (!extention || !ALLOWED_FILE_TYPE.includes(extention)) {
        throw new CustomError(
          RUNTIME_ERROR.code,
          RUNTIME_ERROR.status,
          `Please upload file with .jpeg, .jpg, .png, .pdf, .doc, .docx .excel extension`
        );
      }
    }
    const fileSize = data?.file?.size;
    if (!fileSize || fileSize > size) {
      throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, `Please upload file less than ${size / (1000 * 1000)} MB`);
    }
  };

  const uploadFile = async ({ files, bucketName, folderName, overWriteFileName, uniqueId, entityName, entityType }) => {
    try {
      if (entityName) {
        bucketName = S3_CONFIG_BY_ENTITIES[entityName].BUCKET_NAME;
      }
      const filePath = path.join(__dirname, '/../../../../resources/' + files.file.name);
      const writeFileAsync = util.promisify(fs.writeFile);
      await writeFileAsync(filePath, files.file.data);

      const fileStream = fs.createReadStream(filePath);
      const fileExtension = files.file.name.split('.')[1];
      const nameFromUniqId = uniqueId ? uniqueId + '.' + fileExtension : undefined;
      const fileName = overWriteFileName || nameFromUniqId || files.file.name;
      if (!folderName && entityType) {
        folderName = `${S3_FOLDER_BY_ENTITY_TYPE[entityName][entityType]}`;
      }
      const fileNameAndPath = `${folderName}/${fileName}`;
      const contentType = files.file.mimetype || files.file?.headers?.['content-type'];
      const fileUploadResponse = await awsService.uploadFileOnS3(bucketName, fileNameAndPath, fileStream, contentType);
      deleteFile(filePath);
      return fileUploadResponse;
    } catch (error) {
      logger.error(`Error while uploading file`, error);
      throw error;
    }
  };

  const uploadFolder = async ({ bucketName, folderPath, entityName, folderName, mimetype }) => {
    try {
      if (entityName) {
        bucketName = S3_CONFIG_BY_ENTITIES[entityName].BUCKET_NAME;
      }
      const uploadPromises = [];
      await recursiveFs.readdirr(folderPath, async (err, dirs, files) => {
        if (!err) {
          //  throw err;
          for (const file of files) {
            const mimetype = mime.lookup(file);
            const fileStream = fs.createReadStream(file);
            const key = file.replace(folderPath, '').substr(1);
            const fileKey = `${folderName}/${key}`;
            uploadPromises.push(awsService.createFolder(bucketName, fileKey, fileStream, true, mimetype ? mimetype : undefined));
            // await awsService.createFolder(bucketName, fileKey, fileStream, false);
          }
        }
      });
      try {
        await Promise.all(uploadPromises);
      } catch (e) {}
      const gameUrl = getGameUrl(folderName + '/index.html');
      return gameUrl;
    } catch (e) {
      console.log(e);
    }
  };

  const getGameUrl = async folderName => {
    return `${config.GAME_URL}/${config.GAME_BUCKET_NAME}/${folderName}`;
  };
  // recursion used to return unique number to avoid data repetition in array
  const returnRandomNumber = (maxRandomNumber = 10, randomNumberExistsDir = {}) => {
    const randomNumber = Math.floor(Math.random() * maxRandomNumber); // generating random number
    if (randomNumber in randomNumberExistsDir) return returnRandomNumber(maxRandomNumber, randomNumberExistsDir);
    randomNumberExistsDir[randomNumber] = true;
    return randomNumber;
  };

  // recursion used to return unique number to avoid data repetition in array
  const readXlsFile = async (file, sheetName) => {
    const filePath = path.join(__dirname, '/../../../../resources/' + file.name);
    const writeFileAsync = util.promisify(fs.writeFile);
    await writeFileAsync(filePath, file.data);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
    const worksheet = workbook.Sheets[sheetName];
    // const range = xlsx.utils.decode_range(worksheet['!ref']);
    return { sheetData, filePath, worksheet };
  };

  const deleteFile = fileName => {
    return fs.unlink(fileName, function(err) {
      if (err) {
        logger.error(`Error while deleting file`, err);
      }
    });
  };

  const removeDirectory = async dirPath => {
    try {
      await fsPromises.rm(dirPath, { recursive: true });
      logger.info(`Directory removed`);
    } catch (err) {
      logger.error(`Error while deleting file`, err);
    }
  };

  const createAvcFolder = async (bucketName, folderName) => {
    const folderKey = `${folderName}/${folderName}_avc`;
    const folderCreateResponse = await awsService.createFolder(bucketName, folderKey);
    return folderCreateResponse;
  };

  const getExtensionOfFile = files => {
    const fileName = files?.file?.name;
    const fileExtension = fileName
      ?.split('.')
      ?.pop()
      ?.toLowerCase();
    return fileExtension;
  };

  const nullStrChecker = param => {
    return param == 'NULL' || param == 'Null' || param == 'NA' ? null : param;
  };
  const convertArrayItemsToCommaSperatedStrings = array => {
    let str = '';
    for (let i = 0; i < array.length; i++) {
      str = str == '' ? `'${array[i]}'` : str + `, '${array[i]}'`;
    }
    return str;
  };

  const getNowTimeStamp = () => {
    return moment(new Date()).format('YYYY-MM-DD HH:mm:ss UTC+00:00');
  };

  const getDifferenceBetweenMappedAndUnmappedIds = (requestedIds, mappedEntities) => {
    let deletedIds = [];
    let addedIds = [];
    let allMappedIds = [];
    if (!requestedIds) requestedIds = [];
    if (mappedEntities && mappedEntities.length) {
      allMappedIds = mappedEntities.map(mappedTag => mappedTag.id);
      deletedIds = difference(allMappedIds, requestedIds);
      addedIds = difference(requestedIds, allMappedIds);
    } else {
      addedIds = difference(requestedIds, allMappedIds);
    }
    return { deletedIds, addedIds, allMappedIds };
  };

  const getDeletedIds = (allMappedIds, requestedIds) => {
    const deletedIds = difference(allMappedIds, requestedIds);
    return deletedIds;
  };

  const calculateAge = dob => {
    const currentDate = new Date();
    const birthDate = new Date(dob);

    let age = currentDate.getFullYear() - birthDate.getFullYear();

    const currentMonth = currentDate.getMonth();
    const birthMonth = birthDate.getMonth();

    if (currentMonth < birthMonth || (currentMonth === birthMonth && currentDate.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 3) age = 3;
    return age;
  };

  const groupByNestedKeyWithSumOrderBySum = (array, nestedKey, sumKey) => {
    let groupedData = groupByNestedKeyWithSum(array, nestedKey, sumKey);

    let sortedGroups = Object.keys(groupedData).sort((a, b) => {
      return groupedData[b].sum - groupedData[a].sum;
    });

    let result = sortedGroups.map(groupKey => {
      return { contentId: groupKey, sum: groupedData[groupKey].sum };
    });

    return result;
  };

  const groupByNestedKeyWithSum = (array, nestedKey, sumKey) => {
    return array.reduce((acc, obj) => {
      let nestedKeyArray = nestedKey.split('.');
      let nestedObj = obj;
      for (let i = 0; i < nestedKeyArray.length; i++) {
        nestedObj = nestedObj[nestedKeyArray[i]];
      }
      let groupKey = nestedObj;
      if (!acc[groupKey]) {
        acc[groupKey] = {
          items: [],
          sum: 0,
        };
      }
      acc[groupKey].items.push(obj);
      acc[groupKey].sum += obj[sumKey];
      return acc;
    }, {});
  };

  const addMonthsToDate = (date, months) => {
    return moment(date)
      .add(months, 'months')
      .format('YYYY-MM-DD');
  };

  const camelCaseToUnderscore = key => {
    return key.replace(/([A-Z])/g, '_$1').toLowerCase();
  };

  const validatePhoneNumber = mobile => {
    const phone = parsePhoneNumber(mobile);
    if (!phone) return false;
    if (!phone.isValid()) {
      return false;
    }
    return true;
  };

  const evalExprAndReturnVal = (expression, data) => jexl.evalSync(expression, data);

  const isInstanceOf = (instance, obj) => obj instanceof instance;

  const hasPermission = (expressionArr, data) => {
    for (const expresssion of expressionArr) {
      const ruleEval = jexl.evalSync(expresssion, data);
      if (isInstanceOf(Boolean, ruleEval)) {
        return !ruleEval;
      }
    }
    return true;
  };

  const filterObject = (originalObject, keysToInclude) => {
    const filteredObj = {};
    for (const key in keysToInclude) {
      const value = originalObject[key];
      if (value !== null && value !== undefined && value !== '') {
        filteredObj[key] = value;
      }
    }
    return filteredObj;
  };

  const parseQueryParam = queryParams => {
    const parsedParams = {};

    for (const key in queryParams) {
      if (queryParams.hasOwnProperty(key)) {
        const value = queryParams[key];
        if (value === 'true') {
          parsedParams[key] = true;
        } else if (value === 'false') {
          parsedParams[key] = false;
        } else {
          parsedParams[key] = value;
        }
      }
    }

    return parsedParams;
  };

  const convertLocalTimeToUTC = (startDate, startTime, endTime, timezone) => {
    const startDateTimeString = `${startDate} ${startTime}`;

    const startDateTime = momentTimezone.tz(startDateTimeString, 'YYYY-MM-DD HH:mm:ss', timezone);

    const endDateTimeString = `${startDate} ${endTime}`;

    const endDateTime = momentTimezone.tz(endDateTimeString, 'YYYY-MM-DD HH:mm:ss', timezone);

    const utcStartDateTime = startDateTime.utc();

    const utcEndDateTime = endDateTime.utc();

    const utcStartDate = utcStartDateTime.format('YYYY-MM-DD');
    const utcStartTime = utcStartDateTime.format('HH:mm:ss');
    const utcEndTime = utcEndDateTime.format('HH:mm:ss');

    return {
      utcStartDate,
      utcStartTime,
      utcEndTime,
    };
  };

  const convertUTCToLocalTime = (date, startTime, endTime, timezone) => {
    const startDateTimeString = `${date} ${startTime}`;
    const startDateTimeUTC = momentTimezone.utc(startDateTimeString, 'YYYY-MM-DD HH:mm:ss');

    const endDateTimeString = `${date} ${endTime}`;
    const endDateTimeUTC = momentTimezone.utc(endDateTimeString, 'YYYY-MM-DD HH:mm:ss');

    const localStartDateTime = startDateTimeUTC.tz(timezone);
    const localEndDateTime = endDateTimeUTC.tz(timezone);

    const localStartDate = localStartDateTime.format('YYYY-MM-DD');
    const localStartTime = localStartDateTime.format('HH:mm:ss');
    const localEndTime = localEndDateTime.format('HH:mm:ss');

    return {
      localStartDate,
      localStartTime,
      localEndTime,
    };
  };

  const getRandomQuestions = (questionsArray, n) => {
    const selectedQuestions = [];
    const totalQuestions = questionsArray.length;

    if (n >= totalQuestions) {
      return questionsArray;
    }

    const getRandomIndices = (max, n) => {
      const indices = new Set();

      while (indices.size < n) {
        const randomIndex = Math.floor(Math.random() * max);
        indices.add(randomIndex);
      }

      return Array.from(indices);
    };

    const indices = getRandomIndices(totalQuestions, n);

    for (const index of indices) {
      selectedQuestions.push(questionsArray[index]);
    }

    return selectedQuestions;
  };

  return {
    getContextCgEntity,
    getContextAppVariant,
    hasTruthyValues: checkAllKeysHaveTruthyAndAddIsCompleteKey,
    hasProp,
    getPlainObjects,
    parseToJSON,
    mapQueryToSearchAttributes,
    formPaginationObj,
    returnRandomNumber,
    getCurrentJWTtoken,
    getContextCgEntityType,
    nullStrChecker,
    convertArrayItemsToCommaSperatedStrings,
    getNowTimeStamp,
    getDifferenceBetweenMappedAndUnmappedIds,
    getDeletedIds,
    calculateAge,
    uploadFolder,
    removeDirectory,
    readXlsFile,
    deleteFile,
    createAvcFolder,
    getExtensionOfFile,
    uploadFile,
    validateInputForFile,
    getGameUrl,
    getAppVariant,
    groupByNestedKeyWithSumOrderBySum,
    groupByNestedKeyWithSum,
    addMonthsToDate,
    camelCaseToUnderscore,
    validatePhoneNumber,
    evalExprAndReturnVal,
    hasPermission,
    filterObject,
    mapQueryToSearchAttributesMultpleOperator,
    parseQueryParam,
    convertLocalTimeToUTC,
    convertUTCToLocalTime,
    getRandomQuestions,
  };
});
