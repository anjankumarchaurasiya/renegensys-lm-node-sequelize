// const { define } = require('src/containerHelper');;
const { define } = require('../../../containerHelper');
const { sign } = require('jsonwebtoken');
const jwt = require('jsonwebtoken');

module.exports = define('userSessionService', ({
  CustomError,
  constants: { TOKEN_EXPIRATION, ENTITY_TYPE, TOKEN_TYPE, PROVIDE_VALID_DATA },
  config,
  userSessionRepository,
}) => {
  const generateToken = async tokenBody => {
    const { entityType, userId, tokenType } = tokenBody;
    let tokenExpiration = TOKEN_EXPIRATION[tokenType.toUpperCase()][entityType.toUpperCase()];

    const secret = tokenType == TOKEN_TYPE.ACCESS ? config.authAccessSecret : config.authRefreshSecret;

    const token = sign({ userId, entityType, v: '0.1' }, secret, {
      expiresIn: tokenExpiration || '7d',
    });
    return token;
  };

  const createUserSession = async sessionData => {
    const { userId, entityType = ENTITY_TYPE.USER } = sessionData;
    const accessToken = await generateToken({ ...sessionData, entityType: entityType, tokenType: TOKEN_TYPE.ACCESS });
    const refreshToken = await generateToken({ ...sessionData, entityType: entityType, tokenType: TOKEN_TYPE.REFRESH });

    const userSessionCreated = await userSessionRepository.create({ userId, accessToken, refreshToken });
    return { accessToken: accessToken, refreshToken: refreshToken, sessionId: userSessionCreated.id };
  };

  const updateUserSession = async (sessionEntity, whereClause) => {
    try {
      const existingUserSession = await userSessionRepository.getUserSession(whereClause);

      if (!existingUserSession) {
        throw new Error('User session not found');
      }
      const updatedUserSession = await userSessionRepository.update(sessionEntity, whereClause);
      return updatedUserSession;
    } catch (error) {
      console.error('Error updating user session:', error);
      throw error;
    }
  };

  const getUserSession = async whereClause => {
    const result = await userSessionRepository.getUserSession(whereClause);
    return result;
  };

  const rotateAccessToken = async body => {
    const { refreshToken } = body;
    try {
      let userId;

      jwt.verify(refreshToken, config.authRefreshSecret, (err, decoded) => {
        if (err) {
          console.error('Token verification error:', err);
          throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide valid RefreshToken `);
        } else {
          const payload = decoded;
          userId = payload.userId;
        }
      });

      const accessToken = await generateToken({ entityType: ENTITY_TYPE.USER, tokenType: TOKEN_TYPE.ACCESS, userId: userId });
      const newRefreshToken = await generateToken({ entityType: ENTITY_TYPE.USER, tokenType: TOKEN_TYPE.REFRESH, userId: userId });

      const updatedUserSession = await updateUserSession(
        { accessToken: accessToken, refreshToken: newRefreshToken },
        { userId: userId, refreshToken: refreshToken }
      );
      if (updatedUserSession) {
        return { accessToken: accessToken, refreshToken: newRefreshToken };
      } else {
        throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide valid RefreshToken `);
      }
    } catch (error) {
      // Handle authentication error
      throw error;
    }
  };

  return {
    createUserSession,
    generateToken,
    updateUserSession,
    getUserSession,
    rotateAccessToken,
  };
});
