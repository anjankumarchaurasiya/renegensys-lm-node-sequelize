const { define } = require('src/containerHelper');

module.exports = define('userSessionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_session');
  const userSessionModel = database['user_session'];

  const getUserSession = async whereClause => {
    const userSession = await userSessionModel.findOne({
      where: {
        recordStatus: 1,
        ...whereClause,
      },
    });

    return userSession;
  };
  return {
    ...baseRepo,
    getUserSession,
  };
});
