'use strict';

module.exports = (sequelize, DataTypes) => {
  const userSession = sequelize.define(
    'user_session',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      accessToken: {
        type: DataTypes.STRING,
      },
      refreshToken: {
        type: DataTypes.STRING,
      },
      userId: {
        type: DataTypes.UUID,
      },
      // deviceName: {
      //   type: DataTypes.STRING,
      // },
      // deviceId: {
      //   type: DataTypes.STRING,
      // },
      // deviceType: {
      //   type: DataTypes.STRING,
      // },
      ipAddress: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      createdBy: {
        type: DataTypes.UUID,
      },
      updatedBy: {
        type: DataTypes.UUID,
      },
    },
    {
      freezeTableName: true,
    }
  );

  userSession.associate = function(models) {
    userSession.belongsTo(models.user, { foreignKey: 'userId' });
  };

  return userSession;
};
