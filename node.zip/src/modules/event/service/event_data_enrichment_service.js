const { define } = require('src/containerHelper');
const _ = require('lodash');

module.exports = define('eventDataEnrichmentService', ({ constants: { eventConstants, CONTENT_TYPE }, logger, dateTimeUtilService }) => {
  const ENRICH_HANDLER = {};
  const eventEnrichment = async messageObj => {
    const eventNameMethod = eventConstants.eventNameEnrichingMethods[messageObj.eventName];
    const eventName = messageObj.eventName;
    // Handle Duplicate notifications for Payments & Slack.
    // await _checkDuplicateMessage(eventName, messageObj);s
    let data = messageObj.data;
    let isTestEnabled = data ? data.isTestEnabled : false;
    let sqsMessageProcessBegin = Date.now();
    if (data && ENRICH_HANDLER[eventNameMethod]) {
      try {
        logger.info(`ENRICH_HANDLER: ${ENRICH_HANDLER[eventNameMethod]}`);
        return ENRICH_HANDLER[eventNameMethod](eventName, messageObj);
      } catch (ex) {
        logger.error(`eventDataEnrichmentService : ENRICH_HANDLER failed for event ${eventName} with params ${JSON.stringify(messageObj)}`, ex);
      }
    }
    if (data) {
      data.isTestEnabled = isTestEnabled;
      let sqsMessageProcessEnd = Date.now() - sqsMessageProcessBegin;
      logger.info(
        `Message ProcessTime ${sqsMessageProcessEnd} ms in eventDataEnrichmentService ${eventName} ${messageObj ? messageObj.awsSQSMessageId : ''}`
      );
    }
  };

  [
    eventConstants.eventNameEnrichingMethods.UPDATE_GAME_LOG,
    eventConstants.eventNameEnrichingMethods.UPDATE_VIDEO_LOG,
    eventConstants.eventNameEnrichingMethods.STORE_PAYWALL_LOG,
    eventConstants.eventNameEnrichingMethods.STORE_PAYMENT_LOG,
    eventConstants.eventNameEnrichingMethods.STORE_PROFILE_LOG,
  ].map(event => {
    ENRICH_HANDLER[event] = async (eventName, messageObj) => {
      logger.info(`==== ENRICHMENT EVENT DATA ==== ${eventName} ==== ${JSON.stringify(messageObj)}`);
      try {
        messageObj.data.ls_created = await dateTimeUtilService.getNowFullTimeStamp();
        let ls_data = {};
        messageObj.data.ls_data = ls_data;

        delete messageObj.data.deviceAttribute;
        return messageObj;
      } catch (e) {
        logger.info(`enrich crashed `, e);
      }
    };
  });

  return {
    eventEnrichment,
  };
});
