const { define, getService } = require('src/containerHelper');
const searchFilters = require('../constants/search_filter_constants');
module.exports = define('eventService', ({
  logger,
  CustomError,
  eventConfigService,
  constants: { eventConstants },
  eventUtilService,
  eventDataEnrichmentService,
  eventConfigRepository,
  generalUtilService,
}) => {
  const handleEventAppNotificationQueue = async messageObj => {
    try {
      await processMessage(messageObj);
    } catch (err) {
      if (err instanceof CustomError) {
      } else {
        logger.error(`NotificationService === Error in processMessage ${err}`, err.stack);
      }
      throw err;
    }
  };

  const processMessage = async messageObj => {
    try {
      const { eventName, eventType } = messageObj;
      let parsedEventConfigData;
      let enrichedData;
      let messageData = messageObj.data;
      // // let d = await eventLogRepository.createLog({ eventName: 'test', eventData: 'v' });
      logger.info(`processMessage for ${eventName} && ${eventType}`);
      let eventConfig = await eventConfigService.getEventConfig({ name: eventName, type: eventType });
      if (eventConfig) {
        eventConfig = eventConfig.get({ plain: true });

        const parsedEventConfig = await eventUtilService.parseConfig(eventConfig, messageData);
        parsedEventConfigData = parsedEventConfig.variables;
        logger.info(`parsedEventConfigData ${JSON.stringify(parsedEventConfigData)} `);
        if (parsedEventConfigData.doEnrichment) {
          enrichedData = await eventDataEnrichmentService.eventEnrichment({
            eventName,
            eventType,
            data: { ...parsedEventConfigData, deviceAttribute: messageData.deviceAttribute },
          });
        } else {
          enrichedData = { data: parsedEventConfigData };
        }
      }
      if (enrichedData && enrichedData.data) {
        await handleEventAux({ eventName, eventType, data: enrichedData.data, eventConfig });
      } else {
        logger.error(`something went wrong in enrichment`);
      }
    } catch (err) {
      throw err;
    }
  };

  const testEvent = async body => {
    await handleEventAppNotificationQueue(body);
  };

  // Based on the notificaiton type call the respective method.
  const handleEventAux = async ({ eventName, eventType, data, eventConfig }) => {
    switch (eventType) {
      case eventConstants.eventType.LOGGING:
        await logMongo({ eventName, eventType, data, eventConfig });
        break;
      case eventConstants.eventType.CALL_URL:
        await callURL({ eventName, eventType, data, eventConfig });
        break;
      case eventConstants.eventType.CALL_METHOD:
        await callMethod({ eventName, eventType, data, eventConfig });
        break;
      default:
        break;
    }
  };

  const logMongo = async ({ eventName, eventType, data, eventConfig }) => {
    const { serviceName, methodName } = eventConfig;
    try {
      let serviceCls = getService(serviceName);
      let methodObj = serviceCls[methodName];
      if (typeof methodObj === 'function') {
        await methodObj(data);
      }
    } catch (e) {
      logger.info(`Error in invoke method call in logging`, e);
      // throw e;
    }
  };

  const callURL = async (actionConfig, data, eventName, eventType) => {};

  const callMethod = async ({ eventName, eventType, data, eventConfig }) => {
    const { serviceName, methodName } = eventConfig;

    try {
      let serviceCls = getService(serviceName);
      let methodObj = serviceCls[methodName];
      if (typeof methodObj === 'function') {
        await methodObj(data);
      }
    } catch (e) {
      logger.info(`Error in invoke method call in method call`, e);
      // throw e;
    }
  };

  const getAllEvents = async queryParams => {
    let eventResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.event);
      eventResponse = await eventConfigRepository.getAllEvents(
        ['id', 'name', 'type', 'serviceName', 'methodName', 'config', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.event);
      eventResponse = await eventConfigRepository.getAllEvents(
        ['id', 'name', 'type', 'serviceName', 'methodName', 'config', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: eventResponse.count, events: eventResponse.rows };
  };

  const createEventConfigs = body => eventConfigRepository.create(body);
  const updateEventConfigs = data => eventConfigRepository.update(data, { id: data.id });
  const deactivateEventConfig = id => eventConfigRepository.deactivate(id);
  return {
    handleEventAppNotificationQueue,
    testEvent,
    getAllEvents,
    createEventConfigs,
    updateEventConfigs,
    deactivateEventConfig,
  };
});
