const { define } = require('src/containerHelper');
const expr = require('expression-eval');
const ejs = require('ejs');
const { clone } = require('ramda');

module.exports = define('eventUtilService', ({ logger, CustomError }) => {
  const parseConfig = async (config, data) => {
    let response = {};
    if (config && data) {
      const eConfig = clone(config.config);
      const variables = await parseTemplateVariables(config, eConfig, data);
      response = {
        ...eConfig,
        variables,
      };
    }

    return response;
  };

  const parseTemplateVariables = async (config, eConfig, data) => {
    const { type, name: eventName } = config;
    try {
      const configVariables = eConfig.variables;
      const response = {};
      if (configVariables) {
        for (const i in configVariables) {
          const v = configVariables[i];
          const key = getKeyName(type, v);
          response[key] = await getValue(v, data, type);
        }
      }
      return response;
    } catch (err) {
      logger.error(`Event name:${eventName}, type:${type} ==== error in parseTemplateVariables====== `, err);
      return [];
    }
  };

  const getKeyName = (notificationType, param) => {
    return param.key;
  };

  const getSanitizedValue = (eventType, val) => {
    return val;
  };

  const getValue = async (variableConfig, data, eventType) => {
    let value = '';
    const ast = expr.parse(variableConfig.valueExpr);
    value = getSanitizedValue(eventType, expr.eval(ast, data));
    if (variableConfig.isEjs) {
      value = ejs.render(value, data);
    }
    return value;
  };

  const parseActionConfig = async (actionConfig, data, eventName, eventType) => {
    // try {
    //   const response = {}
    //   if (actionConfig.actionVariables) {
    //     const { actionVariables } = actionConfig
    //     for (const i in actionVariables) {
    //       const v = actionVariables[i]
    //       const key = getKeyName(type, v)
    //       response[key] = await getValue(v, data, type)
    //     }
    //     return response
    //   }
    //   logger.info(`Event name:${eventName}, type:${eventType} ==== actionConfig missing `)
    //   return null
    // } catch (err) {
    //   logger.error(`Event name:${eventName}, type:${eventType} ==== error in parseActionConfig====== `, err)
    //   return []
    // }
  };

  return {
    parseConfig,
    parseActionConfig,
  };
});
