module.exports = Object.freeze({
  event: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
    },
    name: {
      op: '$like',
      alias: 'name',
    },
    serviceName: {
      op: '$like',
      alias: 'service_name',
    },
    type: {
      op: '$like',
      alias: 'type',
    },
    methodName: {
      op: '$like',
      alias: 'method_name',
    },
  },
});
