const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  EVENT_CREATED_SUCCESSFULLY,
  EVENT_UPDATED_SUCCESSFULLY,
  EVENT_MESSAGE_SENT_SUCCESSFULLY,
  EVENT_DEACTIVATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
  } = container.cradle;
  const { eventService, logger, commonUtilService, authorizeMiddleware } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      const events = await eventService.getAllEvents(query);
      res.status(Status.OK).json(await Success(events));
    } catch (e) {
      next(e);
    }
  });
  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create the Event', body);
      let data = await eventService.createEventConfigs(body);
      res.status(Status.OK).json(await Success(data, EVENT_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.patch('/:eventId', async (req, res, next) => {
    try {
      const {
        params: { eventId },
        body,
      } = req;
      await eventService.updateEventConfigs({ ...body, id: eventId });
      let data;
      res.status(Status.OK).json(await Success(data, EVENT_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.post('/send-message', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Event Send-Message Route', body);
      await commonUtilService.sendMessageToQueue(req.body);
      let data;
      res.status(Status.OK).json(await Success(data, EVENT_MESSAGE_SENT_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.delete('/:eventId', async (req, res, next) => {
    try {
      const {
        params: { eventId },
      } = req;
      await eventService.deactivateEventConfig({ id: eventId });
      let data;
      res.status(Status.OK).json(await Success(data, EVENT_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
