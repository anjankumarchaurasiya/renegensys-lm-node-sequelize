const { define } = require('src/containerHelper');

module.exports = define('eventLogModel', ({ mongoDBConn }) => {
  const eventLogSchema = new mongoDBConn.base.Schema({
    eventName: {
      type: String,
      required: true,
    },
    eventData: {
      type: String,
    },
  });

  eventLogSchema.index({ eventName: 1 }, { name: 'name_idx' });

  return mongoDBConn.model('event_log', eventLogSchema);
});
