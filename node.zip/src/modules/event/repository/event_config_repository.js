const { define } = require('src/containerHelper');

module.exports = define('eventConfigRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('event_config');
  const eventConfigModel = database['event_config'];

  const getConfig = async whereClause =>
    eventConfigModel.findOne({
      where: {
        recordStatus: 1,
        ...whereClause,
      },
    });

  const bulkCreate = data => eventConfigModel.bulkCreate(data, { ignoreDuplicates: true });

  const getAllEvents = (attributes, whereClause, orderBy, limit, offset) => {
    const finalClause = {
      where: whereClause,
      attributes: attributes,
    };
    if (limit && offset) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }
    if (orderBy) finalClause.order = orderBy;
    return eventConfigModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    getConfig,
    bulkCreate,
    getAllEvents,
  };
});
