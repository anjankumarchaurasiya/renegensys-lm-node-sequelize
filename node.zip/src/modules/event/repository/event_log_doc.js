const { define } = require('src/containerHelper');

module.exports = define('eventLogRepository', ({
  // mongoDBConn,
  eventLogModel,
}) => {
  //   const eventLogSchema = new mongoDBConn.base.Schema({
  //       eventName: {
  //         type: String,
  //         required: true
  //       },
  //       eventData: {
  //         type: Object,
  //         required: true
  //       }
  //   })

  //   eventLogSchema.index({ eventName: 1 }, { name: 'name_idx' })

  //   const eventLogSchemaMongoModel = mongoDBConn.model('event_log', eventLogSchema)

  const createLog = async data => {
    let d = await eventLogModel.create(data, true);
  };

  return {
    createLog,
  };
});
