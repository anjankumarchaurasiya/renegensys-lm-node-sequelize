const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const request = require('request');
var bodyParser = require('body-parser');

module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
  } = container.cradle;
  const { logger, webhookService } = container.cradle;

  router.post('/sns', bodyParser.text(), async (req, res, next) => {
    try {
      // to do
    } catch (e) {
      next(e);
    }
  });

  return router;
};
