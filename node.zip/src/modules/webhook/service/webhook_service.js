const { define } = require('src/containerHelper');
const moment = require('moment');

module.exports = define('webhookService', ({ config, awsService, constants: { eventConstants, CONTENT_TYPE }, dateTimeUtilService }) => {
  const venisoTagUpdate = async queryParams => {};

  return {
    venisoTagUpdate,
  };
});
