module.exports = (sequelize, DataTypes) => {
  const Category = sequelize.define(
    'category',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
        unique: true,
      },
      type: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Category.associate = function(models) {
    Category.hasMany(models.question, {
      foreignKey: 'categoryId',
      sourceKey: 'id',
    });
    Category.hasMany(models.quiz, {
      foreignKey: 'categoryId',
      sourceKey: 'id',
    });
    Category.hasMany(models.feedback, {
      foreignKey: 'categoryId',
      sourceKey: 'id',
    });
  };
  return Category;
};
