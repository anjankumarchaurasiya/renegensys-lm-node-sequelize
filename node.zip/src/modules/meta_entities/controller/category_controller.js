const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { CATEGORY_CREATED_SUCCESSFULLY, CATEGORY_UPDATED_SUCCESSFULLY, CATEGORY_DELETED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const { categoryService, logger, userContextMiddleware, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create category route');
      await categoryService.createCategory(body);
      let data;
      res.status(Status.OK).json(await Success(data, CATEGORY_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:categoryId', async (req, res, next) => {
    try {
      const {
        params: { categoryId },
        body,
      } = req;
      logger.info('Update category route');
      await categoryService.updateCategory({ id: categoryId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, CATEGORY_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:categoryId', async (req, res, next) => {
    try {
      const {
        params: { categoryId },
      } = req;
      let categoryDetail = await categoryService.getCategory({ id: categoryId });
      res.status(Status.OK).json(await Success(categoryDetail));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter/list', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get category List`);
      const categoryList = await categoryService.getCategoryList(query);
      res.status(Status.OK).json(await Success(categoryList));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:categoryId', async (req, res, next) => {
    try {
      const {
        params: { categoryId },
      } = req;
      logger.info('Delete category route');
      await categoryService.deactivateCategory(categoryId);
      let data;
      res.status(Status.OK).json(await Success(data, CATEGORY_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
