const { define } = require('src/containerHelper');

module.exports = define('categoryRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('category');
  const categoryModel = database['category'];

  const bulkCreate = data => categoryModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
