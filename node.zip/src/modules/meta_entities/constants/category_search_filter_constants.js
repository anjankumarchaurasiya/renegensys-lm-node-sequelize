module.exports = Object.freeze({
  category: {
    name: {
      op: '$like',
      alias: 'name',
      dataType: 'STRING',
    },
    type: {
      op: '$like',
      alias: 'type',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
  },
});
