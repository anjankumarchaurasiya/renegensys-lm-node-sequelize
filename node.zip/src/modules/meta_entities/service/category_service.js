const { define } = require('src/containerHelper');
const searchFilters = require('../constants/category_search_filter_constants');
module.exports = define('categoryService', ({
  categoryRepository,
  CustomError,
  generalUtilService,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
}) => {
  const createCategory = async categoryData => {
    const { name } = categoryData;
    const isCategoryExist = await categoryRepository.findOne({ name: name });
    if (isCategoryExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Category already exists with name`);
    }
    const category = await categoryRepository.create(categoryData);
    return category;
  };

  const updateCategory = async categoryData => {
    const { name } = categoryData;
    const category = await categoryRepository.findOne({ id: categoryData.id });
    if (!category) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Category not found');
    }
    if (name) {
      const categoryNameExist = await categoryRepository.findOne({ name: name });
      if (categoryNameExist) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Category already exists with same name`);
      }
    }
    await categoryRepository.update(categoryData, { id: categoryData.id });
  };

  const getCategory = async categoryId => {
    const category = await categoryRepository.findOne(categoryId);
    if (!category) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Category not found');
    }
    return category;
  };

  const getCategoryList = async queryParams => {
    let categoryListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.category);
      categoryListResponse = await categoryRepository.findAndCountAll(
        ['id', 'name', 'type', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.category);

      categoryListResponse = await categoryRepository.findAndCountAll(['id', 'name', 'type', 'created_at', 'recordStatus'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }

    return { count: categoryListResponse.count, category: categoryListResponse.rows };
  };

  const deactivateCategory = async categoryId => {
    let category = await categoryRepository.findOne({ id: categoryId });
    if (!category) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Category not found `);
    }
    await categoryRepository.deactivate({ id: categoryId });
  };
  const bulkCreate = data => categoryRepository.bulkCreate(data);

  return {
    createCategory,
    updateCategory,
    getCategory,
    getCategoryList,
    deactivateCategory,
    bulkCreate,
  };
});
