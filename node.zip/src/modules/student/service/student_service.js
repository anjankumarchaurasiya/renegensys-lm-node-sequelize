const { define } = require('src/containerHelper');
const { USER_ROLES, LEARNING_SESSION_NOT_STARTED } = require('src/constants');
const moment = require('moment');

module.exports = define('studentService', ({
  generalUtilService,
  CustomError,
  constants: {
    ENTITY_ALREADY_EXISTS,
    UNAUTHORIZED_REQUEST,
    ENTITY_NOT_FOUND,
    ERROR_CAPSTONE_NOT_CHECKED,
    ERROR_CAPSTONE_SUBMIT_FAILED,
    ALREADY_JOINED_SESSION,
    SESSION_STATUS_TYPE,
    INVALID_REQUEST,
    LEARNING_SESSION_NOT_JOINED,
  },
  studentRepository,
  userQuizProgressRepository,
  learningSessionRepository,
  categoryRepository,
  userResponseRepository,
  userResponseContentRepository,
  batchQuizRepository,
  batchRepository,
  logger,
  userRoleService,
  learningSessionAttendanceRepository,
}) => {
  const getCourseByUserId = async userId => {
    const courseDetail = await studentRepository.getCourseByUserId(userId);
    if (courseDetail) {
      return courseDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Course not found `);
    }
  };
  const getLearningSessionByBatchId = async batchId => {
    let learningSessionDetail = await studentRepository.getLearningSessionByBatchId(batchId);

    if (learningSessionDetail) {
      const modifiedLearningSessions = await Promise.all(
        learningSessionDetail.map(async session => {
          const learningSessionId = session.id;
          session = session.get({ plain: true });
          // Iterate over each module within the learning session
          const modifiedModules = await Promise.all(
            session.learning_session_modules.map(async learningSessionModule => {
              const module = learningSessionModule.module;
              const moduleId = module.id;

              // Fetch topic count for the current module from module_topic table
              const topicCount = module.topics.length;

              // Fetch completed topic counts for the current module from learning_session_progress table
              const completedTopics = await Promise.all(
                module.topics.map(async topic => {
                  const topicId = topic.id;
                  const completedTopicCount = await studentRepository.completedTopicCountBasedOnModuleIdTopicIdLearningSessionId(
                    moduleId,
                    learningSessionId,
                    topicId
                  );

                  // Determine if the topic is completed based on completion counts
                  const isTopicCompleted = completedTopicCount > 0;

                  // Update the topic with the completion status
                  return {
                    ...topic,
                    isTopicCompleted: isTopicCompleted,
                  };
                })
              );
              // Fetch completed topic count for the current module from learning_session_progress table
              const completedTopicCount = await studentRepository.completedTopicCountBasedOnModuleId(moduleId, learningSessionId);

              // Determine if the module is completed based on topic counts
              const isModuleCompleted = topicCount > 0 && completedTopicCount === topicCount;

              // Update the module with the completion status
              return {
                ...learningSessionModule,
                module: {
                  isModuleCompleted: isModuleCompleted,
                  ...module,
                  topics: completedTopics,
                },
              };
            })
          );

          // Construct the modified session object
          const modifiedSession = {
            ...session,
            learning_session_modules: modifiedModules,
          };

          return modifiedSession;
        })
      );
      // Return the updated learningSessionDetail directly

      return modifiedLearningSessions;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `learningSession not found`);
    }
  };
  const getSessionQuizByBatchId = async batchId => {
    const preSession = await categoryRepository.findOne({ name: 'PRE_SESSION' });
    const postSession = await categoryRepository.findOne({ name: 'POST_SESSION' });
    const capstoneCategory = await categoryRepository.findOne({ name: 'CAPSTONE' });
    const examCategory = await categoryRepository.findOne({ name: 'EXAM' });
    const preSessionCategoryId = preSession?.id;
    const postSessionCategoryId = postSession?.id;
    const capstoneCategoryId = capstoneCategory?.id;
    const examCategoryId = examCategory?.id;
    const preSessionResult = await getSessionQuizByBatchCategory(batchId, preSessionCategoryId);
    const postSessionResult = await getSessionQuizByBatchCategory(batchId, postSessionCategoryId);
    const batchInfo = await batchRepository.findOne({ id: batchId });
    const capstoneResult = await batchQuizRepository.findOne({ batchId: batchId, categoryId: capstoneCategoryId });
    const examQuizResult = await batchQuizRepository.findOne({ batchId: batchId, categoryId: examCategoryId });

    return {
      preSessionResult: preSessionResult,
      postSessionResult: postSessionResult,
      examQuizId: examQuizResult?.quizId ? examQuizResult.quizId : '',
      capstoneId: capstoneResult?.quizId ? capstoneResult.quizId : '',
      learningSessionFeedbackId: batchInfo?.feedbackId,
    };
  };
  const getSessionQuizByBatchCategory = async (batchId, categoryId) => {
    let learningSession = await studentRepository.getSessionQuizByBatchId(batchId, categoryId);
    const updatedLearningSession = await Promise.all(
      learningSession.map(async session => {
        if (session.learning_session_quizzes && session.learning_session_quizzes.length > 0) {
          const updatedQuizzes = await Promise.all(
            session.learning_session_quizzes.map(async sessionQuiz => {
              const userResponses = await userQuizProgressRepository.findOne({ quiz_id: sessionQuiz.dataValues.quiz_id });
              const examAttempt = userResponses?.dataValues ? true : false;
              return {
                ...sessionQuiz.toJSON(),
                examAttempt,
              };
            })
          );
          return {
            ...session.toJSON(),
            learning_session_quizzes: updatedQuizzes,
          };
        } else {
          return session.toJSON();
        }
      })
    );
    if (updatedLearningSession) {
      return updatedLearningSession;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `sessionQuiz not found `);
    }
  };
  const getCapstoneReport = async (userId, userQuizProgressId) => {
    try {
      const quizProgress = await userQuizProgressRepository.findOne({ id: userQuizProgressId });
      if (quizProgress) {
        const quizId = quizProgress.quizId;
        const capstoneReport = await studentRepository.getCapstoneReport(quizId, userId, userQuizProgressId);
        return capstoneReport;
      } else {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `Capstone not exist`);
      }
    } catch (error) {
      console.error(error);
    }
  };
  const submitCapstone = async (userId, capstoneResponse, quizId, isSubmit) => {
    // Validate input: capstoneResponse must be an array of objects
    if (!Array.isArray(capstoneResponse)) {
      throw new Error('Invalid data format. Expected an array of objects.');
    }

    // Check if new record should be inserted based on previous capstone check
    const shouldInsertNewRecord = await studentRepository.isCheckedPreviousCapstone(userId, quizId);

    // Ensure that a new record should be inserted or updated
    if (!shouldInsertNewRecord || shouldInsertNewRecord?.earnPoint !== null) {
      // Process each item in the capstoneResponse array
      const promises = capstoneResponse.map(async item => {
        const { questionId, answerDescription, contentIds } = item;
        // Validate required fields
        if (!questionId || !answerDescription || !Array.isArray(contentIds) || !quizId) {
          throw new Error('Invalid data format. Missing required fields.');
        }
        // Determine the result value based on the isSubmit flag
        const resultValue = isSubmit === true ? 'ATTEMPTED' : 'DRAFT';

        // Find existing draft response for the specified quizId and questionId
        let existingDraft = await studentRepository.findExistingDraftresponse(quizId, questionId, userId, 'DRAFT');

        // Update existing draft or create a new user response
        if (existingDraft) {
          existingDraft.response = answerDescription;
          existingDraft.result = resultValue;
          await existingDraft.save();
        } else {
          existingDraft = await userResponseRepository.create({
            userId,
            quizId,
            questionId,
            response: answerDescription,
            result: resultValue,
          });
        }

        const userResponseId = existingDraft.id;

        // Delete previous content associated with the user response
        await studentRepository.deletePreviousContentOfCapstone(userResponseId);

        // Insert new content for the user response
        const userResponseContents = await Promise.all(
          contentIds.map(async contentId => {
            const userResponseContent = await userResponseContentRepository.create({
              userResponseId,
              contentId,
            });
            return userResponseContent;
          })
        );
        return { userResponse: existingDraft, userResponseContents };
      });

      // Wait for all promises to resolve
      const createdResponses = await Promise.all(promises);

      // If isSubmit is true, submit the capstone project
      if (isSubmit) {
        const quizProgress = await studentRepository.capstoneProjectSubmitbyUser({
          userId,
          quizId,
          isSubmitted: true,
        });

        // Update user response with the quiz progress ID
        const updatePromises = createdResponses.map(async ({ userResponse }) => {
          await userResponse.update({ userQuizProgressId: quizProgress.id });
          return userResponse;
        });
        await Promise.all(updatePromises);
      }
      return createdResponses;
    } else if (shouldInsertNewRecord?.earnPoint == null) {
      // Throw an error if capstone has not been checked by teacher
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, ERROR_CAPSTONE_NOT_CHECKED);
    }
  };

  const joinSession = async (sessionId, user) => {
    await userRoleService.fetchAndValidateRoles(user.id, USER_ROLES.STUDENT);
    const existingLearningSession = await learningSessionRepository.findOne({ id: sessionId });

    if (existingLearningSession.status !== SESSION_STATUS_TYPE.INPROGRESS) {
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, LEARNING_SESSION_NOT_STARTED);
    }
    const currentTimeUtc = moment().utc();

    const existingAttendanceRecord = await learningSessionAttendanceRepository.findOne({
      learningSessionId: sessionId,
      userId: user.id,
      outTime: null,
    });

    if (existingAttendanceRecord) {
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, ALREADY_JOINED_SESSION);
    }

    const learningSessionAttendanceData = {
      learningSessionId: sessionId,
      userId: user.id,
      roleId: user.user_roles[0].roleId,
      inTime: currentTimeUtc,
    };

    return learningSessionAttendanceRepository.create(learningSessionAttendanceData);
  };

  const leftSession = async (sessionId, userId) => {
    const isStudentJoined = await learningSessionAttendanceRepository.findOne({ learningSessionId: sessionId, userId: userId });
    if (!isStudentJoined) {
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, LEARNING_SESSION_NOT_JOINED);
    }
    const currentTimeUtc = moment().utc();
    return learningSessionAttendanceRepository.update({ outTime: currentTimeUtc }, { learningSessionId: sessionId, userId: userId });
  };

  return {
    getCourseByUserId,
    getLearningSessionByBatchId,
    getSessionQuizByBatchId,
    getCapstoneReport,
    submitCapstone,
    joinSession,
    leftSession,
  };
});
