const { define } = require('src/containerHelper');
const { Op, Sequelize } = require('sequelize');
module.exports = define('studentRepository', ({ database, baseRepositoryV2, logger }) => {
  const baseRepo = baseRepositoryV2('student');
  const courseModel = database['course'];
  const batchModel = database['batch'];
  const batchUserModel = database['batch_user'];
  const learningSessionModel = database['learning_session'];
  const learningSessionModuleModel = database['learning_session_module'];
  const topicModel = database['topic'];
  const moduleModel = database['module'];
  const topicContentModel = database['topic_content'];
  const contentModel = database['content'];
  const learningSessionContentModel = database['learning_session_content'];
  const learningSessionFeedbackModel = database['learning_session_feedback'];
  const moduleTopicModel = database['module_topic'];
  const learningSessionQuizModel = database['learning_session_quiz'];
  const quizModel = database['quiz'];
  const questionContentModel = database['question_content'];
  const userResponseModel = database['user_response'];
  const questionModel = database['question'];
  const questionOptionModel = database['question_option'];
  const userQuizProgressModel = database['user_quiz_progress'];
  const userResponseContentModel = database['user_response_content'];
  const quizQuestionModel = database['quiz_question'];
  const learningSessionProgressModel = database['learning_session_progress'];

  const getCourseByUserId = async userId => {
    try {
      return batchUserModel.findAll({
        where: { userId, recordStatus: true },
        attributes: ['id', 'batchId', 'recordStatus'],
        include: [
          {
            model: batchModel,
            attributes: ['batchNumber', 'startDate', 'endDate', 'classMode'],
            include: [
              {
                model: courseModel,
                attributes: ['id', 'title', 'description', 'slug', 'thumbnail'],
              },
            ],
          },
        ],
      });
    } catch (error) {
      logger.error('Error in get course of Specific user :', error);
      throw error;
    }
  };
  const getLearningSessionByBatchId = async batchId => {
    try {
      const query = await learningSessionModel.findAll({
        where: { batchId, recordStatus: true },
        attributes: ['id', 'title', 'batchId', 'status', 'recordStatus'],
        include: [
          {
            model: learningSessionModuleModel,
            attributes: ['id'],
            include: [
              {
                model: moduleModel,

                attributes: ['id', 'title'],
                include: [
                  {
                    model: topicModel,
                    attributes: ['id', 'title', 'thumbnail'],
                    through: {
                      model: moduleTopicModel,
                      attributes: ['id', 'order', 'recordStatus', 'createdAt'],
                    },
                    include: [
                      {
                        model: topicContentModel,
                        attributes: ['id'],
                        where: { recordStatus: true },
                        include: [
                          {
                            model: contentModel,
                            attributes: ['title', 'url', 'slug', 'type', 'description'],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            model: learningSessionContentModel,
            attributes: ['id', 'type'],
            where: { recordStatus: true },
            required: false,
            include: [
              {
                model: contentModel,
                attributes: ['title', 'url', 'slug', 'type', 'description'],
              },
            ],
          },
          {
            model: learningSessionFeedbackModel,
            attributes: ['id', 'feedbackId'],
            where: { recordStatus: true },
            required: false,
          },
        ],
      });
      return query;
    } catch (error) {
      logger.error('Error in get session of Specific batch :', error);
      throw error;
    }
  };
  const getSessionQuizByBatchId = async (batchId, categoryId) => {
    try {
      const learningSession = await learningSessionModel.findAll({
        where: { batchId, recordStatus: true },
        attributes: ['id', 'title', 'batchId', 'recordStatus'],
        include: [
          {
            model: learningSessionQuizModel,
            where: { recordStatus: true },
            attributes: ['id'],
            include: [
              {
                model: quizModel,
                where: { recordStatus: true, categoryId: categoryId },
                attributes: ['id', 'title', 'categoryId'],
              },
            ],
          },
        ],
      });
      return learningSession;
    } catch (error) {
      logger.error('Error in get quiz of Specific batch :', error);
      throw error;
    }
  };
  const getCapstoneReport = async (quizId, userId, userQuizProgressId) => {
    try {
      const userResponseData = await userQuizProgressModel.findOne({
        where: {
          id: userQuizProgressId,
          userId: userId,
          quizId: quizId,
          earnPoint: {
            [Op.not]: null,
            [Op.not]: '',
          },
        },
        attributes: ['id', 'quizId', 'userId', 'completionTime', 'earnPoint', 'totalPoint', 'isPassed', 'percentage', 'attemptNo'],
        include: [
          {
            model: userResponseModel,
            where: { userId: userId, quizId: quizId },
            attributes: ['id', 'userQuizProgressId', 'quizId', 'questionId', 'response', 'teacherFeedback', 'earnPoint', 'recordStatus', 'result'],
            include: [
              {
                model: questionModel,
                attributes: ['id', 'question'],
                include: [
                  {
                    model: quizQuestionModel,
                    attributes: ['points'],
                  },
                  {
                    model: questionContentModel,
                    attributes: ['id'],
                    include: [
                      {
                        model: contentModel,
                        attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                      },
                    ],
                  },
                ],
              },
              {
                model: userResponseContentModel,
                attributes: ['id'],
                include: [
                  {
                    model: contentModel,
                    attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                  },
                ],
              },
            ],
          },
        ],
      });
      return userResponseData;
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };
  const capstoneProjectSubmitbyUser = async ({ userId, quizId, isSubmitted }) => {
    try {
      // Find the maximum attempt_no for the given userId and quizId
      const maxAttempt = await userQuizProgressModel.max('attempt_no', {
        where: { userId, quizId },
      });

      const nextAttemptNo = maxAttempt ? maxAttempt + 1 : 1;
      const totalPoint = await quizQuestionModel.sum('points', {
        where: { quizId },
      });

      const quizProgress = await userQuizProgressModel.create({
        userId,
        quizId,
        isSubmitted,
        attemptNo: nextAttemptNo,
        totalPoint: totalPoint || 0,
      });

      return quizProgress;
    } catch (error) {
      console.error('Error creating user quiz progress:', error);
      throw error;
    }
  };
  const findExistingDraftresponse = async (quizId, questionId, userId, result) => {
    return userResponseModel.findOne({
      where: {
        quizId,
        questionId,
        userId,
        result,
      },
      order: [['created_at', 'DESC']],
    });
  };
  const deletePreviousContentOfCapstone = async userResponseId => {
    try {
      // Find existing user_response_content records
      const existingUserResponseContents = await userResponseContentModel.findAll({
        where: {
          userResponseId,
        },
      });

      // Delete existing records
      await Promise.all(
        existingUserResponseContents.map(async userResponseContent => {
          await userResponseContent.destroy();
        })
      );
    } catch (error) {
      throw error;
    }
  };
  const isCheckedPreviousCapstone = async (userId, quizId) => {
    return await userQuizProgressModel.findOne({
      where: {
        userId,
        quizId,
      },
      order: [['created_at', 'DESC']],
    });
  };
  // get count of topic based on moduleid & learningsessionid from learnignprogresstable
  const completedTopicCountBasedOnModuleId = async (moduleId, learningSessionId) => {
    const topicCount = await learningSessionProgressModel.count({
      where: {
        moduleId,
        learningSessionId,
      },
    });
    return topicCount;
  };
  const completedTopicCountBasedOnModuleIdTopicIdLearningSessionId = async (moduleId, learningSessionId, topicId) => {
    const topicCount = await learningSessionProgressModel.count({
      where: {
        moduleId,
        learningSessionId,
        topicId,
      },
    });
    return topicCount;
  };
  return {
    ...baseRepo,
    getCourseByUserId,
    getLearningSessionByBatchId,
    getSessionQuizByBatchId,
    getCapstoneReport,
    capstoneProjectSubmitbyUser,
    findExistingDraftresponse,
    deletePreviousContentOfCapstone,
    isCheckedPreviousCapstone,
    completedTopicCountBasedOnModuleId,
    completedTopicCountBasedOnModuleIdTopicIdLearningSessionId,
  };
});
