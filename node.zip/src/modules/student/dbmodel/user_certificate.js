'use strict';

module.exports = (sequelize, DataTypes) => {
  const userCertificate = sequelize.define(
    'user_certificate',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
      },
      courseId: {
        type: DataTypes.UUID,
      },
      userId: {
        type: DataTypes.UUID,
      },
      certificateUrl: {
        type: DataTypes.STRING,
      },
      desigredName: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      createdBy: {
        type: DataTypes.UUID,
      },
      updatedBy: {
        type: DataTypes.UUID,
      },
    },
    {
      freezeTableName: true,
    }
  );

  userCertificate.associate = function(models) {
    userCertificate.belongsTo(models.user, { foreignKey: 'userId' });
    userCertificate.belongsTo(models.batch, { foreignKey: 'batchId' });
    userCertificate.belongsTo(models.course, { foreignKey: 'courseId' });
  };

  return userCertificate;
};
