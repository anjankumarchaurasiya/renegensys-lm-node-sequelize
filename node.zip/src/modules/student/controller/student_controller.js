const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { CAPSTONE_SUBMITED_SUCCESSFULLY, LEARNING_SESSION_JOINED_SUCCESSFULLY, LEARNING_SESSION_LEFT_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const { authorizeMiddleware, studentService, courseService, learningSessionService, logger } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  // to get list of courses
  router.get('/course', async (req, res, next) => {
    try {
      const userId = req.user.id;
      const courseList = await studentService.getCourseByUserId(userId);
      res.status(Status.OK).json(await Success(courseList));
    } catch (e) {
      next(e);
    }
  });
  // to get list of module and topic and topic resources
  router.get('/course/:courseId', async (req, res, next) => {
    try {
      const {
        params: { courseId },
        query,
      } = req;
      let courseDetail = await courseService.getCourse(courseId, query);
      res.status(Status.OK).json(await Success(courseDetail));
    } catch (e) {
      next(e);
    }
  });
  // to get list of session and all session info module-> topic-> resources by batchid, quiz info
  router.get('/session/:batchId', async (req, res, next) => {
    try {
      const {
        params: { batchId },
      } = req;
      let learningSessionList = await studentService.getLearningSessionByBatchId(batchId);
      let { preSessionResult, postSessionResult, examQuizId, capstoneId, learningSessionFeedbackId } = await studentService.getSessionQuizByBatchId(
        batchId
      );
      res
        .status(Status.OK)
        .json(
          await Success({
            learningSessionList,
            preSessionResult,
            postSessionResult,
            examQuizId,
            capstoneId,
            batchFeedbackId: learningSessionFeedbackId,
          })
        );
    } catch (e) {
      next(e);
    }
  });
  // to get report of capstone project
  router.get('/capstone-report/:userQuizProgressId', async (req, res, next) => {
    try {
      const {
        params: { userQuizProgressId },
      } = req;
      const userId = req.user.id;
      logger.info('Get capstone project report');
      const usereport = await studentService.getCapstoneReport(userId, userQuizProgressId);
      res.status(Status.OK).json(await Success(usereport));
    } catch (e) {
      next(e);
    }
  });

  // submit capstone from user
  router.post('/capstone', async (req, res, next) => {
    try {
      const { user } = req;

      const { isSubmit, capstoneResponse, quizId } = req.body;
      const userId = user.id;
      logger.info('Submit capstone response from user');
      await studentService.submitCapstone(userId, capstoneResponse, quizId, isSubmit);
      let data;
      res.status(Status.OK).json(await Success(data, CAPSTONE_SUBMITED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/session/join/:sessionId', async (req, res, next) => {
    try {
      const {
        params: { sessionId },
        user,
      } = req;
      //const userId = user.id;
      await studentService.joinSession(sessionId, user);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_JOINED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/session/left/:sessionId', async (req, res, next) => {
    try {
      const {
        params: { sessionId },
        user,
      } = req;
      const userId = user.id;
      await studentService.leftSession(sessionId, userId);
      let data;
      res.status(Status.OK).json(await Success(data, LEARNING_SESSION_LEFT_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
