'use strict';

module.exports = (sequelize, DataTypes) => {
  const Audit = sequelize.define(
    'audit',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
      entity: {
        type: DataTypes.STRING,
      },
      action: {
        type: DataTypes.STRING,
      },
      previousData: {
        type: DataTypes.STRING(2000),
      },
      updatedData: {
        type: DataTypes.STRING(2000),
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: false,
        defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  return Audit;
};
