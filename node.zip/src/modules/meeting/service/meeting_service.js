const { define } = require('src/containerHelper');

module.exports = define('meetingService', ({ zoomService, logger }) => {
  const createMeeting = async (strategyName, meetingDetails) => {
    const strategyService = _strategy(strategyName);
    if (!strategyService) {
      const errorMessage = `Strategy for ${strategyName} is not defined.`;
      logger.error(errorMessage);
      throw new Error(errorMessage);
    }
    return strategyService(meetingDetails);
  };

  const _strategy = strategyName => {
    const providers = {
      zoom: _zoom,
      agora: _agora,
    };
    return providers[strategyName];
  };

  const _zoom = async meetingDetails => {
    return zoomService.createMeeting(meetingDetails);
  };

  const _agora = async meetingDetails => {
    return { msg: 'Agora is not available in this platform' };
  };

  return {
    createMeeting,
  };
});
