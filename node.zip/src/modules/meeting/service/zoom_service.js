const { define } = require('src/containerHelper');
const axios = require('axios');

const { MEETING_TYPE } = require('src/constants');

module.exports = define('zoomService', ({ configMasterService, logger }) => {
  async function createMeeting(meetingDetails) {
    const configName = `ZOOM_MEET_CREDENTIALS_${process.env.NODE_ENV}`;
    let providerConfig;
    try {
      providerConfig = await configMasterService.getConfigByName(configName);
      if (!providerConfig || !providerConfig.config) {
        logger.error('Zoom configuration not found or is invalid.');
        return null;
      }
    } catch (error) {
      logger.error(`Error fetching Zoom configuration: ${error.message}`);
      return null;
    }

    const { topic, duration, startTime, timezone, date } = meetingDetails;
    if (!topic || !duration || !startTime || !timezone || !date) {
      logger.error('Invalid meeting details provided.');
      return null;
    }

    try {
      const tokenParams = new URLSearchParams({
        grant_type: providerConfig.config.GRANT_TYPE,
        account_id: providerConfig.config.ACCOUNT_ID,
      });

      const authResponse = await axios.post(
        `${providerConfig.config.AUTH_TOKEN_URL}?${tokenParams.toString()}`,
        {},
        {
          auth: {
            username: providerConfig.config.CLIENT_ID,
            password: providerConfig.config.CLIENT_SECRET,
          },
        }
      );

      if (authResponse.status !== 200) {
        logger.error('Failed to get access token from Zoom');
        return null;
      }

      const access_token = authResponse.data.access_token;
      const startDateTime = `${date}T${startTime}`;

      const payload = {
        topic: topic,
        duration: duration,
        start_time: startDateTime,
        type: MEETING_TYPE.type_2,
        timezone: timezone,
      };

      const meetingResponse = await axios.post(`${providerConfig.config.API_BASE_URL}/users/me/meetings`, payload, {
        headers: {
          Authorization: `Bearer ${access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (meetingResponse.status !== 201) {
        logger.error('Failed to create Zoom meeting');
        return null;
      }

      return {
        startUrl: meetingResponse.data.start_url,
        meetingUrl: meetingResponse.data.join_url,
        password: meetingResponse.data.password,
        meetingTime: meetingResponse.data.start_time,
        purpose: meetingResponse.data.topic,
        duration: meetingResponse.data.duration,
      };
    } catch (error) {
      logger.error(`Zoom Service Error: ${error.message}`);
      return null;
    }
  }

  return {
    createMeeting,
  };
});
