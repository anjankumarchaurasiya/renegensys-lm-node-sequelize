const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { MEETING_PLATFORM } = require('src/constants');
const { meetingService, logger } = container.cradle;
const { MEETING_CREATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success },
    userContextMiddleware,
    auth,
    authorizeMiddleware,
  } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/create-meeting', async (req, res) => {
    const { body } = req;
    const { platform = MEETING_PLATFORM.default, ...meetingDetails } = body;
    logger.info('Create Meeting route for platform: ' + platform);
    let data = await meetingService.createMeeting(platform, meetingDetails);
    res.status(Status.OK).json(await Success(data, MEETING_CREATED_SUCCESSFULLY));
  });

  return router;
};
