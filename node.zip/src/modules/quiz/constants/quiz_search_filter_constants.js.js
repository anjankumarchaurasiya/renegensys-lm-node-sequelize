module.exports = Object.freeze({
  quiz: {
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    categoryIds: {
      op: '$in',
      alias: 'category_id',
      dataType: 'UUID',
    },
    examDate: {
      op: '$eq',
      alias: 'exam_date',
      dataType: 'DATEONLY',
    },
  },
});
