const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { RETEST_REQUEST_CREATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const { attemptRequestService, logger, authorizeMiddleware, userContextMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);

  router.use(authorizeMiddleware);
  // for user request for retest
  router.post('/retest', async (req, res, next) => {
    try {
      const { quizId, quizType } = req.body;
      const userId = req.user.id;
      let data = await attemptRequestService.retestRequest(userId, quizId, quizType);
      logger.info('Retest Request');
      res.status(Status.OK).json(await Success(data, RETEST_REQUEST_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  // for admin request for accept/reject
  router.patch('/accept-retest-attempt/:attemptRequestId', async (req, res, next) => {
    try {
      const {
        params: { attemptRequestId },
      } = req;
      const { status } = req.body;
      logger.info('Accept Retest Request');
      await attemptRequestService.acceptRetestAttempt(attemptRequestId, status);
      res.status(Status.OK).json(await Success('Retest request updated successfully'));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
