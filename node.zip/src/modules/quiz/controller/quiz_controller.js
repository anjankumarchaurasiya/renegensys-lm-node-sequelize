const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  QUIZ_CREATED_SUCCESSFULLY,
  CAPSTONE_CREATED_SUCCESSFULLY,
  QUIZ_UPDATED_SUCCESSFULLY,
  QUIZ_PROGRESS_CREATED_SUCCESSFULLY,
  USER_RESPONSE_CREATED_SUCCESSFULLY,
  USER_QUIZ_DETAILS_CREATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const {
    quizService,
    userResponseService,
    learningSessionQuizService,
    userQuizProgressService,
    logger,
    authorizeMiddleware,
    userContextMiddleware,
  } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);

  router.use(authorizeMiddleware);

  router.post('/', auth.authenticate(), async (req, res, next) => {
    try {
      const { body } = req;
      const { quizData, questionData, type } = body;
      logger.info('Create quiz route');
      await quizService.createQuiz(quizData, questionData, type);
      let data;
      let message = type === 'CAPSTONE' ? CAPSTONE_CREATED_SUCCESSFULLY : QUIZ_CREATED_SUCCESSFULLY;
      res.status(Status.OK).json(await Success(data, message));
    } catch (e) {
      next(e);
    }
  });

  router.get('/report/get-report/:quizId/:userId/:userQuizProgressId', async (req, res, next) => {
    try {
      const {
        params: { quizId, userId, userQuizProgressId },
      } = req;
      logger.info('Get user response report');
      const usereport = await userResponseService.getUserResponseReport(quizId, userId, userQuizProgressId);
      res.status(Status.OK).json(await Success(usereport));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter/list', auth.authenticate(), async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get quiz  List ::`);
      const quizList = await quizService.getQuizList(query);
      res.status(Status.OK).json(await Success(quizList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:quizId', async (req, res, next) => {
    try {
      const {
        params: { quizId },
        query,
      } = req;
      let quizDetail = await quizService.getQuiz(quizId, query);
      res.status(Status.OK).json(await Success(quizDetail));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:quizId/learning-session', async (req, res, next) => {
    try {
      const {
        params: { quizId },
        body: { linked, unLinked },
      } = req;
      await quizService.updateQuizSessions(linked, unLinked, quizId);
      let data;
      res.status(Status.OK).json(await Success(data, QUIZ_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:quizId/learning-session', async (req, res, next) => {
    try {
      const {
        params: { quizId },
        query,
      } = req;
      let quizDetail = await learningSessionQuizService.getAlllearningSessionOfQuiz(quizId, query);
      res.status(Status.OK).json(await Success(quizDetail));
    } catch (e) {
      next(e);
    }
  });

  router.post('/start', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create user quiz progress route');
      let data = await userQuizProgressService.createUserQuizProgress(body);
      res.status(Status.OK).json(await Success(data, QUIZ_PROGRESS_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/submit', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create user response route');
      let data = await userResponseService.createUserResponse(body);
      res.status(Status.OK).json(await Success(data, USER_RESPONSE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.post('/user-quiz-details', async (req, res, next) => {
    try {
      const { body, user } = req;
      const userId = user.id;
      const { quizId, quizType } = body;
      logger.info('Create user quiz details route');
      const {
        quizDetails,
        leftAttempt,
        lastMarksObtained,
        highestMarksObtained,
        lastMarksResponse,
        highestMarksResponse,
        attemptRequest,
      } = await userQuizProgressService.getQuizDetailsByQuizId(quizId, quizType, userId);
      const { userQuizProgress: lastQuizProgress } = lastMarksResponse;
      const { userQuizProgress: highestQuizProgress } = highestMarksResponse;

      let data = {
        quizDetails,
        leftAttempt,
        lastObtained: { lastMarksObtained, quizProgressId: lastQuizProgress?.id },
        highestObtained: { highestMarksObtained, quizProgressId: highestQuizProgress?.id },
        attemptRequest,
      };
      res.status(Status.OK).json(await Success(data));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
