const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { RETEST_REQUEST_CREATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const { capstoneService, logger, authorizeMiddleware, userContextMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);
  // for user request for retest
  router.get('/capstone-project/:batchId/:quizId', async (req, res, next) => {
    try {
      const {
        params: { batchId, quizId },
      } = req;
      const userId = req.user.id;
      let data = await capstoneService.getCapstoneByBatchId(userId, batchId, quizId);
      logger.info('Get capstone by batchid');
      res.status(Status.OK).json(await Success(data));
    } catch (e) {
      next(e);
    }
  });
  // for user capstone details
  router.get('/user-capstone-details/:quizId', async (req, res, next) => {
    try {
      const {
        params: { quizId },
      } = req;
      const userId = req.user.id;
      logger.info('Get capstone details by quizid and userid');

      const {
        quizDetails,
        leftAttempt,
        lastMarksObtained,
        highestMarksObtained,
        lastMarksResponse,
        highestMarksResponse,
        attemptRequest,
        isCapstoneInDraft,
        batchQuizDetails,
      } = await capstoneService.getCapstoneByQuizIdUserId(quizId, userId);
      const { userQuizProgress: lastQuizProgress, lastCapstoneDetails: lastCapstoneDetails } = lastMarksResponse;
      const isReviewed = lastCapstoneDetails?.earnPoint == null || lastCapstoneDetails?.earnPoint == '' ? false : true;
      const { userQuizProgress: highestQuizProgress } = highestMarksResponse;
      const batchId = batchQuizDetails?.batchId;
      let data = {
        quizDetails,
        leftAttempt,
        lastObtained: { lastMarksObtained, quizProgressId: lastQuizProgress?.id },
        highestObtained: { highestMarksObtained, quizProgressId: highestQuizProgress?.id },
        attemptRequest,
        isCapstoneInDraft,
        isReviewed,
        batchId,
      };
      res.status(Status.OK).json(await Success(data));
    } catch (e) {
      next(e);
    }
  });
  // get draft capstone list of student by quizId
  router.get('/draft-capstone/:quizId', async (req, res, next) => {
    try {
      const {
        params: { quizId },
      } = req;
      const userId = req.user.id;
      logger.info('Get draft capstone list by quizid and userid');

      const data = await capstoneService.draftCasptoneListByQuizUserId(quizId, userId, 'DRAFT');
      res.status(Status.OK).json(await Success(data));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
