const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { USER_QUIZ_PROGRESS_CREATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const { userQuizProgressService, logger, userContextMiddleware, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create user quiz progress route');
      let data = await userQuizProgressService.createUserQuizProgress(body);
      res.status(Status.OK).json(await Success(data, USER_QUIZ_PROGRESS_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
