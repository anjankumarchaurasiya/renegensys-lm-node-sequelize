module.exports = (sequelize, DataTypes) => {
  const Quiz = sequelize.define(
    'quiz',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
        unique: true,
      },
      categoryId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      questionSelectionConfig: {
        type: DataTypes.JSON,
      },
      description: {
        type: DataTypes.TEXT,
      },
      duration: {
        type: DataTypes.STRING,
      },
      questionToSelect: {
        type: DataTypes.INTEGER,
      },
      passingPercentage: {
        type: DataTypes.DOUBLE,
        validate: {
          min: 0,
          max: 100,
        },
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Quiz.associate = function(models) {
    Quiz.hasMany(models.quiz_question, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
    Quiz.belongsToMany(models.question, {
      through: models.quiz_question,
      foreignKey: 'quizId',
      otherKey: 'questionId',
    });

    Quiz.belongsToMany(models.learning_session, {
      through: models.learning_session_quiz,
      foreignKey: 'quizId',
      otherKey: 'learningSessionId',
    });
    Quiz.hasMany(models.learning_session_quiz, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
    Quiz.belongsTo(models.category, {
      foreignKey: 'categoryId',
      sourceKey: 'id',
    });
    Quiz.hasMany(models.batch_quiz, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
    Quiz.belongsToMany(models.batch, {
      through: models.batch_quiz,
      foreignKey: 'quizId',
      otherKey: 'batchId',
    });
    Quiz.hasMany(models.user_response, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
    Quiz.hasMany(models.user_quiz_progress, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
  };

  return Quiz;
};
