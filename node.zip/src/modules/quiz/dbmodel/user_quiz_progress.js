module.exports = (sequelize, DataTypes) => {
  const UserQuizProgress = sequelize.define(
    'user_quiz_progress',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      quizId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      completionTime: {
        type: DataTypes.TIME,
      },
      startTime: {
        type: DataTypes.TIME,
      },
      endTime: {
        type: DataTypes.TIME,
      },
      earnPoint: {
        type: DataTypes.FLOAT,
      },
      totalPoint: {
        type: DataTypes.INTEGER,
      },
      isPassed: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      percentage: {
        type: DataTypes.FLOAT,
      },
      attemptNo: {
        type: DataTypes.INTEGER,
      },
      attemptRequestId: {
        type: DataTypes.UUID,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  UserQuizProgress.associate = function(models) {
    UserQuizProgress.hasMany(models.user_response, {
      foreignKey: 'userQuizProgressId',
      sourceKey: 'id',
    });
    UserQuizProgress.belongsTo(models.quiz, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
    UserQuizProgress.belongsTo(models.user, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
  };

  return UserQuizProgress;
};
