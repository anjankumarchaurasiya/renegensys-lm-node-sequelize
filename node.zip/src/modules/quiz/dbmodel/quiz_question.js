module.exports = (sequelize, DataTypes) => {
  const QuizQuestion = sequelize.define(
    'quiz_question',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      quizId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      questionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      points: {
        type: DataTypes.INTEGER,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  QuizQuestion.associate = function(models) {
    QuizQuestion.belongsTo(models.quiz, {
      foreignKey: 'quizId',
      sourceKey: 'id',
      allowNull: false,
    });
    QuizQuestion.belongsTo(models.question, {
      foreignKey: 'questionId',
      targetKey: 'id',
      allowNull: false,
    });
  };

  return QuizQuestion;
};
