module.exports = (sequelize, DataTypes) => {
  const AttemptRequest = sequelize.define(
    'attempt_request',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      quizId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      type: {
        type: DataTypes.STRING,
      },
      requestStatus: {
        type: DataTypes.ENUM('PENDING', 'APPROVED', 'REJECTED'),
        default: 'PENDING',
      },
      attemptNo: {
        type: DataTypes.INTEGER,
      },
      isAttempt: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  AttemptRequest.associate = function(models) {
    AttemptRequest.belongsTo(models.quiz, {
      foreignKey: 'quizId',
      targetKey: 'id',
    });
    AttemptRequest.belongsTo(models.user, {
      foreignKey: 'userId',
      targetKey: 'id',
    });
    AttemptRequest.belongsTo(models.user_quiz_progress, {
      foreignKey: 'attemptRequestId',
      targetKey: 'id',
    });
  };

  return AttemptRequest;
};
