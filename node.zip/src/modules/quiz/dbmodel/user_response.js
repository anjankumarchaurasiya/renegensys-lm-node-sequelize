module.exports = (sequelize, DataTypes) => {
  const UserResponse = sequelize.define(
    'user_response',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userQuizProgressId: {
        type: DataTypes.UUID,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      quizId: {
        type: DataTypes.UUID,
      },
      questionId: {
        type: DataTypes.UUID,
      },
      questionOptionId: {
        type: DataTypes.UUID,
      },
      response: {
        type: DataTypes.STRING,
      },
      teacherFeedback: {
        type: DataTypes.STRING,
      },
      earnPoint: {
        type: DataTypes.FLOAT,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      result: {
        type: DataTypes.ENUM('WRONG', 'CORRECT', 'UNATTEMPTED', 'ATTEMPTED', 'DRAFT'),
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  UserResponse.associate = function(models) {
    UserResponse.belongsTo(models.question_option, {
      foreignKey: 'questionOptionId',
      sourceKey: 'id',
    });
    UserResponse.belongsTo(models.question, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
    UserResponse.belongsTo(models.quiz, {
      foreignKey: 'quizId',
      targetKey: 'id',
    });
    UserResponse.belongsTo(models.user_quiz_progress, {
      foreignKey: 'userQuizProgressId',
      targetKey: 'id',
    });
    UserResponse.hasMany(models.user_response_content, {
      foreignKey: 'userResponseId',
      sourceKey: 'id',
    });
    UserResponse.belongsTo(models.quiz_question, {
      foreignKey: 'questionId',
      targetKey: 'questionId',
    });
  };

  return UserResponse;
};
