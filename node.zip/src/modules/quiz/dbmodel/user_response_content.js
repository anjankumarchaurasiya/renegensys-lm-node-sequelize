'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserResponseContent = sequelize.define(
    'user_response_content',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userResponseId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      contentId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      createdAt: {
        type: 'TIMESTAMP',
      },
      updatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  UserResponseContent.associate = function(models) {
    UserResponseContent.belongsTo(models.user_response, {
      foreignKey: 'userResponseId',
      targetKey: 'id',
    });
    UserResponseContent.belongsTo(models.content, {
      foreignKey: 'contentId',
      targetKey: 'id',
    });
  };
  return UserResponseContent;
};
