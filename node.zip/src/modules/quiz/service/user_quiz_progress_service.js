const { define } = require('src/containerHelper');
const moment = require('moment');
module.exports = define('userQuizProgressService', ({
  userQuizProgressRepository,
  attemptRequestRepository,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND, INVALID_REQUEST },
  quizRepository,
  configMasterService,
}) => {
  const createUserQuizProgress = async data => {
    const { userId, quizId, attemptRequestId } = data;
    const startTime = moment().format('HH:mm:ss');
    const count = (await checkUserAttemptCountBasedOnBatch({ userId, quizId })) + 1;
    const userQuizProgress = await userQuizProgressRepository.create({ ...data, startTime, attemptNo: count });
    return userQuizProgress;
  };
  const checkUserAttemptCountBasedOnBatch = async whereClause => {
    return userQuizProgressRepository.checkUserAttemptCountBasedOnBatch(whereClause);
  };

  const updateUserQuizProgress = async (data, id) => {
    const userQuizProgress = await userQuizProgressRepository.update(data, { id });
    if (data.attemptRequestId) {
      await attemptRequestRepository.update({ isAttempt: 1 }, { id: data.attemptRequestId });
    }
    return userQuizProgress;
  };

  const getUserQuizProgress = async id => {
    const userQuizProgress = await userQuizProgressRepository.findOne({ id });
    return userQuizProgress;
  };
  //  get quiz details,left ateempt and marks obtained
  const getQuizDetailsByQuizId = async (quizId, quizType, userId) => {
    const isQuizExist = await quizRepository.findOne({ id: quizId });
    if (isQuizExist) {
      const entityName = 'WITHOUT_PERMISSION';
      const configFound = await configMasterService.getConfigByName(quizType);
      const retestAttemptWithoutPermission = configFound.config[entityName];
      const { quizDetails, leftAttempt } = await userQuizProgressRepository.getUserQuizDetails(
        quizId,
        quizType,
        userId,
        retestAttemptWithoutPermission
      );
      const lastMarksResponse = await userQuizProgressRepository.lastUserMarksObtainedByUser(quizId, userId);
      const lastMarksObtained = await resultCalculation(lastMarksResponse);
      const highestMarksResponse = await userQuizProgressRepository.highestUserMarksObtainedByUser(quizId, userId);
      const highestMarksObtained = await resultCalculation(highestMarksResponse);
      const getLastAttemptRequestDetails = await attemptRequestRepository.getLastOpenRetestRequestIsAttemptZero(userId, quizId, quizType);
      return {
        quizDetails,
        leftAttempt,
        lastMarksObtained,
        highestMarksObtained,
        lastMarksResponse,
        highestMarksResponse,
        attemptRequest: getLastAttemptRequestDetails,
      };
    } else {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `Quiz not exist`);
    }
  };
  // result calucation
  const resultCalculation = async marksObtained => {
    const { userResponses, userQuizProgress } = marksObtained;
    let stringMarksObtained = '';
    if (userResponses) {
      const correctResponses = userResponses.filter(response => response.result === 'CORRECT');
      const totalQuestions = userResponses.length;
      const totalCorrect = correctResponses.length;

      if (totalCorrect > 0 && totalQuestions > 0) {
        if (userQuizProgress && userQuizProgress.percentage !== undefined) {
          const highestPercentage = userQuizProgress?.percentage;
          stringMarksObtained = `${totalCorrect}/${totalQuestions} (${highestPercentage}%)`;
        } else {
          stringMarksObtained = `${totalCorrect}/${totalQuestions} (N/A)`;
        }
      } else {
        stringMarksObtained = 'N/A';
      }
    } else {
      return (stringMarksObtained = 'N/A');
    }
    return stringMarksObtained;
  };
  return {
    createUserQuizProgress,
    updateUserQuizProgress,
    getUserQuizProgress,
    checkUserAttemptCountBasedOnBatch,
    getQuizDetailsByQuizId,
  };
});
