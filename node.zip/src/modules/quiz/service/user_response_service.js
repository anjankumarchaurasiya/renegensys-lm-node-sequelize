const { define } = require('src/containerHelper');
const moment = require('moment');

module.exports = define('userResponseService', ({
  userResponseRepository,
  quizQuestionRepository,
  quizQuestionService,
  quizRepository,
  userQuizProgressService,
  CustomError,
  constants: { UNAUTHORIZED_REQUEST },
}) => {
  const createUserResponse = async data => {
    const { userId, quizId, response, userQuizProgressId, questionData } = data;
    const userResponseData = [];
    let totalEarnPoints = 0;
    let totalPoints = 0;

    const userResponsePromises = questionData.map(async ({ questionId, questionOptionId }) => {
      const { earnPoint, point, result, correctPoint } = await quizQuestionService.calculateEarnedPointsAndResult(questionId, questionOptionId);
      totalEarnPoints += correctPoint;
      totalPoints += point;
      const userResponse = {
        userId,
        quizId,
        userQuizProgressId,
        response,
        questionId,
        earnPoint,
        questionOptionId,
        result,
        ...data,
      };
      const createdResponse = await userResponseRepository.create(userResponse);
      userResponseData.push(createdResponse);
    });
    await Promise.all(userResponsePromises);

    const quiz = await quizRepository.findOne({ id: quizId });
    let userQuizProgressdata = {
      earnPoint: totalEarnPoints,
      totalPoint: totalPoints,
    };
    userQuizProgressdata.percentage = (totalEarnPoints / totalPoints) * 100;
    userQuizProgressdata.isPassed = userQuizProgressdata.percentage >= quiz.passingPercentage ? true : false;

    const userQuizProgress = await userQuizProgressService.getUserQuizProgress(userQuizProgressId);

    const endTime = moment().format('HH:mm:ss');
    userQuizProgressdata.endTime = endTime;

    const startTime = moment(userQuizProgress.startTime, 'HH:mm:ss');
    const endTimeMoment = moment(endTime, 'HH:mm:ss');
    const completionTime = moment.utc(endTimeMoment.diff(startTime)).format('HH:mm:ss');

    userQuizProgressdata.completionTime = completionTime;
    userQuizProgressdata.attemptRequestId = userQuizProgress.attemptRequestId ? userQuizProgress.attemptRequestId : null;

    await userQuizProgressService.updateUserQuizProgress(userQuizProgressdata, userQuizProgressId);
    return getUserResponseReport(quizId, userId, userQuizProgressId);
  };

  const getUserResponseReport = async (quizId, userId, userQuizProgressId) => {
    try {
      const quizExist = await quizQuestionRepository.findAll({ quizId: quizId });
      if (quizExist) {
        const questions = await userResponseRepository.getUserReport(quizId, userId, userQuizProgressId);
        return questions;
      } else {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `Quiz not exist`);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return {
    createUserResponse,
    getUserResponseReport,
  };
});
