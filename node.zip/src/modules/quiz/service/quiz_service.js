const { define } = require('src/containerHelper');
const searchFilters = require('../constants/quiz_search_filter_constants.js');

module.exports = define('quizService', ({
  generalUtilService,
  CustomError,
  constants: {
    ENTITY_ALREADY_EXISTS,
    UNAUTHORIZED_REQUEST,
    ENTITY_NOT_FOUND,
    INVALID_REQUEST,
    QUIZ_TITLE_EXISTS_ERROR,
    CAPSTONE_TITLE_EXISTS_ERROR,
    OPTION_REQUIRED_ERROR,
    DURATION_REQUIRED_ERROR,
  },
  quizRepository,
  questionRepository,
  questionOptionRepository,
  quizQuestionRepository,
  categoryRepository,
  learningSessionQuizRepository,
  learningSessionRepository,
  questionContentRepository,
  logger,
}) => {
  const createQuiz = async (quizData, questionData, type) => {
    try {
      const { title, categoryId, questionToSelect } = quizData;
      const isQuizExist = await quizRepository.findOne({ title: title });
      const isCategoryExist = categoryRepository.findOne({ id: categoryId });

      /** check type is capstone then set duration 0 */
      if (quizData.duration == 0 && type !== 'CAPSTONE') {
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, DURATION_REQUIRED_ERROR);
      } else if (type == 'CAPSTONE') {
        quizData.duration = '0';
      }

      if (isQuizExist) {
        /** based on type change error message */
        let message = type === 'CAPSTONE' ? CAPSTONE_TITLE_EXISTS_ERROR : QUIZ_TITLE_EXISTS_ERROR;
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, message);
      }
      if (!isCategoryExist) {
        throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, 'Category  not found');
      }
      if (questionToSelect !== undefined && questionToSelect > questionData.length) {
        throw new CustomError(
          INVALID_REQUEST.code,
          INVALID_REQUEST.status,
          `questionToSelect must be less than or equal to the total no of question`
        );
      }

      const quiz = await quizRepository.create(quizData);
      const createdQuestionIds = [];
      let questionPoints = [];

      await Promise.all(
        questionData.map(async question => {
          const { options, description, content, point, ...restQuestionData } = question;
          const createQuestion = await questionRepository.create({
            ...restQuestionData,
            quizId: quiz.id,
          });
          createdQuestionIds.push(createQuestion.id);
          questionPoints.push({ questionId: createQuestion.id, point });
          if (content) {
            const questionId = createQuestion.dataValues.id;
            const contentArray = content;
            const contentModifiedArray = contentArray.map(contentId => ({
              contentId,
              questionId,
              quizId: quiz.id,
            }));

            await questionContentRepository.bulkCreate(contentModifiedArray);
          }
          /** for capstone type option not required */
          if (type !== 'CAPSTONE') {
            if (options && options.length > 0) {
              await Promise.all(
                options.map(async option => {
                  await questionOptionRepository.create({
                    ...option,
                    questionId: createQuestion.id,
                    description: option.description,
                  });
                })
              );
            } else {
              throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, OPTION_REQUIRED_ERROR);
            }
          }
        })
      );
      await quizQuestionRepository.bulkCreate(
        questionPoints.map(({ questionId, point }) => ({
          quizId: quiz.id,
          questionId,
          points: point,
        }))
      );
      return quiz;
    } catch (error) {
      throw error;
    }
  };

  const getQuizList = async queryParams => {
    let quizListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.quiz);
      quizListResponse = await quizRepository.getQuizes(
        ['id', 'title', 'duration', 'created_at', 'description', 'recordStatus', 'categoryId', 'passingPercentage', 'questionToSelect'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.quiz);
      quizListResponse = await quizRepository.getQuizes(
        ['id', 'title', 'duration', 'created_at', 'description', 'recordStatus', 'categoryId', 'passingPercentage', 'questionToSelect'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }

    const quizzesWithQuestions = quizListResponse.rows.map(quiz => {
      const numberOfQuestions = quiz.questions.length;
      return { numberOfQuestions, ...quiz.dataValues };
    });
    return { count: quizListResponse.rows.length, quiz: quizzesWithQuestions };
  };

  const getQuiz = async (quizId, queryParams) => {
    const parsedparams = generalUtilService.parseQueryParam(queryParams);
    let quizDetail = await quizRepository.getQuiz(
      quizId,
      parsedparams.viewTree,
      parsedparams.studentView,
      parsedparams.viewSession,
      queryParams.linked,
      queryParams.sessionTitle,
      queryParams.courseId,
      queryParams.batchId
    );

    if (parsedparams.studentView && quizDetail && quizDetail.questionToSelect !== null && quizDetail.questionToSelect !== undefined) {
      const questionToSelect = quizDetail.questionToSelect;
      const selectedQuestions = await generalUtilService.getRandomQuestions(quizDetail.questions, questionToSelect);
      quizDetail = quizDetail.get({ plain: true });
      quizDetail.questions = selectedQuestions;
    }

    if (quizDetail) {
      return quizDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Quiz not found `);
    }
  };

  const updateQuizSessions = async (linked = [], unLinked = [], quizId) => {
    for (const linkedId of linked) {
      const isLinkingExists = await learningSessionQuizRepository.findOne({ learningSessionId: linkedId, quizId: quizId });
      if (!isLinkingExists) {
        await learningSessionQuizRepository.create({ learningSessionId: linkedId, quizId: quizId });
      }
      await learningSessionQuizRepository.update({ recordStatus: 1 }, { learningSessionId: linkedId, quizId: quizId });
    }

    for (const unlinkedId of unLinked) {
      const isUnlinkedSessionExists = await learningSessionRepository.findOne({ id: unlinkedId });
      if (!isUnlinkedSessionExists) {
        logger.error(`Unlinked Learning Session with ID ${unlinkedId} not found`);
        continue;
      }
      await learningSessionQuizRepository.update({ recordStatus: 0 }, { learningSessionId: unlinkedId, quizId: quizId });
    }
  };

  return {
    createQuiz,
    getQuizList,
    getQuiz,
    updateQuizSessions,
  };
});
