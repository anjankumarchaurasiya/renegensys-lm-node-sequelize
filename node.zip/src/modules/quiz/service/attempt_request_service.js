const { define } = require('src/containerHelper');

module.exports = define('attemptRequestService', ({
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND, INVALID_REQUEST },
  attemptRequestRepository,
  userQuizProgressService,
  configMasterService,
}) => {
  const retestRequest = async (userId, quizId, quizType) => {
    const entityName = 'WITHOUT_PERMISSION';
    const configFound = await configMasterService.getConfigByName(quizType);
    const retestAttemptWithoutPermission = configFound.config[entityName];
    let countOfGivenExamWithoutPermission = await userQuizProgressService.checkUserAttemptCountBasedOnBatch({ quizId, userId });
    let message;
    if (quizType === 'EXAM') {
      if (countOfGivenExamWithoutPermission >= retestAttemptWithoutPermission) {
        const isRetestAttemptOpen = await attemptRequestRepository.getLastOpenRetestRequest(userId, quizId, quizType);
        if (isRetestAttemptOpen?.isAttempt == false) {
          throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, `Your previous retest attempt request is still open`);
        } else {
          const attemptNo = isRetestAttemptOpen?.attemptNo ? isRetestAttemptOpen.attemptNo + 1 : countOfGivenExamWithoutPermission + 1;
          return await attemptRequestRepository.create({
            userId,
            quizId,
            type: quizType,
            requestStatus: 'PENDING',
            attemptNo: attemptNo,
            isAttempt: false,
          });
        }
      } else {
        message = 'You are not eligible to give retest';
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      }
    } else if (quizType === 'PRE_SESSION') {
      if (retestAttemptWithoutPermission === 0) {
        message = `For ${quizType} user can give unlimited exam for now`;
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      } else if (countOfGivenExamWithoutPermission >= retestAttemptWithoutPermission) {
        const isRetestAttemptOpen = await attemptRequestRepository.findOne({ userId, quizId, type: quizType });
        if (isRetestAttemptOpen?.isAttempt == false) {
          throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, `Your previous retest attempt request is still open`);
        } else {
          const attemptNo = isRetestAttemptOpen?.attemptNo ? isRetestAttemptOpen.attemptNo + 1 : countOfGivenExamWithoutPermission + 1;
          return await attemptRequestRepository.create({
            userId,
            quizId,
            type: quizType,
            requestStatus: 'PENDING',
            attemptNo: attemptNo,
            isAttempt: false,
          });
        }
      } else {
        message = 'You are not eligible to give retest';
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      }
    } else if (quizType === 'POST_SESSION') {
      if (retestAttemptWithoutPermission === 0) {
        message = `For ${quizType} user can give unlimited exam for now`;
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      } else if (countOfGivenExamWithoutPermission >= retestAttemptWithoutPermission) {
        const isRetestAttemptOpen = await attemptRequestRepository.findOne({ userId, quizId, type: quizType });
        if (isRetestAttemptOpen?.isAttempt == false) {
          throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, `Your previous retest attempt request is still open`);
        } else {
          const attemptNo = isRetestAttemptOpen?.attemptNo ? isRetestAttemptOpen.attemptNo + 1 : countOfGivenExamWithoutPermission + 1;
          return await attemptRequestRepository.create({
            userId,
            quizId,
            type: quizType,
            requestStatus: 'PENDING',
            attemptNo: attemptNo,
            isAttempt: false,
          });
        }
      } else {
        message = 'You are not eligible to give retest';
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      }
    } else if (quizType === 'CAPSTONE_PROJECT') {
      if (retestAttemptWithoutPermission === 0) {
        message = `For ${quizType} user can give unlimited exam for now`;
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      } else if (countOfGivenExamWithoutPermission >= retestAttemptWithoutPermission) {
        const isRetestAttemptOpen = await attemptRequestRepository.findOne({ userId, quizId, type: quizType });
        if (isRetestAttemptOpen?.isAttempt == false) {
          throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, `Your previous retest attempt request is still open`);
        } else {
          const attemptNo = isRetestAttemptOpen?.attemptNo ? isRetestAttemptOpen.attemptNo + 1 : countOfGivenExamWithoutPermission + 1;
          return await attemptRequestRepository.create({
            userId,
            quizId,
            type: quizType,
            requestStatus: 'PENDING',
            attemptNo: attemptNo,
            isAttempt: false,
          });
        }
      } else {
        message = 'You are not eligible to give retest';
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status.status, message);
      }
    }
  };
  const acceptRetestAttempt = async (attemptRequestId, status) => {
    const isAttemptExist = await attemptRequestRepository.findOne({ id: attemptRequestId });
    if (isAttemptExist) {
      await attemptRequestRepository.update({ requestStatus: status }, { id: attemptRequestId });
    } else {
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, `Retest request record not found`);
    }
  };
  return {
    retestRequest,
    acceptRetestAttempt,
  };
});
