const { define } = require('src/containerHelper');

const { QUESTION_RESULT_TYPE } = require('../../../constants');

module.exports = define('quizQuestionService', ({ quizQuestionRepository, questionOptionRepository }) => {
  const getQuizQuestionList = async whereClause => {
    return quizQuestionRepository.findAll(whereClause);
  };

  const calculateEarnedPointsAndResult = async (questionId, questionOptionId) => {
    const quizQuestionData = await quizQuestionRepository.findOne({ questionId });

    if (!questionOptionId) {
      return {
        correctPoint: 0,
        earnPoint: quizQuestionData.points,
        point: quizQuestionData.points,
        result: QUESTION_RESULT_TYPE.UNATTEMPTED,
      };
    }

    const questionCorrectOptions = await questionOptionRepository.findOne({ questionId, isCorrectOption: 1 });

    if (questionOptionId == questionCorrectOptions.id) {
      return {
        correctPoint: quizQuestionData.points,
        earnPoint: quizQuestionData.points,
        point: quizQuestionData.points,
        result: QUESTION_RESULT_TYPE.CORRECT,
      };
    }
    return {
      correctPoint: 0,
      earnPoint: quizQuestionData.points,
      point: quizQuestionData.points,
      result: QUESTION_RESULT_TYPE.WRONG,
    };
  };

  return {
    getQuizQuestionList,
    calculateEarnedPointsAndResult,
  };
});
