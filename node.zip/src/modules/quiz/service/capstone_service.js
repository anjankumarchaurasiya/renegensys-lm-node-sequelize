const { define } = require('src/containerHelper');
const searchFilters = require('../constants/quiz_search_filter_constants.js');

module.exports = define('capstoneService', ({
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, BATCH_NOT_FOUND, UNAUTHORIZED_REQUEST },
  capstoneRepository,
  batchQuizRepository,
  userResponseRepository,
  quizRepository,
  configMasterService,
  attemptRequestRepository,
  logger,
}) => {
  const getCapstoneByBatchId = async (userId, batchId, quizId) => {
    const isBatchExist = await batchQuizRepository.findOne({ batchId: batchId });
    if (!isBatchExist) {
      logger.info('Batch not exist');
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, BATCH_NOT_FOUND);
    } else {
      const batchQuizData = await capstoneRepository.getCapstoneByBatchId(userId, batchId, quizId);
      if (batchQuizData && batchQuizData.length > 0) {
        return batchQuizData[0];
      } else {
        return null;
      }
    }
  };

  //  get capstone details,left ateempt and marks obtained
  const getCapstoneByQuizIdUserId = async (quizId, userId) => {
    const isQuizExist = await quizRepository.findOne({ id: quizId });
    if (isQuizExist) {
      const entityName = 'WITHOUT_PERMISSION';
      const configFound = await configMasterService.getConfigByName('CAPSTONE_PROJECT');
      const retestAttemptWithoutPermission = configFound.config[entityName];
      const { quizDetails, leftAttempt } = await capstoneRepository.getUserCapstoneDetails(quizId, userId, retestAttemptWithoutPermission);
      const lastMarksResponse = await capstoneRepository.lastUserMarksObtainedByUser(quizId, userId);
      const batchQuizDetails = await batchQuizRepository.findOne({ quizId });
      const lastMarksObtained = await resultCalculation(lastMarksResponse);
      const highestMarksResponse = await capstoneRepository.highestUserMarksObtainedByUser(quizId, userId);
      const highestMarksObtained = await resultCalculation(highestMarksResponse);
      const getLastAttemptRequestDetails = await attemptRequestRepository.getLastOpenRetestRequestIsAttemptZero(userId, quizId, 'CAPSTONE');

      const isCapstoneInDraft = await capstoneRepository.findExistingDraftresponse(quizId, userId, 'DRAFT');
      return {
        quizDetails,
        leftAttempt,
        lastMarksObtained,
        highestMarksObtained,
        lastMarksResponse,
        highestMarksResponse,
        attemptRequest: getLastAttemptRequestDetails,
        isCapstoneInDraft: isCapstoneInDraft,
        batchQuizDetails,
      };
    } else {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `Quiz not exist`);
    }
  };
  // result calucation
  const resultCalculation = async marksObtained => {
    const { userResponses, userQuizProgress } = marksObtained;
    let stringMarksObtained = '';
    if (userResponses) {
      const correctIncorrectResponses = userResponses.filter(response => response.result === 'ATTEMPTED');

      const totalQuestions = correctIncorrectResponses.length;
      const totalCorrectIncorrect = correctIncorrectResponses.length;

      if (totalCorrectIncorrect > 0 && totalQuestions > 0) {
        if (userQuizProgress && userQuizProgress.percentage !== undefined) {
          const highestPercentage = userQuizProgress?.percentage;
          stringMarksObtained = `${totalCorrectIncorrect}/${totalQuestions} (${highestPercentage}%)`;
        } else {
          stringMarksObtained = `${totalCorrectIncorrect}/${totalQuestions} (N/A)`;
        }
      } else {
        stringMarksObtained = 'N/A';
      }
    } else {
      return (stringMarksObtained = 'N/A');
    }
    return userQuizProgress?.earnPoint == null || userQuizProgress?.earnPoint == '' ? (stringMarksObtained = 'N/A') : stringMarksObtained;
  };
  const draftCasptoneListByQuizUserId = async (quizId, userId, result) => {
    try {
      const quizExistInResponse = await userResponseRepository.findOne({ quizId: quizId, userId: userId, result: result });
      if (quizExistInResponse) {
        const capstoneList = await capstoneRepository.getDraftCapstoneList(quizId, userId, result);
        return capstoneList;
      } else {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `Draft Capstone not exist`);
      }
    } catch (error) {
      console.error(error);
    }
  };
  return {
    getCapstoneByBatchId,
    getCapstoneByQuizIdUserId,
    draftCasptoneListByQuizUserId,
  };
});
