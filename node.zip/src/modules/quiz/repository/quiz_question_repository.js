const { define } = require('src/containerHelper');

module.exports = define('quizQuestionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('quiz_question');
  const quizQuestionModel = database['quiz_question'];

  const bulkCreate = data => quizQuestionModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
