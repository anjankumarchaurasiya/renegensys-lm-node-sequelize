const { model } = require('mongoose');
const { define } = require('src/containerHelper');
const { Op, Sequelize } = require('sequelize');

module.exports = define('userResponseContentRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_response_content');
  const userResponseModel = database['user_response_content'];

  const bulkCreate = data => userResponseModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
