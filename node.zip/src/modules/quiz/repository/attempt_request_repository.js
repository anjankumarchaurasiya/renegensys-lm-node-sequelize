const { define } = require('src/containerHelper');

module.exports = define('attemptRequestRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('attempt_request');
  const attemptRequestModel = database['attempt_request'];

  const bulkCreate = data => attemptRequestModel.bulkCreate(data, { ignoreDuplicate: true });
  const getLastOpenRetestRequest = async (userId, quizId, type) => {
    return attemptRequestModel.findOne({
      where: { userId, quizId, type },
      order: [['created_at', 'DESC']],
    });
  };
  const getLastOpenRetestRequestIsAttemptZero = async (userId, quizId, type) => {
    return attemptRequestModel.findOne({
      attributes: ['id', 'quizId', 'requestStatus', 'attemptNo'],
      where: { userId, quizId, type, isAttempt: false },
      order: [['created_at', 'DESC']],
    });
  };
  return {
    ...baseRepo,
    bulkCreate,
    getLastOpenRetestRequest,
    getLastOpenRetestRequestIsAttemptZero,
  };
});
