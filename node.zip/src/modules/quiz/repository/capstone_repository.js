const { define } = require('src/containerHelper');
const { Op, Sequelize } = require('sequelize');

module.exports = define('capstoneRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('capstone');
  const batchQuizModel = database['batch_quiz'];
  const quizQuestionModel = database['quiz_question'];
  const questionModel = database['question'];
  const questionContentModel = database['question_content'];
  const contentModel = database['content'];
  const userQuizProgressModel = database['user_quiz_progress'];
  const userResponseModel = database['user_response'];
  const quizeModel = database['quiz'];
  const userResponseContentModel = database['user_response_content'];

  const bulkCreate = data => attemptRequestModel.bulkCreate(data, { ignoreDuplicate: true });
  const getCapstoneByBatchId = async (userId, batchId, quizId) => {
    const batchQuizData = await batchQuizModel.findAll({
      where: {
        batchId: batchId,
        quizId: quizId,
      },
      attributes: ['id', 'batchId', 'quizId'],
      include: [
        {
          model: quizQuestionModel,
          attributes: ['id', 'questionId', 'quizId', 'points'],
          required: true,
          on: {
            quizId: Sequelize.col('batch_quiz.quiz_id'),
          },
          include: [
            {
              model: questionModel,
              attributes: ['id', 'question', 'questionType', 'categoryId'],
              include: [
                {
                  model: questionContentModel,
                  attributes: ['id'],
                  include: [
                    {
                      model: contentModel,
                      attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    });
    return batchQuizData;
  };

  // Get quiz details
  const getUserCapstoneDetails = async (quizId, userId, retestAttemptWithoutPermission) => {
    try {
      const tillNowAttampted = await userQuizProgressModel.count({
        where: { quizId: quizId, userId: userId },
      });
      const leftAttempt = retestAttemptWithoutPermission >= tillNowAttampted ? retestAttemptWithoutPermission - tillNowAttampted : 0;
      const quizDetails = await quizeModel.findOne({
        where: {
          id: quizId,
        },
        attributes: ['id', 'duration', 'passingPercentage'],
      });

      return { quizDetails: quizDetails, leftAttempt: leftAttempt };
    } catch (error) {
      console.error('Error fetching questions:', error);
      throw error;
    }
  };
  // Get last user obtained marks
  const lastUserMarksObtainedByUser = async (quizId, userId) => {
    const userQuizProgress = await userQuizProgressModel.findOne({
      where: {
        userId: userId,
        quizId: quizId,
      },
      attributes: ['id', 'quizId', 'earnPoint', 'totalPoint', 'percentage', 'isPassed', 'completionTime', 'startTime', 'endTime'],
      order: [['created_at', 'DESC']],
    });

    let userResponses = null;

    if (userQuizProgress) {
      userResponses = await userResponseModel.findAll({
        where: {
          userQuizProgressId: userQuizProgress.id,
          quizId: quizId,
        },
        attributes: ['earnPoint', 'result'],
      });
    }
    const tillNowAttampted = await userQuizProgressModel.count({
      where: { quizId: quizId, userId: userId },
    });

    // for same id if more then 1 attempt then return lastattempt
    if (tillNowAttampted > 1) {
      return userQuizProgress?.earnPoint == null || userQuizProgress?.earnPoint == ''
        ? { userQuizProgress: '', userResponses: '', lastCapstoneDetails: userQuizProgress }
        : { userQuizProgress, userResponses, lastCapstoneDetails: userQuizProgress };
    } else {
      return { userQuizProgress: '', userResponses: '', lastCapstoneDetails: userQuizProgress };
    }
  };
  // Get highest user obtained marks
  const highestUserMarksObtainedByUser = async (quizId, userId) => {
    const userQuizProgress = await userQuizProgressModel.findOne({
      where: {
        userId: userId,
        quizId: quizId,
        earnPoint: {
          [Op.eq]: Sequelize.literal(`(SELECT MAX(earn_point) FROM user_quiz_progress WHERE user_id = '${userId}' AND quiz_id = '${quizId}')`),
        },
      },
    });

    let userResponses = null;
    if (userQuizProgress) {
      userResponses = await userResponseModel.findAll({
        where: {
          userQuizProgressId: userQuizProgress.id,
          quizId: quizId,
        },
        attributes: ['earnPoint', 'result'],
      });
    }

    return userQuizProgress?.earnPoint == 0 || userQuizProgress?.earnPoint == ''
      ? { userQuizProgress: '', userResponses: '' }
      : { userQuizProgress, userResponses };
  };
  const findExistingDraftresponse = async (quizId, userId, result) => {
    try {
      const foundRecord = await userResponseModel.findOne({
        where: {
          quizId,
          userId,
          result,
        },
      });

      return !!foundRecord;
    } catch (error) {
      return false;
    }
  };
  // get draft capstone list by userid and quizid
  const getDraftCapstoneList = async (quizId, userId, result) => {
    try {
      const userResponseData = await userResponseModel.findAll({
        where: { userId: userId, quizId: quizId, result },
        attributes: ['id', 'userQuizProgressId', 'quizId', 'questionId', 'response', 'teacherFeedback', 'earnPoint', 'recordStatus', 'result'],
        include: [
          {
            model: questionModel,
            attributes: ['id', 'question'],
            include: [
              {
                model: quizQuestionModel,
                attributes: ['points'],
              },
              {
                model: questionContentModel,
                attributes: ['id'],
                include: [
                  {
                    model: contentModel,
                    attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                  },
                ],
              },
            ],
          },
          {
            model: userResponseContentModel,
            attributes: ['id'],
            include: [
              {
                model: contentModel,
                attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
              },
            ],
          },
        ],
        order: [['created_at', 'DESC']],
      });
      return userResponseData;
    } catch (error) {
      console.error('Error in fetching capstone draft list', error);
      throw error;
    }
  };
  return {
    ...baseRepo,
    bulkCreate,
    getCapstoneByBatchId,
    getUserCapstoneDetails,
    highestUserMarksObtainedByUser,
    lastUserMarksObtainedByUser,
    findExistingDraftresponse,
    getDraftCapstoneList,
  };
});
