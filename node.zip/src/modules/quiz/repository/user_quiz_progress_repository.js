const { define } = require('src/containerHelper');
const { Sequelize, Op } = require('sequelize');

module.exports = define('userQuizProgressRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_quiz_progress');
  const userQuizProgressModel = database['user_quiz_progress'];
  const userResponseModel = database['user_response'];
  const quizeModel = database['quiz'];

  const bulkCreate = data => userQuizProgressModel.bulkCreate(data, { ignoreDuplicate: true });

  const checkUserAttemptCountBasedOnBatch = async whereClause => {
    try {
      return userQuizProgressModel.count({
        where: whereClause,
      });
    } catch (error) {
      throw error;
    }
  };
  // Get quiz details
  const getUserQuizDetails = async (quizId, quizType, userId, retestAttemptWithoutPermission) => {
    try {
      const tillNowAttampted = await userQuizProgressModel.count({
        where: { quizId: quizId, userId: userId },
      });
      const leftAttempt = retestAttemptWithoutPermission >= tillNowAttampted ? retestAttemptWithoutPermission - tillNowAttampted : 0;
      const quizDetails = await quizeModel.findOne({
        where: {
          id: quizId,
        },
        attributes: ['id', 'duration', 'passingPercentage'],
      });

      return { quizDetails: quizDetails, leftAttempt: leftAttempt };
    } catch (error) {
      console.error('Error fetching questions:', error);
      throw error;
    }
  };
  // Get last user obtained marks
  const lastUserMarksObtainedByUser = async (quizId, userId) => {
    const userQuizProgress = await userQuizProgressModel.findOne({
      where: {
        userId: userId,
        quizId: quizId,
      },
      attributes: ['id', 'quizId', 'earnPoint', 'totalPoint', 'percentage', 'isPassed', 'completionTime', 'startTime', 'endTime'],
      order: [['created_at', 'DESC']],
    });
    let userResponses = null;

    if (userQuizProgress) {
      userResponses = await userResponseModel.findAll({
        where: {
          userQuizProgressId: userQuizProgress.id,
          quizId: quizId,
        },
        attributes: ['earnPoint', 'result'],
      });
    }

    return { userQuizProgress, userResponses };
  };
  // Get highest user obtained marks
  const highestUserMarksObtainedByUser = async (quizId, userId) => {
    const userQuizProgress = await userQuizProgressModel.findOne({
      where: {
        userId: userId,
        quizId: quizId,
        earnPoint: {
          [Op.eq]: Sequelize.literal(`(SELECT MAX(earn_point) FROM user_quiz_progress WHERE user_id = '${userId}' AND quiz_id = '${quizId}')`),
        },
      },
    });

    let userResponses = null;
    if (userQuizProgress) {
      userResponses = await userResponseModel.findAll({
        where: {
          userQuizProgressId: userQuizProgress.id,
          quizId: quizId,
        },
        attributes: ['earnPoint', 'result'],
      });
    }
    return { userQuizProgress, userResponses };
  };
  return {
    ...baseRepo,
    bulkCreate,
    checkUserAttemptCountBasedOnBatch,
    getUserQuizDetails,
    lastUserMarksObtainedByUser,
    highestUserMarksObtainedByUser,
  };
});
