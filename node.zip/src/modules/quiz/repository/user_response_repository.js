const { model } = require('mongoose');
const { define } = require('src/containerHelper');
const { Op, Sequelize } = require('sequelize');

module.exports = define('userResponseRepository', ({ database, baseRepositoryV2, logger }) => {
  const baseRepo = baseRepositoryV2('user_response');
  const userResponseModel = database['user_response'];
  const questionModel = database['question'];
  const questionOptionModel = database['question_option'];
  const userQuizProgressModel = database['user_quiz_progress'];
  const quizModel = database['quiz'];

  const bulkCreate = data => userResponseModel.bulkCreate(data, { ignoreDuplicate: true });

  const getUserReport = async (quizId, userId, userQuizProgressId) => {
    try {
      const queryOptions = {
        where: { userQuizProgressId: userQuizProgressId },
        include: [
          {
            model: questionModel,
            attributes: ['id', 'question'],
            include: [
              {
                model: questionOptionModel,
                attributes: ['id', 'option', 'isCorrectOption', 'order', 'description'],
              },
            ],
          },
        ],
        attributes: ['questionId', 'questionOptionId', 'response', 'earnPoint', 'recordStatus', 'result'],
      };

      const resultCounts = await userResponseModel.findAll({
        attributes: ['result', [Sequelize.fn('COUNT', Sequelize.col('*')), 'count']],
        where: {
          userQuizProgressId: userQuizProgressId,
        },
        group: ['result'],
      });

      const userResponseQuizData = await userResponseModel.findAll(queryOptions);

      const userQuizProgressData = await userQuizProgressModel.findOne({
        where: { id: userQuizProgressId },
        include: [{ model: quizModel, attributes: ['id', 'title'] }],
      });

      const userResponseData = userResponseQuizData.map(userResponse => {
        const plainUserResponse = userResponse.toJSON();

        if (plainUserResponse.questionOptionId === null) {
          return plainUserResponse;
        }

        plainUserResponse.question.question_options = plainUserResponse.question.question_options.map(option => {
          if (!option.hasOwnProperty('isSelected')) {
            option.isSelected = false;
          }
          if (option.id === plainUserResponse.questionOptionId) {
            option.isSelected = true;
          }
          return option;
        });

        return plainUserResponse;
      });

      return { userResponseData, userQuizProgressData, resultCounts };
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };

  return {
    ...baseRepo,
    bulkCreate,
    getUserReport,
  };
});
