const { define } = require('src/containerHelper');
const { Op } = require('sequelize');
module.exports = define('quizRepository', ({ database, baseRepositoryV2, logger }) => {
  const baseRepo = baseRepositoryV2('quiz');
  const quizModel = database['quiz'];
  const categoryModel = database['category'];
  const questionModel = database['question'];
  const quizQuestionModel = database['quiz_question'];
  const questionOptionModel = database['question_option'];
  const learningSessionModel = database['learning_session'];
  const learningSessionQuizModel = database['learning_session_quiz'];
  const batchModel = database['batch'];
  const courseModel = database['course'];
  const batchQuizModel = database['batch_quiz'];
  const questionContentModel = database['question_content'];
  const contentModel = database['content'];

  const bulkCreate = data => quizModel.bulkCreate(data, { ignoreDuplicate: true });

  const getQuizes = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseforBatchQuiz = {};
    let requiredValue = false;

    if (whereClause.exam_date) {
      whereClauseforBatchQuiz.exam_date = whereClause.exam_date;
      requiredValue = true;
      delete whereClause.exam_date;
    }
    whereClauseforBatchQuiz.recordStatus = 1;
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        { model: categoryModel, attributes: ['name', 'type'] },
        {
          model: batchQuizModel,
          attributes: ['id', 'batchId', 'quizId', 'startTime', 'examDate', 'recordStatus'],
          where: whereClauseforBatchQuiz,
          required: requiredValue,
          include: [
            {
              model: batchModel,
              attributes: ['id', 'batchNumber'],
            },
          ],
        },
        {
          model: questionModel,
          attributes: ['id', 'question'],
          through: {
            model: quizQuestionModel,
            attributes: ['id', 'points'],
          },
          include: [
            {
              model: categoryModel,
              attributes: ['id', 'name'],
            },
            {
              model: questionOptionModel,
              attributes: ['id', 'option', 'isCorrectOption', 'description', 'order'],
            },
            {
              model: questionContentModel,
              attributes: ['id'],
              include: [
                {
                  model: contentModel,
                  attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                },
              ],
            },
          ],
        },
      ],
    };
    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return quizModel.findAndCountAll(finalClause);
  };

  const getQuiz = async (quizId, viewTree, studentView, viewSession, linked, sessionTitle, courseId, batchId) => {
    try {
      const queryOptions = {
        where: { id: quizId },
      };

      if (viewTree) {
        queryOptions.include = [
          {
            model: questionModel,
            attributes: ['id', 'question', 'question_type', 'created_at'],
            include: [
              {
                model: categoryModel,
                attributes: ['id', 'name'],
              },
              {
                model: questionOptionModel,
                attributes: ['id', 'option', 'order', 'isCorrectOption'],
              },
            ],
            through: {
              model: quizQuestionModel,
              attributes: ['id', 'points'],
            },
          },
        ];
      } else if (studentView) {
        queryOptions.include = [
          {
            model: questionModel,
            attributes: ['id', 'question', 'question_type', 'created_at'],
            include: [
              {
                model: questionOptionModel,
                attributes: ['id', 'order', 'option'],
              },
            ],
            through: {
              model: quizQuestionModel,
              attributes: ['id', 'points'],
            },
          },
          {
            model: batchQuizModel,
            attributes: ['id', 'batchId', 'quizId', 'startTime', 'examDate', 'recordStatus'],
          },
        ];
      } else if (viewSession) {
        let whereClauseforLearningSession = {};

        let whereClauseforLearningQuizSession = linked ? { recordStatus: 1 } : { recordStatus: 0 };

        if (sessionTitle) {
          whereClauseforLearningSession.title = { [Op.like]: `%${sessionTitle}%` };
        }
        if (courseId) {
          whereClauseforLearningSession.courseId = courseId;
        }
        if (batchId) {
          whereClauseforLearningSession.batchId = batchId;
        }
        queryOptions.include = [
          {
            model: learningSessionModel,
            where: whereClauseforLearningSession,
            attributes: ['id', 'title', 'batchId', 'courseId', 'date', 'start_time', 'end_time'],
            through: {
              where: whereClauseforLearningQuizSession,
              model: learningSessionQuizModel,
              attributes: ['id', 'recordStatus'],
            },
            include: [
              {
                model: batchModel,
                attributes: ['id', 'batchNumber'],
              },
              {
                model: courseModel,
                attributes: ['id', 'title'],
              },
            ],
          },
        ];
      }

      return await quizModel.findOne(queryOptions);
    } catch (error) {
      logger.error('Error in get Specific Quiz:', error);
      throw error;
    }
  };

  return {
    ...baseRepo,
    bulkCreate,
    getQuizes,
    getQuiz,
  };
});
