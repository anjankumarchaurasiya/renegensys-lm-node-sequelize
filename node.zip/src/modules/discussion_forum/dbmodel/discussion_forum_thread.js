'use strict';

module.exports = (sequelize, DataTypes) => {
  const DiscussionForumThread = sequelize.define(
    'discussion_forum_thread',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      topic: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      content: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
    },
    {
      freezeTableName: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  DiscussionForumThread.associate = function(models) {
    DiscussionForumThread.hasMany(models.discussion_forum_thread_comment, {
      foreignKey: 'discussionForumThreadId',
      sourceKey: 'id',
    });

    DiscussionForumThread.hasMany(models.discussion_forum_thread_spam, {
      foreignKey: 'discussionForumThreadId',
      sourceKey: 'id',
    });
  };

  return DiscussionForumThread;
};
