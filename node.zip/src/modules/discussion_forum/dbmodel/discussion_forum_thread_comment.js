'use strict';

module.exports = (sequelize, DataTypes) => {
  const DiscussionForumThreadComment = sequelize.define(
    'discussion_forum_thread_comment',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      discussionForumThreadId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      comment: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      likeCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      dislikeCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: false,
      },
    },
    {
      freezeTableName: true,
      underscored: true,
      timestamps: true,
    }
  );

  DiscussionForumThreadComment.associate = function(models) {
    // Association with DiscussionForumThread

    DiscussionForumThreadComment.belongsTo(models.discussion_forum_thread, {
      foreignKey: 'discussionForumThreadId',
      targetKey: 'id',
    });

    DiscussionForumThreadComment.hasMany(models.discussion_forum_thread_spam, {
      foreignKey: 'discussionForumThreadCommentId',
      sourceKey: 'id',
    });
  };

  return DiscussionForumThreadComment;
};
