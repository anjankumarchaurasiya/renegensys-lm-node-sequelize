'use strict';

module.exports = (sequelize, DataTypes) => {
  const DiscussionForumThreadSpam = sequelize.define(
    'discussion_forum_thread_spam',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      discussionForumThreadId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      discussionForumThreadCommentId: {
        type: DataTypes.UUID,
      },
      createdBy: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      reportedAgainst: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      courseId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      warningGiven: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      freezeTableName: true,
      underscored: true,
      timestamps: true,
    }
  );

  DiscussionForumThreadSpam.associate = function(models) {
    DiscussionForumThreadSpam.belongsTo(models.discussion_forum_thread, {
      foreignKey: 'discussionForumThreadId',
      targetKey: 'id',
    });

    DiscussionForumThreadSpam.belongsTo(models.discussion_forum_thread_comment, {
      foreignKey: 'discussionForumThreadCommentId',
      targetKey: 'id',
    });
  };

  return DiscussionForumThreadSpam;
};
