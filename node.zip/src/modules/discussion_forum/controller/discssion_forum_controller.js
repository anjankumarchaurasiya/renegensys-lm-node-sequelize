const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { DISCUSSION_THREAD_CREATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const { discussionForumThreadService, logger, userContextMiddleware, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));

  router.use(userContextMiddleware);

  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create Discussion Forum Thread route');
      await discussionForumThreadService.createDiscussionForumThread(body);
      let data;
      res.status(Status.OK).json(await Success(data, DISCUSSION_THREAD_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
