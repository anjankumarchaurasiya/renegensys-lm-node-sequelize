const { define } = require('src/containerHelper');

module.exports = define('discussionForumThreadService', ({
  discussionForumThreadRepository,
  discussionForumThreadCommentRepository,
  discussionForumThreadSpamRepository,

  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND },
  generalUtilService,
}) => {
  const createDiscussionForumThread = async body => {
    //Please Change code as per your requirement
    await discussionForumThreadRepository.create(body);
  };
  return {
    createDiscussionForumThread,
  };
});
