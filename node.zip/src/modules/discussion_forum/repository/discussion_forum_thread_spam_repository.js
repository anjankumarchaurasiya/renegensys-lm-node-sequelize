const { define } = require('src/containerHelper');

module.exports = define('discussionForumThreadSpamRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('discussion_forum_thread_spam');

  return {
    ...baseRepo,
  };
});
