const { define } = require('src/containerHelper');

module.exports = define('discussionForumThreadRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('discussion_forum_thread');

  return {
    ...baseRepo,
  };
});
