const { define } = require('src/containerHelper');

module.exports = define('discussionForumThreadCommentRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('discussion_forum_thread_comment');

  return {
    ...baseRepo,
  };
});
