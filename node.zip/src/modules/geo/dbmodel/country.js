'use strict';

module.exports = (sequelize, DataTypes) => {
  const Country = sequelize.define(
    'country',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
      },
      code: {
        type: DataTypes.STRING,
      },
      timezone: {
        type: DataTypes.STRING,
      },
      defaultLanguage: {
        type: DataTypes.STRING,
      },
      defaultUtcOffset: {
        type: DataTypes.INTEGER,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Country.associate = function(models) {
    Country.belongsToMany(models.language, { through: models.country_language, foreignKey: { name: 'countryId' } });
  };
  return Country;
};
