'use strict';

module.exports = (sequelize, DataTypes) => {
  const Language = sequelize.define(
    'language',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING, // Hindi, English
      },
      localName: {
        type: DataTypes.STRING,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Language.associate = function(models) {
    Language.belongsToMany(models.country, { through: models.country_language, foreignKey: { name: 'languageId' } });
  };
  return Language;
};
