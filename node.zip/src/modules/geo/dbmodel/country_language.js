'use strict';

module.exports = (sequelize, DataTypes) => {
  const CountryLanguage = sequelize.define(
    'country_language',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      countryId: {
        type: DataTypes.UUID,
      },
      languageId: {
        type: DataTypes.UUID,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  CountryLanguage.associate = function(models) {
    CountryLanguage.belongsTo(models.country, {
      foreignKey: 'countryId',
      sourceKey: 'id',
    });
    CountryLanguage.belongsTo(models.language, {
      foreignKey: 'langaugeId',
      sourceKey: 'id',
    });
  };
  return CountryLanguage;
};
