const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { COUNTRY_CREATED_SUCCESSFULLY, COUNTRY_UPDATED_SUCCESSFULLY, COUNTRY_DEACTIVATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    auth,
    userContextMiddleware,
    response: { Success, Fail },
  } = container.cradle;
  const { countryService, logger, authorizeMiddleware } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Create country ::`);
      const country = await countryService.createCountry(body);
      let data = country.get({ plain: true });
      res.status(Status.OK).json(await Success(data, COUNTRY_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:countryId', async (req, res, next) => {
    try {
      const {
        params: { countryId },
      } = req;
      logger.info(`Get country ::`);
      const country = await countryService.getCountry({ id: countryId });
      res.status(Status.OK).json(await Success(country.get({ plain: true })));
    } catch (e) {
      next(e);
    }
  });

  // to get list of country
  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get country  List ::`);
      const countryList = await countryService.getCountryList(query);
      res.status(Status.OK).json(await Success(countryList));
    } catch (e) {
      next(e);
    }
  });

  // to update specific country of country Id
  router.patch('/:countryId', async (req, res, next) => {
    try {
      const {
        params: { countryId },
        body,
      } = req;
      await countryService.updateCountry({ ...body, id: characterId });
      let data;
      res.status(Status.OK).json(await Success(data, COUNTRY_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  // to deactivate country by country Id
  router.delete('/:countryId', async (req, res, next) => {
    try {
      const {
        params: { countryId },
      } = req;
      await countryService.deactivateCountry(countryId);
      let data;
      res.status(Status.OK).json(await Success(data, COUNTRY_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
