const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { LANGUAGE_CREATED_SUCCESSFULLY, LANGUAGE_UPDATED_SUCCESSFULLY, LANGUAGE_DEACTIVATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    auth,
    userContextMiddleware,
    response: { Success, Fail },
  } = container.cradle;
  const { languageService, logger, authorizeMiddleware } = container.cradle;
  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);

  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info(`Create language ::`);
      const language = await languageService.createLanguage(body);
      if (language) {
        let data = language.get({ plain: true });
        res.status(Status.CREATED).json(await Success(data, LANGUAGE_CREATED_SUCCESSFULLY));
      } else {
        let data = language.get({ plain: true });
        res.status(Status.CREATED).json(await Success(data, LANGUAGE_CREATED_SUCCESSFULLY));
      }
    } catch (e) {
      next(e);
    }
  });

  router.get('/:languageId', async (req, res, next) => {
    try {
      const {
        params: { languageId },
      } = req;
      logger.info(`Get language ::`);
      const language = await languageService.getLanguage(languageId);
      res.status(Status.OK).json(await Success(language.get({ plain: true })));
    } catch (e) {
      next(e);
    }
  });

  // to get list of language
  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get language  List ::`);
      const languageList = await languageService.getLanguageList(query);
      res.status(Status.OK).json(await Success(languageList));
    } catch (e) {
      next(e);
    }
  });

  // to update specific country of country Id
  router.patch('/:languageId', async (req, res, next) => {
    try {
      const {
        params: { languageId },
        body,
      } = req;
      await languageService.updateLanguage({ ...body, id: languageId });
      let data;
      res.status(Status.OK).json(await Success(data, LANGUAGE_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  // to deactivate country by country Id
  router.delete('/:languageId', async (req, res, next) => {
    try {
      const {
        params: { languageId },
      } = req;
      await languageService.deactivateLanguage(languageId);
      let data;
      res.status(Status.OK).json(await Success(data, LANGUAGE_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
