const { define } = require('src/containerHelper');
const searchFilters = require('../constants/geo_search_filter_constants');
module.exports = define('countryService', ({ countryRepository, generalUtilService }) => {
  const createCountry = data => countryRepository.create(data);
  const updateCountry = async data => {
    return countryRepository.update(data, { id: data.id });
  };
  const deactivateCountry = async countryId => await countryRepository.deactivate({ id: countryId });
  const getCountry = whereClause => countryRepository.findOne(whereClause);

  const bulkCreateCountry = data => countryRepository.bulkCreate(data);

  const getCountryList = async queryParams => {
    let countryListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.country);
      countryListResponse = await countryRepository.findAndCountAll(['id', 'name', 'code'], whereClause, [['created_at', 'DESC']], limit, offset);
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.country);
      countryListResponse = await countryRepository.findAndCountAll(['id', 'name', 'code'], whereClause, [['created_at', 'DESC']]);
    }

    return { count: countryListResponse.count, country: countryListResponse.rows };
  };

  return {
    createCountry,
    bulkCreateCountry,
    updateCountry,
    deactivateCountry,
    getCountry,
    getCountryList,
  };
});
