const { define } = require('src/containerHelper');
const searchFilters = require('../constants/geo_search_filter_constants');
module.exports = define('languageService', ({ languageRepository, generalUtilService }) => {
  const createLanguage = data => languageRepository.create(data);
  const updateLanguage = async data => {
    return languageRepository.update(data, { id: data.id });
  };
  const deactivateLanguage = async languageId => await languageRepository.deactivate({ id: languageId });
  const getLanguage = languageId => languageRepository.findOne({ id: languageId });

  const bulkCreateLanguage = data => languageRepository.bulkCreate(data);

  const getLanguageList = async queryParams => {
    let languageListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.langauge);
      languageListResponse = await languageRepository.findAndCountAll(['id', 'name'], whereClause, [['created_at', 'DESC']], limit, offset);
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.langauge);
      languageListResponse = await languageRepository.findAndCountAll(['id', 'name'], whereClause, [['created_at', 'DESC']]);
    }

    return { count: languageListResponse.count, language: languageListResponse.rows };
  };

  return {
    createLanguage,
    bulkCreateLanguage,
    updateLanguage,
    deactivateLanguage,
    getLanguage,
    getLanguageList,
  };
});
