module.exports = Object.freeze({
  country: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
    },
  },
  language: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
    },
  },
});
