const { define } = require('src/containerHelper');

module.exports = define('languageRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('language');
  const languageModel = database['language'];
  const bulkCreate = data => languageModel.bulkCreate(data, { ignoreDuplicates: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
