const { define } = require('src/containerHelper');

module.exports = define('countryRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('country');
  const countryModel = database['country'];
  const bulkCreate = data => countryModel.bulkCreate(data, { ignoreDuplicates: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
