const { define } = require('src/containerHelper');

module.exports = define('countryLanguageRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('country_language');

  return {
    ...baseRepo,
  };
});
