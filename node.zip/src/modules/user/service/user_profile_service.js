const { define } = require('src/containerHelper');

module.exports = define('userProfileService', ({ userProfileRepository }) => {
  const createProfile = async userId => {
    return userProfileRepository.create({ userId });
  };

  return {
    createProfile,
  };
});
