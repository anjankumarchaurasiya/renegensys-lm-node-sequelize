const { define } = require('src/containerHelper');

module.exports = define('userOtpService', ({ userOtpRepository }) => {
  const addOtpByUserId = async ({ userId, otp, type }) => {
    return userOtpRepository.create({ userId, otp, type });
  };

  const getLatestOtpByUserId = async userId => {
    const latestOtp = await userOtpRepository.getOtpByUserId(userId);
    return latestOtp;
  };

  return {
    addOtpByUserId,
    getLatestOtpByUserId,
  };
});
