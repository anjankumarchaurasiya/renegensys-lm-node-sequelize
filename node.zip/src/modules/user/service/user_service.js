const { define } = require('src/containerHelper');
const searchFilters = require('../constants/user_search_filter_constants');

module.exports = define('userService', ({
  userProfileRepository,
  countryRepository,
  roleManagementService,
  userRepository,
  constants: { UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND, USER_ALREADY_EXISTS, OTP_TYPE, PROVIDE_VALID_DATA, PROVIDE_VALID_MOBILE_NUMBER },
  config,
  userOtpService,
  commonUtilService,
  userSessionService,
  CustomError,
  generalUtilService,
  userRoleService,
  notificationService,
  logger,
}) => {
  const getUserById = async userId => {
    let userDetail = await userRepository.getUserById(userId);
    if (userDetail) {
      let countryDetail = await countryRepository.findOne({ code: userDetail.countryCode });
      userDetail = userDetail.get({ plain: true });
      let userResponse = { ...userDetail, country: countryDetail.name };
      return userResponse;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
    }
  };

  const getUserByIdForAuthenticate = async userId => {
    let userDetail = await userRepository.getUserByIdForAuthenticate(userId);
    if (userDetail) {
      let countryDetail = await countryRepository.findOne({ code: userDetail.countryCode });
      userDetail = userDetail.get({ plain: true });
      let userResponse = { ...userDetail, country: countryDetail.name };
      return userResponse;
    } else {
      logger.error(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
    }
  };

  const getUser = async query => {
    const user = await userRepository.findOne(query);
    return user;
  };

  const findUserByPhoneNumber = async queryParams => {
    const { mobile, dialCode } = queryParams;
    const mobileNumber = `${dialCode}${mobile}`;
    let userDetail = await userRepository.findUserByPhoneNumber(mobileNumber);
    if (userDetail) {
      return userDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
    }
  };

  const findUserByEmail = async queryParams => {
    const { email } = queryParams;
    const emailId = `${email}`;
    let userDetail = await userRepository.findUserByEmail(emailId);
    if (userDetail) {
      return userDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
    }
  };

  const createUser = async userData => {
    const { mobile, dialCode, email } = userData;
    const mobileNumber = `${dialCode}${mobile}`;

    if (!generalUtilService.validatePhoneNumber(mobileNumber)) {
      throw new CustomError(PROVIDE_VALID_MOBILE_NUMBER.code, PROVIDE_VALID_MOBILE_NUMBER.status, 'Invalid Mobile Number!');
    }
    try {
      let userMobile = await userRepository.findUserByPhoneNumber(mobileNumber);
      let userEmail = await userRepository.findUserByEmail(email);
      let userExistWithDregNo = await userRepository.findOne({ dreg_no: userData.dregNo });
      if (userMobile && userEmail && userExistWithDregNo) {
        throw new CustomError(
          USER_ALREADY_EXISTS.code,
          USER_ALREADY_EXISTS.status,
          `User already exists with provided Email , Mobile No. and DregNo `
        );
      } else if (userMobile) {
        throw new CustomError(USER_ALREADY_EXISTS.code, USER_ALREADY_EXISTS.status, `User already exists with Mobile No. `);
      } else if (userEmail) {
        throw new CustomError(USER_ALREADY_EXISTS.code, USER_ALREADY_EXISTS.status, `User already exists with provided Email `);
      } else if (userExistWithDregNo) {
        throw new CustomError(USER_ALREADY_EXISTS.code, USER_ALREADY_EXISTS.status, `User already exists with DregNo `);
      }

      let user = await userRepository.create(userData);
      let userProfileData = { userId: user.id };
      await userProfileRepository.create(userProfileData);
      await userRoleService.assignRoleByName(user.id, userData.roles);
      return user;
    } catch (error) {
      throw error;
    }
  };

  const logIn = async body => {
    const { mobile, dialCode, email } = body;
    //validations
    if (!mobile && !email && !dialCode) {
      throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide a valid mobile number and dialCode or email`);
    } else if ((mobile && !dialCode) || (!mobile && dialCode)) {
      throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide both valid mobile number and dialCode`);
    }

    try {
      let userId;
      let userEmail;
      let userDialCode;
      let userMobile;
      let userDetail;

      if (dialCode && mobile) {
        const mobileNumber = `${dialCode}${mobile}`;
        if (!generalUtilService.validatePhoneNumber(mobileNumber)) {
          throw new CustomError(PROVIDE_VALID_MOBILE_NUMBER.code, PROVIDE_VALID_MOBILE_NUMBER.status, 'Invalid Mobile Number!');
        }
        userDialCode = dialCode;
        userMobile = mobile;
        userDetail = await userRepository.findUserByPhoneNumber(mobileNumber);

        if (userDetail) {
          if (!userDetail.recordStatus) {
            throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'User is not active');
          }
          userId = userDetail.id;
          userEmail = userDetail.email;
        } else {
          throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
        }
      }

      if (email) {
        userEmail = email;
        userDetail = await userRepository.findUserByEmail(email);
        if (userDetail) {
          if (!userDetail.recordStatus) {
            throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'User is not active');
          }
          userId = userDetail.id;
          userDialCode = userDetail.dialCode;
          userMobile = userDetail.mobile;
        } else {
          throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
        }
      }

      const otp = commonUtilService.generateOTP(config.otpLength);
      await userOtpService.addOtpByUserId({ userId: userId, otp: otp, type: OTP_TYPE.USER_LOGIN });

      const smsContent = {
        mobile: userDetail.mobile,
        otp: otp,
        dialCode: userDetail.dialCode,
        countryCode: userDetail.countryCode,
      };
      notificationService.sendNotification('OTP', 'sms', smsContent);

      const emailNotificationContent = {
        email: userDetail.email,
        otp: otp,
        userId: userDetail.id,
        countryCode: userDetail.countryCode,
        firstName: userDetail.firstName,
        dialCode: userDetail.dialCode,
      };
      notificationService.sendNotification('OTP', 'email', emailNotificationContent);
    } catch (err) {
      throw err;
    }
  };

  const verifyUserOTP = async ({ dialCode, mobile, otp, email }) => {
    //validations
    if (!mobile && !email && !dialCode) {
      throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide a valid mobile number and dialCode or email`);
    }

    if ((mobile && !dialCode) || (!mobile && dialCode)) {
      throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide both valid mobile number and dialCode`);
    }

    try {
      let userId;
      if (mobile && dialCode) {
        const mobileNumber = `${dialCode}${mobile}`;

        if (!generalUtilService.validatePhoneNumber(mobileNumber)) {
          throw new CustomError(PROVIDE_VALID_MOBILE_NUMBER.code, PROVIDE_VALID_MOBILE_NUMBER.status, 'Invalid Mobile Number!');
        }

        let userDetail = await userRepository.findUserByPhoneNumber(mobileNumber);
        if (userDetail) {
          userId = userDetail.id;
        } else {
          throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
        }
      }

      if (email) {
        let userDetail = await userRepository.findUserByEmail(email);
        if (userDetail) {
          userId = userDetail.id;
        } else {
          throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
        }
      }

      let storedOtp = await userOtpService.getLatestOtpByUserId(userId);
      const isOTPVerified = otp === storedOtp;

      if (!isOTPVerified) {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Please provide correct OTP sent to Email or Mobile');
      }

      const [userSession, user, roles, userProfile, ModulesAccess] = await Promise.all([
        userSessionService.createUserSession({ userId: userId }),
        userRepository.findBy(['id', 'firstName', 'lastName', 'dregNo', 'email', 'mobile', 'dialCode', 'countryCode', 'timezone'], { id: userId }),
        userRoleService.getUserRolesWithNames(userId),
        userProfileRepository.findBy(['profileUrl'], { userId: userId }),
        userRoleService.fetchAndValidateAdminRolesPermission(userId),
      ]);

      const roleNames = roles.map(userRole => userRole.roles.dataValues.name);

      const userData = {
        userSession,
        user,
        roles: roleNames,
        userProfile,
        ModulesAccess,
      };

      return userData;
    } catch (err) {
      throw err;
    }
  };

  const logOut = async () => {
    const token = generalUtilService.getCurrentJWTtoken();
    return userSessionService.updateUserSession({ recordStatus: 0 }, { accessToken: token });
  };

  const bulkCreateUsers = users => userRepository.bulkCreate(users);

  const resendUserOTP = async body => {
    const { mobile, dialCode, email } = body;
    //validations
    if (!mobile && !email && !dialCode) {
      throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide a valid mobile number and dialCode or email`);
    }

    if ((mobile && !dialCode) || (!mobile && dialCode)) {
      throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, `Please provide both valid mobile number and dialCode`);
    }

    try {
      let userId;
      let userDetail;
      if (mobile && dialCode) {
        const mobileNumber = `${dialCode}${mobile}`;
        userDetail = await userRepository.findUserByPhoneNumber(mobileNumber);
        if (userDetail) {
          userId = userDetail.id;
        } else {
          throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
        }
      }

      if (email) {
        userDetail = await userRepository.findUserByEmail(email);
        if (userDetail) {
          userId = userDetail.id;
        } else {
          throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
        }
      }

      const otp = commonUtilService.generateOTP(config.otpLength);
      await userOtpService.addOtpByUserId({ userId: userId, otp: otp, type: OTP_TYPE.RESEND_OTP });

      const smsContent = {
        mobile: userDetail.mobile,
        otp: otp,
        dialCode: userDetail.dialCode,
        countryCode: userDetail.countryCode,
      };
      notificationService.sendNotification('OTP', 'sms', smsContent);

      const emailNotificationContent = {
        email: userDetail.email,
        otp: otp,
        userId: userDetail.id,
        countryCode: userDetail.countryCode,
        firstName: userDetail.firstName,
        dialCode: userDetail.dialCode,
      };
      notificationService.sendNotification('OTP', 'email', emailNotificationContent);
    } catch (err) {
      throw err;
    }
  };

  const getUserList = async queryParams => {
    let userListResponse;
    let queryData = {};
    let roleIds = [];
    if (queryParams.roles) {
      const rolesArray = queryParams.roles.split(',');
      for (const roleName of rolesArray) {
        const currentRole = await roleManagementService.getRoleByRoleName(roleName);
        if (currentRole) {
          roleIds.push(currentRole.id);
        }
      }
      queryData.roles = roleIds;
    }
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.user);

      userListResponse = await userRepository.getUsers(
        ['id', 'firstName', 'lastName', 'dialCode', 'countryCode', 'mobile', 'email', 'recordStatus', 'dregNo', 'timeZone', 'created_at'],
        whereClause,
        queryData,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.user);
      userListResponse = await userRepository.getUsers(
        ['id', 'firstName', 'lastName', 'dialCode', 'countryCode', 'mobile', 'email', 'recordStatus', 'dregNo', 'timeZone', 'created_at'],
        whereClause,
        queryData,
        [['created_at', 'DESC']]
      );
    }
    return { count: userListResponse.count, user: userListResponse.rows };
  };

  const updateUser = async data => {
    const { mobile, email, dialCode, city, state, socialMediaLinks, address, bio, profileUrl } = data;
    const user = await userRepository.findOne({ id: data.id });

    if (!user) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'User not found');
    }

    if (email) {
      // Check if email already exists
      const isEmailExist = await userRepository.findOne({ email: email });
      if (isEmailExist && isEmailExist.id !== data.id) {
        throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status.status, 'Email already exists');
      }
    }

    if (mobile && dialCode) {
      const mobileNumber = `${dialCode}${mobile}`;
      if (!generalUtilService.validatePhoneNumber(mobileNumber)) {
        throw new CustomError(PROVIDE_VALID_MOBILE_NUMBER.code, PROVIDE_VALID_MOBILE_NUMBER.status, 'Invalid Mobile Number!');
      }
      // Check if mobile number with dial code already exists
      const isMobileNumberExist = await userRepository.findUserByPhoneNumber(mobileNumber);
      if (isMobileNumberExist) {
        throw new CustomError(PROVIDE_VALID_DATA.code, PROVIDE_VALID_DATA.status, 'Mobile number with dial code already exists');
      }
    }
    const userProfileData = {
      city,
      state,
      socialMediaLinks,
      address,
      bio,
      profileUrl,
    };
    const userProfile = await userProfileRepository.findOne({ userId: data.id });
    if (userProfile && Object.keys(userProfileData).length > 0) {
      await userProfileRepository.update(userProfileData, { userId: data.id });
    }
    await userRepository.update(data, { id: data.id });
    // if (data.roles) {
    //   const userRoleList = await userRoleService.getUserRole({
    //     userId: data.id,
    //     recordStatus: 1,
    //   });

    //   const allMappedUserRole = userRoleList.map(mappedObj => {
    //     return { id: mappedObj.roleId };
    //   });

    //   const roleIds = [];
    //   for (const roleName of data.roles) {
    //     const currentRole = await roleManagementService.getRoleByRoleName(roleName);
    //     if (currentRole) {
    //       roleIds.push(currentRole.id);
    //     }
    //   }
    //   data.roleIds = roleIds;

    //   const mappedAndUnmappedIds = generalUtilService.getDifferenceBetweenMappedAndUnmappedIds(data.roleIds, allMappedUserRole);

    //   await userRoleService.assignRoleById(data.id, mappedAndUnmappedIds.addedIds || ['fc329c2e-9d36-44f0-ba3f-001bda55076f']);

    //   for (const deletedId of mappedAndUnmappedIds.deletedIds) {
    //     await userRoleService.deactivateUserRole({ roleId: deletedId, userId: data.id });
    //   }
    // }
  };

  const deactivateUser = id => userRepository.deactivate(id);

  return {
    getUserById,
    getUser,
    createUser,
    logIn,
    verifyUserOTP,
    bulkCreateUsers,
    logOut,
    resendUserOTP,
    findUserByPhoneNumber,
    findUserByEmail,
    getUserList,
    updateUser,
    deactivateUser,
    getUserByIdForAuthenticate,
  };
});
