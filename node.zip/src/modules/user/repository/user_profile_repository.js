const { define } = require('src/containerHelper');

module.exports = define('userProfileRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_profile');
  const userProfileModel = database['user_profile'];

  return {
    ...baseRepo,
  };
});
