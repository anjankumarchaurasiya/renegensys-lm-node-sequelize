const { define } = require('src/containerHelper');

module.exports = define('userOtpRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_otp');
  const userOtpModel = database['user_otp'];

  const getOtpByUserId = async userId => {
    let record = await userOtpModel.findOne({
      where: {
        user_id: userId,
      },
      order: [['created_at', 'DESC']],
    });

    return record.otp;
  };

  return {
    ...baseRepo,
    getOtpByUserId,
  };
});
