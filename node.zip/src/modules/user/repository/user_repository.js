const { define } = require('src/containerHelper');

module.exports = define('userRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user');
  const userModel = database['user'];
  const userRoleModel = database['user_role'];
  const roleModel = database['role'];
  const userProfileModel = database['user_profile'];

  const findUserByPhoneNumber = number => {
    return userModel.findOne({
      where: {
        $and: [
          database.sequelize.where(database.sequelize.fn('concat', database.sequelize.col('dial_code'), '', database.sequelize.col('mobile')), {
            [database.sequelize.Op.eq]: number,
          }),
        ],
      },
      raw: true,
      nest: true,
    });
  };

  const findUserByEmail = email => {
    return userModel.findOne({
      where: {
        email: email,
      },
    });
  };

  const bulkCreate = data =>
    userModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });
  const getUserByIdForAuthenticate = async userId => {
    return userModel.findOne({
      where: { id: userId },
      // attributes: { exclude: ['otp'] },
      //
      include: [
        {
          model: userRoleModel,
          where: { recordStatus: 1 },
          required: false,
          order: [[roleModel, 'order', 'ASC']],
          include: [
            {
              model: roleModel,
              as: 'roles',
              where: { recordStatus: 1 },
              required: false,
            },
          ],
        },
        {
          model: userProfileModel,
          where: { recordStatus: 1 },
          required: false,
        },
      ],
    });
  };
  const getUserById = async userId => {
    return userModel.findOne({
      where: { id: userId },
      // attributes: { exclude: ['otp'] },
      //
      include: [
        {
          model: userRoleModel,
          where: { recordStatus: 1 },
          required: false,
          order: [[roleModel, 'order', 'ASC']],
          include: [
            {
              model: roleModel,
              as: 'roles',
              where: { recordStatus: 1 },
              required: false,
            },
          ],
        },
        {
          model: userProfileModel,
          where: { recordStatus: 1 },
          attributes: ['id', 'city', 'state', 'address', 'bio', 'profileUrl', 'socialMediaLinks'],
          required: false,
        },
      ],
    });
  };
  const getUsers = async (attributes, whereClause, queryData, orderBy, limit, offset) => {
    let whereClauseForRole;

    if (queryData?.roles?.length) {
      whereClauseForRole = { [database.sequelize.Op.in]: queryData.roles };
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: userRoleModel,
          attributes: ['id'],
          where: whereClauseForRole ? { roleId: whereClauseForRole } : {},

          include: [
            {
              model: roleModel,
              as: 'roles',
              attributes: ['id', 'name', 'recordStatus'],
            },
          ],
        },
        {
          model: userProfileModel,
          as: 'user_profile',
          attributes: ['id', 'city', 'state', 'address', 'bio', 'profileUrl', 'socialMediaLinks', 'recordStatus'],
        },
      ],
    };
    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }

    return userModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    findUserByPhoneNumber,
    findUserByEmail,
    getUserById,
    getUsers,
    bulkCreate,
    getUserByIdForAuthenticate,
  };
});
