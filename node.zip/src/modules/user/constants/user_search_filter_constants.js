module.exports = Object.freeze({
  user: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
    },
    firstName: {
      op: '$like',
      alias: 'firstName',
    },
    lastName: {
      op: '$like',
      alias: 'lastName',
    },
    email: {
      op: '$like',
      alias: 'email',
    },
    dialCode: {
      op: '$like',
      alias: 'dialCode',
    },
    mobile: {
      op: '$like',
      alias: 'mobile',
    },
    dregNo: {
      op: '$like',
      alias: 'dregNo',
    },
  },
});
