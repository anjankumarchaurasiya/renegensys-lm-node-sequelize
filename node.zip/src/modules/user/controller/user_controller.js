const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  USER_CREATED_SUCCESSFULLY,
  OTP_SENT_SUCCESSFULLY,
  USER_UPDATED_SUCCESSFULLY,
  USER_DEACTIVATED_SUCCESSFULLY,
  OTP_VERIFIED_SUCCESSFULLY,
  LOGGED_OUT_SUCCESSFULLY,
  OTP_RESENT_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const { userService, logger, authorizeMiddleware } = container.cradle;

  router.post('/', auth.authenticate(), userContextMiddleware, authorizeMiddleware, async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create user route');
      await userService.createUser(body);
      let data;
      res.status(Status.OK).json(await Success(data, USER_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/login', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('User login route');
      await userService.logIn(body);
      let data;
      res.status(Status.OK).json(await Success(data, OTP_SENT_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter/list', auth.authenticate(), userContextMiddleware, authorizeMiddleware, async (req, res, next) => {
    try {
      const { query } = req;
      const userList = await userService.getUserList(query);
      res.status(Status.OK).json(await Success(userList));
    } catch (e) {
      next(e);
    }
  });

  router.post('/verify-otp', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('User OTP verify route');
      let data = await userService.verifyUserOTP(body);
      res.status(Status.OK).json(await Success(data, OTP_VERIFIED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/logout', auth.authenticate(), userContextMiddleware, authorizeMiddleware, async (req, res, next) => {
    try {
      logger.info('Log out user route');
      await userService.logOut();
      res.status(Status.OK).json(await Success(LOGGED_OUT_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:userId', auth.authenticate(), userContextMiddleware, authorizeMiddleware, async (req, res, next) => {
    try {
      const {
        params: { userId },
        body,
      } = req;
      await userService.updateUser({ id: userId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, USER_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.delete('/:userId', auth.authenticate(), userContextMiddleware, authorizeMiddleware, async (req, res, next) => {
    try {
      const {
        params: { userId },
      } = req;
      await userService.deactivateUser({ id: userId });
      let data;
      res.status(Status.OK).json(await Success(data, USER_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  router.get('/:userId', auth.authenticate(), userContextMiddleware, authorizeMiddleware, async (req, res, next) => {
    try {
      const {
        params: { userId },
      } = req;
      let userDetail = await userService.getUserById(userId);
      res.status(Status.OK).json(await Success(userDetail));
    } catch (e) {
      next(e);
    }
  });

  router.post('/resend-otp', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('User resend OTP route');
      await userService.resendUserOTP(body);
      let data;
      res.status(Status.OK).json(await Success(data, OTP_RESENT_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
