'use strict';

module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define(
    'user',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      firstName: {
        type: DataTypes.STRING,
      },
      lastName: {
        type: DataTypes.STRING,
      },
      dregNo: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      mobile: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      dialCode: {
        type: DataTypes.STRING,
      },
      countryCode: {
        type: DataTypes.STRING,
      },
      timezone: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  User.associate = function(models) {
    User.hasMany(models.learning_session, {
      foreignKey: 'primaryFacultyId',
      sourceKey: 'id',
    });
    User.hasMany(models.learning_session, {
      foreignKey: 'secondaryFacultyId',
      sourceKey: 'id',
    });
    User.hasMany(models.learning_session, {
      foreignKey: 'srmId',
      sourceKey: 'id',
    });
    User.hasMany(models.user_role, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
    User.hasMany(models.user_session, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
    User.hasMany(models.user_otp, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
    User.hasOne(models.user_profile, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
    User.hasMany(models.batch_user, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
    User.belongsToMany(models.batch, {
      through: models.batch_user,
      foreignKey: 'userId',
      otherKey: 'batchId',
    });
    User.hasMany(models.user_quiz_progress, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
  };

  return User;
};
