'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserOtp = sequelize.define(
    'user_otp',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
      },
      otp: {
        type: DataTypes.STRING,
      },
      type: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      createdBy: {
        type: DataTypes.UUID,
      },
      updatedBy: {
        type: DataTypes.UUID,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  UserOtp.associate = models => {
    UserOtp.belongsTo(models.user, {
      foreignKey: '',
      sourceKey: 'id',
    });
  };

  return UserOtp;
};
