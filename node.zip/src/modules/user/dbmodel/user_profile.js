'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserProfile = sequelize.define(
    'user_profile',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
      },
      city: {
        type: DataTypes.STRING,
      },
      state: {
        type: DataTypes.STRING,
      },
      address: {
        type: DataTypes.STRING,
      },
      bio: {
        type: DataTypes.STRING,
      },
      profileUrl: {
        type: DataTypes.STRING,
      },
      socialMediaLinks: {
        type: DataTypes.JSON,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      createdBy: {
        type: DataTypes.UUID,
      },
      updatedBy: {
        type: DataTypes.UUID,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  UserProfile.associate = function(models) {
    UserProfile.belongsTo(models.user, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
  };
  return UserProfile;
};
