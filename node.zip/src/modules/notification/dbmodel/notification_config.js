module.exports = (sequelize, DataTypes) => {
  const NotificationConfig = sequelize.define(
    'notification_config',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: DataTypes.STRING,
      },
      countryCode: {
        type: DataTypes.STRING,
      },
      config: {
        type: DataTypes.JSON,
      },
      rule: {
        type: DataTypes.STRING,
      },
      notificationType: {
        type: DataTypes.STRING,
      },
      template: {
        type: DataTypes.STRING,
      },
      templateType: {
        type: DataTypes.STRING,
      },
      provider: {
        type: DataTypes.STRING,
      },
      defaultAccount: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
    },
    {
      timestamps: true,
      freezeTableName: true,
    }
  );

  NotificationConfig.associate = function(models) {};
  return NotificationConfig;
};
