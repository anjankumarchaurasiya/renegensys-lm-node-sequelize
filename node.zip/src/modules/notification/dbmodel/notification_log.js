module.exports = (sequelize, DataTypes) => {
  const NotificationLog = sequelize.define(
    'notification_log',
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
      },
      trackingId: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
      notificationName: {
        type: DataTypes.STRING,
      },
      notificationType: {
        type: DataTypes.STRING,
      },
      sentTo: {
        type: DataTypes.STRING,
      },
      sentStatus: {
        type: DataTypes.STRING, // sent, failed
      },
      isError: {
        type: DataTypes.BOOLEAN,
        default: false,
      },
      openCount: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      },
      lastOpenAt: {
        type: DataTypes.DATE,
      },
      notificationUUID: {
        type: DataTypes.UUID,
      },
      error: {
        type: DataTypes.TEXT, // JSON response
      },
      ip: {
        type: DataTypes.STRING,
      },
      template: {
        type: DataTypes.STRING,
      },
      whTemplate: {
        type: DataTypes.STRING,
      },
    },

    {
      freezeTableName: true,
    }
  );

  NotificationLog.associate = function(models) {
    // associations can be defined here
  };
  return NotificationLog;
};
