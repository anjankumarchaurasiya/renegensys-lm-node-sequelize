'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserNotificationPreference = sequelize.define(
    'user_notification_preference',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
      },
      notificationType: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  UserNotificationPreference.associate = function(models) {
    UserNotificationPreference.belongsTo(models.user, {
      foreignKey: 'userId',
      sourceKey: 'id',
    });
  };
  return UserNotificationPreference;
};
