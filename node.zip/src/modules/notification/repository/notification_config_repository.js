const { define } = require('src/containerHelper');

module.exports = define('notificationConfigRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('notification_config');
  const notificationConfigModel = database['notification_config'];
  const bulkCreate = data => notificationConfigModel.bulkCreate(data, { ignoreDuplicates: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
