const { define } = require('src/containerHelper');

module.exports = define('notificationLogRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('notification_log');
  const notificationLogModel = database['notification_log'];
  const bulkCreate = data => notificationLogModel.bulkCreate(data, { ignoreDuplicates: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
