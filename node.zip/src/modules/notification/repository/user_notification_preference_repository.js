const { define } = require('src/containerHelper');

module.exports = define('userNotificationPreferenceRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('user_notification_preference');
  const userNotificationPreference = database['user_notification_preference'];
  const getUserNotificationPreferences = async (attributes, whereClause) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
    };
    return userNotificationPreference.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    getUserNotificationPreferences,
  };
});
