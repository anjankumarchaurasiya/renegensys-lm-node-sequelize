const { define } = require('src/containerHelper');

module.exports = define('notificationLogService', ({ notificationLogRepository, logger }) => {
  const createNotificationLog = async data => notificationLogRepository.create(data);

  const updateNotificationLogById = async (updatedData, logId) => {
    try {
      await notificationLogRepository.update(updatedData, {
        where: { id: logId },
      });

      return true;
    } catch (error) {
      logger.error('Error updating notification log:', error);
      // throw error;
    }
  };

  return {
    createNotificationLog,
    updateNotificationLogById,
  };
});
