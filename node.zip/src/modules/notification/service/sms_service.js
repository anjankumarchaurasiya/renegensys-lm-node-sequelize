const { define } = require('src/containerHelper');
const { omit, isNil, propEq, find } = require('ramda');
const _ = require('lodash');

module.exports = define('smsService', ({
  CustomError,
  configMasterService,
  logger,
  axiosWrapper,
  requestClient,
  constants: { RUNTIME_ERROR, MSG_91_ERROR, PLUGIN_ERROR },
}) => {
  /* -------------------------------------------------------------------------- */
  /*                               Private Methods                              */
  /* -------------------------------------------------------------------------- */

  const sendSms = async ({ mobile, dialCode, provider, smsText }) => {
    try {
      const strategyService = _strategy(provider);
      //  try catch thro error form here also
      const sent = strategyService.strategy({ mobile, dialCode, smsText, provider });
      return sent;
    } catch (err) {
      throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, 'something went wrong while sending otp');
    }
  };

  const _strategy = strategyName => {
    const providers = [
      { name: 'karix', strategy: _karix },
      { name: 'msg91', strategy: _msg91 },
      { name: 'plugin', strategy: _plugin },
    ];
    const strategy = find(propEq('name', strategyName.toLowerCase()))(providers);
    if (isNil(strategy)) {
      logger.error(`Please define the strategy as karix or msg91`);
    }
    return strategy;
  };

  // Send OTP using msg91 as karix
  const _karix = async ({ mobile, dialCode, appVariant = 'toondemy', otp, provider }) => {
    logger.info('_karix strategy reached');
  };

  // Send OTP using Plugin as provider
  const _plugin = async ({ mobile, dialCode, smsText, provider }) => {
    const configName = `${provider}_${process.env.NODE_ENV}`;
    const providerConfig = await configMasterService.getConfigByName(configName);

    if (!providerConfig) {
      throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, `${configName} not found`);
    }

    const mobileNumber = `${dialCode}${mobile}`;
    const requestParams = `?da=${mobileNumber}&ud=${smsText}&id=${providerConfig.config.pluginId}`;
    const options = {
      url: providerConfig.config.baseUrl + requestParams,
      headers: {
        Authorization: `Bearer ${providerConfig.config.authKey}`,
      },
      method: 'POST',
      timeout: 10000,
    };

    try {
      const response = await requestClient.gotRequest(options);
      if (!response) {
        let errorMessage = `Error while sending sms  with data and OTP notification`;
        logger.error(errorMessage);
        throw new CustomError(PLUGIN_ERROR.code, PLUGIN_ERROR.status, errorMessage);
      }
      logger.info(`SMS send successfully  for OTP notification with response ::`);
      return response;
    } catch (err) {
      logger.error(`Error while sending sms to ${mobile} with data and OTP notification`, err);
      //throw err;
    }
  };

  const _msg91 = async ({ mobile, dialCode, appVariant = 'toondemy', otp, provider }) => {
    const configName = `otp_${provider}_${process.env.NODE_ENV}}`;
    const otpConfig = await configMasterService.getConfigByName(configName);

    logger.info(`OTP Config: ${configName}`);
    if (!otpConfig) {
      throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, `${configName} not found`);
    }
    const mobileNumber = `${dialCode}${mobile}`;
    const config = {
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    };
    // prepare url to send OTP message
    let url = `${otpConfig.config.baseUrl}?authkey=${otpConfig.config.authKey}&template_id=${otpConfig.config.templateId}`;
    if (otpConfig.config && otpConfig.config.campaignId) {
      url = `${url}&campaign=${otpConfig.config.campaignId}`;
    }
    url = `${url}&mobile=${mobileNumber}&otp=${otp}&extra_param={\"COMPANY_NAME\":\"${otpConfig.config.companyName}\",\"HASHCODE\":\"${otpConfig.config.hashCode}\"}`;
    logger.info(`URL formed to send OTP: - ${url}`);

    try {
      const response = await axiosWrapper.get({
        url,
        data: {},
        headers: {},
      });
      if (response.status !== 200) {
        let errorMessage = `Error while sending sms to ${mobile} with data and OTP notification`;
        logger.error(errorMessage);
        throw new CustomError(MSG_91_ERROR.code, MSG_91_ERROR.status, errorMessage);
      }
      logger.info(`SMS send successfully to ${mobile} for OTP notification with response :: ${response.data}`);
      return response.data;
    } catch (err) {
      logger.error(`Error while sending sms to ${mobile} with data and OTP notification`, err);
      // throw err;
    }
  };

  return {
    sendSms,
  };
});
