const { define } = require('src/containerHelper');
const sgMail = require('@sendgrid/mail');
const nodemailer = require('nodemailer');

module.exports = define('emailService', ({ logger, configMasterService }) => {
  const sendEmail = async ({ to, subject, text, strategyName }) => {
    try {
      const strategyService = _strategy(strategyName);
      const sent = await strategyService({ to, subject, text });
      return sent;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  };

  const _strategy = strategyName => {
    const providers = {
      nodemailer: _nodemailer,
      sendgrid: _sendgrid,
    };
    const strategy = providers[strategyName];
    if (!strategy) {
      logger.error(`Please define the strategy as nodemailer or sendgrid`);
    }
    return strategy;
  };

  const _nodemailer = async ({ to, subject, text }) => {
    const configName = `${'nodemailer'}_${process.env.NODE_ENV}`;
    const providerConfig = await configMasterService.getConfigByName(configName);

    const createTransporter = () => {
      return nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: providerConfig.config.email,
          pass: providerConfig.config.password,
        },
      });
    };

    const mailOptions = {
      from: providerConfig.config.email,
      to,
      subject,
      text,
    };
    const transporter = createTransporter();
    return await transporter.sendMail(mailOptions);
  };

  const _sendgrid = async ({ to, subject, text }) => {
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    const sendGridContent = {
      to,
      from: providerConfig.config.email,
      subject,
      text,
    };
    return await sgMail.send(sendGridContent);
  };

  return {
    sendEmail,
  };
});
