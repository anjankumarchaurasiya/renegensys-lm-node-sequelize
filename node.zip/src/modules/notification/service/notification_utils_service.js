const { define } = require('src/containerHelper');
const expr = require('expression-eval');
const ejs = require('ejs');
const { clone } = require('ramda');

module.exports = define('notificationUtilService', ({ logger, configMasterService }) => {
  const getKeyName = (notificationType, param) => {
    if (notificationType === 'whatsapp' && param.index !== undefined) {
      return param.index;
    }
    return param.key;
  };

  const getSanitizedValue = (notificationType, val, variableConfig) => {
    if (notificationType === 'whatsapp') {
      if (typeof val === 'string') {
        val = val.replace(/\s\s+|\t/g, ' ');
      }
      if (variableConfig.isBold) {
        return `*${val}*`;
      }
    }
    return val;
  };

  const getValue = async (variableConfig, data, notiType) => {
    let value = '';
    const ast = expr.parse(variableConfig.valueExpr);
    value = getSanitizedValue(notiType, expr.eval(ast, data), variableConfig);
    if (variableConfig.isEjs) {
      value = ejs.render(value, data);
    }
    return value;
  };

  const _getField = (config, data, fieldName) => {
    const configVar = config[fieldName];

    if (configVar !== undefined) {
      if (Array.isArray(configVar)) {
        return configVar.map(itemConfig => {
          const ast = expr.parse(itemConfig.valueExpr || itemConfig);
          return expr.eval(ast, data);
        });
      } else {
        const ast = expr.parse(configVar.valueExpr || configVar);
        return expr.eval(ast, data);
      }
    }

    return null;
  };

  const getCountryCodeExprKey = config => {
    let { countryCodeExpr } = config;
    if (!countryCodeExpr) {
      let toExpr = null;
      if (config.toExpr) {
        toExpr = config.toExpr;
        if (Array.isArray(toExpr)) {
          [toExpr] = toExpr;
        }
        if (toExpr.indexOf('.') > 0) {
          countryCodeExpr = `${toExpr.substring(0, toExpr.lastIndexOf('.'))}.countryCode`;
        } else {
          countryCodeExpr = 'countryCode';
        }
      }
    }
    return countryCodeExpr;
  };

  const getCountryCodeExpr = (config, eventData) => {
    try {
      let countryCodeExpr = getCountryCodeExprKey(config);
      if (countryCodeExpr) {
        let ast = expr.parse(countryCodeExpr);
        let result = expr.eval(ast, eventData);
        if (!result && countryCodeExpr.endsWith('countryCode')) {
          countryCodeExpr = `${countryCodeExpr.substring(0, countryCodeExpr.length - 11)}country_code`;
          ast = expr.parse(countryCodeExpr);
          result = expr.eval(ast, eventData);
        }
        return result;
      }
    } catch (err) {
      logger.error(`Error in getCountryCodeExpr ${JSON.stringify(err)}`);
    }
    return null;
  };

  const parseTemplateVariables = async (notificationConfig, nconfig, data) => {
    const { notificationType, name: notificationName } = notificationConfig;

    try {
      const configVariables = notificationConfig.variables;

      const response = {};
      if (configVariables) {
        for (const i in configVariables) {
          const v = configVariables[i];

          const key = getKeyName(notificationType, v);
          response[key] = await getValue(v, data, notificationType);
        }
      }
      return response;
    } catch (err) {
      logger.error(`Notification name:${notificationName}, type:${notificationType} ==== error in parseTemplateVariables====== `, err);
      return [];
    }
  };

  const getProviderConfig = async (provider, providerConfigType) => {
    try {
      logger.info(`defaultAccount ---- ${defaultAccount}`);
      if (defaultAccount) {
        const config = await configMasterService.getConfigByName(defaultAccount, providerConfigType);
        if (config) {
          return JSON.parse(config);
        }
      }
      const config = await configMasterService.getConfigByName(`DEFAULT_${providerConfigType}_${provider}`, providerConfigType);
      logger.info(`selected Provider Config -- DEFAULT_${providerConfigType}_${provider}`);
      if (config) {
        return config;
      }
    } catch (error) {
      logger.error(`Error while getting config for ${provider} is :: ${{ providerConfigType, defaultAccount }}`);
      throw error;
    }
    return {};
  };

  const parseConfig = async (notificationConfig, data, notificationType) => {
    let response = {};
    let toField;
    let toDialCode;
    if (notificationConfig && data) {
      if (data.template) {
        data.template = data.template.trim();
      }

      const nconfig = clone(notificationConfig);

      if (nconfig.config.toExpr) {
        toField = _getField(nconfig.config, data, 'toExpr');

        if (!Array.isArray(toField)) {
          toField = [toField];
        }
      }

      if (nconfig.config.toDialCode) {
        toDialCode = _getField(nconfig.config, data, 'toDialCode');
        if (!Array.isArray(toDialCode)) {
          toDialCode = [toDialCode];
        }
      }

      const variables = await parseTemplateVariables(notificationConfig.config, nconfig.config, data);

      response = {
        ...nconfig,
        variables,
        toDialCode,
        toField,
      };
    }
    return response;
  };

  const parseActionConfig = async (actionConfig, data, notificationName, notificationType) => {
    try {
      const response = {};
      if (actionConfig.actionVariables) {
        const { actionVariables } = actionConfig;
        for (const i in actionVariables) {
          const v = actionVariables[i];
          const key = getKeyName(notificationType, v);
          response[key] = await getValue(v, data, notificationType);
        }
        return response;
      }
      logger.info(`Notification name:${notificationName}, type:${notificationType} ==== actionConfig missing `);
      return null;
    } catch (err) {
      logger.error(`Notification name:${notificationName}, type:${notificationType} ==== error in parseActionConfig====== `, err);
      return [];
    }
  };

  return {
    getProviderConfig,
    parseConfig,
    parseActionConfig,
  };
});
