const { define } = require('src/containerHelper');
// const searchFilters = require('../constants/geo_search_filter_constants');
const searchFilters = require('../constants/search_filter_constants');

module.exports = define('notificationConfigService', ({ notificationConfigRepository, generalUtilService }) => {
  const bulkCreateNotificationConfig = data => notificationConfigRepository.bulkCreate(data);

  const getNotificationConfigList = async queryParams => {
    let notificationConfigListResponse;
    const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributes(queryParams, searchFilters.notificationConfig);
    notificationConfigListResponse = await notificationConfigRepository.findAndCountAll(
      ['name', 'config', 'rule', 'notification_type', 'template', 'template_type', 'provider', 'default_account'],
      whereClause,
      [['created_at', 'DESC']],
      limit,
      offset
    );

    return { count: notificationConfigListResponse.count, notificationConfig: notificationConfigListResponse.rows };
  };

  const getNotificationConfigForNameType = async (notificaitonName, notificationType, countryCode) => {
    return notificationConfigRepository.findOne({ name: notificaitonName, notificationType: notificationType, countryCode: countryCode });
  };

  return {
    bulkCreateNotificationConfig,
    getNotificationConfigList,
    getNotificationConfigForNameType,
  };
});
