const { define } = require('src/containerHelper');
const user_service = require('../../user/service/user_service');

module.exports = define('userNotificationPreferenceService', ({ userService, userNotificationPreferenceRepository }) => {
  const createOrUpdateUserNotificationPreference = async data => {
    const { userId, notificationPreferences } = data;
    let userDetail = await userService.getUserById(userId);
    if (!userDetail) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `User not found `);
    }

    notificationPreferences.forEach(async notificationPreference => {
      const { notificationType, recordStatus } = notificationPreference;
      const foundNotificationPreference = await userNotificationPreferenceRepository.findOne({ notificationType, userId });
      if (foundNotificationPreference) {
        return userNotificationPreferenceRepository.update({ recordStatus: recordStatus }, { id: foundNotificationPreference.id });
      } else {
        return userNotificationPreferenceRepository.create({ userId, notificationType, recordStatus });
      }
    });
  };

  const getUserNotificationPreferencesByUserId = userId => {
    return userNotificationPreferenceRepository.getUserNotificationPreferences(['id', 'userId', 'notificationType', 'recordStatus'], {
      userId: userId,
    });
  };

  return {
    createOrUpdateUserNotificationPreference,
    getUserNotificationPreferencesByUserId,
  };
});
