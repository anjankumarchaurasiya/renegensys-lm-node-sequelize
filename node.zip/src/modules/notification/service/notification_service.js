const sgMail = require('@sendgrid/mail');
const nodemailer = require('nodemailer');
const { define } = require('src/containerHelper');
const expr = require('expression-eval');
const ejs = require('ejs');
const { clone } = require('ramda');

module.exports = define('notificationService', ({
  logger,
  constants: { notificationConstants },
  notificationConfigService,
  notificationUtilService,
  notificationLogService,
  emailService,
  smsService,
}) => {
  const sendEmail = async (notificationName, notificationType, notificationConfig, notificationData) => {
    logger.info(`Sending push notification. Notification name : ${notificationName}`);
    const nConfig = await notificationUtilService.parseConfig(notificationConfig, notificationData, notificationType);
    let message;
    let nconfigVariables;

    if (nConfig.variables && notificationConfig && notificationConfig.template) {
      nconfigVariables = nConfig.variables;

      logger.info(
        `notificationConfig.template value : ${notificationConfig.template}, nconfig.variables value : ${JSON.stringify(nConfig.config.variables)}`
      );
      message = ejs.render(notificationConfig.template, nconfigVariables);
    } else {
      logger.info(
        `nconfig.variables or template not found while sending push notification. Notification name : ${notificationName} : notificationConfig.template : ${notificationConfig.template} : nConfig.variables : ${nConfig.variables}`
      );
    }

    logger.info(`Final Parsed Value config ${JSON.stringify(nconfigVariables)}`);

    if (nconfigVariables && nConfig.toField) {
      await emailService.sendEmail({
        to: nConfig.toField,
        subject: notificationName,
        text: message,
        strategyName: notificationConfig.provider,
      });
    } else {
      logger.error(`Push notification was not sent`);
    }
  };

  const sendSMS = async (notificationName, notificationType, notificationConfig, notificationData) => {
    logger.info(`Sending push notification. Notification name : ${notificationName}`);

    const nConfig = await notificationUtilService.parseConfig(notificationConfig, notificationData, notificationType);
    let message = '';
    let nconfigVariables;

    if (nConfig.variables && notificationConfig && notificationConfig.template) {
      nconfigVariables = nConfig.variables;

      logger.info(
        `notificationConfig.template value : ${notificationConfig.template}, nconfig.variables value : ${JSON.stringify(nConfig.config.variables)}`
      );
      message = ejs.render(notificationConfig.template, nconfigVariables);
    } else {
      logger.info(
        `nconfig.variables or template not found while sending push notification. Notification name : ${notificationName} : notificationConfig.template : ${notificationConfig.template} : nConfig.variables : ${nConfig.variables}`
      );
    }

    logger.info(`Final Parsed Value config ${JSON.stringify(nconfigVariables)}`);

    smsService.sendSms({
      mobile: nConfig.toField,
      dialCode: nConfig.toDialCode,
      provider: nConfig.provider,
      smsText: message,
    });
  };

  const sendWhatsapp = async (notificationName, notificationType, notificationData) => {};
  const sendIVR = async (notificationName, notificationType, notificationData) => {};

  // Method to send push notitification
  const sendPushNotification = async (notificationName, notificationType, notificationConfig, notificationData) => {
    let actionObject;
    logger.info(`Sending push notification. Notification name : ${notificationName} : notification Type : ${notificationType}`);
    const nConfig = await notificationUtilService.parseConfig(notificationConfig, notificationData);
    if (notificationConfig.actionConfig) {
      actionObject = await notificationUtilService.parseActionConfig(
        notificationConfig.actionConfig,
        notificationData,
        notificationName,
        notificationType
      );
    }
    let message = '';
    let nconfigVariables;

    if (nConfig.variables && notificationConfig && notificationConfig.template) {
      nconfigVariables = nConfig.variables;
      logger.info(
        `notificationConfig.template value : ${notificationConfig.template}, nconfig.variables value : ${JSON.stringify(nConfig.variables)}`
      );
      message = ejs.render(notificationConfig.template, nconfigVariables);
    } else {
      logger.info(
        `nconfig.variables or template not found while sending push notification. Notification name : ${notificationName} : notificationConfig.template : ${notificationConfig.template} : nConfig.variables : ${nConfig.variables}`
      );
    }

    logger.info(`Final Parsed Value config ${JSON.stringify(nconfigVariables)}`);
    if (nconfigVariables && nconfigVariables.userId) {
      const { connectionId } = nconfigVariables;
      await pushNotificationService.sendPushNotification(connectionId, notificationName, nConfig, notificationData, actionObject, message);
    } else {
      logger.error(`Push notification was not sent because userId was not available`);
    }
  };

  // Based on the notificaiton type call the respective method.
  const sendNotificationAux = async (notificationName, notificationType, processedNotifConfig, notificationData) => {
    switch (notificationType) {
      case 'email':
        await sendEmail(notificationName, notificationType, processedNotifConfig, notificationData);
        break;
      case 'sms':
        await sendSMS(notificationName, notificationType, processedNotifConfig, notificationData);
        break;
      case 'ivr':
        await sendIVR(notificationName, processedNotifConfig, notificationData);
        break;
      case 'whatsapp':
        await sendWhatsapp(notificationName, processedNotifConfig, notificationData);
        break;
      case 'slack':
        await sendSlackNotification(notificationName, notificationType, processedNotifConfig, notificationData);
        break;
      case 'push':
        await sendPushNotification(notificationName, notificationType, processedNotifConfig, notificationData);
        break;
      default:
        break;
    }
  };

  const sendNotification = async (notificationName, notificationType, nData) => {
    let notificationTrackingId = null;

    const { countryCode } = nData;
    const notificationConfig = await notificationConfigService.getNotificationConfigForNameType(notificationName, notificationType, countryCode);

    const notificationData = clone(nData);

    const notificationLogContext = {
      receiverId: nData.userId,
      notificationName,
      notificationType,
      sentTo: nData.email,
    };

    // If no notification config found with specific name and type we record a entry in the notification log table with skipped status

    if (!notificationConfig) {
      notificationLogContext.status = notificationConstants.NOTIFICATION_STATUS.SKIPPED;
      notificationLogContext.subStatus = notificationConstants.NOTIFICATION_SUB_STATUS.NO_CONFIG_FOUND;
      notificationLogContext.reason = notificationConstants.REASONS.NO_CONFIG_FOUND;
      await notificationLogService.createNotificationLog(notificationLogContext);
      return;
    }

    logger.info(
      `notification log INIT : notfication Name : ${notificationName} : notification Type : ${notificationType} : notification data : ${JSON.stringify(
        notificationData
      )}`
    );
    try {
      notificationData.notificationLogContext = notificationLogContext;
      const notificationDataInitPayload = { ...notificationLogContext, status: notificationConstants.NOTIFICATION_STATUS.INIT };
      const notificationLogCreated = await notificationLogService.createNotificationLog(notificationDataInitPayload);
      if (notificationLogCreated) {
        notificationTrackingId = notificationLogCreated.id;
        notificationData.notificationTrackingId = notificationTrackingId;
      }
    } catch (err) {
      logger.error(`Error while creating notification Log init ${err}`);
    }

    let isEligibleToSend = false;

    const ast = expr.parse(notificationConfig.rule);
    isEligibleToSend = expr.eval(ast, notificationData);
    logger.info(`Eligible rule found to send notfication : rule :  ${notificationConfig.rule} `);

    if (!isEligibleToSend) {
      const updatedNotificationLogData = {
        status: notificationConstants.NOTIFICATION_STATUS.SKIPPED,
        subStatus: notificationConstants.NOTIFICATION_SUB_STATUS.NO_ELIGIBLE_RULE,
        reason: notificationConstants.REASONS.NO_ELIGIBLE_RULE,
      };
      await notificationLogService.createNotificationLog(updatedNotificationLogData, notificationTrackingId);
    }

    await sendNotificationAux(notificationName, notificationType, notificationConfig.get({ plain: true }), notificationData);
  };

  return {
    sendNotification,
  };
});
