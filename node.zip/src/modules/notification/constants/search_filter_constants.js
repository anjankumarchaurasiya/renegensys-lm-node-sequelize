module.exports = Object.freeze({
  notification_config: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
    },
  },
});
