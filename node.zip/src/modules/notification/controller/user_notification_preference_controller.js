const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { USER_NOTIFICATION_CREATED_SUCCESSFULLY, USER_NOTIFICATION_UPDATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
    userContextMiddleware,
    authorizeMiddleware,
  } = container.cradle;
  const { userNotificationPreferenceService, logger } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create user notification preference');
      let data = await userNotificationPreferenceService.createOrUpdateUserNotificationPreference(body);
      res.status(Status.OK).json(await Success(data, USER_NOTIFICATION_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Update user notification preference');
      let data = await userNotificationPreferenceService.createOrUpdateUserNotificationPreference(body);
      res.status(Status.OK).json(await Success(data, USER_NOTIFICATION_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:userId', async (req, res, next) => {
    try {
      const {
        params: { userId },
      } = req;
      logger.info('Get user notification preference');
      const result = await userNotificationPreferenceService.getUserNotificationPreferencesByUserId(userId);
      res.status(Status.OK).json(await Success(result));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
