const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  COURSE_CREATED_SUCCESSFULLY,
  COURSE_UPDATED_SUCCESSFULLY,
  COURSE_DEACTIVATED_SUCCESSFULLY,
  COURSE_MODULE_MAPPING_SUCCESSFULLY,
  COURSE_MODULE_MAPPING_UPDATED_SUCCESSFULLY,
  COURSE_FAQ_CREATED_SUCCESSFULLY,
  COURSE_FAQ_UPDATED_SUCCESSFULLY,
  COURSE_FAQ_DELETED_SUCCESSFULLY,
  COURSE_STATUS_CHANGED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const { courseService, courseModuleService, logger, frequentlyAskedQuestionService, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create course route');
      await courseService.createCourse(body);
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  // to get list of courses
  router.get('/filter/list', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get course  List ::`);
      const courseList = await courseService.getCourseList(query);
      res.status(Status.OK).json(await Success(courseList));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:courseId', async (req, res, next) => {
    try {
      const {
        params: { courseId },
        body,
      } = req;
      await courseService.updateCourse({ id: courseId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:courseId', async (req, res, next) => {
    try {
      const {
        params: { courseId },
        query,
      } = req;
      let courseDetail = await courseService.getCourse(courseId, query);
      res.status(Status.OK).json(await Success(courseDetail));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/bulk', async (req, res, next) => {
    try {
      const { body } = req;
      let data = await courseService.bulkDeactivateCourse(body);
      res.status(Status.OK).json(await Success(data, COURSE_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:courseId', async (req, res, next) => {
    try {
      const {
        params: { courseId },
      } = req;
      await courseService.deactivateCourse({ id: courseId });
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  /** Create course mapping with module */
  router.post('/:courseId/module', async (req, res, next) => {
    try {
      const {
        params: { courseId },
        body: { modules },
      } = req;
      logger.info('Create course module mapping');
      await courseModuleService.createCourseModule(courseId, modules);
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_MODULE_MAPPING_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  /** Update course mapping with module*/
  router.patch('/:courseId/module', async (req, res, next) => {
    try {
      const {
        params: { courseId },
        body: { unLinked, order },
      } = req;
      logger.info('Update course module mapping');
      await courseModuleService.updateCourseModule(courseId, unLinked, order);
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_MODULE_MAPPING_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.post('/:courseId/faq', async (req, res, next) => {
    try {
      const {
        params: { courseId },
        body,
      } = req;
      logger.info('Create Frequently asked Question ');
      await frequentlyAskedQuestionService.createFaq(courseId, body);
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_FAQ_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:courseId/faq/:faqId', async (req, res, next) => {
    try {
      const {
        params: { courseId, faqId },
        body,
      } = req;
      logger.info('Update Frequently asked Question');
      await frequentlyAskedQuestionService.updateFaq(courseId, faqId, body);
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_FAQ_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:courseId/faq/:faqId', async (req, res, next) => {
    try {
      const {
        params: { courseId, faqId },
        body,
      } = req;
      logger.info('Delete Frequently asked Question ');
      await frequentlyAskedQuestionService.deactivateFaq(courseId, faqId, body);
      let data;
      res.status(Status.OK).json(await Success(data, COURSE_FAQ_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:courseId/faq/filter/list', async (req, res, next) => {
    try {
      const {
        params: { courseId },
      } = req;
      const { query } = req;
      logger.info('Get All Frequently asked Question ');
      const faqList = await frequentlyAskedQuestionService.getFaqList(courseId, query);
      res.status(Status.OK).json(await Success(faqList));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/bulk/activate', async (req, res, next) => {
    try {
      const {
        body: { courseIds },
      } = req;
      let data = await courseService.bulkActivateCourse(courseIds);
      res.status(Status.OK).json(await Success(data, COURSE_STATUS_CHANGED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
