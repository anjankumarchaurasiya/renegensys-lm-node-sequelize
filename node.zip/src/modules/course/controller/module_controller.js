const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  MODULE_CREATED_SUCCESSFULLY,
  MODULE_UPDATED_SUCCESSFULLY,
  MODULE_DELETED_SUCCESSFULLY,
  MODULE_TOPIC_MAPPING_CREATED_SUCCESSFULLY,
  MODULE_TOPIC_MAPPING_UPDATED_SUCCESSFULLY,
  MODULE_ACTIVATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const { moduleService, moduleTopicService, logger, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create module route');
      await moduleService.createModule(body);
      let data;
      res.status(Status.OK).json(await Success(data, MODULE_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/:moduleId', async (req, res, next) => {
    try {
      const {
        params: { moduleId },
        body,
      } = req;
      logger.info('Update module route');
      await moduleService.updateModule({ id: moduleId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, MODULE_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/filter/list', async (req, res, next) => {
    try {
      const { query } = req;
      const moduleList = await moduleService.getModuleList(query);
      res.status(Status.OK).json(await Success(moduleList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:moduleId', async (req, res, next) => {
    try {
      const {
        params: { moduleId },
        query,
      } = req;
      let moduleDetail = await moduleService.getModule(moduleId, query);
      res.status(Status.OK).json(await Success(moduleDetail));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/bulk', async (req, res, next) => {
    try {
      const { body } = req;
      let data = await moduleService.deactivateBulk(body);
      res.status(Status.OK).json(await Success(data, MODULE_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.delete('/:moduleId', async (req, res, next) => {
    try {
      const {
        params: { moduleId },
      } = req;
      logger.info('Delete module route');
      await moduleService.deactivateModuleById(moduleId);
      let data;
      res.status(Status.OK).json(await Success(data, MODULE_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Create Module topic mapping with topic */
  router.post('/:moduleId/topic', async (req, res, next) => {
    try {
      const {
        params: { moduleId },
        body: { topics },
      } = req;
      logger.info('Create module topic mapping');
      await moduleTopicService.createModuleTopic(moduleId, topics);
      let data;

      res.status(Status.OK).json(await Success(data, MODULE_TOPIC_MAPPING_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  /** Update module mapping with topic*/
  router.patch('/:moduleId/topic', async (req, res, next) => {
    try {
      const {
        params: { moduleId },
        body: { unLinked, order },
      } = req;
      logger.info('Update module topic mapping');
      await moduleTopicService.updateModuleTopic(moduleId, unLinked, order);
      let data;
      res.status(Status.OK).json(await Success(data, MODULE_TOPIC_MAPPING_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/bulk/activate', async (req, res, next) => {
    try {
      const {
        body: { moduleIds },
      } = req;
      let data = await moduleService.bulkActivateModule(moduleIds);
      res.status(Status.OK).json(await Success(data, MODULE_ACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
