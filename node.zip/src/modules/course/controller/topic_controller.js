const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { TOPIC_CREATED_SUCCESSFULLY, TOPIC_UPDATED_SUCCESSFULLY, TOPIC_DELETED_SUCCESSFULLY, TOPIC_ACTIVATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
  } = container.cradle;
  const { topicService, logger, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);
  /** Create topic */
  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      await topicService.createTopic(body);
      let data;
      res.status(Status.OK).json(await Success(data, TOPIC_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Get topic list */
  router.get('/', async (req, res, next) => {
    try {
      const { query } = req;
      logger.info(`Get topic  List ::`);
      const topicList = await topicService.getTopicList(query);
      res.status(Status.OK).json(await Success(topicList));
    } catch (e) {
      next(e);
    }
  });

  /** Update topic */
  router.patch('/:topicId', async (req, res, next) => {
    try {
      const {
        params: { topicId },
        body,
      } = req;
      await topicService.updateTopic({ id: topicId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, TOPIC_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Get specific topic by id */
  router.get('/:topicId', async (req, res, next) => {
    try {
      const {
        params: { topicId },
        query,
      } = req;
      let topicDetails = await topicService.getTopicById(topicId, query);
      res.status(Status.OK).json(await Success(topicDetails));
    } catch (e) {
      next(e);
    }
  });
  /** Bulk deactivate */
  router.delete('/bulk', async (req, res, next) => {
    try {
      const { body } = req;
      let data = await topicService.deactivateBulk(body);
      res.status(Status.OK).json(await Success(data, TOPIC_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  /** Single Topic deactivate */
  router.delete('/:topicId', async (req, res, next) => {
    try {
      const {
        params: { topicId },
      } = req;
      logger.info('Delete topic route');
      await topicService.deactivateTopicById(topicId);
      let data;
      res.status(Status.OK).json(await Success(data, TOPIC_DELETED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/bulk/activate', async (req, res, next) => {
    try {
      const {
        body: { topicIds },
      } = req;
      let data = await topicService.bulkActivateTopic(topicIds);
      res.status(Status.OK).json(await Success(data, TOPIC_ACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
