module.exports = Object.freeze({
  topic: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
    },
    title: {
      op: '$like',
      alias: 'title',
    },
    slug: {
      op: '$like',
      alias: 'slug',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    moduleId: {
      op: '$eq',
      alias: 'module_id',
      dataType: 'UUID',
    },
    linked: {
      op: '$eq',
      alias: 'linked',
      dataType: 'BOOLEAN',
    },
    topicId: {
      op: '$eq',
      alias: 'topic_id',
      dataType: 'UUID',
    },
  },
});
