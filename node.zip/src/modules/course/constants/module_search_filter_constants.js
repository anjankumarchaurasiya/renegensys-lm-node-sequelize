module.exports = Object.freeze({
  module: {
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    description: {
      op: '$like',
      alias: 'description',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    courseId: {
      op: '$eq',
      alias: 'course_id',
      dataType: 'UUID',
    },
    slug: {
      op: '$like',
      alias: 'slug',
      dataType: 'STRING',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    linked: {
      op: '$eq',
      alias: 'linked',
      dataType: 'BOOLEAN',
    },
  },
});
