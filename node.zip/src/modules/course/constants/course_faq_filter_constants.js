module.exports = Object.freeze({
  faq: {
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    courseId: {
      op: '$eq',
      alias: 'module_id',
      dataType: 'UUID',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
  },
});
