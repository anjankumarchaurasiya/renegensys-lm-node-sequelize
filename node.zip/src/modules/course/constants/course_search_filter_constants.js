module.exports = Object.freeze({
  course: {
    title: {
      op: '$like',
      alias: 'title',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    moduleId: {
      op: '$eq',
      alias: 'module_id',
      dataType: 'UUID',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    slug: {
      op: '$like',
      alias: 'slug',
      dataType: 'STRING',
    },
  },
});
