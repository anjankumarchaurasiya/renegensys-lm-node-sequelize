const { define } = require('src/containerHelper');

module.exports = define('topicRepository', ({ database, baseRepositoryV2, logger }) => {
  const baseRepo = baseRepositoryV2('topic');
  const moduleTopicModel = database['module_topic'];
  const moduleModel = database['module'];
  const topicModel = database['topic'];
  const courseModuleModel = database['course_module'];
  const courseModel = database['course'];
  const topicContentModel = database['topic_content'];
  const contentModel = database['content'];
  const bulkCreate = data => topicModel.bulkCreate(data, { ignoreDuplicates: true });

  const getTopic = async (whereClause, usages) => {
    try {
      let includeArray = [];
      if (usages) {
        includeArray.push({
          model: moduleModel,
          attributes: ['id', 'title', 'description', 'slug', 'thumbnail', 'recordStatus'],
          through: {
            model: moduleTopicModel,
            where: { topicId: whereClause.id },
            attributes: [],
          },
          include: [
            {
              model: courseModel,
              attributes: ['id', 'title', 'description', 'slug', 'thumbnail', 'recordStatus'],
              through: {
                model: courseModuleModel,
                attributes: [],
              },
            },
          ],
        });
      }
      return topicModel.findOne({
        where: whereClause,
        attributes: ['id', 'title', 'thumbnail', 'recordStatus'],
        include: includeArray,
      });
    } catch (error) {
      logger.error('Error fetching all modules with topics:', error);
      throw error;
    }
  };
  const getTopicsWithContent = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForTopic;
    let finalWhereClauseForModulTopiceModel = {};
    let requiredValue = false;
    let requiredValueForModuleTopic = false;

    if (whereClause.topic_id) {
      whereClauseForTopic = whereClause.topic_id;
      requiredValue = true;
      delete whereClause.topic_id;
    }
    let linkedWasDeleted = 'linked' in whereClause;
    if (whereClause.linked) {
      finalWhereClauseForModulTopiceModel.recordStatus = whereClause.linked;
      requiredValueForModuleTopic = true;
      delete whereClause.linked;
    }

    if (whereClause.module_id) {
      finalWhereClauseForModulTopiceModel.moduleId = whereClause.module_id;
      requiredValueForModuleTopic = true;
      delete whereClause.module_id;
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      distinct: true,
      include: [
        {
          model: moduleTopicModel,
          attributes: ['id', 'order'],
          where: finalWhereClauseForModulTopiceModel,
          required: requiredValueForModuleTopic,
          include: [
            {
              model: moduleModel,
              as: 'module',
              attributes: ['id', 'title', 'description', 'recordStatus'],
            },
          ],
          order: [['order', 'ASC']],
        },
        {
          model: topicContentModel,
          attributes: ['id'],
          where: {
            ...(whereClauseForTopic ? { topicId: whereClauseForTopic } : {}),
            record_status: true,
          },
          required: requiredValue,
          include: [
            {
              model: topicModel,
              as: 'topic',
              attributes: [],
            },
            {
              model: contentModel,
              as: 'content',
              attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
            },
          ],
        },
      ],
    };
    if (linkedWasDeleted) {
      // Add order at the end
      finalClause.order = [[{ model: moduleTopicModel }, 'order', 'ASC']];
    } else {
      // Add order at the beginning
      finalClause.order = orderBy;
    }
    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }

    return topicModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    getTopic,
    getTopicsWithContent,
  };
});
