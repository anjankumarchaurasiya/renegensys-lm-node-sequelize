const { define } = require('src/containerHelper');

module.exports = define('courseRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('course');
  const courseModel = database['course'];
  const moduleModel = database['module'];
  const topicModel = database['topic'];
  const courseModuleModel = database['course_module'];
  const moduleTopicModel = database['module_topic'];
  const topicContentModel = database['topic_content'];
  const contentModel = database['content'];

  const bulkCreate = data => courseModel.bulkCreate(data, { ignoreDuplicates: true });

  const getCourse = async (courseId, treeParams) => {
    try {
      const queryOptions = {
        where: { id: courseId },
        attributes: ['id', 'title', 'description', 'recordStatus', 'created_at'],
      };
      if (treeParams.viewTree) {
        queryOptions.include = [
          {
            model: moduleModel,
            attributes: ['id', 'title', 'description', 'recordStatus', 'created_at'],
            through: {
              model: courseModuleModel,
              attributes: ['id', 'recordStatus', 'order', 'createdAt'],
            },
            include: [
              {
                model: topicModel,
                attributes: ['id', 'title', 'recordStatus', 'created_at'],
                through: {
                  model: moduleTopicModel,
                  attributes: ['id', 'order', 'recordStatus', 'createdAt'],
                },
              },
            ],
          },
        ];
      }
      if (treeParams.viewStudent) {
        queryOptions.include = [
          {
            model: moduleModel,
            attributes: ['id', 'title', 'description', 'recordStatus', 'created_at'],
            through: {
              model: courseModuleModel,
              attributes: ['id', 'recordStatus', 'order', 'createdAt'],
            },
            where: { recordStatus: 1 },
            include: [
              {
                model: topicModel,
                attributes: ['id', 'title', 'recordStatus', 'created_at'],
                through: {
                  model: moduleTopicModel,
                  attributes: ['id', 'order', 'recordStatus', 'createdAt'],
                },
                where: { recordStatus: 1 },
                include: [
                  {
                    model: topicContentModel,
                    attributes: ['id'],
                    where: { recordStatus: 1 },
                    include: [
                      {
                        model: contentModel,
                        attributes: ['title', 'url', 'slug', 'type', 'description'],
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ];
      }
      return await courseModel.findOne(queryOptions);
    } catch (error) {
      console.error('Error in getCourseTree:', error);
      throw error;
    }
  };

  const getCourses = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForModule;
    let requiredValue = false;

    if (whereClause.module_id) {
      whereClauseForModule = whereClause.module_id;
      requiredValue = true;
      delete whereClause.module_id;
    }
    let finalClause = {
      where: whereClause,
      distinct: true,
      attributes: attributes,
      order: orderBy,
      include: [
        {
          model: courseModuleModel,
          attributes: ['id'],
          where: whereClauseForModule ? { moduleId: whereClauseForModule } : {},
          required: requiredValue,
          include: [
            {
              model: moduleModel,
              as: 'module',
              attributes: ['id', 'title', 'description', 'recordStatus'],
            },
          ],
        },
      ],
    };
    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return courseModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    getCourses,
    getCourse,
  };
});
