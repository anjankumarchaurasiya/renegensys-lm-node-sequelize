const { define } = require('src/containerHelper');

module.exports = define('moduleTopicRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('module_topic');
  const moduleTopicModel = database['module_topic'];
  /** Bulk create */
  const bulkCreate = data =>
    moduleTopicModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });
  /** Get single data by module id, order by desc, findone*/
  const getLastModuleTopic = async moduleId => {
    return moduleTopicModel.findOne({
      where: moduleId,
      order: [['order', 'DESC']],
    });
  };
  return {
    ...baseRepo,
    bulkCreate,
    getLastModuleTopic,
  };
});
