const { define } = require('src/containerHelper');

module.exports = define('topicContentRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('topic_content');
  const topicContentModel = database['topic_content'];

  const bulkCreate = data =>
    topicContentModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
