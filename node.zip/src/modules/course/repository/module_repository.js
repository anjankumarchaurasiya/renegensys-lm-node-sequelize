const { define } = require('src/containerHelper');

module.exports = define('moduleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('module');
  const moduleModel = database['module'];
  const courseModel = database['course'];
  const courseModuleModel = database['course_module'];
  const topicModel = database['topic'];
  const moduleTopicModel = database['module_topic'];
  const bulkCreate = data => moduleModel.bulkCreate(data, { ignoreDuplicates: true });

  const getModules = async (attributes, whereClause, orderBy, limit, offset) => {
    let finalWhereClauseForCourseModuleModel = {};
    let requiredValue = false;

    if (whereClause.linked) {
      finalWhereClauseForCourseModuleModel.recordStatus = whereClause.linked;
      requiredValue = true;
    }
    if (whereClause.course_id) {
      finalWhereClauseForCourseModuleModel.courseId = whereClause.course_id;
      requiredValue = true;
      delete whereClause.course_id;
    }
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      distinct: true,
      include: [
        {
          model: courseModuleModel,
          attributes: ['id', 'courseId', 'moduleId', 'order'],
          where: finalWhereClauseForCourseModuleModel,
          required: requiredValue,
          include: [
            {
              model: courseModel,
              as: 'course',
              attributes: ['id', 'title', 'description', 'recordStatus'],
            },
          ],
        },
      ],
    };
    if (whereClause.hasOwnProperty('linked')) {
      finalClause.order = [[{ model: courseModuleModel }, 'order', 'ASC']];
    } else if (orderBy) {
      finalClause.order = orderBy;
    }
    if (whereClause.linked) {
      delete whereClause.linked;
    }
    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return moduleModel.findAndCountAll(finalClause);
  };

  const getModule = async (moduleId, viewTree, usages) => {
    try {
      // Setting up the query options
      const queryOptions = {
        where: { id: moduleId },
        attributes: ['id', 'title', 'description', 'recordStatus', 'created_at'],
      };

      // If viewTree is true, add the include option
      if (viewTree) {
        queryOptions.include = [
          {
            model: topicModel,
            attributes: ['id', 'title', 'thumbnail', 'recordStatus', 'created_at'],
            through: {
              model: moduleTopicModel,
              attributes: ['id', 'order', 'recordStatus', 'createdAt'],
            },
          },
        ];
      }
      if (usages) {
        queryOptions.include = [
          {
            model: courseModel,
            attributes: ['id', 'title', 'description', 'slug', 'thumbnail', 'recordStatus', 'created_at'],
            through: {
              model: courseModuleModel,
              attributes: ['id', 'order', 'recordStatus', 'createdAt'],
            },
          },
        ];
      }

      // Execute the query with the conditional options
      return await moduleModel.findOne(queryOptions);
    } catch (error) {
      logger.error('Error in getModuleTree:', error);
      throw error;
    }
  };

  return {
    ...baseRepo,
    bulkCreate,
    getModules,
    getModule,
  };
});
