const { define } = require('src/containerHelper');

module.exports = define('courseFrequentlyAskedQuestionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('course_faq');
  const courseModuleModel = database['course_faq'];

  return {
    ...baseRepo,
  };
});
