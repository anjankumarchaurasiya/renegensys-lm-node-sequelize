const { define } = require('src/containerHelper');

module.exports = define('frequentlyAskedQuestionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('frequently_asked_question');

  const faqModel = database['frequently_asked_question'];
  const courseFaqModel = database['course_faq'];
  const courseModel = database['course'];
  const getAllFaq = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForCourse;
    let requiredValue = false;

    if (whereClause.course_id) {
      whereClauseForCourse = whereClause.course_id;
      requiredValue = true;
      delete whereClause.course_id;
    }
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      include: [
        {
          model: courseFaqModel,
          attributes: ['id', 'order'],
          where: whereClauseForCourse ? { courseId: whereClauseForCourse } : {},
          required: requiredValue,
          include: [
            {
              model: courseModel,
              as: 'course',
              attributes: ['id', 'title', 'description', 'recordStatus'],
            },
          ],
        },
      ],
    };
    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return faqModel.findAndCountAll(finalClause);
  };
  return {
    ...baseRepo,
    getAllFaq,
  };
});
