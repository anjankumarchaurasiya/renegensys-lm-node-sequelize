const { define } = require('src/containerHelper');

module.exports = define('courseModuleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('course_module');
  const courseModuleModel = database['course_module'];

  /** Bulk create */
  const bulkCreate = data =>
    courseModuleModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });
  /** Get single data by course id, order by desc, findone*/
  const getLastCourseModule = async courseId => {
    return courseModuleModel.findOne({
      where: courseId,
      order: [['order', 'DESC']],
    });
  };
  return {
    ...baseRepo,
    bulkCreate,
    getLastCourseModule,
  };
});
