'use strict';

module.exports = (sequelize, DataTypes) => {
  const CourseFaq = sequelize.define(
    'course_faq',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      courseId: {
        type: DataTypes.UUID,
      },
      faqId: {
        type: DataTypes.UUID,
      },
      order: {
        type: DataTypes.INTEGER,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
      },
      updatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  CourseFaq.associate = function(models) {
    CourseFaq.belongsTo(models.course, {
      foreignKey: 'courseId',
      sourceKey: 'id',
      allowNull: false,
    });
    CourseFaq.belongsTo(models.frequently_asked_question, {
      foreignKey: 'faqId',
      targetKey: 'id',
      allowNull: false,
    });
  };
  return CourseFaq;
};
