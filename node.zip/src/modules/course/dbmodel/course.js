'use strict';

module.exports = (sequelize, DataTypes) => {
  const Course = sequelize.define(
    'course',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
        unique: true,
      },
      description: {
        type: DataTypes.TEXT,
      },
      slug: {
        type: DataTypes.STRING,
      },
      thumbnail: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Course.associate = function(models) {
    Course.hasMany(models.course_module, {
      foreignKey: 'courseId',
      sourceKey: 'id',
    });
    Course.belongsToMany(models.module, {
      through: models.course_module,
      foreignKey: 'courseId',
      otherKey: 'moduleId',
    });
    Course.hasMany(models.learning_session, {
      foreignKey: 'courseId',
      sourceKey: 'id',
    });
  };

  return Course;
};
