'use strict';

module.exports = (sequelize, DataTypes) => {
  const Topic = sequelize.define(
    'topic',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
      },
      thumbnail: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
      },
      updatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Topic.associate = function(models) {
    Topic.belongsToMany(models.module, {
      through: models.module_topic,
      foreignKey: 'topicId',
      otherKey: 'moduleId',
    });
    Topic.hasMany(models.module_topic, {
      foreignKey: 'topicId',
      otherKey: 'id',
    });
    Topic.hasMany(models.topic_content, {
      foreignKey: 'topicId',
      otherKey: 'id',
    });
  };

  return Topic;
};
