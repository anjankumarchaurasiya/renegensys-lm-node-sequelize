'use strict';

module.exports = (sequelize, DataTypes) => {
  const Module = sequelize.define(
    'module',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
      },
      description: {
        type: DataTypes.TEXT,
      },
      slug: {
        type: DataTypes.STRING,
      },
      thumbnail: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Module.associate = function(models) {
    Module.belongsToMany(models.course, {
      through: models.course_module,
      foreignKey: 'moduleId',
      otherKey: 'courseId',
    });
    Module.hasMany(models.course_module, {
      foreignKey: 'moduleId',
      sourceKey: 'id',
    });
    Module.belongsToMany(models.topic, {
      through: models.module_topic,
      foreignKey: 'moduleId',
      otherKey: 'topicId',
    });
    Module.hasMany(models.module_topic, {
      foreignKey: 'moduleId',
      sourceKey: 'id',
    });
    Module.hasMany(models.course_module, {
      foreignKey: 'moduleId',
      sourceKey: 'id',
    });
    Module.belongsToMany(models.learning_session, {
      through: models.learning_session_module,
      foreignKey: 'moduleId',
      otherKey: 'learningSessionId',
    });
    Module.hasMany(models.learning_session_module, {
      foreignKey: 'moduleId',
      sourceKey: 'id',
    });
    Module.hasMany(models.learning_session_progress, {
      foreignKey: 'moduleId',
      sourceKey: 'id',
    });
  };

  return Module;
};
