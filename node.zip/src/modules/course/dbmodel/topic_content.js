'use strict';

module.exports = (sequelize, DataTypes) => {
  const TopicContent = sequelize.define(
    'topic_content',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      topicId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      contentId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      order: {
        type: DataTypes.INTEGER,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
      },
      updatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  TopicContent.associate = function(models) {
    TopicContent.belongsTo(models.topic, {
      foreignKey: 'topicId',
      sourceKey: 'id',
      allowNull: false,
    });
    TopicContent.belongsTo(models.content, {
      foreignKey: 'contentId',
      targetKey: 'id',
      allowNull: false,
    });
  };
  return TopicContent;
};
