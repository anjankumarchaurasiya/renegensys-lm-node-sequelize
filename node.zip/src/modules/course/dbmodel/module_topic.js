'use strict';

module.exports = (sequelize, DataTypes) => {
  const ModuleTopic = sequelize.define(
    'module_topic',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },

      moduleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      topicId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      order: {
        type: DataTypes.INTEGER,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
      },
      updatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
      underscored: true,
      underscoredAll: true,
      timestamps: true,
    }
  );

  ModuleTopic.associate = function(models) {
    ModuleTopic.belongsTo(models.module, {
      foreignKey: 'moduleId',
      sourceKey: 'id',
      allowNull: false,
    });
    ModuleTopic.belongsTo(models.topic, {
      foreignKey: 'topicId',
      targetKey: 'id',
      allowNull: false,
    });
  };
  return ModuleTopic;
};
