'use strict';
module.exports = (sequelize, DataTypes) => {
  const FrequentlyAskedQuestion = sequelize.define(
    'frequently_asked_question',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      question: {
        type: DataTypes.TEXT,
      },
      answer: {
        type: DataTypes.TEXT,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: DataTypes.DATE,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  FrequentlyAskedQuestion.associate = function(models) {
    FrequentlyAskedQuestion.hasMany(models.course_faq, {
      foreignKey: 'faqId',
      sourceKey: 'id',
    });
    FrequentlyAskedQuestion.belongsToMany(models.course, {
      through: models.course_faq,
      foreignKey: 'faqId',
      otherKey: 'courseId',
    });
  };
  return FrequentlyAskedQuestion;
};
