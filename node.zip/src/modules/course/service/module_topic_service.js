const { define } = require('src/containerHelper');
const { Op } = require('sequelize');

module.exports = define('moduleTopicService', ({ moduleTopicRepository, CustomError, constants: { ENTITY_ALREADY_EXISTS } }) => {
  const getModuleTopic = async whereClause => {
    return moduleTopicRepository.findAll(whereClause);
  };

  /** Module mapping with topic  */
  const createModuleTopic = async function(module_id, topics) {
    let newTopics = (topics = topics.map(entry => ({
      ...entry,
      module_id: module_id,
    })));
    const existingEntries = await moduleTopicRepository.findAll({
      [Op.or]: newTopics.map(({ topic_id, module_id }) => ({ topic_id, module_id })),
    });
    const findExistingModuleTopic = await moduleTopicRepository.getLastModuleTopic({ module_id });
    const lastOrder = findExistingModuleTopic?.order ? findExistingModuleTopic.order : 0;
    const existingPairs = existingEntries.map(({ topicId, moduleId }) => ({ topicId, moduleId }));
    let currentOrder = lastOrder;
    const topicsToBeAdded = newTopics
      .map(({ topic_id, order, module_id }) => ({
        topicId: topic_id,
        moduleId: module_id,
        order: ++currentOrder,
      }))
      .filter(({ topicId, moduleId }) => !existingPairs.find(pair => pair.topicId === topicId && pair.moduleId === moduleId));

    if (topicsToBeAdded.length > 0) {
      return moduleTopicRepository.bulkCreate(topicsToBeAdded);
    } else {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `No new data to add`);
    }
  };
  /** Update module mapping with topic */
  const updateModuleTopic = async function(module_id, unLinkedData, orderData) {
    let newUnLinked = (unLinkedData = unLinkedData.map(entry => ({
      ...entry,
      module_id: module_id,
    })));
    let newOrder = (orderData = orderData.map(entry => ({
      ...entry,
      module_id: module_id,
    })));
    if (newUnLinked && newUnLinked.length > 0) {
      const recordPromises = newUnLinked.map(async item => {
        const { topic_id, recordStatus, module_id } = item;
        const moduleTopicDetail = await moduleTopicRepository.findOne({ topic_id, module_id });
        if (moduleTopicDetail) {
          return moduleTopicRepository.update({ recordStatus: false, order: 0 }, { topic_id, module_id });
        } else {
          return null;
        }
      });
      await Promise.all(recordPromises.filter(Boolean));
    }

    if (newOrder && newOrder.length > 0) {
      const findExistingModuleTopic = await moduleTopicRepository.getLastModuleTopic({ module_id });
      let lastOrder = findExistingModuleTopic?.order ? findExistingModuleTopic.order : 0;
      let currentOrder = lastOrder;
      const orderPromises = newOrder.map(async (item, index) => {
        const { topic_id, order, module_id } = item;
        if (order == 0) {
          item.order = ++currentOrder;
        }
        const moduleTopicDetail = await moduleTopicRepository.findOne({ topic_id, module_id });
        if (moduleTopicDetail) {
          return moduleTopicRepository.update({ order: item.order, recordStatus: true }, { topic_id, module_id });
        } else {
          return null;
        }
      });
      await Promise.all(orderPromises.filter(Boolean));
    }
  };

  const bulkCreateModuleTopic = moduleTopics => moduleTopicRepository.bulkCreate(moduleTopics);

  return {
    getModuleTopic,
    createModuleTopic,
    updateModuleTopic,
    bulkCreateModuleTopic,
  };
});
