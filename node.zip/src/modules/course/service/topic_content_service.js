const { define } = require('src/containerHelper');
module.exports = define('topicContentService', ({ topicContentRepository }) => {
  const getTopicContent = async whereClause => {
    return topicContentRepository.findAll(whereClause);
  };

  const bulkCreateTopicContent = topicContents => topicContentRepository.bulkCreate(topicContents);

  return {
    getTopicContent,
    bulkCreateTopicContent,
  };
});
