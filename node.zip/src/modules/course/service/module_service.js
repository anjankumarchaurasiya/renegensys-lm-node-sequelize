const { define } = require('src/containerHelper');
const searchFilters = require('../constants/module_search_filter_constants');
//const sequelize = require('src/infra/sequelize');

module.exports = define('moduleService', ({
  moduleRepository,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND },
  commonUtilService,
  generalUtilService,
  courseModuleRepository,
  moduleTopicRepository,
  logger,

  transactionDecorator: { transaction },
}) => {
  const createModule = async moduleData => {
    const { title } = moduleData;
    const isModuleExist = await moduleRepository.findOne({ title: title });

    if (isModuleExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Module  already exists with Title`);
    }

    const slug = commonUtilService.toLsUnderScore(title);

    moduleData.slug = slug;
    moduleData.recordStatus = false;
    await moduleRepository.create(moduleData);
  };

  const updateModule = async moduleData => {
    const { id, title } = moduleData;

    const isModuleExist = await moduleRepository.findOne({ id: id });

    if (!isModuleExist) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Module not found');
    }

    if (title) {
      const havingSameTitle = await moduleRepository.findOne({ title: title });
      if (havingSameTitle) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Module  already exists with same Title`);
      }
      const slug = commonUtilService.toLsUnderScore(title);
      moduleData.slug = slug;
    }

    await moduleRepository.update(moduleData, { id: id });
  };

  const getModule = async (moduleId, queryParams) => {
    const parsedparams = generalUtilService.parseQueryParam(queryParams);
    const moduleTreeDetail = await moduleRepository.getModule(moduleId, parsedparams.viewTree, parsedparams.usages);
    if (moduleTreeDetail) {
      return moduleTreeDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Module not found `);
    }
  };

  const deactivateModuleById = async moduleId => {
    try {
      await transaction(async () => {
        await moduleRepository.deactivate({ id: moduleId });
        await courseModuleRepository.deactivate({ moduleId: moduleId });
        await moduleTopicRepository.deactivate({ moduleId: moduleId });
      })();
    } catch (error) {
      logger.error('Error while decativation of module ,course_module and module_topic', error);
    }
  };

  const deactivateBulk = async body => {
    try {
      const { moduleIds } = body;
      const successfulDeactivations = [];
      const unsuccessfulDeactivations = [];

      await Promise.all(
        moduleIds.map(async moduleId => {
          const moduleDetail = await moduleRepository.findOne({ id: moduleId });
          if (!moduleDetail) {
            unsuccessfulDeactivations.push(moduleId);
            return null;
          }
          successfulDeactivations.push(moduleId);
          await transaction(async () => {
            await courseModuleRepository.deactivate({ moduleId: moduleId });
            await moduleTopicRepository.deactivate({ moduleId: moduleId });
            await moduleRepository.deactivate({ id: moduleId });
          })();
        })
      );

      return {
        successfulDeactivations,
        unsuccessfulDeactivations,
      };
    } catch (error) {
      logger.error('Error while decativation of module ,course_module and module_topic', error);
    }
  };

  const getModuleList = async queryParams => {
    let moduleListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.module);
      moduleListResponse = await moduleRepository.getModules(
        ['id', 'title', 'description', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.module);
      moduleListResponse = await moduleRepository.getModules(['id', 'title', 'description', 'created_at', 'recordStatus'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }

    return { count: moduleListResponse.count, module: moduleListResponse.rows };
  };

  const bulkCreateModules = modules => moduleRepository.bulkCreate(modules);

  const bulkActivateModule = async moduleIds => {
    const succesfullActivations = [];
    const unsuccesfullActivations = [];

    await Promise.all(
      moduleIds.map(async moduleId => {
        const moduleDetail = await moduleRepository.findOne({ id: moduleId });
        if (!moduleDetail) {
          unsuccesfullActivations.push(moduleId);
          return null;
        }
        succesfullActivations.push(moduleId);
        return moduleRepository.update({ recordStatus: 1 }, { id: moduleId });
      })
    );

    return {
      succesfullActivations,
      unsuccesfullActivations,
    };
  };
  return {
    createModule,
    updateModule,
    getModule,
    deactivateModuleById,
    deactivateBulk,
    getModuleList,
    bulkCreateModules,
    bulkActivateModule,
  };
});
