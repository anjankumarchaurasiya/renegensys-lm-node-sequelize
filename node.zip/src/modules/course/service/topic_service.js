const { define } = require('src/containerHelper');
const searchFilters = require('../constants/topic_search_filter_constants');

module.exports = define('topicService', ({
  topicRepository,
  topicContentRepository,
  contentRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST },
  moduleTopicRepository,
  transactionDecorator: { transaction },
}) => {
  /** Create topic */
  const createTopic = async topicData => {
    const { title } = topicData;
    const isTopicExist = await topicRepository.findOne({ title: title });
    if (isTopicExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Topic already exists with Title`);
    }
    const topic = await topicRepository.create(topicData);
    if (topic) {
      const topicId = topic.dataValues.id;
      const resourcesArray = topicData.resources;
      const modifiedResourcesArray = resourcesArray.map(contentId => ({
        contentId,
        topicId,
      }));
      await topicContentRepository.bulkCreate(modifiedResourcesArray);
    }
    return topic;
  };

  /** Get topic list */
  const getTopicList = async queryParams => {
    let topicListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.topic);
      topicListResponse = await topicRepository.getTopicsWithContent(
        ['id', 'title', 'thumbnail', 'recordStatus', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.topic);
      topicListResponse = await topicRepository.getTopicsWithContent(['id', 'title', 'thumbnail', 'recordStatus', 'created_at'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }
    return { count: topicListResponse.count, topic: topicListResponse.rows };
  };

  /** Update topic list */
  const updateTopic = async topicData => {
    const { title, thumbnail, recordStatus } = topicData;
    const topic = await topicRepository.findOne({ id: topicData.id });
    if (!topic) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Topic not found');
    }
    if (title) {
      const isNameExist = await topicRepository.findOne({ title: title });
      if (isNameExist && isNameExist.id !== topicData.id) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status.status, 'Topic already exists');
      }
    }
    const updateData = {
      title,
      thumbnail,
      ...(recordStatus !== undefined && { recordStatus }),
    };
    await topicRepository.update(updateData, { id: topicData.id });
    if (topic) {
      const topicId = topicData.id;
      const resourcesArray = topicData.addResources;
      const removeResourcesArray = topicData.removeResources;

      /** create new content */
      if (resourcesArray && resourcesArray.length > 0) {
        const modifiedResourcesArray = resourcesArray.map(contentId => ({
          contentId,
          topicId,
        }));
        await topicContentRepository.bulkCreate(modifiedResourcesArray);
      }
      /** remove previous content */
      if (removeResourcesArray && removeResourcesArray.length > 0) {
        /** deactivate topic content based on content & topi id */
        const recordPromisesTopicContent = removeResourcesArray.map(async contentId => {
          const topicContentDetail = await topicContentRepository.findOne({ contentId, topicId });
          if (topicContentDetail) {
            return topicContentRepository.update({ recordStatus: 0 }, { contentId, contentId });
          } else {
            return null;
          }
        });
        await Promise.all(recordPromisesTopicContent.filter(Boolean));

        /** deactivate content which by contentid */
        const recordPromisesContent = removeResourcesArray.map(async contentId => {
          const topicContentDetail = await contentRepository.findOne({ id: contentId });
          if (topicContentDetail) {
            return contentRepository.update({ recordStatus: 0 }, { id: contentId });
          } else {
            return null;
          }
        });
        await Promise.all(recordPromisesContent.filter(Boolean));
      }
    }
  };

  /** Get specific topic by id */
  const getTopicById = async (topicId, queryParams) => {
    try {
      const parsedParams = generalUtilService.parseQueryParam(queryParams);
      const moduleTopicResponse = await topicRepository.getTopic({ id: topicId }, parsedParams.usages);
      return moduleTopicResponse;
    } catch (error) {
      logger.error('Error fetching module data with topics:', error);
      throw error;
    }
  };
  /** Bulk deactivate */
  const deactivateBulk = async body => {
    try {
      const { topicIds } = body;
      const succesfullDeactivations = [];
      const unsuccesfullDeactivations = [];

      await Promise.all(
        topicIds.map(async topicId => {
          const topicDetail = await topicRepository.findOne({ id: topicId });
          if (!topicDetail) {
            unsuccesfullDeactivations.push(topicId);
            return null;
          }
          succesfullDeactivations.push(topicId);
          await transaction(async () => {
            await moduleTopicRepository.deactivate({ topicId: topicId });
            await topicRepository.deactivate({ id: topicId });
          })();
        })
      );

      return {
        succesfullDeactivations,
        unsuccesfullDeactivations,
      };
    } catch (error) {
      logger.error('Error While deactivation topic and module topic', error);
    }
  };

  /** single topic deactivtae */
  const deactivateTopicById = async topicId => {
    try {
      await transaction(async () => {
        await moduleTopicRepository.deactivate({ topicId: topicId });
        await topicRepository.deactivate({ id: topicId });
      })();
    } catch (error) {
      logger.error('Error While deactivation topic and module topic', error);
    }
  };

  const bulkCreateTopics = topics => topicRepository.bulkCreate(topics);

  const bulkActivateTopic = async topicIds => {
    const succesfullActivations = [];
    const unsuccesfullActivations = [];

    await Promise.all(
      topicIds.map(async topicId => {
        const topicDetail = await topicRepository.findOne({ id: topicId });
        if (!topicDetail) {
          unsuccesfullActivations.push(topicId);
          return null;
        }
        succesfullActivations.push(topicId);
        return topicRepository.update({ recordStatus: 1 }, { id: topicId });
      })
    );

    return {
      succesfullActivations,
      unsuccesfullActivations,
    };
  };

  return {
    createTopic,
    getTopicList,
    updateTopic,
    getTopicById,
    deactivateBulk,
    deactivateTopicById,
    bulkCreateTopics,
    bulkActivateTopic,
  };
});
