const { define } = require('src/containerHelper');
const { Op } = require('sequelize');

module.exports = define('courseModuleService', ({ courseModuleRepository, CustomError, constants: { ENTITY_ALREADY_EXISTS } }) => {
  const getCourseModule = async whereClause => {
    return courseModuleRepository.findAll(whereClause);
  };

  /** Course mapping with module  */
  const createCourseModule = async function(course_id, modules) {
    let newModules = (modules = modules.map(entry => ({
      ...entry,
      course_id: course_id,
    })));
    const existingEntries = await courseModuleRepository.findAll({
      [Op.or]: newModules.map(({ module_id, course_id }) => ({ module_id, course_id })),
    });
    const findExistingCourse = await courseModuleRepository.getLastCourseModule({ course_id });
    const lastOrder = findExistingCourse?.order ? findExistingCourse.order : 0;
    const existingPairs = existingEntries.map(({ courseId, moduleId }) => ({ courseId, moduleId }));
    let currentOrder = lastOrder;
    const modulesToBeAdded = newModules
      .map(({ module_id, order, course_id }) => ({
        moduleId: module_id,
        courseId: course_id,
        order: ++currentOrder,
      }))
      .filter(({ moduleId, courseId }) => !existingPairs.find(pair => pair.moduleId === moduleId && pair.courseId === courseId));

    if (modulesToBeAdded.length > 0) {
      return courseModuleRepository.bulkCreate(modulesToBeAdded);
    } else {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `No new data to add`);
    }
  };
  /** Update course mapping with module*/
  const updateCourseModule = async function(course_id, unLinkedData, orderData) {
    let newUnLinked = (unLinkedData = unLinkedData.map(entry => ({
      ...entry,
      course_id: course_id,
    })));
    let newOrder = (orderData = orderData.map(entry => ({
      ...entry,
      course_id: course_id,
    })));
    if (newUnLinked && newUnLinked.length > 0) {
      const recordPromises = newUnLinked.map(async item => {
        const { module_id, recordStatus, course_id } = item;
        const courseModuleDetail = await courseModuleRepository.findOne({ module_id, course_id });
        if (courseModuleDetail) {
          const dataupdate = await courseModuleRepository.update({ recordStatus: false, order: 0 }, { module_id, course_id });
          return dataupdate;
        } else {
          return null;
        }
      });
      await Promise.all(recordPromises.filter(Boolean));
    }
    if (newOrder && newOrder.length > 0) {
      const findExistingCourse = await courseModuleRepository.getLastCourseModule({ course_id });
      let lastOrder = findExistingCourse?.order ? findExistingCourse.order : 0;
      let currentOrder = lastOrder;
      const orderPromises = newOrder.map(async item => {
        const { module_id, order, course_id } = item;
        if (order == 0) {
          item.order = ++currentOrder;
        }
        const courseModuleDetail = await courseModuleRepository.findOne({ module_id, course_id });
        if (courseModuleDetail) {
          return courseModuleRepository.update({ order: item.order, recordStatus: true }, { module_id, course_id });
        } else {
          return null;
        }
      });
      await Promise.all(orderPromises.filter(Boolean));
    }
  };

  const bulkCreateCourseModule = courseModules => courseModuleRepository.bulkCreate(courseModules);
  return {
    getCourseModule,
    createCourseModule,
    updateCourseModule,
    bulkCreateCourseModule,
  };
});
