const { define } = require('src/containerHelper');

const searchFilters = require('../constants/course_faq_filter_constants');

module.exports = define('frequentlyAskedQuestionService', ({
  frequentlyAskedQuestionRepository,
  courseRepository,
  courseFrequentlyAskedQuestionRepository,

  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND },
  generalUtilService,
}) => {
  const createFaq = async (courseId, faqData) => {
    const { order } = faqData;
    const isCourseExist = await courseRepository.findOne({ id: courseId });

    if (!isCourseExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Course not found `);
    }

    const faqExistWithSameOrder = await courseFrequentlyAskedQuestionRepository.findBy(['order'], { courseId: courseId, order: order });

    if (faqExistWithSameOrder) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `FAQ already exists with same course and order `);
    }

    const faq = await frequentlyAskedQuestionRepository.create(faqData);
    const course_faqData = { courseId: courseId, faqId: faq.id, order: order };
    await courseFrequentlyAskedQuestionRepository.create(course_faqData);
  };

  const updateFaq = async (courseId, faqId, faqData) => {
    const isCourseExist = await courseRepository.findOne({ id: courseId });
    if (!isCourseExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Course not found `);
    }

    const isFaqExist = await courseFrequentlyAskedQuestionRepository.findBy({ faqId: faqId });
    if (!isFaqExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `FAQ not found `);
    }

    await frequentlyAskedQuestionRepository.update(faqData, { id: faqId });
    if (faqData?.order) {
      const course_Faq = await courseFrequentlyAskedQuestionRepository.findBy({ courseId: courseId, faqId: faqId });
      await courseFrequentlyAskedQuestionRepository.update(faqData, { id: course_Faq.id });
    }
  };

  const deactivateFaq = async (courseId, faqId, faqData) => {
    const isCourseExist = await courseRepository.findOne({ id: courseId });
    if (!isCourseExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Course not found `);
    }

    const isFaqExist = await courseFrequentlyAskedQuestionRepository.findBy({ faqId: faqId });
    if (!isFaqExist) {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `FAQ not found `);
    }

    await frequentlyAskedQuestionRepository.findAndDeactivate({ id: faqId });
    const course_Faq = await courseFrequentlyAskedQuestionRepository.findBy({ courseId: courseId, faqId: faqId });

    await courseFrequentlyAskedQuestionRepository.findAndDeactivate({ id: course_Faq.id });
  };

  const getFaqList = async (courseId, queryParams) => {
    let faqListResponse;
    queryParams.courseId = courseId;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.course);
      faqListResponse = await frequentlyAskedQuestionRepository.getAllFaq(
        ['id', 'question', 'answer', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.course);
      faqListResponse = await frequentlyAskedQuestionRepository.getAllFaq(['id', 'question', 'answer', 'created_at', 'recordStatus'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }

    return { count: faqListResponse.count, frequentlyAskedQuestion: faqListResponse.rows };
  };
  return {
    createFaq,
    updateFaq,
    deactivateFaq,
    getFaqList,
  };
});
