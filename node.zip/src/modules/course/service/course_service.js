const { define } = require('src/containerHelper');
const searchFilters = require('../constants/course_search_filter_constants');

module.exports = define('courseService', ({
  courseRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
  courseModuleRepository,
  transactionDecorator: { transaction },
}) => {
  const createCourse = async courseData => {
    const { title } = courseData;
    const isCourseExist = await courseRepository.findOne({ title: title });
    if (isCourseExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Course already exists with Title`);
    }
    const slug = commonUtilService.toLsUnderScore(title);
    courseData.slug = slug;
    const course = await courseRepository.create(courseData);
    return course;
  };

  const updateCourse = async courseData => {
    const { title } = courseData;
    const course = await courseRepository.findOne({ id: courseData.id });
    if (!course) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Course not found');
    }
    if (title) {
      // Check if title already exists
      const slug = commonUtilService.toLsUnderScore(title);
      courseData.slug = slug;
      const isTitleExist = await courseRepository.findOne({ title: title });
      if (isTitleExist && isTitleExist.id !== courseData.id) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status.status, 'Course already exists');
      }
    }

    await courseRepository.update(courseData, { id: courseData.id });
  };

  const getCourse = async (courseId, queryParams) => {
    const parsedParams = generalUtilService.parseQueryParam(queryParams);
    const courseTreeDetail = await courseRepository.getCourse(courseId, parsedParams);
    if (courseTreeDetail) {
      return courseTreeDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Course not found `);
    }
  };

  const deactivateCourse = async whereClause => {
    try {
      await transaction(async () => {
        await courseRepository.deactivate(whereClause);
        await courseModuleRepository.deactivate({ course_id: whereClause.id });
      })();
    } catch (error) {
      logger.error('Error while deactivation course and course module', error);
    }
  };

  const bulkDeactivateCourse = async body => {
    try {
      const { courseIds } = body;
      const succesfullDeactivations = [];
      const unsuccesfullDeactivations = [];

      await Promise.all(
        courseIds.map(async courseId => {
          const courseDetail = await courseRepository.findOne({ id: courseId });
          if (!courseDetail) {
            unsuccesfullDeactivations.push(courseId);
            return null;
          }
          succesfullDeactivations.push(courseId);
          await transaction(async () => {
            await courseModuleRepository.deactivate({ courseId: courseId });
            await courseRepository.deactivate({ id: courseId });
          })();
        })
      );

      return {
        succesfullDeactivations,
        unsuccesfullDeactivations,
      };
    } catch (error) {
      logger.error('Error while deactivation course and course module', error);
    }
  };

  const getCourseList = async queryParams => {
    let courseListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.course);
      courseListResponse = await courseRepository.getCourses(
        ['id', 'title', 'description', 'thumbnail', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.course);
      courseListResponse = await courseRepository.getCourses(['id', 'title', 'description', 'thumbnail', 'created_at', 'recordStatus'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }

    return { count: courseListResponse.count, course: courseListResponse.rows };
  };

  const bulkCreateCourses = courses => courseRepository.bulkCreate(courses);

  const bulkActivateCourse = async courseIds => {
    const succesfullActivations = [];
    const unsuccesfullActivations = [];

    await Promise.all(
      courseIds.map(async courseId => {
        const courseDetail = await courseRepository.findOne({ id: courseId });
        if (!courseDetail) {
          unsuccesfullActivations.push(courseId);
          return null;
        }
        succesfullActivations.push(courseId);
        return courseRepository.update({ recordStatus: 1 }, { id: courseId });
      })
    );

    return {
      succesfullActivations,
      unsuccesfullActivations,
    };
  };

  return {
    createCourse,
    getCourseList,
    updateCourse,
    deactivateCourse,
    bulkDeactivateCourse,
    getCourse,
    bulkCreateCourses,
    bulkActivateCourse,
  };
});
