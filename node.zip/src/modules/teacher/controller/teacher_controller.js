const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');

const {
  LEARNING_SESSION_START,
  LEARNING_SESSION_COMPLETED,
  SESSION_STATUS_TYPE,
  CAPSTONE_SUBMITED_SUCCESSFULLY,
  SPAM_REPORT_CREATED_SUCCSSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
    logger,
  } = container.cradle;
  const { authorizeMiddleware, teacherService } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  // to get list of session and all session info module-> topic-> resources by batchid, quiz info based on teacher id
  router.get('/session/:batchId', async (req, res, next) => {
    try {
      const {
        params: { batchId },
      } = req;
      const userId = req.user.id;
      let learningSessionList = await teacherService.getLearningSessionByBatchIdForTeacher(batchId, userId);
      let { preSessionResult, postSessionResult, capstoneId } = await teacherService.getSessionQuizByBatchIdForTeacher(batchId, userId);
      res.status(Status.OK).json(await Success({ learningSessionList, preSessionResult, postSessionResult, capstoneId }));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:teacherId/batches', async (req, res, next) => {
    try {
      const {
        params: { teacherId },
      } = req;
      const { query } = req;
      const batchList = await teacherService.getAllBatchOfTeacher(teacherId, query);
      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:teacherId/courses', async (req, res, next) => {
    try {
      const {
        params: { teacherId },
      } = req;
      const { query } = req;
      const batchList = await teacherService.getAllCoursesOfTeacher(teacherId, query);
      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:teacherId/sessions', async (req, res, next) => {
    try {
      const {
        params: { teacherId },
      } = req;
      const { query } = req;
      const batchList = await teacherService.getAllSessionsOfTeacher(teacherId, query);
      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/session-list/:sessionId', async (req, res, next) => {
    try {
      const {
        params: { sessionId },
      } = req;
      const userId = req.user.id;
      let learningSessionList = await teacherService.getSessionListForTeacherByTeacherIdSessionId(sessionId, userId);

      res.status(Status.OK).json(await Success(learningSessionList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/session-details/:sessionId', async (req, res, next) => {
    try {
      const {
        params: { sessionId },
      } = req;
      let learningSession = await teacherService.getLearningSessionForTeacher(sessionId);
      res.status(Status.OK).json(await Success({ learningSession }));
    } catch (e) {
      next(e);
    }
  });

  /** Get Quiz Result of a Session */
  router.get('/session/result/:sessonId/:quizId', async (req, res, next) => {
    try {
      const { query } = req;
      const {
        params: { sessonId, quizId },
      } = req;
      query.sessonId = sessonId;
      query.quizId = quizId;
      const batchList = await teacherService.getAllQuizResult(query);
      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/student-quiz-report/:quizId/:studentId', async (req, res, next) => {
    try {
      const {
        params: { quizId, studentId },
        query: { reportType },
      } = req;
      let learningSession = await teacherService.getStudentResponseReport(quizId, studentId, reportType);

      res.status(Status.OK).json(await Success({ learningSession }));
    } catch (e) {
      next(e);
    }
  });

  router.get('/capstone/result/:quizId/:batchId', async (req, res, next) => {
    try {
      const {
        params: { quizId, batchId },
        query,
      } = req;
      const { user } = req;
      query.quizId = quizId;
      query.batchId = batchId;
      const result = await teacherService.getAllCapstoneResult(query);
      res.status(Status.OK).json(await Success(result));
    } catch (e) {
      next(e);
    }
  });
  router.get('/capstone/capstone-list/:status', async (req, res, next) => {
    try {
      const {
        params: { status },
        query,
      } = req;
      const primaryFacultyId = req.user.id;

      const result = await teacherService.getAllCapstoneList(primaryFacultyId, status);
      res.status(Status.OK).json(await Success(result));
    } catch (e) {
      next(e);
    }
  });
  // submit capstone from teacher
  router.post('/submit-capstone', async (req, res, next) => {
    try {
      const { user } = req;
      const { capstoneResponse, quizId, quizProgressId } = req.body;
      const userId = user.id;
      logger.info('Submit capstone response from teacher');
      let data = await teacherService.submitCapstone(userId, capstoneResponse, quizId, quizProgressId);
      res.status(Status.OK).json(await Success(data, CAPSTONE_SUBMITED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.patch('/session/:sessionId', async (req, res, next) => {
    try {
      const {
        params: { sessionId },
        body: { status },
      } = req;
      await teacherService.updateLearningSessionStatus(sessionId, status);
      let data;
      const msg = status === SESSION_STATUS_TYPE.INPROGRESS ? LEARNING_SESSION_START : LEARNING_SESSION_COMPLETED;
      res.status(Status.OK).json(await Success(data, msg));
    } catch (e) {
      next(e);
    }
  });

  // submit student spam report by teacher
  router.post('/spam-report', async (req, res, next) => {
    try {
      const { user } = req;
      const { learningSessionId, studentId, spamReason, warningGiven } = req.body;
      const reportedBy = user.id;
      const userId = studentId;
      logger.info('Submit spam report from teacher');
      let data = await teacherService.submitSpamReport(learningSessionId, userId, spamReason, warningGiven, reportedBy);
      res.status(Status.OK).json(await Success(data, SPAM_REPORT_CREATED_SUCCSSFULLY));
    } catch (e) {
      next(e);
    }
  });

  // submit student spam report by teacher
  router.post('/spam-report', async (req, res, next) => {
    try {
      const { user } = req;
      const { learningSessionId, studentId, spamReason, warningGiven } = req.body;
      const reportedBy = user.id;
      const userId = studentId;
      logger.info('Submit spam report from teacher');
      let data = await teacherService.submitSpamReport(learningSessionId, userId, spamReason, warningGiven, reportedBy);
      res.status(Status.OK).json(await Success(data, SPAM_REPORT_CREATED_SUCCSSFULLY));
    } catch (e) {
      next(e);
    }
  });
  // get capstone by userQuizProgressId for review
  router.get('/capstone/review/:userQuizProgressId', async (req, res, next) => {
    try {
      const {
        params: { userQuizProgressId },
        user,
      } = req;
      const teacherId = user.id;
      const details = await teacherService.getCapstoneForReview(userQuizProgressId, teacherId);
      res.status(Status.OK).json(await Success(details));
    } catch (e) {
      next(e);
    }
  });

  router.get('/getParticipants/:batchId', async (req, res, next) => {
    try {
      const {
        params: { batchId },
      } = req;
      const userList = await teacherService.getAllParticipants(batchId);
      res.status(Status.OK).json(await Success(userList));
    } catch (e) {
      next(e);
    }
  });

  router.get('/getAttendees/:sessionId', async (req, res, next) => {
    try {
      const {
        params: { sessionId },
      } = req;
      const userList = await teacherService.getAllAttendees(sessionId);
      res.status(Status.OK).json(await Success(userList));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
