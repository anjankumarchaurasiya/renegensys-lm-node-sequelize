const { define } = require('src/containerHelper');
const { Sequelize, Op } = require('sequelize');
module.exports = define('teacherRepository', ({ database, baseRepositoryV2, logger, constants: { ASSESMENT_STATUS } }) => {
  const baseRepo = baseRepositoryV2('student');
  const courseModel = database['course'];
  const batchModel = database['batch'];
  const learningSessionModel = database['learning_session'];
  const learningSessionModuleModel = database['learning_session_module'];
  const topicModel = database['topic'];
  const moduleModel = database['module'];
  const topicContentModel = database['topic_content'];
  const contentModel = database['content'];
  const learningSessionContentModel = database['learning_session_content'];
  const moduleTopicModel = database['module_topic'];
  const learningSessionQuizModel = database['learning_session_quiz'];
  const quizModel = database['quiz'];
  const userModel = database['user'];
  const userQuizProgressModel = database['user_quiz_progress'];
  const userResponseModel = database['user_response'];
  const questionModel = database['question'];
  const questionOptionModel = database['question_option'];
  const batchQuizModel = database['batch_quiz'];
  const quizQuestionModel = database['quiz_question'];
  const questionContentModel = database['question_content'];
  const userResponseContentModel = database['user_response_content'];
  const batchUserModel = database['batch_user'];
  const userProfileModel = database['user_profile'];
  const learningSessionAttendanceModel = database['learning_session_attendance'];

  const getLearningSessionByBatchIdForTeacher = async (batchId, userId) => {
    try {
      return learningSessionModel.findAll({
        where: { batchId, primaryFacultyId: userId, recordStatus: true },
        attributes: ['id', 'title', 'batchId', 'status', 'recordStatus'],
        include: [
          {
            model: learningSessionModuleModel,
            attributes: ['id'],
            include: [
              {
                model: moduleModel,
                attributes: ['title'],
                include: [
                  {
                    model: topicModel,
                    attributes: ['id', 'title', 'thumbnail'],
                    through: {
                      model: moduleTopicModel,
                      attributes: ['id', 'order', 'recordStatus', 'createdAt'],
                    },
                    include: [
                      {
                        model: topicContentModel,
                        attributes: ['id'],
                        where: { recordStatus: true },
                        include: [
                          {
                            model: contentModel,
                            attributes: ['title', 'url', 'slug', 'type', 'description'],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            model: learningSessionContentModel,
            attributes: ['id', 'type'],
            where: { recordStatus: true },
            required: false,
            include: [
              {
                model: contentModel,
                attributes: ['title', 'url', 'slug', 'type', 'description'],
              },
            ],
          },
        ],
      });
    } catch (error) {
      logger.error('Error in get session of Specific batch :', error);
      throw error;
    }
  };
  const getSessionQuizByBatchIdForTeacher = async (batchId, categoryId, userId) => {
    try {
      const learningSession = await learningSessionModel.findAll({
        where: { batchId, primaryFacultyId: userId, recordStatus: true },
        attributes: ['id', 'title', 'batchId', 'recordStatus'],
        include: [
          {
            model: learningSessionQuizModel,
            where: { recordStatus: true },
            attributes: ['id'],
            include: [
              {
                model: quizModel,
                where: { recordStatus: true, categoryId: categoryId },
                attributes: ['id', 'title', 'categoryId'],
              },
            ],
          },
        ],
      });
      return learningSession;
    } catch (error) {
      logger.error('Error in get quiz of Specific batch :', error);
      throw error;
    }
  };

  const getCourses = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForTeacher = {};

    if (whereClause?.teacher_id) {
      whereClauseForTeacher.primaryFacultyId = whereClause.teacher_id;
      delete whereClause.teacher_id;
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: learningSessionModel,
          where: whereClauseForTeacher,
          attributes: ['id', 'title', 'primaryFacultyId'],
          include: [
            {
              model: batchModel,
              attributes: ['id', 'startDate'],
            },
          ],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    const result = await courseModel.findAndCountAll(finalClause);
    result.rows = result.rows.map(course => {
      const startDate = course.learning_sessions.length > 0 ? course.learning_sessions[0].batch.startDate : null;
      delete course.dataValues.learning_sessions;
      return {
        ...course.toJSON(),
        startDate: startDate,
      };
    });
    return result;
  };

  const getBatches = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForTeacher = {};

    if (whereClause?.teacher_id) {
      whereClauseForTeacher.primaryFacultyId = whereClause.teacher_id;
      delete whereClause.teacher_id;
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: learningSessionModel,
          where: whereClauseForTeacher,
          attributes: ['id', 'title', 'primaryFacultyId', 'secondaryFacultyId'],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    const result = await batchModel.findAndCountAll(finalClause);

    result.rows = result.rows.map(batch => {
      const noOfSessions = batch.learning_sessions.length;
      delete batch.dataValues.learning_sessions;
      return {
        ...batch.toJSON(),
        noOfSessions: noOfSessions,
      };
    });
    return result;
  };

  const getLearningSessions = async (attributes, whereClause, orderBy, limit, offset) => {
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: learningSessionModuleModel,
          attributes: ['id'],
          include: [
            {
              model: moduleModel,
              attributes: ['id', 'title'],
            },
          ],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    const result = await learningSessionModel.findAndCountAll(finalClause);

    result.rows = result.rows.map(session => ({
      ...session.toJSON(),
      noOfModules: session.learning_session_modules ? session.learning_session_modules.length : 0,
    }));
    return result;
  };

  const getSessionListForTeacherByTeacherIdSessionId = async (sessionId, teacherId) => {
    try {
      return learningSessionModel.findAll({
        where: { id: sessionId, primaryFacultyId: teacherId, recordStatus: true },
        attributes: ['id', 'status', 'title', 'batchId', 'recordStatus'],
        include: [
          {
            model: learningSessionModuleModel,
            attributes: ['id'],
            include: [
              {
                model: moduleModel,
                attributes: ['id', 'title'],
                include: [
                  {
                    model: topicModel,
                    attributes: ['id', 'title', 'thumbnail'],
                    through: {
                      model: moduleTopicModel,
                      attributes: ['id', 'order', 'recordStatus', 'createdAt'],
                    },
                    include: [
                      {
                        model: topicContentModel,
                        attributes: ['id'],
                        where: { recordStatus: true },
                        include: [
                          {
                            model: contentModel,
                            attributes: ['title', 'url', 'slug', 'type', 'description'],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          // {
          //   model: learningSessionContentModel,
          //   attributes: ['id', 'type'],
          //   where: { recordStatus: true },
          //   required: false,
          //   include: [
          //     {
          //       model: contentModel,
          //       attributes: ['title', 'url', 'slug', 'type', 'description'],
          //     },
          //   ],
          // },
        ],
      });
    } catch (error) {
      logger.error('Error in get session of Specific batch :', error);
      throw error;
    }
  };

  const getLearningSessionById = async learningSessionId => {
    try {
      const queryOptions = {
        where: { id: learningSessionId },
        attributes: ['id', 'title', 'status', 'reason'],
        include: [
          {
            model: userModel,
            as: 'PrimaryFaculty',
            attributes: ['firstName', 'lastName'],
          },
          {
            model: userModel,
            as: 'SecondaryFaculty',
            attributes: ['firstName', 'lastName'],
          },
          {
            model: userModel,
            as: 'SRM',
            attributes: ['firstName', 'lastName'],
          },
          {
            model: learningSessionContentModel,
            attributes: ['id', 'type'],
            include: [
              {
                model: contentModel,
                attributes: ['title'],
              },
            ],
          },
        ],
      };

      return await learningSessionModel.findOne(queryOptions);
    } catch (error) {
      logger.error('Error in getCourseTree:', error);
      throw error;
    }
  };

  const getQuizResult = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForUser = {};
    let whereClauseForSession = {};

    if (whereClause?.learning_session_id) {
      whereClauseForSession.learning_session_id = whereClause.learning_session_id;
      delete whereClause.learning_session_id;
    }

    if (whereClause?.name) {
      whereClauseForUser = {
        [Op.or]: [{ firstName: whereClause.name }, { lastName: whereClause.name }],
      };
      delete whereClause.name;
    }

    if (whereClause?.dregNo) {
      whereClauseForUser.dregNo = whereClause.dregNo;
      delete whereClause.dregNo;
    }

    const subquery = `(SELECT user_quiz_progress.user_id, MAX(user_quiz_progress.attempt_no) AS maxAttemptNo FROM user_quiz_progress GROUP BY user_quiz_progress.user_id)`;
    const maxPercentage = `(SELECT MAX(percentage) FROM user_quiz_progress WHERE user_quiz_progress.user_id = user.id)`;
    const maxEarnPoint = `(SELECT earn_point FROM user_quiz_progress WHERE user_quiz_progress.user_id = user.id AND percentage = (${maxPercentage}) LIMIT 1)`;
    const maxTotalPoint = `(SELECT total_point FROM user_quiz_progress WHERE user_quiz_progress.user_id = user.id AND percentage = (${maxPercentage}) LIMIT 1)`;

    const finalClause = {
      order: orderBy,
      attributes: [
        ...attributes,
        [Sequelize.literal(maxPercentage), 'maxPercentage'],
        [Sequelize.literal(maxEarnPoint), 'maxEarnPoint'],
        [Sequelize.literal(maxTotalPoint), 'maxTotalPoint'],
      ],
      where: {
        [Op.and]: [Sequelize.literal(`(user_quiz_progress.user_id, user_quiz_progress.attempt_no) IN ${subquery}`), whereClause],
      },
      distinct: true,
      include: [
        {
          model: quizModel,
          attributes: ['id', 'title'],
          required: true,
          include: [
            {
              model: learningSessionQuizModel,
              attributes: ['id', 'learning_session_id'],
              where: whereClauseForSession,
              required: true,
            },
          ],
        },
        {
          model: userModel,
          where: whereClauseForUser,
          attributes: ['id', 'firstName', 'lastName', 'dregNo'],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }

    return userQuizProgressModel.findAndCountAll(finalClause);
  };

  const getUserProgress = async (quizId, userId, reportType) => {
    let condition = {
      where: {
        quizId,
        userId,
      },
      order: reportType === 'BEST_PERFPORMANCE' ? [['percentage', 'DESC']] : [['created_at', 'DESC']],
    };
    return userQuizProgressModel.findOne(condition);
  };

  const getStudentReport = async userQuizProgressId => {
    try {
      const queryOptions = {
        where: { userQuizProgressId: userQuizProgressId },
        include: [
          {
            model: questionModel,
            attributes: ['id', 'question'],
            include: [
              {
                model: questionOptionModel,
                attributes: ['id', 'option', 'isCorrectOption', 'order', 'description'],
              },
            ],
          },
        ],
        attributes: ['questionId', 'questionOptionId', 'response', 'earnPoint', 'recordStatus', 'result'],
      };

      const resultCounts = await userResponseModel.findAll({
        attributes: ['result', [Sequelize.fn('COUNT', Sequelize.col('*')), 'count']],
        where: {
          userQuizProgressId: userQuizProgressId,
        },
        group: ['result'],
      });

      const userResponseQuizData = await userResponseModel.findAll(queryOptions);

      const userQuizProgressData = await userQuizProgressModel.findOne({
        where: { id: userQuizProgressId },
        include: [{ model: quizModel, attributes: ['id', 'title'] }],
      });

      const userResponseData = userResponseQuizData.map(userResponse => {
        const plainUserResponse = userResponse.toJSON();

        if (plainUserResponse.questionOptionId === null) {
          return plainUserResponse;
        }

        plainUserResponse.question.question_options = plainUserResponse.question.question_options.map(option => {
          if (!option.hasOwnProperty('isSelected')) {
            option.isSelected = false;
          }
          if (option.id === plainUserResponse.questionOptionId) {
            option.isSelected = true;
          }
          return option;
        });

        return plainUserResponse;
      });

      return { userResponseData, userQuizProgressData, resultCounts };
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };

  const getCapstoneResult = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForBatch = {};
    let whereClauseForUser = {};
    let whereClauseForLearningSession = {};

    if (whereClause?.batch_id) {
      whereClauseForBatch.batchId = whereClause.batch_id;
      delete whereClause.batch_id;
    }
    if (whereClause?.name) {
      whereClauseForUser = {
        [Op.or]: [{ firstName: whereClause.name }, { lastName: whereClause.name }],
      };
      delete whereClause.name;
    }

    if (whereClause?.dregNo) {
      whereClauseForUser.dregNo = whereClause.dregNo;
      delete whereClause.dregNo;
    }

    if (whereClause?.status) {
      if (whereClause.status['$like'].includes(ASSESMENT_STATUS.COMPLETED)) {
        whereClause.earn_point = { [Op.not]: null };
      } else if (whereClause.status['$like'].includes(ASSESMENT_STATUS.PENDING)) {
        whereClause.earn_point = null;
      }
      delete whereClause.status;
    }

    const subquery = `(SELECT user_quiz_progress.user_id, MAX(user_quiz_progress.attempt_no) AS maxAttemptNo FROM user_quiz_progress GROUP BY user_quiz_progress.user_id)`;
    const maxPercentage = `(SELECT MAX(percentage) FROM user_quiz_progress WHERE user_quiz_progress.user_id = user.id)`;
    const maxEarnPoint = `(SELECT earn_point FROM user_quiz_progress WHERE user_quiz_progress.user_id = user.id AND percentage = (${maxPercentage}) LIMIT 1)`;
    const maxTotalPoint = `(SELECT total_point FROM user_quiz_progress WHERE user_quiz_progress.user_id = user.id AND percentage = (${maxPercentage}) LIMIT 1)`;

    const finalClause = {
      order: orderBy,
      attributes: [
        ...attributes,
        [Sequelize.literal(maxPercentage), 'maxPercentage'],
        [Sequelize.literal(maxEarnPoint), 'maxEarnPoint'],
        [Sequelize.literal(maxTotalPoint), 'maxTotalPoint'],
      ],

      where: {
        [Op.and]: [Sequelize.literal(`(user_quiz_progress.user_id, user_quiz_progress.attempt_no) IN ${subquery}`), whereClause],
      },

      distinct: true,
      include: [
        {
          model: quizModel,
          attributes: ['id', 'title'],
          required: true,
          include: {
            model: batchQuizModel,
            attributes: ['batchId'],
            where: whereClauseForBatch,
            required: true,
          },
        },
        { model: userModel, where: whereClauseForUser, attributes: ['id', 'firstName', 'lastName', 'dregNo'] },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }

    return userQuizProgressModel.findAndCountAll(finalClause);
  };

  const updateUserResponses = async capstoneResponse => {
    const responseUpdates = capstoneResponse.map(async response => {
      const { responseId, teacherFeedback, earnPoint } = response;
      await userResponseModel.update({ teacherFeedback, earnPoint }, { where: { id: responseId } });
    });
    await Promise.all(responseUpdates);
  };
  const updateQuizProgress = async (quizProgressId, quizId) => {
    const userResponses = await userResponseModel.findAll({
      where: { userQuizProgressId: quizProgressId },
      attributes: ['earnPoint'],
    });
    const quizDetails = await quizModel.findByPk(quizId);
    const totalEarnPoint = userResponses.reduce((acc, response) => acc + response.earnPoint, 0);

    const quizProgress = await userQuizProgressModel.findByPk(quizProgressId);
    if (quizProgress) {
      const passingPercentage = quizDetails.passingPercentage;
      const totalPoint = quizProgress.totalPoint;
      const percentage = (totalEarnPoint / totalPoint) * 100;
      const isPassed = percentage >= passingPercentage ? 1 : 0;
      await quizProgress.update({ earnPoint: totalEarnPoint, percentage, isPassed });
      return { earnPoint: totalEarnPoint, percentage, isPassed };
    } else {
      return null;
    }
  };
  const getCapstoneForReview = async (userQuizProgressId, teacherId) => {
    try {
      const userResponseData = await userQuizProgressModel.findOne({
        where: {
          id: userQuizProgressId,
        },
        attributes: ['id', 'quizId', 'userId', 'completionTime', 'earnPoint', 'totalPoint', 'isPassed', 'percentage', 'attemptNo'],
        include: [
          {
            model: userResponseModel,
            attributes: ['id', 'userQuizProgressId', 'quizId', 'questionId', 'response', 'teacherFeedback', 'earnPoint', 'recordStatus', 'result'],
            include: [
              {
                model: questionModel,
                attributes: ['id', 'question'],
                include: [
                  {
                    model: quizQuestionModel,
                    attributes: ['points'],
                  },
                  {
                    model: questionContentModel,
                    attributes: ['id'],
                    include: [
                      {
                        model: contentModel,
                        attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                      },
                    ],
                  },
                ],
              },
              {
                model: userResponseContentModel,
                attributes: ['id'],
                include: [
                  {
                    model: contentModel,
                    attributes: ['id', 'title', 'url', 'slug', 'type', 'description', 'recordStatus'],
                  },
                ],
              },
            ],
          },
        ],
      });
      return userResponseData;
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };

  const getAllParticipants = batchId => {
    try {
      return batchUserModel.findAll({
        where: {
          batchId: batchId,
        },
        attributes: ['id'],
        include: [
          {
            model: userModel,
            attributes: ['id', 'firstName', 'lastName'],
            include: [
              {
                model: userProfileModel,
                attributes: ['id', 'profileUrl'],
              },
            ],
          },
        ],
      });
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };

  const getAllAttendees = async sessionId => {
    try {
      return learningSessionAttendanceModel.findAll({
        where: {
          learningSessionId: sessionId,
        },
        attributes: ['id'],
        include: [
          {
            model: userModel,
            attributes: ['id', 'firstName', 'lastName'],
            include: [
              {
                model: userProfileModel,
                attributes: ['id', 'profileUrl'],
              },
            ],
          },
        ],
      });
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };
  const getAllCapstoneList = async (primaryFacultyId, status) => {
    try {
      const userResponseData = await batchModel.findAll({
        attributes: ['id', 'batchNumber', 'courseId'],
        include: [
          {
            model: courseModel,
            attributes: ['id', 'title'],
          },
          {
            model: learningSessionModel,
            attributes: ['id', 'title', 'primaryFacultyId', 'batchId'],
            where: { primaryFacultyId: primaryFacultyId },
          },
          {
            model: batchQuizModel,
            attributes: ['id', 'batchId', 'quizId'],
          },
        ],
      });
      return userResponseData;
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };
  const fetchUserQuizProgress = async (quizId, status) => {
    try {
      const whereCondition = {
        quizId: quizId,
      };

      if (status === 'PENDING') {
        whereCondition.earnPoint = {
          [Sequelize.Op.is]: null,
        };
      } else if (status === 'COMPLETED') {
        whereCondition.earnPoint = {
          [Sequelize.Op.ne]: null,
        };
      }
      return userQuizProgressModel.findAll({
        where: whereCondition,
        attributes: [
          'id',
          'quizId',
          'earnPoint',
          'totalPoint',
          'attemptNo',
          'isPassed',
          'completionTime',
          'startTime',
          'endTime',
          'percentage',
          'created_at',
          'updated_at',
        ],
        include: [
          { model: userModel, attributes: ['id', 'firstName', 'lastName', 'dregNo'] },
          { model: quizModel, attributes: ['id', 'title'] },
        ],
      });
    } catch (error) {
      logger.error('Error fetching report:', error);
    }
  };
  return {
    ...baseRepo,
    updateUserResponses,
    updateQuizProgress,
    getCourses,
    getBatches,
    getLearningSessions,
    getLearningSessionByBatchIdForTeacher,
    getSessionQuizByBatchIdForTeacher,
    getSessionListForTeacherByTeacherIdSessionId,
    getLearningSessionById,
    getQuizResult,
    getUserProgress,
    getStudentReport,
    getCapstoneResult,
    getCapstoneForReview,
    getAllParticipants,
    getAllAttendees,
    getAllCapstoneList,
    fetchUserQuizProgress,
  };
});
