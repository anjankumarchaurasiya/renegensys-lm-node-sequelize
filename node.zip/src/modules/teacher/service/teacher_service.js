const { define } = require('src/containerHelper');
const searchFilters = require('../constants/teacher_search_filter_constant');
const moment = require('moment');

const { LEARNING_SESSION_START_BEFORE_TIME, LEARNING_SESSION_START_BEFORE_DATE, LEARNING_SESSION_NOT_FOUND } = require('src/constants');

module.exports = define('teacherService', ({
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, INVALID_REQUEST, ENTITY_NOT_FOUND, SESSION_STATUS_TYPE },
  teacherRepository,
  categoryRepository,
  batchQuizRepository,
  learningSessionRepository,
  learningSessionAttendanceRepository,
  learningSessionSpamReportRepository,
  studentRepository,
  userQuizProgressRepository,
  logger,
}) => {
  const getLearningSessionByBatchIdForTeacher = async (batchId, userId) => {
    let learningSessionDetail = await teacherRepository.getLearningSessionByBatchIdForTeacher(batchId, userId);
    if (learningSessionDetail) {
      return learningSessionDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `learningSession not found `);
    }
  };
  const getSessionQuizByBatchIdForTeacher = async (batchId, userId) => {
    const preSession = await categoryRepository.findOne({ name: 'PRE_SESSION' });
    const postSession = await categoryRepository.findOne({ name: 'POST_SESSION' });
    const capstoneCategory = await categoryRepository.findOne({ name: 'CAPSTONE' });
    const preSessionCategoryId = preSession?.id;
    const postSessionCategoryId = postSession?.id;
    const capstoneCategoryId = capstoneCategory?.id;
    const preSessionResult = await getSessionQuizByBatchCategory(batchId, preSessionCategoryId, userId);
    const postSessionResult = await getSessionQuizByBatchCategory(batchId, postSessionCategoryId, userId);
    const capstoneResult = await batchQuizRepository.findOne({ batchId: batchId, categoryId: capstoneCategoryId });
    return {
      preSessionResult: preSessionResult,
      postSessionResult: postSessionResult,
      capstoneId: capstoneResult?.quizId ? capstoneResult.quizId : '',
    };
  };

  const getSessionQuizByBatchCategory = async (batchId, categoryId, userId) => {
    let learningSession = await teacherRepository.getSessionQuizByBatchIdForTeacher(batchId, categoryId, userId);
    const updatedLearningSession = await Promise.all(
      learningSession.map(async session => {
        if (session.learning_session_quizzes && session.learning_session_quizzes.length > 0) {
          const updatedQuizzes = await Promise.all(
            session.learning_session_quizzes.map(async sessionQuiz => {
              return {
                ...sessionQuiz.toJSON(),
              };
            })
          );
          return {
            ...session.toJSON(),
            learning_session_quizzes: updatedQuizzes,
          };
        } else {
          return session.toJSON();
        }
      })
    );
    if (updatedLearningSession) {
      return updatedLearningSession;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `sessionQuiz not found `);
    }
  };
  const getAllBatchOfTeacher = async (teacherId, queryParams) => {
    queryParams.teacherId = teacherId;
    let batchListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.teacherBatches);
      batchListResponse = await teacherRepository.getBatches(
        ['id', 'batchNumber', 'courseId', 'startDate', 'endDate', 'classMode', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.teacherBatches);
      batchListResponse = await teacherRepository.getBatches(
        ['id', 'batchNumber', 'courseId', 'startDate', 'endDate', 'classMode', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }

    return { count: batchListResponse.count, batch: batchListResponse.rows };
  };

  const getAllCoursesOfTeacher = async (teacherId, queryParams) => {
    queryParams.teacherId = teacherId;
    let courseListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.teacherCourses);
      courseListResponse = await teacherRepository.getCourses(
        ['id', 'title', 'description', 'thumbnail', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.teacherCourses);
      courseListResponse = await teacherRepository.getCourses(['id', 'title', 'description', 'thumbnail', 'created_at'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }

    return { count: courseListResponse.count, course: courseListResponse.rows };
  };

  const getAllSessionsOfTeacher = async (teacherId, queryParams) => {
    queryParams.teacherId = teacherId;
    let sessionListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.teacherSessions);
      sessionListResponse = await teacherRepository.getLearningSessions(
        ['id', 'title', 'date', 'startTime', 'endTime', 'batchId', 'status', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.teacherSessions);
      sessionListResponse = await teacherRepository.getLearningSessions(
        ['id', 'title', 'date', 'startTime', 'endTime', 'batchId', 'status', 'created_at'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }

    return { count: sessionListResponse.count, sessions: sessionListResponse.rows };
  };

  const getSessionListForTeacherByTeacherIdSessionId = async (sessionId, teacherId) => {
    let learningSessionDetail = await teacherRepository.getSessionListForTeacherByTeacherIdSessionId(sessionId, teacherId);
    if (learningSessionDetail) {
      const modifiedLearningSessions = await Promise.all(
        learningSessionDetail.map(async session => {
          const learningSessionId = session.id;
          session = session.get({ plain: true });
          // Iterate over each module within the learning session
          const modifiedModules = await Promise.all(
            session.learning_session_modules.map(async learningSessionModule => {
              const module = learningSessionModule.module;
              const moduleId = module.id;

              // Fetch topic count for the current module from module_topic table
              const topicCount = module.topics.length;

              // Fetch completed topic counts for the current module from learning_session_progress table
              const completedTopics = await Promise.all(
                module.topics.map(async topic => {
                  const topicId = topic.id;
                  const completedTopicCount = await studentRepository.completedTopicCountBasedOnModuleIdTopicIdLearningSessionId(
                    moduleId,
                    learningSessionId,
                    topicId
                  );

                  // Determine if the topic is completed based on completion counts
                  const isTopicCompleted = completedTopicCount > 0;

                  // Update the topic with the completion status
                  return {
                    ...topic,
                    isTopicCompleted: isTopicCompleted,
                  };
                })
              );
              // Fetch completed topic count for the current module from learning_session_progress table
              const completedTopicCount = await studentRepository.completedTopicCountBasedOnModuleId(moduleId, learningSessionId);

              // Determine if the module is completed based on topic counts
              const isModuleCompleted = topicCount > 0 && completedTopicCount === topicCount;

              // Update the module with the completion status
              return {
                ...learningSessionModule,
                module: {
                  isModuleCompleted: isModuleCompleted,
                  ...module,
                  topics: completedTopics,
                },
              };
            })
          );

          // Construct the modified session object
          const modifiedSession = {
            ...session,
            learning_session_modules: modifiedModules,
          };

          return modifiedSession;
        })
      );
      // Return the updated learningSessionDetail directly

      return modifiedLearningSessions;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `learningSession not found `);
    }
  };

  const getLearningSessionForTeacher = async sessionId => {
    let learningSessionDetail = await teacherRepository.getLearningSessionById(sessionId);
    if (learningSessionDetail) {
      return learningSessionDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `learningSession not found `);
    }
  };

  const getAllQuizResult = async function(queryParams) {
    let sessionQuizListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
        queryParams,
        searchFilters.sessionQuizResult
      );
      sessionQuizListResponse = await teacherRepository.getQuizResult(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'recordStatus', 'deactivatedAt', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.sessionQuizResult);
      sessionQuizListResponse = await teacherRepository.getQuizResult(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'recordStatus', 'deactivatedAt', 'created_at'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: sessionQuizListResponse.count, sessionQuizResult: sessionQuizListResponse.rows };
  };

  const getStudentResponseReport = async (quizId, userId, reportType) => {
    const userQuizprogress = await teacherRepository.getUserProgress(quizId, userId, reportType);
    const result = await teacherRepository.getStudentReport(userQuizprogress.dataValues.id);
    return result;
  };

  const getAllCapstoneResult = async function(queryParams) {
    let sessionQuizListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.capstoneResult);
      sessionQuizListResponse = await teacherRepository.getCapstoneResult(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.capstoneResult);
      sessionQuizListResponse = await teacherRepository.getCapstoneResult(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'created_at'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: sessionQuizListResponse.count, sessionQuizResult: sessionQuizListResponse.rows };
  };
  const getAllCapstoneList = async function(primaryFacultyId, status) {
    if (status === 'PENDING' || status === 'COMPLETED') {
      const allQuizList = await teacherRepository.getAllCapstoneList(primaryFacultyId, status);

      const modifiedAllQuizList = await Promise.all(
        allQuizList.map(async batch => {
          batch = batch.get({ plain: true });

          const modifiedBatchQuizzes = await Promise.all(
            batch.batch_quizzes.map(async batchQuiz => {
              const quizId = batchQuiz.quizId;

              const userQuizProgressData = await teacherRepository.fetchUserQuizProgress(quizId, status);
              if (userQuizProgressData.length > 0) {
                return {
                  ...batchQuiz,
                  userQuizProgress: userQuizProgressData,
                };
              } else {
                return null;
              }
            })
          );
          const filteredModifiedBatchQuizzes = modifiedBatchQuizzes.filter(quiz => quiz !== null);
          if (filteredModifiedBatchQuizzes.length > 0) {
            return {
              ...batch,
              batch_quizzes: filteredModifiedBatchQuizzes,
            };
          } else {
            return null;
          }
        })
      );
      const filteredModifiedAllQuizList = modifiedAllQuizList.filter(batch => batch !== null);
      return filteredModifiedAllQuizList;
    } else {
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, 'Status should be pending or completed');
    }
  };

  const submitCapstone = async (userId, capstoneResponse, quizId, quizProgressId) => {
    try {
      await teacherRepository.updateUserResponses(capstoneResponse);
      return await teacherRepository.updateQuizProgress(quizProgressId, quizId);
    } catch (error) {
      console.error('Error updating user responses and quiz progress:', error);
      throw error;
    }
  };

  const updateLearningSessionStatus = async (sessionId, status) => {
    const existingLearningSession = await learningSessionRepository.findOne({ id: sessionId });
    if (status === SESSION_STATUS_TYPE.INPROGRESS) {
      const currentDate = moment();
      const sessionDate = moment(existingLearningSession.date);
      const sessionDateTime = moment(`${existingLearningSession.date} ${existingLearningSession.startTime}`, 'YYYY-MM-DD HH:mm:ss');

      if (!currentDate.isSame(sessionDate, 'day')) {
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, LEARNING_SESSION_START_BEFORE_DATE);
      }

      const beforeStart = sessionDateTime.clone().subtract(10, 'minutes');
      if (currentDate.isAfter(beforeStart)) {
        const currentTime = moment().format('HH:mm:ss');
        await learningSessionRepository.update({ status: status, actualStartTime: currentTime }, { id: sessionId });
      } else {
        throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, LEARNING_SESSION_START_BEFORE_TIME);
      }
    }
    if (status === SESSION_STATUS_TYPE.COMPLETED) {
      const currentTime = moment().format('HH:mm:ss');
      await learningSessionRepository.update({ status: status, actualEndTime: currentTime }, { id: sessionId });

      const sessionUsers = await learningSessionAttendanceRepository.findAll({ learningSessionId: sessionId, outTime: null });
      const relevantUserIds = sessionUsers.map(sessionUser => sessionUser.userId);

      const currentTimeUtc = moment().utc();
      await Promise.all(
        relevantUserIds.map(async userId => {
          await learningSessionAttendanceRepository.update({ outTime: currentTimeUtc }, { learningSessionId: sessionId, userId: userId });
        })
      );
    }
  };

  const submitSpamReport = async (learningSessionId, userId, spamReason, warningGiven, reportedBy) => {
    let learningSession = await learningSessionRepository.findOne({ id: learningSessionId });
    if (learningSession) {
      let submitResponse = await learningSessionSpamReportRepository.create({ learningSessionId, userId, reportedBy, spamReason, warningGiven });
      return submitResponse;
    } else {
      throw new CustomError(INVALID_REQUEST.code, INVALID_REQUEST.status, LEARNING_SESSION_NOT_FOUND);
    }
  };
  const getCapstoneForReview = async (userQuizProgressId, teacherId) => {
    try {
      const quiz = await userQuizProgressRepository.findOne({ id: userQuizProgressId });
      if (quiz) {
        const capstoneReport = await teacherRepository.getCapstoneForReview(userQuizProgressId, teacherId);
        return capstoneReport;
      } else {
        throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, `Capstone not exist`);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const getAllParticipants = batchId => {
    return teacherRepository.getAllParticipants(batchId);
  };

  const getAllAttendees = sessionId => {
    return teacherRepository.getAllAttendees(sessionId);
  };

  return {
    getLearningSessionByBatchIdForTeacher,
    getSessionQuizByBatchIdForTeacher,
    getSessionListForTeacherByTeacherIdSessionId,
    getAllBatchOfTeacher,
    getAllCoursesOfTeacher,
    getAllSessionsOfTeacher,
    getLearningSessionForTeacher,
    getAllQuizResult,
    getStudentResponseReport,
    getAllCapstoneResult,
    updateLearningSessionStatus,
    submitCapstone,
    submitSpamReport,
    getCapstoneForReview,
    getAllParticipants,
    getAllAttendees,
    getAllCapstoneList,
  };
});
