module.exports = Object.freeze({
  teacherBatches: {
    teacherId: {
      op: '$eq',
      alias: 'teacher_id',
      dataType: 'UUID',
    },
    courseId: {
      op: '$eq',
      alias: 'course_id',
      dataType: 'UUID',
    },
  },
  teacherCourses: {
    teacherId: {
      op: '$eq',
      alias: 'teacher_id',
      dataType: 'UUID',
    },
  },

  teacherSessions: {
    teacherId: {
      op: '$eq',
      alias: 'primary_faculty_id',
      dataType: 'UUID',
    },
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
    status: {
      op: '$like',
      alias: 'status',
      dataType: 'STRING',
    },
  },

  sessionQuizResult: {
    sessonId: {
      op: '$eq',
      alias: 'learning_session_id',
      dataType: 'UUID',
    },
    quizId: {
      op: '$eq',
      alias: 'quiz_id',
      dataType: 'UUID',
    },
    dregNo: {
      op: '$like',
      alias: 'dregNo',
      dataType: 'STRING',
    },
    name: {
      op: '$like',
      alias: 'name',
      dataType: 'STRING',
    },
    earnPoint: {
      op: '$like',
      alias: 'earnPoint',
      dataType: 'STRING',
    },
    isPassed: {
      op: '$eq',
      alias: 'is_passed',
      dataType: 'BOOLEAN',
    },
  },

  capstoneResult: {
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
    quizId: {
      op: '$eq',
      alias: 'quiz_id',
      dataType: 'UUID',
    },
    dregNo: {
      op: '$like',
      alias: 'dregNo',
      dataType: 'STRING',
    },
    name: {
      op: '$like',
      alias: 'name',
      dataType: 'STRING',
    },
    status: {
      op: '$like',
      alias: 'status',
      dataType: 'STRING',
    },
    isPassed: {
      op: '$eq',
      alias: 'is_passed',
      dataType: 'BOOLEAN',
    },
  },
});
