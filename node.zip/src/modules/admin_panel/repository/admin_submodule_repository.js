const { define } = require('src/containerHelper');

module.exports = define('adminSubmoduleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('admin_submodule');
  const adminSubmoduleModel = database['admin_submodule'];

  const bulkCreate = data => adminSubmoduleModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
