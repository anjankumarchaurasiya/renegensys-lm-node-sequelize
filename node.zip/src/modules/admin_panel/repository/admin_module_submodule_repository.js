const { define } = require('src/containerHelper');

module.exports = define('adminModuleSubmoduleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('admin_module_submodule');
  const adminModuleSubmoduleModel = database['admin_module_submodule'];

  const bulkCreate = data => adminModuleSubmoduleModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
