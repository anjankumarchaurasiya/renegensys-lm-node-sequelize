const { define } = require('src/containerHelper');

module.exports = define('adminPanelPermissionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('admin_panel_permission');
  const adminPanelPermissionModel = database['admin_panel_permission'];

  const bulkCreate = data => adminPanelPermissionModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
