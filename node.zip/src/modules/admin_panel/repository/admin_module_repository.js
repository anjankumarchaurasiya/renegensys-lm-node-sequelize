const { define } = require('src/containerHelper');

module.exports = define('adminModuleRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('admin_module');
  const adminModuleModel = database['admin_module'];

  const bulkCreate = data => adminModuleModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
