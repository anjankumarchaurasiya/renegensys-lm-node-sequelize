'use strict';
module.exports = (sequelize, DataTypes) => {
  const AdminModuleSubmodule = sequelize.define(
    'admin_module_submodule',
    {
      id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        autoIncrement: false,
      },
      adminModuleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      adminSubmoduleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  AdminModuleSubmodule.associate = function(models) {
    AdminModuleSubmodule.belongsTo(models.admin_module, {
      foreignKey: 'adminModuleId',
      targetKey: 'id',
    });
    AdminModuleSubmodule.belongsTo(models.admin_submodule, {
      foreignKey: 'adminSubmoduleId',
      targetKey: 'id',
    });
  };

  return AdminModuleSubmodule;
};
