'use strict';
module.exports = (sequelize, DataTypes) => {
  const AdminSubmodule = sequelize.define(
    'admin_submodule',
    {
      id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        autoIncrement: false,
      },
      name: {
        type: DataTypes.STRING,
        default: 'default',
        allowNull: false,
      },
      icon: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      redirectLink: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  return AdminSubmodule;
};
