'use strict';
module.exports = (sequelize, DataTypes) => {
  const AdminPanelPermission = sequelize.define(
    'admin_panel_permission',
    {
      id: {
        type: DataTypes.UUID,
        primaryKey: true,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        autoIncrement: false,
      },
      roleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      adminModuleId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      adminSubmoduleId: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      canView: {
        type: DataTypes.BOOLEAN,
        defaultValue: 0,
      },
      canDelete: {
        type: DataTypes.BOOLEAN,
        defaultValue: 0,
      },
      canUpdate: {
        type: DataTypes.BOOLEAN,
        defaultValue: 0,
      },
      canCreate: {
        type: DataTypes.BOOLEAN,
        defaultValue: 0,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: 1,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  AdminPanelPermission.associate = function(models) {
    AdminPanelPermission.belongsTo(models.role, {
      foreignKey: 'roleId',
      targetKey: 'id',
    });
    AdminPanelPermission.belongsTo(models.admin_module, {
      foreignKey: 'adminModuleId',
      targetKey: 'id',
    });
    AdminPanelPermission.belongsTo(models.admin_submodule, {
      foreignKey: 'adminSubmoduleId',
      targetKey: 'id',
    });
  };

  return AdminPanelPermission;
};
