const { define } = require('src/containerHelper');

module.exports = define('adminPanelPermissionService', ({ adminPanelPermissionRepository }) => {
  const createAdminPanelPermission = async data => {
    const adminPanelPermission = await adminPanelPermissionRepository.create(data);
    return adminPanelPermission;
  };
  const bulkCreateAdminPanelPermission = data => adminPanelPermissionRepository.bulkCreate(data);
  return {
    createAdminPanelPermission,
    bulkCreateAdminPanelPermission,
  };
});
