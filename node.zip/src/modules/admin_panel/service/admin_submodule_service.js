const { define } = require('src/containerHelper');

module.exports = define('adminSubmoduleService', ({ adminSubmoduleRepository }) => {
  const createAdminSubmodule = async data => {
    const adminSubmodule = await adminSubmoduleRepository.create(data);
    return adminSubmodule;
  };
  const bulkCreateAdminSubmodule = data => adminSubmoduleRepository.bulkCreate(data);
  return {
    createAdminSubmodule,
    bulkCreateAdminSubmodule,
  };
});
