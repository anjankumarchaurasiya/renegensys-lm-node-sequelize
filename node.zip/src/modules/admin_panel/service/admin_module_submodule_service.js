const { define } = require('src/containerHelper');

module.exports = define('adminModuleSubmoduleService', ({ adminModuleSubmoduleRepository }) => {
  const createAdminModuleSubmodule = async data => {
    const adminModuleSubmodule = await adminModuleSubmoduleRepository.create(data);
    return adminModuleSubmodule;
  };
  const bulkCreateAdminModuleSubmodule = data => adminModuleSubmoduleRepository.bulkCreate(data);
  return {
    createAdminModuleSubmodule,
    bulkCreateAdminModuleSubmodule,
  };
});
