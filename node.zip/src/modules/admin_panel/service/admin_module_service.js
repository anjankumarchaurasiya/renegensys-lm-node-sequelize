const { define } = require('src/containerHelper');

module.exports = define('adminModuleService', ({ adminModuleRepository }) => {
  const createAdminModule = async data => {
    const adminModule = await adminModuleRepository.create(data);
    return adminModule;
  };
  const bulkCreateAdminModule = data => adminModuleRepository.bulkCreate(data);
  return {
    createAdminModule,
    bulkCreateAdminModule,
  };
});
