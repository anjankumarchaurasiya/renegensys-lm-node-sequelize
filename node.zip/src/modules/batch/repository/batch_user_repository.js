const { define } = require('src/containerHelper');

const { Op, fn, col, where } = require('sequelize');

module.exports = define('batchUserRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('batch_user');
  const batchUserModel = database['batch_user'];
  const userModel = database['user'];
  const userRoleModel = database['user_role'];

  /** Bulk create */
  const bulkCreate = data =>
    batchUserModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getUserBatches = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForRole;
    let whereClauseForUser = {};
    let requiredForBatchUser = false;
    let roleFlag = false;

    if (whereClause.linked) {
      whereClause.recordStatus = whereClause.linked;
    }

    if (whereClause.role_id) {
      whereClauseForRole = whereClause.role_id;
      roleFlag = true;
      delete whereClause.role_id;
    }

    whereClauseForUser[Op.and] = [];
    if (whereClause.email) {
      whereClauseForUser[Op.and].push({ email: whereClause.email });
      requiredForBatchUser = true;
      delete whereClause.email;
    }

    if (whereClause.dregNo) {
      whereClauseForUser[Op.and].push({ dregNo: whereClause.dregNo });
      requiredForBatchUser = true;
      delete whereClause.dregNo;
    }

    if (whereClause.mobile) {
      whereClauseForUser[Op.and].push({ mobile: whereClause.mobile });
      requiredForBatchUser = true;
      delete whereClause.mobile;
    }

    if (whereClause.name) {
      let searchPattern = whereClause.name['$like'].replace(/%/g, '');
      searchPattern = `%${searchPattern.split(' ').join('%')}%`;

      whereClauseForUser[Op.and].push(where(fn('concat', col('first_name'), ' ', col('last_name')), { [Op.like]: searchPattern }));
      delete whereClause.name;
    }

    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: userModel,
          attributes: ['id', 'firstName', 'lastName', 'mobile', 'email', 'dregNo', 'dialCode', 'countryCode'],
          where: whereClauseForUser,
          include: [
            {
              model: userRoleModel,
              where: roleFlag ? { role_id: whereClauseForRole } : {},
              attributes: ['id', 'userId', 'roleId'],
              // required: false,
            },
          ],
        },
      ],
    };
    if (limit && offset > -1) {
      finalClause.limit = limit;
      finalClause.offset = offset;
    }
    return batchUserModel.findAndCountAll(finalClause);
  };

  return {
    ...baseRepo,
    bulkCreate,
    getUserBatches,
  };
});
