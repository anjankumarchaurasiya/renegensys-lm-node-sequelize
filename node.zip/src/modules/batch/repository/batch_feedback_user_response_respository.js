const { define } = require('src/containerHelper');
module.exports = define('batchFeedbackUserResponseRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('batch_feedback_user_response');
  const batchFeedbackUserResponseModel = database['batch_feedback_user_response'];

  const bulkCreate = data =>
    batchFeedbackUserResponseModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
