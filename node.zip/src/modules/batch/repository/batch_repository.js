const { define } = require('src/containerHelper');
const { Op } = require('sequelize');
const { feedback } = require('../../learning_session/constants/feedback_search_filter_constants');

module.exports = define('batchRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('batch');
  const batchModel = database['batch'];
  const courseModel = database['course'];
  const batchUserModel = database['batch_user'];
  const userModel = database['user'];
  const userRoleModel = database['user_role'];
  const feedbackModel = database['feedback'];

  const bulkCreate = data =>
    batchModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });
  /** Get batch by id */
  const getBatchById = async batchId => {
    return batchModel.findOne({
      where: { id: batchId },
      include: [{ model: courseModel, attributes: ['id', 'title'] }],
    });
  };
  /** Get batches */
  const getBatches = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForCourse;
    if (whereClause.course_id) {
      whereClauseForCourse = whereClause.course_id;
    }
    let finalClause = {
      where: whereClause,
      attributes: attributes,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: courseModel,
          attributes: ['id', 'title', 'created_at', 'recordStatus'],
          where: whereClauseForCourse ? { id: whereClauseForCourse } : {},
        },
        {
          model: feedbackModel,
          attributes: ['id', 'title', 'description', 'categoryId'],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }
    return batchModel.findAndCountAll(finalClause);
  };
  return {
    ...baseRepo,
    bulkCreate,
    getBatches,
    getBatchById,
  };
});
