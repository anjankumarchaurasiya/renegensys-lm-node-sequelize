const { define } = require('src/containerHelper');

const { Sequelize, Op, literal } = require('sequelize');

module.exports = define('batchQuizRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('batch_quiz');
  const batchQuizModel = database['batch_quiz'];
  const quizModel = database['quiz'];
  const userModel = database['user'];
  const userQuizProgressModel = database['user_quiz_progress'];
  const attemptRequestModel = database['attempt_request'];
  const userResponseModel = database['user_response'];
  /** Bulk create */
  const bulkCreate = data =>
    batchQuizModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });

  const getExamResultBatch = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForBatch = {};
    let whereClauseForUser = {};

    if (whereClause?.batch_id) {
      whereClauseForBatch.batchId = whereClause.batch_id;
      delete whereClause.batch_id;
    }
    if (whereClause?.category_id) {
      whereClauseForBatch.categoryId = whereClause.category_id;
      delete whereClause.category_id;
    }
    if (whereClause?.name) {
      whereClauseForUser = {
        [Op.or]: [{ firstName: whereClause.name }, { lastName: whereClause.name }],
      };
      delete whereClause.name;
    }

    if (whereClause?.dregNo) {
      whereClauseForUser.dregNo = whereClause.dregNo;
      delete whereClause.dregNo;
    }
    const subquery = `(SELECT user_quiz_progress.user_id, MAX(user_quiz_progress.attempt_no) AS maxAttemptNo FROM user_quiz_progress GROUP BY user_quiz_progress.user_id)`;
    const finalClause = {
      order: orderBy,
      attributes: [
        ...attributes,
        [
          Sequelize.literal(
            '(SELECT request_status FROM attempt_request WHERE user_quiz_progress.quiz_id = attempt_request.quiz_id AND user_quiz_progress.user_id = attempt_request.user_id AND request_status="PENDING")'
          ),
          'requestStatus',
        ],
        [
          Sequelize.literal(
            '(SELECT id  FROM attempt_request WHERE user_quiz_progress.quiz_id = attempt_request.quiz_id AND user_quiz_progress.user_id = attempt_request.user_id AND request_status="PENDING")'
          ),
          'attemptRequestId',
        ],
      ],

      where: {
        [Op.and]: [Sequelize.literal(`(user_quiz_progress.user_id, user_quiz_progress.attempt_no) IN ${subquery}`), whereClause],
      },

      distinct: true,
      include: [
        {
          model: quizModel,
          attributes: ['id', 'title'],
          required: true,
          include: {
            model: batchQuizModel,
            attributes: ['batchId'],
            where: whereClauseForBatch,
            required: true,
          },
        },
        { model: userModel, where: whereClauseForUser, attributes: ['id', 'firstName', 'lastName', 'dregNo'] },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }

    return userQuizProgressModel.findAndCountAll(finalClause);
  };

  const getAllExamResultBatchOfStudent = async (attributes, whereClause, orderBy, limit, offset) => {
    let whereClauseForUserResponse = {};

    if (whereClause?.userId) {
      whereClauseForUserResponse.userId = whereClause.userId;
      delete whereClause.userId;
    }
    if (whereClause?.quizId) {
      whereClauseForUserResponse.quizId = whereClause.quizId;
      delete whereClause.quizId;
    }

    const finalClause = {
      attributes: attributes,
      where: whereClause,
      order: orderBy,
      distinct: true,
      include: [
        {
          model: userResponseModel,
          where: whereClauseForUserResponse,
          attributes: ['id', 'result', 'earnPoint'],
        },
      ],
    };

    if (limit && offset > -1) {
      (finalClause.limit = limit), (finalClause.offset = offset);
    }

    const results = await userQuizProgressModel.findAndCountAll(finalClause);

    const countResults = results.rows.map(row => {
      const counts = {
        UNATTEMPTED: 0,
        CORRECT: 0,
        WRONG: 0,
      };

      let totalEarnPointsForCorrect = 0;
      let totalEarnPointsForWrong = 0;
      let totalEarnPointsForUnattempted = 0;

      row.user_responses.forEach(response => {
        if (response.result === 'CORRECT') {
          totalEarnPointsForCorrect += parseFloat(response.earnPoint);
          counts.CORRECT++;
        } else if (response.result === 'WRONG') {
          totalEarnPointsForWrong += parseFloat(response.earnPoint);
          counts.WRONG++;
        } else {
          totalEarnPointsForUnattempted += parseFloat(response.earnPoint);
          counts.UNATTEMPTED++;
        }
      });

      const totalCounts = counts.CORRECT + counts.WRONG + counts.UNATTEMPTED;
      let totalPoints = parseFloat(row.totalPoint);

      const percentages = {
        CORRECT: ((totalEarnPointsForCorrect / totalPoints) * 100).toFixed(2),
        WRONG: ((totalEarnPointsForWrong / totalPoints) * 100).toFixed(2),
        UNATTEMPTED: ((totalEarnPointsForUnattempted / totalPoints) * 100).toFixed(2),
      };

      return {
        ...row.toJSON(),
        combined: {
          WRONG: `${counts.WRONG}/${totalCounts} (${percentages.WRONG}%)`,
          CORRECT: `${counts.CORRECT}/${totalCounts} (${percentages.CORRECT}%)`,
          UNATTEMPTED: `${counts.UNATTEMPTED}/${totalCounts} (${percentages.UNATTEMPTED}%)`,
        },
      };
    });

    return {
      ...results,
      rows: countResults.map(row => ({
        id: row.id,
        quizId: row.quizId,
        totalPoint: row.totalPoint,
        attemptNo: row.attemptNo,
        isPassed: row.isPassed,
        ...row.combined,
      })),
    };
  };

  return {
    ...baseRepo,
    bulkCreate,
    getExamResultBatch,
    getAllExamResultBatchOfStudent,
  };
});
