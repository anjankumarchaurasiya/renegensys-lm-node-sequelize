const { define } = require('src/containerHelper');
const { Op } = require('sequelize');

const searchFilters = require('../constants/batch_search_filter_constants');

module.exports = define('batchUserService', ({
  batchUserRepository,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND },
  generalUtilService,
}) => {
  /** Course mapping with module  */
  const createBatchUser = async function(batch_id, users) {
    let newUsers = users.map(user_id => ({
      user_id: user_id,
      batch_id: batch_id,
    }));
    const existingEntries = await batchUserRepository.findAll({
      [Op.or]: newUsers.map(({ batch_id, user_id }) => ({ batch_id, user_id })),
    });
    const existingPairs = existingEntries.map(({ batchId, userId }) => ({ batchId, userId }));
    const usersToBeAdded = newUsers
      .map(({ user_id, batch_id }) => ({
        batchId: batch_id,
        userId: user_id,
      }))
      .filter(({ batchId, userId }) => !existingPairs.find(pair => pair.batchId === batchId && pair.userId === userId));
    if (usersToBeAdded.length > 0) {
      return batchUserRepository.bulkCreate(usersToBeAdded);
    }
  };

  const getBatchUser = async (batchId, queryParams) => {
    queryParams.batchId = batchId;
    let batchUserListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.batchUser);
      batchUserListResponse = await batchUserRepository.getUserBatches(
        ['id', 'batch_Id', 'user_id', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.batchUser);
      batchUserListResponse = await batchUserRepository.getUserBatches(['id', 'batch_Id', 'user_id', 'created_at', 'recordStatus'], whereClause, [
        ['created_at', 'DESC'],
      ]);
    }

    return { count: batchUserListResponse.count, batch: batchUserListResponse.rows };
  };

  const bulkCreateBatchUsers = batchUsers => batchUserRepository.bulkCreate(batchUsers);

  const updateBatchUsers = async (linked = [], unLinked = [], batchId) => {
    for (const linkedId of linked) {
      const isLinkingExists = await batchUserRepository.findOne({ userId: linkedId, batchId: batchId });
      if (!isLinkingExists) {
        await batchUserRepository.create({ userId: linkedId, batchId: batchId });
      }
      await batchUserRepository.update({ recordStatus: 1 }, { userId: linkedId, batchId: batchId });
    }

    for (const unlinkedId of unLinked) {
      const isUnlinkedSessionExists = await batchUserRepository.findOne({ userId: unlinkedId, batchId: batchId });
      if (!isUnlinkedSessionExists) {
        logger.error(`Unlinked User with ID ${unlinkedId} not found`);
        continue;
      }
      await batchUserRepository.update({ recordStatus: 0 }, { userId: unlinkedId, batchId: batchId });
    }
  };

  return {
    createBatchUser,
    bulkCreateBatchUsers,
    getBatchUser,
    updateBatchUsers,
  };
});
