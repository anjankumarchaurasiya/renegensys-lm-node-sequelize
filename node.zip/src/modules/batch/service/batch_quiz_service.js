const { define } = require('src/containerHelper');

const searchFilters = require('../constants/batch_search_filter_constants');

const { BATCH_WITH_QUIZ_ALREADY_EXIST_SAME_CATEGORY } = require('src/constants');

module.exports = define('batchQuizService', ({
  batchQuizRepository,
  quizRepository,
  CustomError,
  generalUtilService,
  constants: { ENTITY_ALREADY_EXISTS, ENTITY_NOT_FOUND },
  logger,
}) => {
  /** Course mapping with module  */
  const createBatchQuiz = async function(batchId, quizId, body) {
    const { examDate, startTime, categoryId } = body;
    const isBatchQuizCategoryExist = await batchQuizRepository.findOne({ batchId, categoryId });
    if (isBatchQuizCategoryExist && isBatchQuizCategoryExist.recordStatus == true) {
      logger.info('Can not Add Multiple Batch with Quiz for same category');
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, BATCH_WITH_QUIZ_ALREADY_EXIST_SAME_CATEGORY);
    } else {
      if (isBatchQuizCategoryExist && isBatchQuizCategoryExist.recordStatus == false) {
        const quizBatchData1 = { batchId, quizId, examDate, startTime, categoryId, recordStatus: true };
        await batchQuizRepository.update(quizBatchData1, { id: isBatchQuizCategoryExist.id });
      } else {
        const quizBatchData = { batchId, quizId, examDate, startTime, categoryId };
        await batchQuizRepository.create(quizBatchData);
      }
    }
  };

  const deactivateBatchQuiz = async function(batchId, quizId) {
    await batchQuizRepository.deactivate({ batchId, quizId });
  };

  const getAllExamResult = async function(queryParams) {
    let batchExamListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.batchQuizResult);
      batchExamListResponse = await batchQuizRepository.getExamResultBatch(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'recordStatus', 'deactivatedAt', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.batchQuizResult);
      batchExamListResponse = await batchQuizRepository.getExamResultBatch(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'recordStatus', 'deactivatedAt', 'created_at'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: batchExamListResponse.count.length, batchExamResult: batchExamListResponse.rows };
  };

  const getAllExamResultOfStudent = async function(queryParams) {
    let studentExamListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(
        queryParams,
        searchFilters.userBatchQuizResult
      );
      studentExamListResponse = await batchQuizRepository.getAllExamResultBatchOfStudent(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'recordStatus', 'deactivatedAt', 'created_at'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.userBatchQuizResult);
      studentExamListResponse = await batchQuizRepository.getAllExamResultBatchOfStudent(
        ['id', 'quizId', 'earnPoint', 'totalPoint', 'attemptNo', 'isPassed', 'percentage', 'recordStatus', 'deactivatedAt', 'created_at'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }
    return { count: studentExamListResponse.count, studentExamResult: studentExamListResponse.rows };
  };
  return {
    createBatchQuiz,
    deactivateBatchQuiz,
    getAllExamResult,
    getAllExamResultOfStudent,
  };
});
