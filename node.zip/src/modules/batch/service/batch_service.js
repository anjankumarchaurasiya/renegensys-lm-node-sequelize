const { define } = require('src/containerHelper');
const searchFilters = require('../constants/batch_search_filter_constants');
const moment = require('moment');

module.exports = define('batchService', ({
  batchRepository,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  commonUtilService,
  courseRepository,
}) => {
  /** Bulk create */
  const createBatch = async batchData => {
    const { courseId, batchNumber } = batchData;

    const [isCourseExist, isBatchExist] = await Promise.all([
      courseRepository.findOne({ id: courseId }),
      batchRepository.findOne({ batchNumber: batchNumber }),
    ]);

    if (isBatchExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Batch already exists with batchNumber`);
    } else if (!isCourseExist) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Course not found');
    }

    const batch = await batchRepository.create(batchData);
    return batch;
  };

  /** Deactivate batch */
  const deactivateBatch = whereClause => batchRepository.deactivate(whereClause);

  /** Bulk deactivated */
  const bulkDeactivateBatch = async body => {
    const { batchIds } = body;
    const succesfullDeactivations = [];
    const unsuccesfullDeactivations = [];

    await Promise.all(
      batchIds.map(async batchId => {
        const batchDetail = await batchRepository.findOne({ id: batchId });
        if (!batchDetail) {
          unsuccesfullDeactivations.push(batchId);
          return null;
        }
        succesfullDeactivations.push(batchId);
        return batchRepository.deactivate({ id: batchId });
      })
    );

    return {
      succesfullDeactivations,
      unsuccesfullDeactivations,
    };
  };
  /** Get batch details by id */
  const getBatchById = async batchId => {
    const batchDetail = await batchRepository.getBatchById(batchId);
    if (batchDetail) {
      return batchDetail;
    } else {
      throw new CustomError(ENTITY_NOT_FOUND.code, ENTITY_NOT_FOUND.status, `Batch not found `);
    }
  };

  /** Batch update */
  const batchUpdate = async BatchData => {
    const batch = await batchRepository.findOne({ id: BatchData.id });
    if (!batch) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Batch not found');
    } else {
      await batchRepository.update(BatchData, { id: BatchData.id });
    }
  };
  /** Get all batch list with filter */
  const getBatchList = async queryParams => {
    let batchListResponse;
    if (queryParams.paginated) {
      const { whereClause, limit, offset } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.batch);
      batchListResponse = await batchRepository.getBatches(
        ['id', 'batchNumber', 'courseId', 'startDate', 'endDate', 'classMode', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']],
        limit,
        offset
      );
    } else {
      const { whereClause } = generalUtilService.mapQueryToSearchAttributesMultpleOperator(queryParams, searchFilters.batch);
      batchListResponse = await batchRepository.getBatches(
        ['id', 'batchNumber', 'courseId', 'startDate', 'endDate', 'classMode', 'created_at', 'recordStatus'],
        whereClause,
        [['created_at', 'DESC']]
      );
    }

    return { count: batchListResponse.count, batch: batchListResponse.rows };
  };

  const bulkCreateBatches = batches => batchRepository.bulkCreate(batches);

  return {
    createBatch,
    deactivateBatch,
    bulkDeactivateBatch,
    getBatchById,
    batchUpdate,
    getBatchList,
    bulkCreateBatches,
  };
});
