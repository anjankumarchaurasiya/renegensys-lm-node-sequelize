const { define } = require('src/containerHelper');

module.exports = define('batchFeedbackUserResponseService', ({
  batchFeedbackUserResponseRepository,
  constants: { ENTITY_ALREADY_EXISTS, UNAUTHORIZED_REQUEST, ENTITY_NOT_FOUND },
  logger,
}) => {
  const bulkCreateBatchFeedbackUserResponse = batchFeedbackUserResponse => {
    batchFeedbackUserResponseRepository.bulkCreate(batchFeedbackUserResponse);
  };

  const createBatchUserFeedbackResponse = async data => {
    const { userId, batchId, feedbackId, questionData } = data;

    const userResponseObjects = questionData.map(({ questionId, questionOptionId, response }) => {
      return {
        batchId,
        userId,
        feedbackId,
        response,
        questionId,
        questionOptionId,
      };
    });

    // Bulk create all user responses
    try {
      bulkCreateBatchFeedbackUserResponse(userResponseObjects);
      logger.info('User batch feedback responses created successfully.');
    } catch (error) {
      logger.error('Error creating user batch feedback responses:', error);
    }
  };

  return { bulkCreateBatchFeedbackUserResponse, createBatchUserFeedbackResponse };
});
