'use strict';

module.exports = (sequelize, DataTypes) => {
  const BatchQuiz = sequelize.define(
    'batch_quiz',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      quizId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      categoryId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      examDate: {
        type: DataTypes.DATEONLY,
      },
      startTime: {
        type: DataTypes.TIME,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  BatchQuiz.associate = function(models) {
    BatchQuiz.belongsTo(models.quiz, {
      foreignKey: 'quizId',
      targetKey: 'id',
      allowNull: false,
      index: false,
    });
    BatchQuiz.belongsTo(models.batch, {
      foreignKey: 'batchId',
      targetKey: 'id',
      allowNull: false,
      index: false,
    });
    BatchQuiz.hasMany(models.quiz_question, {
      foreignKey: 'quizId',
      sourceKey: 'quizId',
    });
    BatchQuiz.belongsTo(models.learning_session, {
      foreignKey: 'batchId',
      sourceKey: 'batchId',
    });
  };
  return BatchQuiz;
};
