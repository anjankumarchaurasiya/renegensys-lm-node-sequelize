'use strict';

module.exports = (sequelize, DataTypes) => {
  const BatchFeedbackUserResponse = sequelize.define(
    'batch_feedback_user_response',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      feedbackId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      questionId: {
        type: DataTypes.UUID,
      },
      questionOptionId: {
        type: DataTypes.UUID,
      },
      response: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  BatchFeedbackUserResponse.associate = function(models) {
    BatchFeedbackUserResponse.belongsTo(models.batch, {
      foreignKey: 'batchId',
      targetKey: 'id',
    });
    BatchFeedbackUserResponse.belongsTo(models.user, {
      foreignKey: 'userId',
      targetKey: 'id',
    });
    BatchFeedbackUserResponse.belongsTo(models.feedback, {
      foreignKey: 'feedbackId',
      targetKey: 'id',
    });
    BatchFeedbackUserResponse.belongsTo(models.question, {
      foreignKey: 'questionId',
      id: 'id',
    });
    BatchFeedbackUserResponse.belongsTo(models.question_option, {
      foreignKey: 'questionOptionId',
      id: 'id',
    });
  };
  return BatchFeedbackUserResponse;
};
