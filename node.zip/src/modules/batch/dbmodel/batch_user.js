'use strict';

module.exports = (sequelize, DataTypes) => {
  const BatchUser = sequelize.define(
    'batch_user',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      batchId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      userId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  BatchUser.associate = function(models) {
    BatchUser.belongsTo(models.user, {
      foreignKey: 'userId',
      targetKey: 'id',
    });
    BatchUser.belongsTo(models.batch, {
      foreignKey: 'batchId',
      targetKey: 'id',
    });
  };
  return BatchUser;
};
