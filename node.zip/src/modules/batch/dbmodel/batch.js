'use strict';

module.exports = (sequelize, DataTypes) => {
  const Batch = sequelize.define(
    'batch',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      batchNumber: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false,
      },
      courseId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      feedbackId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      startDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      endDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
      },
      classMode: {
        type: DataTypes.ENUM('WEEK_DAYS', 'WEEK_ENDS'),
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
      createdBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      updatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  Batch.associate = function(models) {
    Batch.belongsTo(models.course, {
      foreignKey: 'courseId',
      targetKey: 'id',
    });
    Batch.belongsTo(models.feedback, {
      foreignKey: 'feedbackId',
      targetKey: 'id',
    });
    Batch.hasMany(models.learning_session, {
      foreignKey: 'batchId',
      sourceKey: 'id',
    });

    Batch.hasMany(models.batch_user, {
      foreignKey: 'batchId',
      sourceKey: 'id',
    });
    Batch.belongsToMany(models.user, {
      through: models.batch_user,
      foreignKey: 'batchId',
      otherKey: 'userId',
    });
    Batch.hasMany(models.batch_quiz, {
      foreignKey: 'batchId',
      sourceKey: 'id',
    });
    Batch.belongsToMany(models.quiz, {
      through: models.batch_quiz,
      foreignKey: 'batchId',
      otherKey: 'quizId',
    });
    Batch.hasMany(models.batch_feedback_user_response, {
      foreignKey: 'batchId',
      sourceKey: 'id',
    });
  };
  return Batch;
};
