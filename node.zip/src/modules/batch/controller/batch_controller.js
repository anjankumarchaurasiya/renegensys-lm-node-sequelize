const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const {
  BATCH_CREATED_SUCCESSFULLY,
  BATCH_DEACTIVATED_SUCCESSFULLY,
  BATCH_UPDATED_SUCCESSFULLY,
  BATCH_MAPPED_WITH_USER_SUCCESSFULLY,
  BATCH_MAPPED_WITH_QUIZ_SUCCESSFULLY,
  BATCH_WITH_USER_MAPPING_UPDATED_SUCCESSFULLY,
} = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
    authorizeMiddleware,
  } = container.cradle;
  const { batchService, logger, batchUserService, batchQuizService } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  /** Create batch */
  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create batch route');
      let data = await batchService.createBatch(body);
      res.status(Status.OK).json(await Success(data, BATCH_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Batch delete */
  router.delete('/:batchId', async (req, res, next) => {
    try {
      const {
        params: { batchId },
      } = req;
      await batchService.deactivateBatch({ id: batchId });
      let data;
      res.status(Status.OK).json(await Success(data, BATCH_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Batch bulk */
  router.delete('/bulk', async (req, res, next) => {
    try {
      const { body } = req;
      let data = await batchService.bulkDeactivateBatch(body);
      res.status(Status.OK).json(await Success(data, BATCH_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Batch details by id */
  router.get('/:batchId', async (req, res, next) => {
    try {
      const {
        params: { batchId },
      } = req;
      let batchDetail = await batchService.getBatchById(batchId);
      res.status(Status.OK).json(await Success(batchDetail));
    } catch (e) {
      next(e);
    }
  });

  /** Batch update */
  router.patch('/:batchId', async (req, res, next) => {
    try {
      const {
        params: { batchId },
        body,
      } = req;
      await batchService.batchUpdate({ id: batchId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, BATCH_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  /** Get all batch with filter & pagination */
  router.get('/filter/list', async (req, res, next) => {
    try {
      const { query } = req;
      const batchList = await batchService.getBatchList(query);
      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  /** Create Batch mapping with User */
  router.post('/:batchId/user', async (req, res, next) => {
    try {
      const {
        params: { batchId },
        body: { users },
      } = req;
      logger.info('Create batch user mapping');
      await batchUserService.createBatchUser(batchId, users);
      let data;
      res.status(Status.OK).json(await Success(data, BATCH_MAPPED_WITH_USER_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  router.get('/:batchId/user', async (req, res, next) => {
    try {
      const {
        params: { batchId },
        query,
      } = req;
      logger.info('Get batch user mapping');
      const batchUserList = await batchUserService.getBatchUser(batchId, query);
      res.status(Status.OK).json(await Success(batchUserList));
    } catch (e) {
      next(e);
    }
  });

  /** Create Batch mapping with Quiz */
  router.post('/:batchId/quiz/:quizId', async (req, res, next) => {
    try {
      const {
        params: { batchId, quizId },
        body,
      } = req;
      logger.info('Create batch user mapping');
      await batchQuizService.createBatchQuiz(batchId, quizId, body);
      let data;
      res.status(Status.OK).json(await Success(data, BATCH_MAPPED_WITH_QUIZ_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Deactivate Batch mapping with Quiz */
  router.delete('/:batchId/quiz/:quizId', async (req, res, next) => {
    try {
      const {
        params: { batchId, quizId },
      } = req;
      logger.info('Deactivate batch user mapping');
      await batchQuizService.deactivateBatchQuiz(batchId, quizId);
      let data;
      res.status(Status.OK).json(await Success(data, BATCH_DEACTIVATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Update Batch mapping with User */
  router.patch('/:batchId/user', async (req, res, next) => {
    try {
      const {
        params: { batchId },
        body: { linked, unLinked },
      } = req;
      logger.info('Update batch user mapping');
      await batchUserService.updateBatchUsers(linked, unLinked, batchId);
      let data;
      res.status(Status.OK).json(await Success(data, BATCH_WITH_USER_MAPPING_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  /** Get EXAM Result of a  batch  */
  router.get('/:batchId/exam-result', async (req, res, next) => {
    try {
      const { query } = req;
      const {
        params: { batchId },
      } = req;
      query.batchId = batchId;
      const batchList = await batchQuizService.getAllExamResult(query);
      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  /** Get EXAM Result of a  batch  */
  router.get('/student-exam-result/:quizId/:userId', async (req, res, next) => {
    try {
      const { query } = req;
      const {
        params: { batchId, quizId, userId },
      } = req;
      query.batchId = batchId;
      query.quizId = quizId;
      query.userId = userId;
      const batchList = await batchQuizService.getAllExamResultOfStudent(query);

      res.status(Status.OK).json(await Success(batchList));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
