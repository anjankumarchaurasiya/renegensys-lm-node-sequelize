module.exports = Object.freeze({
  batch: {
    batchNumber: {
      op: '$like',
      alias: 'batch_number',
      dataType: 'STRING',
    },
    courseId: {
      op: '$eq',
      alias: 'course_id',
      dataType: 'UUID',
    },
    startDate: {
      op: '$eq',
      alias: 'start_date',
      dataType: 'DATEONLY',
    },
    endDate: {
      op: '$eq',
      alias: 'end_date',
      dataType: 'DATEONLY',
    },
    classMode: {
      op: '$eq',
      alias: 'class_mode',
      dataType: 'ENUM',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
  },
  batchUser: {
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
    roleId: {
      op: '$eq',
      alias: 'role_id',
      dataType: 'UUID',
    },
    createdAt: {
      op: ['$gte', '$lt'],
      alias: 'created_at',
      dataType: 'DATETIME',
    },
    linked: {
      op: '$eq',
      alias: 'linked',
      dataType: 'BOOLEAN',
    },
    email: {
      op: '$like',
      alias: 'email',
    },
    mobile: {
      op: '$like',
      alias: 'mobile',
    },
    dregNo: {
      op: '$like',
      alias: 'dregNo',
    },
    name: {
      op: '$like',
      alias: 'name',
    },
    linked: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
  },

  batchQuizResult: {
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
    categoryId: {
      op: '$eq',
      alias: 'category_id',
      dataType: 'UUID',
    },
    dregNo: {
      op: '$like',
      alias: 'dregNo',
      dataType: 'STRING',
    },
    name: {
      op: '$like',
      alias: 'name',
      dataType: 'STRING',
    },
    earnPoint: {
      op: '$eq',
      alias: 'earn_point',
      dataType: 'STRING',
    },
    isPassed: {
      op: '$eq',
      alias: 'is_passed',
      dataType: 'BOOLEAN',
    },
  },

  userBatchQuizResult: {
    batchId: {
      op: '$eq',
      alias: 'batch_id',
      dataType: 'UUID',
    },
    userId: {
      op: '$eq',
      alias: 'user_id',
      dataType: 'UUID',
    },
    quizId: {
      op: '$eq',
      alias: 'quiz_id',
      dataType: 'UUID',
    },
    attemptNo: {
      op: '$eq',
      alias: 'attempt_no',
      dataType: 'UUID',
    },
    earnPoint: {
      op: '$eq',
      alias: 'earn_point',
      dataType: 'STRING',
    },
    isPassed: {
      op: '$eq',
      alias: 'is_passed',
      dataType: 'BOOLEAN',
    },
  },
});
