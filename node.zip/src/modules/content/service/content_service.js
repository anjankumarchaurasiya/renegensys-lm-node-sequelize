const { define } = require('src/containerHelper');

module.exports = define('contentService', ({
  contentRepository,
  commonUtilService,
  generalUtilService,
  CustomError,
  constants: { ENTITY_ALREADY_EXISTS },
}) => {
  const createContent = async (files, contentData) => {
    const { title, uniqueId, folderName, bucketName, fileName, entityName, entityType, url, type } = contentData;

    if (files) {
      if (!entityName || !entityType) {
        throw new Error('entityName and entityType are required when files are provided');
      }
    } else {
      if (!url && !type) {
        throw new Error('Either url with type must be provided when files are not provided');
      }
    }

    const isContentExist = await contentRepository.findOne({ title: title });

    if (isContentExist) {
      throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `Content already exists with Title`);
    }
    const slug = commonUtilService.toLsUnderScore(title);
    contentData.slug = slug;

    if (files && !isContentExist) {
      const s3FileUploadResponse = await generalUtilService.uploadFile({
        files,
        bucketName,
        folderName,
        overWriteFileName: fileName,
        uniqueId,
        entityName,
        entityType,
      });
      if (s3FileUploadResponse?.Location) {
        const modifiedUrl = s3FileUploadResponse.Location.replace('s3.amazonaws.com', 'vinecrms.com');
        contentData.url = modifiedUrl;
        contentData.type = entityType;
      } else {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status, `File upload completed but Location not available.`);
      }
    } else {
      contentData.url = url;
      contentData.type = type;
    }

    const content = await contentRepository.create(contentData);
    return content;
  };
  /** Update content */
  const updateContent = async contentData => {
    const { title } = contentData;
    const content = await contentRepository.findOne({ id: contentData.id });
    if (!content) {
      throw new CustomError(UNAUTHORIZED_REQUEST.code, UNAUTHORIZED_REQUEST.status, 'Content not found');
    }
    if (title) {
      // Check if title already exists
      const slug = commonUtilService.toLsUnderScore(title);
      contentData.slug = slug;
      const isTitleExist = await contentRepository.findOne({ title: title });
      if (isTitleExist && isTitleExist.id !== contentData.id) {
        throw new CustomError(ENTITY_ALREADY_EXISTS.code, ENTITY_ALREADY_EXISTS.status.status, 'Content already exists');
      }
    }
    return await contentRepository.update(contentData, { id: contentData.id });
  };

  const bulkCreateContents = contents => contentRepository.bulkCreate(contents);

  return {
    createContent,
    updateContent,
    bulkCreateContents,
  };
});
