const { define } = require('src/containerHelper');

module.exports = define('contentRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('content');
  const contentModel = database['content'];
  const bulkCreate = data => contentModel.bulkCreate(data, { ignoreDuplicates: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
