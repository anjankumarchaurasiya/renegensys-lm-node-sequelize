const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { CONTENT_CREATED_SUCCESSFULLY, CONTENT_UPDATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    userContextMiddleware,
    auth,
    authorizeMiddleware,
  } = container.cradle;
  const { contentService, logger } = container.cradle;

  router.use(auth.authenticate(true));
  router.use(userContextMiddleware);
  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { files, body } = req;
      logger.info('Create content route');
      let data = await contentService.createContent(files, body);
      res.status(Status.OK).json(await Success(data, CONTENT_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  /** Content update */
  router.patch('/:contentId', async (req, res, next) => {
    try {
      const {
        params: { contentId },
        body,
      } = req;
      logger.info('Update content route');
      await contentService.updateContent({ id: contentId, ...body });
      let data;
      res.status(Status.OK).json(await Success(data, CONTENT_UPDATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });
  return router;
};
