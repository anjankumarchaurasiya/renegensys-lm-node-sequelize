'use strict';

module.exports = (sequelize, DataTypes) => {
  const Content = sequelize.define(
    'content',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      title: {
        type: DataTypes.STRING,
        unique: true,
      },
      slug: {
        type: DataTypes.STRING,
      },
      type: {
        type: DataTypes.STRING,
      },
      description: {
        type: DataTypes.STRING,
      },
      url: {
        type: DataTypes.STRING,
        required: true,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      createdAt: {
        type: 'TIMESTAMP',
      },
      updatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Content.associate = function(models) {
    Content.belongsToMany(models.topic, {
      through: models.topic_content,
      foreignKey: 'contentId',
      otherKey: 'topicId',
    });
    Content.belongsToMany(models.question, {
      through: models.question_content,
      foreignKey: 'contentId',
      otherKey: 'questionId',
    });
  };

  return Content;
};
