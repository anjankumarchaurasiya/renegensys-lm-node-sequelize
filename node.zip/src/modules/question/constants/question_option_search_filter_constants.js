module.exports = Object.freeze({
  questionOption: {
    option: {
      op: '$like',
      alias: 'option',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
  },
});
