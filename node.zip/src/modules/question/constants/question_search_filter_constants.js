module.exports = Object.freeze({
  question: {
    question: {
      op: '$like',
      alias: 'question',
      dataType: 'STRING',
    },
    recordStatus: {
      op: '$eq',
      alias: 'record_status',
      dataType: 'BOOLEAN',
    },
  },
});
