module.exports = (sequelize, DataTypes) => {
  const Question = sequelize.define(
    'question',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      categoryId: {
        type: DataTypes.UUID,
      },
      question: {
        type: DataTypes.STRING,
      },
      questionType: {
        type: DataTypes.STRING,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  Question.associate = function(models) {
    Question.belongsTo(models.quiz, {
      foreignKey: 'quizId',
      sourceKey: 'id',
    });
    Question.belongsTo(models.category, {
      foreignKey: 'categoryId',
      sourceKey: 'id',
    });

    Question.belongsToMany(models.quiz, {
      through: models.quiz_question,
      foreignKey: 'questionId',
      otherKey: 'quizId',
    });
    Question.hasMany(models.quiz_question, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });

    Question.hasMany(models.question_option, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
    Question.hasMany(models.user_response, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
    Question.belongsToMany(models.content, {
      through: models.question_content,
      foreignKey: 'questionId',
      otherKey: 'contentId',
    });
    Question.hasMany(models.question_content, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
    Question.hasMany(models.learning_session_feedback_user_response, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
    Question.hasMany(models.batch_feedback_user_response, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
  };

  return Question;
};
