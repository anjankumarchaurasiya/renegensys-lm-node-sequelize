'use strict';

module.exports = (sequelize, DataTypes) => {
  const QuestionContent = sequelize.define(
    'question_content',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      questionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      contentId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
      deactivatedBy: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );
  QuestionContent.associate = function(models) {
    QuestionContent.belongsTo(models.question, {
      foreignKey: 'questionId',
      targetKey: 'id',
    });
    QuestionContent.belongsTo(models.content, {
      foreignKey: 'contentId',
      targetKey: 'id',
    });
  };
  return QuestionContent;
};
