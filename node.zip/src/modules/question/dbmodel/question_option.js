module.exports = (sequelize, DataTypes) => {
  const QuestionOption = sequelize.define(
    'question_option',
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
      },
      questionId: {
        type: DataTypes.UUID,
        allowNull: false,
      },
      option: {
        type: DataTypes.STRING,
      },
      order: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.STRING,
      },
      isCorrectOption: {
        type: DataTypes.BOOLEAN,
      },
      recordStatus: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      deactivatedAt: {
        type: 'TIMESTAMP',
      },
    },
    {
      freezeTableName: true,
      timestamps: true,
    }
  );

  QuestionOption.associate = function(models) {
    QuestionOption.belongsTo(models.question, {
      foreignKey: 'questionId',
      sourceKey: 'id',
    });
    QuestionOption.hasMany(models.user_response, {
      foreignKey: 'questionOptionId',
      sourceKey: 'id',
    });
    QuestionOption.hasMany(models.learning_session_feedback_user_response, {
      foreignKey: 'questionOptionId',
      sourceKey: 'id',
    });
    QuestionOption.hasMany(models.batch_feedback_user_response, {
      foreignKey: 'questionOptionId',
      sourceKey: 'id',
    });
  };

  return QuestionOption;
};
