const { define } = require('src/containerHelper');

module.exports = define('questionOptionService', ({ questionOptionRepository }) => {
  const createQuestionOption = async data => {
    const questionOption = await questionOptionRepository.create(data);
    return questionOption;
  };
  const bulkCreateQuestionOption = questions => questionOptionRepository.bulkCreate(questions);

  return {
    bulkCreateQuestionOption,
  };
});
