const { define } = require('src/containerHelper');

module.exports = define('questionService', ({ questionRepository }) => {
  const createQuestion = async data => {
    const question = await questionRepository.create(data);
    return question;
  };

  const bulkCreateQuestion = questions => questionRepository.bulkCreate(questions);

  return {
    createQuestion,
    bulkCreateQuestion,
  };
});
