const { define } = require('src/containerHelper');

module.exports = define('questionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('question');
  const questionModel = database['question'];

  const bulkCreate = data => questionModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
