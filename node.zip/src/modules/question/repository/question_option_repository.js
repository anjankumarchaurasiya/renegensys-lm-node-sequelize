const { define } = require('src/containerHelper');

module.exports = define('questionOptionRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('question_option');
  const questionOptionModel = database['question_option'];

  const bulkCreate = data => questionOptionModel.bulkCreate(data, { ignoreDuplicate: true });

  return {
    ...baseRepo,
    bulkCreate,
  };
});
