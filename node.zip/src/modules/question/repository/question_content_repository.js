const { define } = require('src/containerHelper');

module.exports = define('questionContentRepository', ({ database, baseRepositoryV2 }) => {
  const baseRepo = baseRepositoryV2('question_content');
  const questionContentModel = database['question_content'];

  const bulkCreate = data => {
    questionContentModel.bulkCreate(data, {
      ignoreDuplicates: true,
    });
  };
  return {
    ...baseRepo,
    bulkCreate,
  };
});
