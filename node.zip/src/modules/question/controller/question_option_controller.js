const { Router } = require('express');
const Status = require('http-status');
const container = require('src/container');
const { QUESTION_OPTION_CREATED_SUCCESSFULLY } = require('src/constants');
module.exports = () => {
  const router = Router();
  const {
    response: { Success, Fail },
    auth,
  } = container.cradle;
  const { questionOptionService, logger, userContextMiddleware, authorizeMiddleware } = container.cradle;

  router.use(auth.authenticate(true));

  router.use(userContextMiddleware);

  router.use(authorizeMiddleware);

  router.post('/', async (req, res, next) => {
    try {
      const { body } = req;
      logger.info('Create question option route');
      await questionOptionService.createQuestionOption(body);
      let data;
      res.status(Status.OK).json(await Success(data, QUESTION_OPTION_CREATED_SUCCESSFULLY));
    } catch (e) {
      next(e);
    }
  });

  return router;
};
