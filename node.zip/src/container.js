const awilix = require('awilix');
const { scopePerRequest } = require('awilix-express');
const server = require('./interfaces/http/server');
const router = require('./interfaces/http/router');
const app = require('./app');
const auth = require('./interfaces/http/auth');
const config = require('../config');
const database = require('./infra/database');
const logger = require('./infra/logging');
const jwt = require('./infra/jwt');
const response = require('./infra/support/response');
const healthCheckService = require('./infra/health-check');
const axiosWrapper = require('./infra/support/axios_wrapper');
const constants = require('./constants');
const CustomError = require('./infra/error');
const transactionDecorator = require('./infra/transaction');
const sessionHook = require('./infra/hook');
const md5 = require('./infra/md5');
const passwordEncryption = require('./infra/encryption');
const loggerMiddleware = require('./interfaces/http/middlewares/http_logger');
const errorHandlerMiddleware = require('./interfaces/http/middlewares/error_handler');
const authorizeHandlerMiddleware = require('./interfaces/http/middlewares/authorize_handler');
const validatorMiddleware = require('./interfaces/http/middlewares/validationMiddleware');
const userContextMiddleware = require('./interfaces/http/middlewares/userContextMiddleware');
const awsService = require('./infra/aws');
const mongoDBConn = require('./infra/no-sql-database/index.js');
const redis = require('./infra/caching');
const baseRepositoryV2 = require('./infra/sequelize/base_v2_repository');
const routeContextMiddleware = require('./interfaces/http/middlewares/routeContextMiddleware');
const requestClient = require('./infra/support/request_client');

const { createContainer, asFunction, asValue, Lifetime, InjectionMode, asClass } = awilix;

const container = createContainer({
  injectionMode: InjectionMode.PROXY,
});

// System
container
  .register({
    app: asFunction(app).singleton(),
    server: asFunction(server).singleton(),
  })
  .register({
    router: asFunction(router).singleton(),
    logger: asFunction(logger).singleton(),
  })
  .register({
    config: asValue(config),
    constants: asValue(constants),
  });

// Middlewares
container
  .register({
    loggerMiddleware: asFunction(loggerMiddleware).singleton(),
  })
  .register({
    containerMiddleware: asValue(scopePerRequest(container)),
    errorHandlerMiddleware: asFunction(errorHandlerMiddleware),
  })
  .register({
    routeContextMiddleware: asFunction(routeContextMiddleware).singleton(),
    userContextMiddleware: asFunction(userContextMiddleware).singleton(),
    validatorMiddleware: asFunction(validatorMiddleware).singleton(),
    authorizeMiddleware: asFunction(authorizeHandlerMiddleware).singleton(),
    baseRepositoryV2: asFunction(baseRepositoryV2).singleton(),
  });
// Database
container.register({
  mongoDBConn: asFunction(mongoDBConn).singleton(),
  database: asFunction(database).singleton(),
  redisClient: asFunction(redis).singleton(),
});

// Infra
container.register({
  auth: asFunction(auth).singleton(),
  jwt: asFunction(jwt).singleton(),
  response: asFunction(response).singleton(),
  healthCheckService: asFunction(healthCheckService).singleton(),
  axiosWrapper: asFunction(axiosWrapper).singleton(),
  requestClient: asFunction(requestClient).singleton(),
  CustomError: asFunction(CustomError).singleton(),
  awsService: asFunction(awsService).singleton(),
  md5: asFunction(md5).singleton(),
  passwordEncryption: asFunction(passwordEncryption).singleton(),
  transactionDecorator: asFunction(transactionDecorator).singleton(),
  sessionHook: asFunction(sessionHook).singleton(),
});

container.loadModules(['modules/**/repository/*.js'], {
  resolverOptions: {
    register: asFunction,
    lifetime: Lifetime.SINGLETON,
  },
  cwd: __dirname,
});

container.loadModules(['modules/**/dbmodel/mongo/*.js'], {
  resolverOptions: {
    register: asFunction,
    lifetime: Lifetime.SINGLETON,
  },
  cwd: __dirname,
});

container.loadModules(['infra/**/no-sql-db-model/*.js'], {
  resolverOptions: {
    register: asFunction,
    lifetime: Lifetime.SINGLETON,
  },
  cwd: __dirname,
});

container.loadModules(['modules/**/service/*.js'], {
  resolverOptions: {
    register: asFunction,
    lifetime: Lifetime.SINGLETON,
  },
  cwd: __dirname,
});
module.exports = container;
