/* eslint-disable */
module.exports = ({ database }) => {
  const sequelize = database.sequelize;
  const transaction = fn => async (...args) => {
    return await sequelize.transaction(t => fn(...args));
  };

  return {
    transaction,
  };
};
