const { compose, trim, replace, partialRight } = require('ramda');
const jsonwebtoken = require('jsonwebtoken');
const { sign, verify: _verify, decode: _decode } = jsonwebtoken;

module.exports = ({ config, redisClient }) => ({
  signin: options => payload => {
    const opt = Object.assign({}, options);
    const pData = {
      id: payload.id,
      type: payload.type,
    };
    redisClient.setKey(payload.type + '_' + payload.id, payload);
    return sign(pData, config.authAccessSecret, opt);
  },
  verify: options => token => {
    const opt = Object.assign({}, options);
    return _verify(token, config.authAccessSecret, opt);
  },
  decode: options => token => {
    const opt = Object.assign({}, options);
    const decodeToken = compose(partialRight(_decode, [opt]), trim, replace(/JWT|jwt/g, ''));

    return decodeToken(token);
  },
  signInWithSignature: (options, signature) => payload => {
    const opt = Object.assign({}, options);
    const pData = {
      id: payload.id,
      type: payload.type,
    };
    redisClient.setKey(payload.type + '_' + payload.id, payload);
    return sign(pData, signature, opt);
  },
});
