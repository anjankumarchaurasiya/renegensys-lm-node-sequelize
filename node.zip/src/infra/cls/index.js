const httpContext = require('express-http-context');

module.exports = () => {
  const setUserContext = (user) => httpContext.set('currentUser', user);

  const getUserContext = () => httpContext.get('currentUser');

  const setRequestId = (id) => httpContext.set('requestId', id);

  const getRequestId = () => httpContext.get('requestId');

  const setResourceContext = (resource) => httpContext.set('resource', resource);

  const getResourceContext = () => httpContext.get('resource');

  const setPagination = (pageNo, pageSize) => {
    const PAGE_SIZE_LIMIT = 50;
    if (pageNo && pageSize) {
      pageNo = parseInt(pageNo, 10);
      pageSize = parseInt(pageSize, 10);
      pageSize = pageSize > PAGE_SIZE_LIMIT ? PAGE_SIZE_LIMIT : pageSize;
      const limit = pageSize;
      const offset = pageNo === 1 ? 0 : limit * --pageNo;
      httpContext.set('limit', limit);
      httpContext.set('offset', offset);
    }
  };

  const getPagination = () => ({
    limit: httpContext.get('limit'),
    offset: httpContext.get('offset'),
  });

  const setRequestBody = (body) => httpContext.set('requestBody', body);

  const getRequestBody = () => httpContext.get('requestBody');

  const setRequestQuery = (query) => httpContext.set('requestQuery', query);

  const getRequestQuery = () => httpContext.get('requestQuery');

  const setRequestParams = (query) => httpContext.set('requestParams', query);

  const getRequestParams = () => httpContext.get('requestParams');

  const setRequestIp = (requestIp) => httpContext.set('requestIp', requestIp);

  const getRequestIp = () => httpContext.get('requestIp');

  const getAllContext = () => ({
    meta: { user: getUserContext() },
    requestId: getRequestId(),
    request: {
      resource: getResourceContext(),
      body: getRequestBody(),
      query: getRequestQuery(),
      params: getRequestParams(),
      requestIp: getRequestIp()
    },
  });

  const setAllContext = ({ meta, request, requestId }) => {
    setUserContext(meta.user);
    setRequestId(requestId);
    setResourceContext(request.resource);
    setRequestBody(request.body);
    setRequestQuery(request.query);
    setRequestParams(request.params);
    setRequestIp(request.requestIp);
  };

  return {
    setUserContext,
    getUserContext,
    setRequestId,
    getRequestId,
    setResourceContext,
    getResourceContext,
    getAllContext,
    setAllContext,
    setPagination,
    getPagination,
    setRequestBody,
    getRequestBody,
    setRequestQuery,
    getRequestQuery,
    setRequestParams,
    getRequestParams,
    setRequestIp,
    getRequestIp
  };
};
