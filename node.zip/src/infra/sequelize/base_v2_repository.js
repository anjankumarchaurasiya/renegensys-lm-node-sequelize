const { Error } = require('sequelize');
const { define } = require('src/containerHelper');
module.exports = define('baseRepositoryV2', ({ database, CustomError, constants: { RUNTIME_ERROR } }) => {
  const create = function(data, modelName) {
    return database[modelName || this.defaultModelName].create(data);
  };
  const findAllBy = function(attributesArr, search, modelName) {
    return database[modelName || this.defaultModelName].findAll({
      attributes: attributesArr,
      where: search,
    });
  };
  const findAll = function(query, modelName) {
    return database[modelName || this.defaultModelName].findAll({
      where: query,
    });
  };
  const findBy = function(attributesArr, search, modelName) {
    return database[modelName || this.defaultModelName].findOne({
      attributes: attributesArr,
      where: search,
    });
  };
  const findOne = function(search, modelName) {
    return database[modelName || this.defaultModelName].findOne({
      where: search,
    });
  };
  const findAndCountAll = function(attributesArr, search, orderBy, limit, offset, modelName) {
    let finalClause = {
      where: search,
    };
    if (attributesArr) {
      finalClause.attributes = attributesArr;
    }
    if ((offset || offset == 0) && limit) {
      finalClause.offset = offset;
      finalClause.limit = limit;
    }
    if (orderBy) {
      finalClause.order = orderBy;
    }
    return database[modelName || this.defaultModelName].findAndCountAll(finalClause);
  };

  const update = function(data, whereClause, modelName) {
    return database[modelName || this.defaultModelName].update(data, {
      where: whereClause,
      individualHooks: true,
    });
  };
  const deactivate = function(whereClause, modelName) {
    return database[modelName || this.defaultModelName].update(
      {
        recordStatus: 0,
        deactivatedAt: new Date(),
      },
      {
        where: whereClause,
        individualHooks: true,
      }
    );
  };

  const findAndDeactivate = async function(whereClause, modelName) {
    const record = await database[modelName || this.defaultModelName].findOne({
      where: whereClause,
    });
    if (record != null) {
      return database[modelName || this.defaultModelName].update(
        {
          recordStatus: 0,
          deactivatedAt: new Date(),
        },
        {
          where: whereClause,
          individualHooks: true,
        }
      );
    } else throw new CustomError(RUNTIME_ERROR.code, RUNTIME_ERROR.status, 'Record Not found');
  };
  const getModel = function(modelName) {
    return database[modelName || this.defaultModelName];
  };

  const increment = function(colName, incrementBy, whereClause, modelName) {
    return database[modelName || this.defaultModelName].increment(colName, { by: incrementBy, where: { recordStatus: 1, ...whereClause } });
  };
  return defaultModelName => {
    const modelProto = {
      defaultModelName,
    };
    return {
      getModel: getModel.bind(modelProto),
      create: create.bind(modelProto),
      findAllBy: findAllBy.bind(modelProto),
      findAll: findAll.bind(modelProto),
      findBy: findBy.bind(modelProto),
      findOne: findOne.bind(modelProto),
      findAndCountAll: findAndCountAll.bind(modelProto),
      update: update.bind(modelProto),
      deactivate: deactivate.bind(modelProto),
      increment: increment.bind(modelProto),
      findAndDeactivate: findAndDeactivate.bind(modelProto),
    };
  };
});
