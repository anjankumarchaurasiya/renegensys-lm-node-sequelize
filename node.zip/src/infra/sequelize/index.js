const path = require('path');
const Sequelize = require('sequelize');
const cls = require('continuation-local-storage');
const opAlias = require('./operatorAlias');
const { readdirSync } = require('fs');
const httpContext = require('express-cls-hooked');
const fs = require('fs');
const CircularJSON = require('circular-json');
const decamelize = require('decamelize');
const operatorsAliasesFu = opAlias.operatorsAliases;
const namespace = cls.createNamespace('transaction-namespace');
Sequelize.useCLS(namespace);
const basename = path.basename(__filename);
module.exports = ({ config, basePath, logger, generalUtilService }) => {
  let sequelize;
  const db = {};
  db.models = {};
  const Op = Sequelize.Op;

  if (config.use_env_variable) {
    sequelize = new Sequelize(process.env[config.use_env_variable], {
      operatorsAliases: operatorsAliasesFu(Op),
      ...config,
    });
  } else {
    sequelize = new Sequelize(config.database, config.username, config.password, {
      operatorsAliases: operatorsAliasesFu(Op),
      ...config,
      benchmark: true,
      // logging: str => {
      //   logger.info(CircularJSON.stringify(str));
      // },
      logging: (msg, executionTime) => {
        if (msg.length < 5000) {
          logger.info(`${CircularJSON.stringify(msg)} ExecutionTime: ${executionTime} ms`);
        }
      },
    });
  }

  sequelize.addHook('beforeDefine', attributes => {
    Object.keys(attributes).forEach(key => {
      if (typeof attributes[key] !== 'function') {
        attributes[key].field = decamelize(key);
      }
    });
  });

  const dir = path.join(basePath, './models');

  readdirSync(dir)
    .filter(file => {
      return file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js';
    })
    .forEach(file => {
      const model = sequelize['import'](path.join(dir, file));
      db[model.name] = model;
    });

  const getDirectories = source =>
    readdirSync(source, { withFileTypes: true })
      .filter(dirent => dirent.isDirectory())
      .map(dirent => dirent.name);

  const dirs = [];
  const modulePath = path.join(__dirname, '/../../modules');
  const allDirs = getDirectories(modulePath);

  allDirs.forEach(m => {
    dirs.push(path.join(modulePath, m, '/dbmodel'));
  });
  for (const i in dirs) {
    const dir = dirs[i];
    if (!fs.existsSync(dir)) continue;
    fs.readdirSync(dir)
      .filter(file => {
        return file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js';
      })
      .forEach(file => {
        const model = sequelize['import'](path.join(dir, file));
        db[model.name] = model;
      });
  }
  Object.keys(db).forEach(modelName => {
    if (db[modelName].associate) {
      db[modelName]['created_by'] = {
        type: Sequelize.UUID,
      };
      db[modelName]['updated_by'] = {
        type: Sequelize.UUID,
      };
      db[modelName].addHook('beforeCreate', (schema, options) => {
        const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
        //const loggedInCgEntity = httpContext.get('currentCgEntity');
        if (loggedInUser) {
          const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;
          !schema.createdBy && schema.setDataValue('createdBy', loggedInUserId);
          !schema.updatedBy && schema.setDataValue('updatedBy', loggedInUserId);
        }
      });
      db[modelName].addHook('beforeBulkUpdate', (schema, options) => {
        const loggedInUser = httpContext.get('loggedInUser');
        if (loggedInUser) {
          const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;
          if (schema.fields.includes('updatedBy') || schema.fields.includes('updated_by')) {
            schema.fields.push('updatedBy');
            schema.attributes.updatedBy = loggedInUserId;
          }
        }
      });
      const Model = db[modelName];

      /****  start - Log the instance data into the Audit table using createLog method ****/
      db[modelName].addHook('afterCreate', async (instance, options) => {
        try {
          const Audit = db['audit'];
          const previousData = await Model.findByPk(instance.id);
          const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
          const resourceType = httpContext.get('resource')
            ? httpContext.get('resource').description
              ? httpContext.get('resource').description
              : 'Create'
            : null;

          if (loggedInUser) {
            const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;
            await Audit.create({
              userId: loggedInUserId,
              entity: modelName,
              action: resourceType,
              previousData: JSON.stringify(previousData),
              updatedData: JSON.stringify(instance.toJSON()),
            });
          }
        } catch (error) {
          console.error(`Error in afterCreate hook for ${modelName}: ${error.message}`);
        }
      });
      db[modelName].addHook('afterUpdate', async (instance, options) => {
        try {
          const Audit = db['audit'];
          const previousData = await Model.findByPk(instance.id);
          const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
          const resourceType = httpContext.get('resource')
            ? httpContext.get('resource').description
              ? httpContext.get('resource').description
              : 'Update'
            : null;

          if (loggedInUser) {
            const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;
            await Audit.create({
              userId: loggedInUserId,
              entity: modelName,
              action: resourceType,
              previousData: JSON.stringify(previousData),
              updatedData: JSON.stringify(instance.toJSON()),
            });
          }
        } catch (error) {
          console.error(`Error in afterUpdate hook for ${modelName}:`, error);
        }
      });
      db[modelName].addHook('afterDestroy', async (instance, options) => {
        try {
          const Audit = db['audit'];
          const previousData = await Model.findByPk(instance.id);
          const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
          const resourceType = httpContext.get('resource')
            ? httpContext.get('resource').description
              ? httpContext.get('resource').description
              : 'Delete'
            : null;

          if (loggedInUser) {
            const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;
            await Audit.create({
              userId: loggedInUserId,
              entity: modelName,
              action: resourceType,
              previousData: JSON.stringify(previousData),
              updatedData: JSON.stringify(instance.toJSON()),
            });
          }
        } catch (error) {
          console.error(`Error in afterDestroy hook for ${modelName}:`, error);
        }
      });
      /** Bulk function  **/
      db[modelName].addHook('afterBulkCreate', async (instances, options) => {
        try {
          const Audit = db['audit'];
          const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
          const resourceType = httpContext.get('resource')
            ? httpContext.get('resource').description
              ? httpContext.get('resource').description
              : 'Bulk Create'
            : null;

          if (loggedInUser) {
            const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;

            if (Array.isArray(instances)) {
              const logs = instances.map(instance => {
                const previousData = Model.findByPk(instance.id);
                return {
                  userId: loggedInUserId,
                  entity: modelName,
                  action: resourceType,
                  previousData: JSON.stringify(previousData),
                  updatedData: JSON.stringify(instance.toJSON()),
                };
              });
              await Audit.bulkCreate(logs);
            }
          }
        } catch (error) {
          console.error(`Error in afterBulkCreate hook for ${modelName}: ${error.message}`);
        }
      });
      db[modelName].addHook('afterBulkUpdate', async (instances, options) => {
        try {
          const Audit = db['audit'];

          const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
          const resourceType = httpContext.get('resource')
            ? httpContext.get('resource').description
              ? httpContext.get('resource').description
              : 'Bulk Update'
            : null;
          if (loggedInUser) {
            const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;

            if (Array.isArray(instances)) {
              const logs = instances.map(instance => {
                const previousData = Model.findByPk(instance.id);
                return {
                  userId: loggedInUserId,
                  entity: modelName,
                  action: resourceType,
                  previousData: JSON.stringify(previousData),
                  updatedData: JSON.stringify(instance.toJSON()),
                };
              });
              await Audit.bulkCreate(logs);
            }
          }
        } catch (error) {
          console.error(`Error in afterBulkUpdate hook for ${modelName}:`, error);
        }
      });
      db[modelName].addHook('afterBulkDestroy', async (instances, options) => {
        try {
          const Audit = db['audit'];
          const loggedInUser = httpContext.get('loggedInUser') ? httpContext.get('loggedInUser') : null;
          const resourceType = httpContext.get('resource')
            ? httpContext.get('resource').description
              ? httpContext.get('resource').description
              : 'Bulk Delete'
            : null;

          if (loggedInUser) {
            const loggedInUserId = loggedInUser.id ? loggedInUser.id : null;

            if (Array.isArray(instances)) {
              const logs = instances.map(instance => {
                const previousData = Model.findByPk(instance.id);
                return {
                  userId: loggedInUserId,
                  entity: modelName,
                  action: resourceType,
                  previousData: JSON.stringify(previousData),
                  updatedData: JSON.stringify(instance.toJSON()),
                };
              });
              await Audit.bulkCreate(logs);
            }
          }
        } catch (error) {
          console.error(`Error in afterBulkDestroy hook for ${modelName}:`, error);
        }
      });
      /**  end - Log the instance data into the Audit table using createLog method **/
      db[modelName].associate(db);
    }
  });
  db.sequelize = sequelize;
  db.Sequelize = Sequelize;

  return db;
};
