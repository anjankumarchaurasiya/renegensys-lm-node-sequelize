const httpContext = require('express-cls-hooked');
const cls = require('cls-hooked');
const nsid = 'a6a29a6f-6747-4b5f-b99f-07ee96e32f88';
const AWS = require('aws-sdk');
const uuidv4 = require('uuid/v4');
const PromiseBlueBird = require('bluebird');
const fs = require('fs');

module.exports = ({ config, logger, healthCheckService, CustomError, constants: { awsConstants } }) => {
  const SQS_CONNECT_TIMEOUT = process.env.SQS_CONNECT_TIMEOUT || 2000;
  // const SQS_MAX_RETRIES = process.env.SQS_MAX_RETRIES || 1

  AWS.config.update({
    accessKeyId: config.AWS_ACCESS_KEY,
    secretAccessKey: config.AWS_SECRET_KEY,
    region: config.AWS_REGION,
  });

  const queueUrlConfig = {};
  const listnerConfig = {};

  const sendToQueue = async (queueName, message) => {
    const sqs = new AWS.SQS({
      apiVersion: '2012-11-05',
    });
    let queueUrl = queueUrlConfig[queueName];
    if (!queueUrl) {
      queueUrl = await getQueueUrlFromName(queueName);
      queueUrlConfig[queueName] = queueUrl;
    }
    const params = {
      MessageBody: JSON.stringify(message),
      QueueUrl: queueUrl,
      MessageGroupId: '2',
    };
    const result = await sqs.sendMessage(params).promise();
    return result;
  };
  const getQueueUrlFromName = async queueName => {
    const sqs = new AWS.SQS({
      apiVersion: '2012-11-05',
    });
    let params = {
      QueueName: queueName,
    };
    let queueUrl = null;
    let queueResult = null;
    try {
      queueResult = await sqs.getQueueUrl(params).promise();
      queueUrl = queueResult.QueueUrl;
      return queueUrl;
    } catch (e) {
      await createQueue(queueName, {
        ReceiveMessageWaitTimeSeconds: '5',
      });
      queueResult = await sqs.getQueueUrl(params).promise();
      queueUrl = queueResult.QueueUrl;
      return queueUrl;
    }
  };

  const createQueue = (queueName, attributes) => {
    const sqs = new AWS.SQS({
      apiVersion: '2012-11-05',
    });
    const params = {
      QueueName: queueName,
      Attributes: { ...attributes, FifoQueue: 'true', ContentBasedDeduplication: 'true' },
    };

    return sqs.createQueue(params).promise();
  };

  const sqsMiddleware = async (message, next) => {
    const ns = cls.getNamespace(nsid) || cls.createNamespace(nsid);
    return ns.runAndReturn(() => next(message));
  };
  const setRequestContext = async (messageId, messageObj, fn) => {
    if (!messageObj.data.context) {
      messageObj.data.context = {
        request_id: uuidv4(),
      };
    }
    if (httpContext) {
      httpContext.set('MessageId', messageId);
      for (let i in messageObj.data.context) {
        httpContext.set(i, messageObj.data.context[i]);
      }
    }
    return fn(messageObj);
  };

  const uploadFileOnS3 = (s3bucket, fileName, file, contentType) => {
    const s3 = new AWS.S3({ apiVersion: '2006-03-01' });

    return new Promise((resolve, reject) => {
      try {
        // Initiate multipart upload
        s3.createMultipartUpload({ Bucket: s3bucket, Key: fileName, ContentType: contentType }, (initErr, multipart) => {
          if (initErr) {
            reject(initErr); // Reject with the initiation error
            return;
          }
          const uploadId = multipart.UploadId;
          const buffer = fs.readFileSync(file.path);
          const partSize = 1024 * 1024 * 5; // Minimum 5MB per chunk
          let partNumber = 0;
          let completedParts = [];

          // Upload parts
          for (let rangeStart = 0; rangeStart < buffer.length; rangeStart += partSize) {
            partNumber++;
            const end = Math.min(rangeStart + partSize, buffer.length);
            const partParams = {
              Body: buffer.slice(rangeStart, end),
              Bucket: s3bucket,
              Key: fileName,
              PartNumber: String(partNumber),
              UploadId: uploadId,
            };
            // Upload a single part
            s3.uploadPart(partParams, (uploadErr, data) => {
              if (uploadErr) {
                reject(uploadErr); // Reject with the upload error
                return;
              }
              // Capture ETag of completed part
              completedParts.push({ ETag: data.ETag, PartNumber: partParams.PartNumber });

              if (partNumber * partSize >= buffer.length) {
                // Sort the completed parts array by part number
                completedParts.sort((a, b) => parseInt(a.PartNumber) - parseInt(b.PartNumber));

                // Complete multipart upload when all parts are uploaded
                const completeParams = {
                  Bucket: s3bucket,
                  Key: fileName,
                  MultipartUpload: {
                    Parts: completedParts,
                  },
                  UploadId: uploadId,
                };
                s3.completeMultipartUpload(completeParams, (completeErr, completeData) => {
                  if (completeErr) {
                    reject(completeErr); // Reject with the completion error
                  } else {
                    if (completeData.Location) {
                      resolve(completeData);
                    } else {
                      reject(new Error('File upload completed but Location not available.'));
                    }
                  }
                });
              }
            });
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  };

  const getPreSignedUrlForDownload = async (bucketName, fileName, expiryTime) => {
    let signedUrl = null;
    const s3 = new AWS.S3({
      signatureVersion: 'v4',
    });

    const params = {
      Bucket: bucketName,
      Key: fileName,
      Expires: expiryTime,
    };

    try {
      signedUrl = await s3.getSignedUrlPromise('getObject', params);
    } catch (err) {
      logger.error('Error creating presigned URL for fileName: ' + fileName, err);
    }
    return signedUrl;
  };

  const subscribeQueue = (listener, queueName, eventMethod, QueueParams = {}) => {
    listnerConfig[queueName] = listener;

    registerLongPolling(listener, queueName, eventMethod, QueueParams);
  };

  const registerLongPolling = async (listener, queueName, eventMethod, QueueParams) => {
    try {
      const sqs = new AWS.SQS({ apiVersion: '2012-11-05', httpOptions: { connectTimeout: SQS_CONNECT_TIMEOUT } });
      let queueUrl = queueUrlConfig[queueName];
      if (!queueUrlConfig[queueName]) {
        queueUrl = await getQueueUrlFromName(queueName);
        queueUrlConfig[queueName] = queueUrl;
      }

      const params = {
        AttributeNames: ['SentTimestamp'],
        MaxNumberOfMessages: QueueParams.MaxNumberOfMessages || 10,
        MessageAttributeNames: ['All'],
        QueueUrl: queueUrl,
        WaitTimeSeconds: QueueParams.WaitTimeSeconds || 10,
        VisibilityTimeout: QueueParams.VisibilityTimeout || 60,
      };

      if (process.env.IS_QUEUE_PROCESSING_ENABLED != undefined && process.env.IS_QUEUE_PROCESSING_ENABLED === 'false') {
        logger.info(`subscribe to queue ${queueName} is stopped from server as IS_QUEUE_PROCESSING_ENABLED is false`);
      } else {
        const healthCheckStatus = await healthCheckService.getState();
        logger.info(`subscribe to queue ${queueName} is done with read status as ${healthCheckStatus}`);
        // eslint-disable-next-line no-unmodified-loop-condition
        while (healthCheckStatus === 'ACTIVE') {
          const data = await sqs.receiveMessage(params).promise();
          if (data.Messages && data.Messages.length > 0) {
            logger.info(`message received from queue ${queueName} length ${data.Messages.length} ${JSON.stringify(data)}`);
            const processed = [];

            await PromiseBlueBird.map(
              data.Messages,
              async processMessage => {
                await sqsMiddleware(processMessage, async function(message) {
                  try {
                    const messageObj = JSON.parse(message.Body);
                    if (messageObj.data) {
                      messageObj.awsSQSMessageId = message.MessageId;
                      await setRequestContext(message.MessageId, messageObj, async function(messageObj) {
                        logger.info(`message queue info ${queueName}, ${`handleEvent${eventMethod}`}`);
                        await listener[`handleEvent${eventMethod}`](messageObj);
                      });
                      processed.push(message);
                    }
                  } catch (err) {
                    if (err instanceof CustomError) {
                      logger.info(`Custom error in message queue info ${queueName} ${JSON.stringify(message)}`, err);
                    } else {
                      let messageBody = JSON.parse(message.Body);
                      logger.error(`Error in message queue info ${queueName} ${messageBody.notificationName} ${JSON.stringify(message)}`, err);
                    }
                  }
                });
              },
              { concurrency: QueueParams.concurrency || 10 }
            );
            if (processed.length > 0) {
              const result = await deleteMessage(sqs, processed, queueUrl);
              logger.info(
                `Deleting message queue info ${queueName} length ${processed.length} ${JSON.stringify(processed)} ${JSON.stringify(result)}`
              );
            }
          }
        }
      }
    } catch (ex) {
      logger.error('exception while registering for long polling', ex);
      throw ex;
    }
  };

  const deleteMessage = async (sqs, messages, queueURL) => {
    try {
      const deleteParams = {
        QueueUrl: queueURL,
        Entries: [],
      };
      for (let i in messages) {
        deleteParams.Entries.push({ Id: i, ReceiptHandle: messages[i].ReceiptHandle });
      }
      return sqs.deleteMessageBatch(deleteParams).promise();
    } catch (err) {
      logger.info('Error in deletting message from queue' + queueURL, err);
    }
  };

  const generateOutputGroupSettings = (folderName, bucketName) => {
    const destination = `s3://${bucketName}/${folderName}/${folderName}_avc/`;
    return {
      ManifestDurationFormat: 'INTEGER',
      SegmentLength: 3,
      TimedMetadataId3Period: 10,
      CaptionLanguageSetting: 'OMIT',
      Destination: destination,
      TimedMetadataId3Frame: 'PRIV',
      CodecSpecification: 'RFC_4281',
      OutputSelection: 'MANIFESTS_AND_SEGMENTS',
      ProgramDateTimePeriod: 600,
      MinSegmentLength: 0,
      DirectoryStructure: 'SINGLE_DIRECTORY',
      ProgramDateTime: 'EXCLUDE',
      SegmentControl: 'SEGMENTED_FILES',
      ManifestCompression: 'NONE',
      ClientCache: 'ENABLED',
      StreamInfResolution: 'INCLUDE',
    };
  };

  const generateMediaConvertTemplateParam = (role, jobTemplate, queue, uploadedVideoLocation, bucketName) => {
    try {
      const videoLocation = uploadedVideoLocation.split('/');
      videoLocation.pop();
      const folderName = videoLocation.pop();
      const outputGroupSettings = generateOutputGroupSettings(folderName, bucketName);

      const params = {
        JobTemplate: jobTemplate,
        Queue: queue,
        UserMetadata: {},
        Role: role,
        Settings: {
          OutputGroups: [
            {
              Name: 'Apple HLS',
              Outputs: awsConstants.MEDIACONVERT_OUTPUT_FORMAT,
              OutputGroupSettings: {
                Type: 'HLS_GROUP_SETTINGS',
                HlsGroupSettings: outputGroupSettings,
              },
            },
          ],
          AdAvailOffset: 0,
          Inputs: [
            {
              AudioSelectors: {
                'Audio Selector 1': {
                  DefaultSelection: 'DEFAULT',
                },
              },
              VideoSelector: {},
              TimecodeSource: 'ZEROBASED',
              FileInput: `s3://${bucketName}/${uploadedVideoLocation}`,
            },
          ],
        },
        AccelerationSettings: {
          Mode: 'DISABLED',
        },
        StatusUpdateInterval: 'SECONDS_60',
        Priority: 0,
        HopDestinations: [],
      };

      return params;
    } catch (error) {
      logger.error(`AWS generateMediaConvertTemplateParam ${error}`);
    }
  };

  const createMediaConvertJob = async (uploadedVideoLocation, bucketName) => {
    logger.info(
      `createMediaConvertJob Upload Location${uploadedVideoLocation} , bucketName: ${bucketName}, mediaConvertPointer: ${mediaConvertPointer}, AWS_REGION: ${config.AWS_REGION}, AWS_ACCOUNT_CONSOLE: ${config.AWS_ACCOUNT_CONSOLE}`
    );
    AWS.config.mediaconvert = { endpoint: config.AWS_MEDIACONVERT_ENDPOINT };
    const mediaConvertPointer = `arn:aws:mediaconvert:${config.AWS_REGION}:${config.AWS_ACCOUNT_CONSOLE}`;
    const jobTemplate = `${mediaConvertPointer}:jobTemplates/System-Ott_Hls_Ts_Avc_Aac`;
    const queue = `${mediaConvertPointer}:queues/Default`;
    const role = `arn:aws:iam::${config.AWS_ACCOUNT_CONSOLE}:role/service-role/MediaConvert_Default_Role`;
    const templateParams = generateMediaConvertTemplateParam(role, jobTemplate, queue, uploadedVideoLocation, bucketName);
    try {
      const jobCreated = await new AWS.MediaConvert({ apiVersion: '2017-08-29' }).createJob(templateParams).promise();
      logger.info(`jobCreated ! ${JSON.stringify(jobCreated)}`);
      return jobCreated;
    } catch (error) {
      logger.error(`AWS createMediaConvertJoberror ${error}`);
      throw Error(error);
    }
  };

  const createFolder = async (bucketName, folderName, body, acl = true, mimetype) => {
    try {
      const s3 = new AWS.S3();
      let params = { Bucket: bucketName, Key: `${folderName}`, Body: body ? body : 'body does not matter', ContentType: mimetype };
      if (acl) {
        params.ACL = 'public-read';
      }

      const result = await s3.upload(params).promise();
      return result;
    } catch (e) {
      logger.error(`Aws create folder error ${e}`);
    }
    // return s3.upload(params).promise()
  };

  const deleteFilesFromDirectory = async ({ bucketName, folderName }) => {
    try {
      const s3 = new AWS.S3();
      const params = {
        Bucket: bucketName,
        Prefix: `${folderName}/`,
      };
      const list = await s3.listObjects(params).promise();
      if (list.Contents.length == 0) {
        return true;
      }
      const deleteParams = {
        Bucket: bucketName,
        Delete: {
          Objects: list.Contents.map(content => {
            return { Key: content.Key };
          }),
        },
      };
      let response = await s3.deleteObjects(deleteParams).promise();
      if (response.Deleted.length) {
        logger.info(`${response.Deleted.length} deleted from ${bucketName}/${folderName}`);
      }
      return true;
    } catch (e) {
      logger.error(`Aws deleteFilesFromDirectory error ${e}`);
    }
  };

  const subscribeToSNSTopic = async (endpoint, protocol, topicArn) => {
    try {
      const sns = new AWS.SNS();
      const params = {
        TopicArn: topicArn,
        Protocol: 'HTTPS',
        Endpoint: endpoint,
      };
      sns.subscribe(params, (err, data) => {
        if (err) {
          console.error(err);
          return;
        }
        return;
      });
    } catch (e) {
      logger.error(`Aws subscribeToSNSTopic error ${e}`);
      return;
    }
  };

  const listSubscriptionsToSNSTopic = async () => {
    try {
      const sns = new AWS.SNS();
      sns.listSubscriptionsByTopic(params, (err, data) => {
        if (err) {
          console.error(err);
          return;
        }
        return data;
      });
    } catch (e) {
      logger.error(`Aws listSubscriptionToSNS error ${e}`);
    }
  };

  // Create a Rekognition client once and reuse it
  const rekognition = new AWS.Rekognition({ region: 'us-east-1' });

  const imgToText = imageBuffer => {
    return new Promise((resolve, reject) => {
      rekognition.detectText({ Image: { Bytes: imageBuffer } }, (err, data) => {
        if (err) {
          console.error(`Error processing ${filename}:`, err);
          reject(err);
        } else {
          resolve(data);
        }
      });
    });
  };
  return {
    sendToQueue,
    registerLongPolling,
    uploadFileOnS3,
    getPreSignedUrlForDownload,
    subscribeQueue,
    createFolder,
    createMediaConvertJob,
    deleteFilesFromDirectory,
    subscribeToSNSTopic,
    listSubscriptionsToSNSTopic,
    imgToText,
  };
};
