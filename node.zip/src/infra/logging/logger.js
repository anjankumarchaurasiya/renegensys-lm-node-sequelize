const winston = require('winston');
const { createLogger, transports: _transports, format } = winston;

module.exports = ({ config }) => {
  const httpTransportOptions = {
    host: 'http-intake.logs.datadoghq.com',
    path: '/api/v2/logs?dd-api-key=176233a4b1ec762cef1553203f887d33&ddsource=nodejs&service=cg-content-api',
    ssl: true,
  };
  return createLogger({
    format: format.combine(format.splat(), format.errors({ stack: true }), format.timestamp(), format.json()),
    transports: [
      new _transports.Console(),
      new _transports.File(
        Object.assign(config.logging, {
          filename: `logs/${config.env}.log`,
        })
      ),
      // new _transports.Http(httpTransportOptions),
    ],
  });
};
