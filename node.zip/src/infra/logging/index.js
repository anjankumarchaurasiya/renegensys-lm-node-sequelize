const httpContext = require('express-cls-hooked');
const R = require('ramda');
const tracer = require('dd-trace');
const logger = require('./logger');

const mergeUserData = (data, eventAttributes = {}) => {
  if (typeof eventAttributes !== 'object') {
    eventAttributes = {};
  }
  const cgEntity = httpContext.get('currentCgEntity') || {};
  const cgEntityType = httpContext.get('cgEntityType') || {};
  const requestId = httpContext.get('request_id');
  const messageId = httpContext.get('MessageId');
  const eventId = httpContext.get('event_id');
  const reqBody = httpContext.get('reqBody');
  const reqQuery = httpContext.get('reqQuery');
  const apiName = httpContext.get('apiName');
  const clientIP = httpContext.get('clientIP');
  const eventName = httpContext.get('event_name');
  const reqIp = httpContext.get('reqIp');
  const appVariant = httpContext.get('appVariant');
  const clientName = httpContext.get('clientName');
  const appVersion = httpContext.get('appVersion');
  const userAgent = httpContext.get('userAgent');
  const serviceKey = httpContext.set('serviceKey');
  const functionKey = httpContext.set('functionName');

  eventAttributes.request = {
    req_body: reqBody,
    api_name: apiName,
    req_query: reqQuery,
    client_ip: clientIP,
    req_ip: reqIp,
    user_agent: userAgent,
    app_variant: appVariant,
    client_name: clientName,
    app_version: appVersion,
    cgId: cgEntity?.id,
    cgEntityType: cgEntityType,
  };
  const service = {
    service_key: serviceKey,
    function_key: functionKey,
  };
  let meta = {};
  const event = {
    event_id: eventId,
    event_name: eventName,
  };
  meta = R.mergeAll([meta, { request_id: requestId, app_variant: appVariant, client_name: clientName, app_version: appVersion }]);
  if (messageId && data.message) {
    data.message = `${messageId} ${data.message}`;
  }
  if (cgEntity) {
    meta = R.mergeAll([meta, { email: cgEntity?.email, cgId: cgEntity.id, mobile: cgEntity?.mobile }]);
  }
  let span = tracer.scope().active();
  if (span == null) {
    span = tracer.startSpan('web.request');
  }
  if (span !== null) {
    span.setTag('meta.cgId', cgEntity?.id);
    span.setTag('meta.cgEntity.mobile', cgEntity?.mobile);
    span.setTag('requestId', requestId);
    span.setTag('appVariant', appVariant);
    span.setTag('appVersion', appVersion);
    span.setTag('clientName', clientName);
    span.setTag('request.requestIp', reqIp);
  }

  return R.mergeAll([data, { meta: meta, ...eventAttributes, event, service }]);
};

module.exports = ({ config }) => {
  const _logger = logger({ config });
  let flgSilent = false;

  return {
    info: (message, eventAttributes) => {
      !flgSilent && _logger.log(mergeUserData({ level: 'info', message }, eventAttributes));
    },
    debug: (message, eventAttributes) => {
      !flgSilent && _logger.log(mergeUserData({ level: 'debug', message }, eventAttributes));
    },
    warn: (message, eventAttributes) => {
      !flgSilent && _logger.log(mergeUserData({ level: 'warn', message }, eventAttributes));
    },
    error: (message, error, eventAttributes) => {
      if (error && error instanceof Error) {
        error.message = `${message}  ${error.message}`;
        !flgSilent && _logger.log(mergeUserData({ level: 'error', message: error }, eventAttributes));
      } else {
        if (error) {
          message = message + JSON.stringify(error);
        }
        !flgSilent && _logger.log(mergeUserData({ level: 'error', message }, eventAttributes));
      }
    },
    silent: flg => {
      flgSilent = flg;
    },
  };
};
