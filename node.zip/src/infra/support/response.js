const { assoc } = require('ramda');

module.exports = ({ config }) => {
  const defaultResponse = (success = true) => {
    return {
      success,
      version: config.version,
      date: new Date(),
    };
  };

  /** comment this code for now if any error in new success function can take hints from this line */
  // const Success = async data => {
  //   return assoc('data', data, defaultResponse(true));
  // };
  const Success = async (data, message) => {
    const response = defaultResponse(true);
    response.data = data;
    response.message = message;
    return response;
  };

  const Fail = async data => {
    return assoc('error', data, defaultResponse(false));
  };

  return {
    Success,
    Fail,
  };
};
