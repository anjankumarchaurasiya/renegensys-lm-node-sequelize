const axios = require('axios');
const http = require('http');
const https = require('https');

axios.defaults.timeout = 100000;
axios.defaults.httpAgent = new http.Agent({ timeout: 500 });
axios.defaults.httpsAgent = new https.Agent({ timeout: 500 });

module.exports = ({ logger }) => {
  const defaultHeaders = {
    accept: 'application/json',
  };

  const defaultOptions = {
    timeout: 10000,
  };

  const base = async ({ url, method, params = {}, data = {}, headers = defaultHeaders, options = defaultOptions }) => {
    const axiosConfig = { url, method, params, data, headers, ...options };
    if (Object.keys(axiosConfig.data).length === 0) {
      delete axiosConfig.data;
    }
    return axios(axiosConfig)
      .then(res => res)
      .catch(err => {
        logger.error(`Error while calling ${url}`, err);
        throw err;
      });
  };

  const get = async ({ url, data = {}, headers, options = {} }) => base({ url, method: 'GET', params: data, headers, options });

  const post = async ({ url, data = {}, headers, options = {} }) => base({ url, method: 'POST', data, headers, options });

  const put = async ({ url, data = {}, headers, options = {} }) => base({ url, method: 'PUT', data, headers, options });

  const patch = async ({ url, data = {}, headers, options = {} }) => base({ url, method: 'PATCH', data, headers, options });

  const _delete = async ({ url, data = {}, headers, options = {} }) => base({ url, method: 'DELETE', data, headers, options });

  const formUrlEncodedPost = async (url, postBody, headers = {}) => {
    // const formData = generateFormURLEncodedStringFromObject(postBody)
    const options = {
      method: 'POST',
      headers: { 'Content-Type': `application/x-www-form-urlencoded;charset=UTF-8`, ...headers },
      data: postBody,
      url,
    };
    return axios(options);
  };

  const generateFormURLEncodedStringFromObject = obj =>
    Object.entries(obj)
      .map((key, val) => `${key}=${encodeURIComponent(val)}`)
      .join('&');

  const generateURIStringFromObject = (uri, obj) => {
    const params = new URLSearchParams(obj);
    uri = `${uri}?${params.toString()}`;
    return uri;
  };

  const postMultipartFormData = async (url, postBody = {}, headers = {}) => {
    const form = new FormData();
    for (const [key, value] of Object.entries(postBody)) {
      if (key === 'file') {
        form.append(`${key}`, value.fileBuf, value.filename);
      } else form.append(`${key}`, value);
    }
    const options = {
      method: 'POST',
      headers: { 'Content-Type': 'multipart/form-data', ...form.getHeaders(), ...headers },
      data: form,
      url,
    };
    return axios(options);
  };
  return {
    get,
    post,
    put,
    patch,
    delete: _delete,
    defaultHeaders,
    defaultOptions,
    formUrlEncodedPost,
    generateFormURLEncodedStringFromObject,
    generateURIStringFromObject,
    postMultipartFormData,
  };
};
