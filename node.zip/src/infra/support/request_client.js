const got = require('got');
const Agent = require('agentkeepalive');
const keepaliveAgent = new Agent({
  maxSockets: process.env.HTTP_MAX_SOCKET || Infinity,
  maxFreeSockets: process.env.HTTP_MAX_FREE_SOCKET || 256,
  timeout: process.env.HTTP_SOCKET_TIMEOUT || 30000, // active socket keepalive for 60 seconds
  freeSocketTimeout: process.env.HTTP_FREE_SOCKET_TIMEOUT || 15000, // free socket keepalive for 30 seconds
  socketActiveTTL: 60000,
  keepAlive: true,
  keepAliveMsecs: 1000,
});

const HTTP_CONNECT_TIMEOUT = process.env.HTTP_CONNECT_TIMEOUT || 10000;
module.exports = ({ logger, CustomError }) => {
  const gotRequest = async options => {
    const url = options.uri ? options.uri : options.url;
    delete options['uri'];
    delete options['url'];
    options.responseType = options.responseType ? options.responseType : 'text';
    if (options['json'] === true) {
      options.responseType = 'json';
      delete options['json'];
    }
    if (options['body'] !== undefined) {
      options['json'] = options['body'];
      delete options['body'];
    }
    if (options['bodyOverRide'] !== undefined) {
      options['body'] = options['json'];
      delete options['json'];
    }
    if (options['dynamicHTTPAgent'] !== undefined) {
      const keepaliveDynamicAgent = new Agent({
        maxSockets: options['dynamicHTTPAgent'].maxSockets || 100,
        maxFreeSockets: options['dynamicHTTPAgent'].maxFreeSockets || 10,
        timeout: options['dynamicHTTPAgent'].timeout || 60000, // active socket keepalive for 60 seconds
        freeSocketTimeout: options['dynamicHTTPAgent'].freeSocketTimeout || 30000, // free socket keepalive for 30 seconds
      });
      delete options['dynamicHTTPAgent'];
      options.agent = { http: keepaliveDynamicAgent };
    } else {
      // options.agent = { http: keepaliveAgent }
      const agentTimeOut = options.timeout ? options.timeout : HTTP_CONNECT_TIMEOUT;
      const agentFreeSocketTimeOut = options.timeout ? options.timeout / 2 : HTTP_CONNECT_TIMEOUT / 2;
      options.agent = { http: new Agent({ timeout: agentTimeOut, freeSocketTimeout: agentFreeSocketTimeOut, keepAlive: true }) };
    }
    try {
      if (!options.timeout) {
        throw new Error('Please provide the Time Out Parameters in Options');
      }
      options.timeout = options.timeout ? options.timeout : HTTP_CONNECT_TIMEOUT;
      options.retry = options.retry ? options.retry : 0;
      logger.info(` External Request url: ${url} Request payload ${JSON.stringify(options['json'])}`);
      const result = await got(url, options);
      if (result && result.timings.phases.total > HTTP_CONNECT_TIMEOUT) {
        logger.info(
          ` External Request url ${url} Response Status Code : ${result.statusCode} GREATER than connection time out ${JSON.stringify(
            result.timings.phases
          )}`
        );
      }
      if (options['debugMode']) {
        logger.info(` External Request debugMode ${url} requestType ${JSON.stringify(result.request)}`);
        logger.info(` External Request debugMode ${url} option ${JSON.stringify(result.request.options)}`);
        logger.info(` External Request debugMode ${url} headers ${JSON.stringify(options.headers)}`);
        logger.info(` External Request debugMode ${url} body ${JSON.stringify(options['json'])}`);
      }
      if (options['responseOverride']) {
        let responseNew = {};
        options['responseOverride'].forEach(element => {
          responseNew[element] = result[element];
        });
        return responseNew;
      }
      return result.body;
    } catch (e) {
      if (e instanceof got.HTTPError) {
        if (e.response && e.response.statusCode >= 400 && e.response.statusCode <= 500) {
          logger.info(
            ` External Request Failed for url ${url} method ${options.method} status Code ${e.response.statusCode} messsage ${
              typeof e.response.body === 'object' ? JSON.stringify(e.response.body) : e.response.body
            }`
          );
        } else {
          logger.error(
            ` External Request Failed for url ${url} method ${options.method} status Code ${e.response.statusCode} messsage ${
              typeof e.response.body === 'object' ? JSON.stringify(e.response.body) : e.response.body
            }`
          );
        }
      } else {
        logger.error(
          ` External Request Failed for url ${url} method ${options.method} status Code ${
            e.response && e.response.statusCode ? e.response.statusCode : e.response
          } messsage `,
          e
        );
      }
      if (e && e.response && e.response.body) {
        const message = typeof e.response.body === 'object' ? JSON.stringify(e.response.body) : e.response.body;
        throw new CustomError(e.code || 'GENERIC', e.statusCode, message);
      }
      throw new CustomError(e.code || 'GENERIC', e.statusCode, e.message);
    }
  };
  return {
    gotRequest,
  };
};
