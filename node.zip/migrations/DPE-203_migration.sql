ALTER TABLE batch_quiz MODIFY exam_date DATE;

ALTER TABLE batch_quiz MODIFY start_time TIME;