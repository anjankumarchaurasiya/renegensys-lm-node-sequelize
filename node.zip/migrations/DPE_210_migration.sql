ALTER TABLE learning_session
ADD meeting_platform VARCHAR(255);