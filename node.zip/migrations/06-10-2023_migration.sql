CREATE TABLE `tta_video` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `post_id` varchar(255) DEFAULT NULL,
  `sender_id` varchar(255) DEFAULT NULL,
  `receiver_id` varchar(255) DEFAULT NULL,
  `chat_id` varchar(255) DEFAULT NULL,
  `source_url` varchar(255) DEFAULT NULL,
  `video_avc_hls_url` varchar(255) DEFAULT NULL,
  `video_key` varchar(255) DEFAULT NULL,
  `job_arn` varchar(255) DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;