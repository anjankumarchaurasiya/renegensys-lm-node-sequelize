ALTER TABLE learning_session
MODIFY COLUMN date date NOT NULL,
MODIFY COLUMN start_time time NOT NULL,
MODIFY COLUMN end_time time NOT NULL;


ALTER TABLE learning_session_content
ADD COLUMN type VARCHAR(255) NOT NULL ;