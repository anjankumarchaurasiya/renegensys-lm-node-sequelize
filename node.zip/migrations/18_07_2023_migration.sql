ALTER TABLE `country`
ADD COLUMN `alpha_three_code` VARCHAR(45) NULL AFTER `timezone`;

ALTER TABLE `tta_parent` 
ADD COLUMN `source` TEXT NULL AFTER `address`;

CREATE TABLE `customer_additional_info` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customer_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `utm_source` varchar(255) DEFAULT NULL,
  `utm_source1` varchar(255) DEFAULT NULL,
  `utm_medium` varchar(255) DEFAULT NULL,
  `utm_campaign` varchar(255) DEFAULT NULL,
  `utm_term` varchar(255) DEFAULT NULL,
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `record_status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `customer_additional_info_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `customer_profile_subscription` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customer_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `profile_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `plan_id` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `plan_validity` varchar(255) DEFAULT NULL,
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `record_status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `profile_id` (`profile_id`),
  CONSTRAINT `customer_profile_subscription_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `customer_profile_subscription_ibfk_2` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

ALTER TABLE `tta_assignment`
ADD COLUMN `time_spent` INT NULL DEFAULT NULL AFTER `is_completed`,
ADD COLUMN `attempt_count` INT NULL DEFAULT NULL AFTER `time_spent`;

INSERT INTO `creativegalileo-v2`.`event_config` (`id`, `name`, `type`, `service_name`, `method_name`, `config`, `record_status`, `created_at`, `updated_at`) VALUES ('8d375732-41bc-11ee-98bb-0a5443f6a978', 'TTA_PARENT_BULK', 'CALL_METHOD', 'ttaParentService', 'handleTtaParentBulk', '{\"variables\": [{\"key\": \"jobId\", \"valueExpr\": \"jobId\"}, {\"key\": \"parentId\", \"valueExpr\": \"parentId\"}, {\"key\": \"name\", \"valueExpr\": \"name\"}, {\"key\": \"dialCode\", \"valueExpr\": \"dialCode\"}, {\"key\": \"mobile\", \"valueExpr\": \"mobile\"}, {\"key\": \"address\", \"valueExpr\": \"address\"}, {\"key\": \"source\", \"valueExpr\": \"source\"}, {\"key\": \"type\", \"valueExpr\": \"type\"}]}', '1', '2023-07-26 06:20:00', '2023-07-26 06:20:00');
INSERT INTO `creativegalileo-v2`.`event_config` (`id`, `name`, `type`, `service_name`, `method_name`, `config`, `record_status`, `created_at`, `updated_at`) VALUES ('8a65a6d0-41bc-11ee-98bb-0a5443f6a978', 'TTA_KID_BULK', 'CALL_METHOD', 'ttaKidService', 'handleTtaKidBulk', '{\"variables\": [{\"key\": \"jobId\", \"valueExpr\": \"jobId\"}, {\"key\": \"parentId\", \"valueExpr\": \"parentId\"}, {\"key\": \"kidId\", \"valueExpr\": \"kidId\"}, {\"key\": \"name\", \"valueExpr\": \"name\"}, {\"key\": \"schoolId\", \"valueExpr\": \"schoolId\"}, {\"key\": \"schoolName\", \"valueExpr\": \"schoolName\"}, {\"key\": \"grade\", \"valueExpr\": \"grade\"}, {\"key\": \"class\", \"valueExpr\": \"class\"}, {\"key\": \"dob\", \"valueExpr\": \"dob\"}, {\"key\": \"teacherName\", \"valueExpr\": \"teacherName\"}, {\"key\": \"registrationTime\", \"valueExpr\": \"registrationTime\"}, {\"key\": \"type\", \"valueExpr\": \"type\"}, {\"key\": \"classId\", \"valueExpr\": \"classId\"}, {\"key\": \"ageMin\", \"valueExpr\": \"ageMin\"}, {\"key\": \"ageMax\", \"valueExpr\": \"ageMax\"}, {\"key\": \"planValidity\", \"valueExpr\": \"planValidity\"}]}', '1', '2023-07-26 06:20:00', '2023-08-29 04:36:18');
INSERT INTO `creativegalileo-v2`.`event_config` (`id`, `name`, `type`, `service_name`, `method_name`, `config`, `record_status`, `created_at`, `updated_at`) VALUES ('c8fedd96-e1d1-45a5-b5eb-a818945851f8', 'TTA_ASSIGNMENT_BULK', 'CALL_METHOD', 'ttaAssignmentService', 'handleTtaAssignmentBulk', '{\"variables\": [{\"key\": \"jobId\", \"valueExpr\": \"jobId\"}, {\"key\": \"parentId\", \"valueExpr\": \"parentId\"}, {\"key\": \"kidId\", \"valueExpr\": \"kidId\"}, {\"key\": \"assignmentId\", \"valueExpr\": \"assignmentId\"}, {\"key\": \"pid\", \"valueExpr\": \"pid\"}, {\"key\": \"contentId\", \"valueExpr\": \"contentId\"}, {\"key\": \"teacherId\", \"valueExpr\": \"teacherId\"}, {\"key\": \"schoolId\", \"valueExpr\": \"schoolId\"}, {\"key\": \"teacherPhotoUrl\", \"valueExpr\": \"teacherPhotoUrl\"}, {\"key\": \"teacherName\", \"valueExpr\": \"teacherName\"}, {\"key\": \"startDate\", \"valueExpr\": \"startDate\"}, {\"key\": \"endDate\", \"valueExpr\": \"endDate\"}, {\"key\": \"source\", \"valueExpr\": \"source\"}]}', '1', '2023-07-26 06:20:00', '2023-07-26 06:20:00');



ALTER TABLE `tta_kid` 
ADD COLUMN `is_worksheet_enabled` TINYINT NULL DEFAULT 0 AFTER `school_name`;

CREATE TABLE `profile_additional_info` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `profile_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_worksheet_enabled` tinyint(1) DEFAULT NULL,
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `record_status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id` (`profile_id`),
  CONSTRAINT `profile_additional_info_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

drop table if exists `worksheet`;
CREATE TABLE `worksheet` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `worksheet_url` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `worksheet_class_term` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worksheet_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `term` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `worksheet_id` (`worksheet_id`),
  CONSTRAINT `worksheet_class_term_ibfk_1` FOREIGN KEY (`worksheet_id`) REFERENCES `worksheet` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `worksheet_domain` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worksheet_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `domain_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `worksheet_domain_worksheetId_domain_id_unique` (`worksheet_id`,`domain_id`),
  KEY `domain_id` (`domain_id`),
  CONSTRAINT `worksheet_domain_ibfk_1` FOREIGN KEY (`worksheet_id`) REFERENCES `worksheet` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `worksheet_domain_ibfk_2` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `worksheet_subdomain` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worksheet_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `subdomain_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `worksheet_subdomain_worksheetId_subdomain_id_unique` (`worksheet_id`,`subdomain_id`),
  KEY `subdomain_id` (`subdomain_id`),
  CONSTRAINT `worksheet_subdomain_ibfk_1` FOREIGN KEY (`worksheet_id`) REFERENCES `worksheet` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `worksheet_subdomain_ibfk_2` FOREIGN KEY (`subdomain_id`) REFERENCES `subdomain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `tag` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `color_code` varchar(255) DEFAULT NULL,
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `worksheet_tag` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `worksheet_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `tag_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `record_status` int DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `worksheet_tag_worksheetId_tagId_unique` (`worksheet_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `worksheet_tag_ibfk_1` FOREIGN KEY (`worksheet_id`) REFERENCES `worksheet` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `worksheet_tag_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


ALTER TABLE `content_attribute` 
ADD COLUMN `game_max_levels` INT NULL DEFAULT NULL AFTER `partner_id`;

ALTER TABLE `tta_assignment`
ADD COLUMN `level_completed` INT NULL DEFAULT NULL AFTER `end_date`,
ADD COLUMN `correct_answer_count` INT NULL DEFAULT NULL AFTER `level_completed`,
ADD COLUMN `wrong_answer_count` INT NULL DEFAULT NULL AFTER `correct_answer_count`;

ALTER TABLE `creativegalileo-v2`.`customer` 
ADD COLUMN `parent_type` VARCHAR(255) NULL DEFAULT NULL AFTER `otp`;

ALTER TABLE `creativegalileo-v2`.`tta_kid` 
ADD COLUMN `school_logo` VARCHAR(255) NULL DEFAULT NULL AFTER `school_name`;

CREATE TABLE `tta_bulk_upload_job` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `job_id` varchar(255) DEFAULT NULL,
  `job_entity` varchar(255) DEFAULT NULL,
  `request` json DEFAULT NULL,
  `response` json DEFAULT NULL,
  `response_status` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

ALTER TABLE `tta_kid` 
ADD COLUMN `age` INT NULL AFTER `school_logo`,
ADD COLUMN `type` VARCHAR(255) NULL AFTER `age`,
ADD COLUMN `class_id` VARCHAR(255) NULL AFTER `type`;

ALTER TABLE `tta_parent` 
ADD COLUMN `type` VARCHAR(255) NULL AFTER `source`;

ALTER TABLE `tta_assignment`
ADD COLUMN `source` VARCHAR(255) NULL DEFAULT NULL AFTER `wrong_answer_count`;

ALTER TABLE `tta_assignment`
ADD COLUMN `score` VARCHAR(255) NULL DEFAULT NULL AFTER `source`,
ADD COLUMN `remark` VARCHAR(255) NULL DEFAULT NULL AFTER `score`;
