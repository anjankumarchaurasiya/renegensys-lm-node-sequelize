ALTER TABLE learning_session_spam_report
MODIFY COLUMN warning_given BOOLEAN DEFAULT FALSE NOT NULL;