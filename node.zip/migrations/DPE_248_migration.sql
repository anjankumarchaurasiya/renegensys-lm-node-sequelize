ALTER TABLE user_quiz_progress
ADD COLUMN attempt_no INTEGER;


ALTER TABLE user_quiz_progress
ADD CONSTRAINT quiz_id
FOREIGN KEY (quiz_id) REFERENCES quiz(id);


ALTER TABLE user_quiz_progress
ADD CONSTRAINT user_id
FOREIGN KEY (user_id) REFERENCES User(id);