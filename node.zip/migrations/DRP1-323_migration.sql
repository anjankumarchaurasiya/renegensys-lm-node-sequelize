ALTER TABLE feedback
ADD COLUMN feedback_category_id CHAR(255) NOT NULL ;


ALTER TABLE learning_session_feedback_user_response
ADD CONSTRAINT learning_session_feedback_user_response_ibfk_3
FOREIGN KEY (feedback_id)
REFERENCES feedback (id)
ON DELETE CASCADE
ON UPDATE CASCADE;


ALTER TABLE feedback
DROP FOREIGN KEY feedback_ibfk_1;

ALTER TABLE learning_session_feedback_user_response
DROP INDEX learning_session_feedback_user_response_ibfk_3,
ADD INDEX feedback_id (feedback_id);

ALTER TABLE feedback
ADD COLUMN categoryId CHAR(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL;

ALTER TABLE feedback
ADD INDEX feedback_category_id (feedback_category_id);

ALTER TABLE feedback
ADD INDEX categoryId (categoryId);

ALTER TABLE feedback
ADD CONSTRAINT feedback_ibfk_2 FOREIGN KEY (categoryId) REFERENCES category (id) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE feedback
ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`feedback_category_id`) REFERENCES `category` (`id`) ON UPDATE CASCADE;
