ALTER TABLE learning_session
CHANGE canceled_by cancelled_by CHAR(36);