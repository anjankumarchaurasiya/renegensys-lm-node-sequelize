CREATE TABLE `batch_user` (
  `id` char(36) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `batch_id` char(36) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `user_id` char(36) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `record_status` tinyint(1) NOT NULL DEFAULT '1',
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `deactivated_by` char(36) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_user_userId_batchId_unique` (`batch_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `batch_user_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `batch_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE `lms_stage`.`quiz`
ADD COLUMN `category_id` CHAR(36) CHARACTER SET 'latin1' COLLATE 'latin1_bin' NOT NULL AFTER `title`;








