ALTER TABLE user_response
ADD result ENUM('WRONG', 'CORRECT', 'UNATTEMPTED');

ALTER TABLE user_quiz_progress
ADD total_point VARCHAR(255),
ADD is_passed BOOLEAN DEFAULT FALSE,
ADD percentage VARCHAR(255);

ALTER TABLE user_response
ADD user_quiz_progress_id CHAR(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
ADD FOREIGN KEY (user_quiz_progress_id) REFERENCES user_quiz_progress(id);
