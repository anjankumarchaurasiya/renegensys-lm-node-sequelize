ALTER TABLE feedback_question
ADD COLUMN word_limit INTEGER;


 