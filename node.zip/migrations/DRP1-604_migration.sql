ALTER TABLE learning_session
MODIFY COLUMN meeting_url TEXT;

CREATE TABLE IF NOT EXISTS learning_session_content (
    learning_session_id INT,
    learning_session_content_id INT,
    PRIMARY KEY (learning_session_id, learning_session_content_id),
    FOREIGN KEY (learningSessionId) REFERENCES learning_session(id),
    FOREIGN KEY (learning_session_content_id) REFERENCES learning_session_content(id)
);


-- Drop the existing foreign key constraint
ALTER TABLE learning_session_module
DROP CONSTRAINT fk_learning_session_module_learning_session;

-- Add a new foreign key constraint referencing the Module table
ALTER TABLE learning_session_module
ADD CONSTRAINT fk_learning_session_module_module
FOREIGN KEY (moduleId) REFERENCES module(id);
