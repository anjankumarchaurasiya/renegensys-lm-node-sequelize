

ALTER TABLE `lms`.`learning_session_progress` 
ADD COLUMN `batch_id` CHAR(36) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_bin' NOT NULL AFTER `user_id`;

ALTER TABLE `lms`.`learning_session_progress` 
ADD INDEX `batch_id` (`batch_id` ASC) VISIBLE;
;

ALTER TABLE `lms`.`learning_session_progress` 
ADD CONSTRAINT `learning_session_progress_ibfk_3`
  FOREIGN KEY (`batch_id`)
  REFERENCES `lms`.`batch` (`id`)
  ON UPDATE CASCADE;
