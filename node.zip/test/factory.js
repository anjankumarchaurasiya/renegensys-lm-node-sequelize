const { resolve } = require('src/container');
const config = resolve('config');

const database = resolve('database');
// const sequelize = database.sequelize;
// const models = database.sequelize.models;
// const models = name => resolve('sequelize')[name];
const infra = name => resolve(name);
const services = name => resolve(name);
const repositories = name => resolve(name);
const constants = resolve('constants');
const logger = resolve('logger');

module.exports = {
  database,
  services,
  infra,
  constants,
  logger,
  repositories,
  config,
};
