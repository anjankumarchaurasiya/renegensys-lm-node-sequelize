const { resolve } = require('src/container');

const logger = resolve('logger');

before(async () => {
  try {
    logger.silent = true;
  } catch (error) {
    logger.error('Error in setting up database', error);
  }
});
