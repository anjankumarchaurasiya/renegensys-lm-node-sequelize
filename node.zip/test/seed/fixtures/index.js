const configs = require('./configs/config.json');
const eventConfigs = require('./configs/event_config.json');
const cronFrameworkConfigs = require('./configs/cron_framework_config.json');
const notificationConfig = require('./configs/notification_config.json');

module.exports = {
  configs,
  eventConfigs,
  cronFrameworkConfigs,
  notificationConfig,
};
