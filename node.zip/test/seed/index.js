const { services, repositories, logger, database, constants } = require('../factory');
const metaEntityFixtures = require('./fixtures');
const configFixtures = require('./fixtures');
const xlsx = require('xlsx');
const util = require('util');
const path = require('path');
const moment = require('moment');

describe('Seed Data', async () => {
  it('Seed User Data', async () => {
    const startTime = performance.now();
    const userService = services('userService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['user_db']);
    let userList = [];
    for (let data of sheetData) {
      data.recordStatus = 1;
      data.dialCode = data.dial_code;
      data.countryCode = data.country_code;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      userList.push(data);
    }
    await userService.bulkCreateUsers(userList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed User Data created');
  }).timeout(3000);

  it('Seed Config Data', async () => {
    const startTime = performance.now();
    const configMasterService = services('configMasterService');
    const userService = services('userService');
    let userDetail = await userService.findUserByPhoneNumber({ dialCode: '+91', mobile: '7073400765' });
    const userId = userDetail.id;
    let configList = [];
    for (let data of configFixtures.configs.configList) {
      data.recordStatus = 1;
      data.createdBy = userId;
      data.lastUpdatedBy = userId;
      data.deactivatedAt = null;
      data.createdAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      data.updatedAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      configList.push(data);
    }
    await configMasterService.bulkCreateConfig(configList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Config Data created');
  }).timeout(3000);

  it('Seed Role Data', async () => {
    const startTime = performance.now();
    const roleManagementService = services('roleManagementService');
    const userService = services('userService');
    let userDetail = await userService.findUserByPhoneNumber({ dialCode: '+91', mobile: '7073400765' });
    const userId = userDetail.id;
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['role_db']);
    let roleList = [];
    for (let data of sheetData) {
      data.recordStatus = 1;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      data.createdBy = userId;
      data.lastUpdatedBy = userId;
      data.deactivatedAt = null;
      roleList.push(data);
    }
    await roleManagementService.bulkCreateRoles(roleList);

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Data created');
  }).timeout(3000);

  it('Seed Country Data', async () => {
    const startTime = performance.now();
    const countryService = services('countryService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['country_db']);

    let countryList = [];
    for (let data of sheetData) {
      data.defaultUtcOffset = data.default_utc_offset;
      data.recordStatus = 1;
      data.deactivatedAt = null;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      countryList.push(data);
    }
    await countryService.bulkCreateCountry(countryList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Data created');
  }).timeout(3000);

  it('Seed event config', async () => {
    const eventConfigService = services('eventConfigService');
    let configList = [];
    for (let data of configFixtures.eventConfigs.eventConfigList) {
      data.recordStatus = 1;
      data.deactivatedAt = null;
      data.createdAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      data.updatedAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      configList.push(data);
    }
    await eventConfigService.bulkCreateEventConfig(configList);
  }).timeout(3000);

  it('Seed cron Framework config', async () => {
    const cronFrameworkConfigService = services('cronFrameworkConfigService');
    let cronFrameworkConfigs = [];
    for (let data of configFixtures.cronFrameworkConfigs.cronFrameworkConfigList) {
      data.recordStatus = 1;
      data.createdAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      data.updatedAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      cronFrameworkConfigs.push(data);
    }
    await cronFrameworkConfigService.bulkCreateCronFrameworkConfig(cronFrameworkConfigs);
  }).timeout(3000);

  it('Seed Notification Config Data', async () => {
    const startTime = performance.now();
    const notificationConfigService = services('notificationConfigService');
    const userService = services('userService');
    let userDetail = await userService.findUserByPhoneNumber({ dialCode: '+91', mobile: '7073400765' });
    const userId = userDetail.id;
    let configList = [];

    for (let data of configFixtures.notificationConfig.configList) {
      data.recordStatus = 1;
      data.createdBy = userId;
      data.lastUpdatedBy = userId;
      data.deactivatedAt = null;
      data.createdAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      data.updatedAt = moment().format('YYYY-MM-DD  HH:mm:ss.000');
      configList.push(data);
    }
    try {
      await notificationConfigService.bulkCreateNotificationConfig(configList);
    } catch (error) {
      console.error('Error during seeding:', error);
    }
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Data created for notification config');
  }).timeout(3000);

  it('Seed User_role Data', async () => {
    const startTime = performance.now();
    const userRoleService = services('userRoleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['user_db']);

    for (let data of sheetData) {
      data.recordStatus = 1;
      data.dialCode = data.dial_code;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      const roleNames = data.roles.split(',').map(role => role.trim());
      await userRoleService.assignRoleByName(data.id, roleNames);
    }
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed User Data created');
  }).timeout(300000);

  it('Seed Category', async () => {
    const startTime = performance.now();
    const categoryService = services('categoryService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const excelData = xlsx.utils.sheet_to_json(workbook.Sheets['category']);
    let categoryList = [];
    for (let data of excelData) {
      data.id = data.id;
      data.name = data.name;
      data.type = data.type;
      data.recordStatus = 1;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      categoryList.push(data);
    }

    await categoryService.bulkCreate(categoryList);

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Data created');
  }).timeout(3000);

  it('Seed Module Data', async () => {
    const startTime = performance.now();
    const moduleService = services('moduleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['module_db']);
    let moduleList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.deactivatedAt = data.deactivated_at;
      data.recordStatus = data.order_status;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      moduleList.push(data);
    }
    await moduleService.bulkCreateModules(moduleList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Module Data created');
  }).timeout(3000);

  it('Seed Course Data', async () => {
    const startTime = performance.now();
    const courseService = services('courseService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['course_db']);
    let courseList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.deactivatedAt = data.deactivated_at;
      data.recordStatus = data.order_status;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      courseList.push(data);
    }
    await courseService.bulkCreateCourses(courseList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Course Data created');
  }).timeout(3000);

  it('Seed Content Data', async () => {
    const startTime = performance.now();
    const contentService = services('contentService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['content_db']);
    let contentList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      contentList.push(data);
    }
    await contentService.bulkCreateContents(contentList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Content Data created');
  }).timeout(3000);

  it('Seed Topic Data', async () => {
    const startTime = performance.now();
    const topicService = services('topicService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['topic_db']);
    let topicList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      topicList.push(data);
    }
    await topicService.bulkCreateTopics(topicList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Topic Data created');
  }).timeout(3000);

  it('Seed Cource Module Data', async () => {
    const startTime = performance.now();
    const courseModuleService = services('courseModuleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['course_module_db']);
    let courseModuleList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      courseModuleList.push(data);
    }
    await courseModuleService.bulkCreateCourseModule(courseModuleList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Course Module Data created');
  }).timeout(3000);

  it('Seed Module Topic Data', async () => {
    const startTime = performance.now();
    const moduleTopicService = services('moduleTopicService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['module_topic_db']);
    let moduleTopicList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.order = 1;
      data.recordStatus = true;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      moduleTopicList.push(data);
    }
    await moduleTopicService.bulkCreateModuleTopic(moduleTopicList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Module Topic Data created');
  }).timeout(3000);

  it('Seed Topic Content Data', async () => {
    const startTime = performance.now();
    const topicContentService = services('topicContentService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['topic_content_db']);
    let topicContentList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.order = 1;
      data.recordStatus = true;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      topicContentList.push(data);
    }
    await topicContentService.bulkCreateTopicContent(topicContentList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Topic Content Data created');
  }).timeout(3000);

  it('Seed  Feedback Data', async () => {
    const startTime = performance.now();
    const feedBackService = services('feedbackService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['feedback_db']);

    let feedBackList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.title = data.title;
      data.description = data.description;
      data.category_id = data.categoryId;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      feedBackList.push(data);
    }
    try {
      await feedBackService.bulkCreateFeedback(feedBackList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed Batch Data', async () => {
    const startTime = performance.now();
    const batchService = services('batchService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['batch_db']);
    let batchList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.batch_number = data.batchNumber;
      data.course_id = data.courseId;
      data.feedback_id = data.feedbackId;
      data.start_date = data.startDate;
      data.end_date = data.endDate;
      data.classMode = 'WEEK_DAYS';
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      batchList.push(data);
    }
    await batchService.bulkCreateBatches(batchList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Batch Data created');
  }).timeout(4000);

  it('Seed Batch User Data', async () => {
    const startTime = performance.now();
    const batchUserService = services('batchUserService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['batch_user_db']);
    let batchUserList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.user_id = data.userId;
      data.batch_id = data.batchId;
      data.record_status = data.recordStatus;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      batchUserList.push(data);
    }
    await batchUserService.bulkCreateBatchUsers(batchUserList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Batch User Data created');
  }).timeout(3000);

  it('Seed Learning Session Data', async () => {
    const startTime = performance.now();
    const learningSessionService = services('learningSessionService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['learning_session_db']);
    let sessionList = [];

    for (let data of sheetData) {
      data.id = data.id;
      data.title = data.title;
      data.batch_id = data.batchId;
      data.course_id = data.courseId;
      data.srm_id = data.srmId;
      data.primary_faculty_id = data.primaryFacultyId;
      data.secondary_faculty_id = data.secondaryFacultyId;
      data.start_time = data.startTime;
      data.end_time = data.endTime;
      data.meeting_start_url = data.meetingStartUrl;
      data.meeting_url = data.meetingUrl;
      data.cancelled_by = data.cancelledBy;
      data.record_status = data.recordStatus;
      data.createdAt = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updatedAt = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));

      sessionList.push(data);
    }
    await learningSessionService.bulkCreateLearningSession(sessionList);
    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Data created');
  }).timeout(3000);

  it('Seed Learning Session Module Data', async () => {
    const startTime = performance.now();
    const learningSessionModuleService = services('learningSessionModuleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['learning_session_module_db']);

    let sessionModuleList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.learning_session_id = data.learningSessionId;
      data.module_id = data.moduleId;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      sessionModuleList.push(data);
    }
    try {
      await learningSessionModuleService.bulkCreate(sessionModuleList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed Question Data', async () => {
    const startTime = performance.now();
    const questionService = services('questionService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['question_db']);

    let questionList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.category_id = data.categoryId;
      data.question = data.question;
      data.question_type = data.questionType;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      questionList.push(data);
    }
    try {
      await questionService.bulkCreateQuestion(questionList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed Question Option Data', async () => {
    const startTime = performance.now();
    const questionOptionService = services('questionOptionService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['question_option_db']);

    let questionOptionList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.question_id = data.questionId;
      data.option = data.option;
      data.is_correct_option = data.isCorrectOption;
      data.description = data.description;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      questionOptionList.push(data);
    }
    try {
      await questionOptionService.bulkCreateQuestionOption(questionOptionList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed Feedback Question Data', async () => {
    const startTime = performance.now();
    const feedbackQuestionService = services('feedbackQuestionService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['feedback_question_db']);

    let feedbackQuestionList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.question_id = data.questionId;
      data.feedback_id = data.feedbackId;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      feedbackQuestionList.push(data);
    }
    try {
      await feedbackQuestionService.bulkCreateFeedbackQuestion(feedbackQuestionList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed LearningSession Feedback  Data', async () => {
    const startTime = performance.now();
    const learningSessionFeedbackService = services('learningSessionFeedbackService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['learningSession_feedback_db']);

    let feedbackQuestionList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.learning_session_id = data.learningSessionId;
      data.feedback_id = data.feedbackId;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      feedbackQuestionList.push(data);
    }
    try {
      await learningSessionFeedbackService.bulkCreateLearningSessionFeedback(feedbackQuestionList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed LearningSession Feedback User Data', async () => {
    const startTime = performance.now();
    const learningSessionFeedbackUserResponseService = services('learningSessionFeedbackUserResponseService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['learningSesion_feedback_user_db']);

    let learningSessionfeedbackUserList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.learning_session_id = data.learningSessionId;
      data.feedback_id = data.feedbackId;
      data.user_id = data.userId;
      data.question_id = data.questionId;
      data.question_option_id = data.questionOptionId;
      data.record_status = data.recordStatus;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      learningSessionfeedbackUserList.push(data);
    }
    try {
      await learningSessionFeedbackUserResponseService.bulkCreateLearningSessionFeedbackUserResponse(learningSessionfeedbackUserList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Learning Session Modules User Data created');
  }).timeout(3000);

  it('Seed  Resource', async () => {
    const startTime = performance.now();
    const roleManagementService = services('roleManagementService');
    const resourceActionRepository = repositories('resourceActionRepository');

    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const excelData = xlsx.utils.sheet_to_json(workbook.Sheets['resource_db']);

    for (const item of excelData) {
      console.log('item', item);
      let allowedFields = item.allowed_fields;
      if (!Array.isArray(allowedFields)) {
        allowedFields = [allowedFields];
      }
      await roleManagementService.addResources([
        {
          resourceName: item.resource_name,
          resourceActions: [
            {
              actionName: item.action_name,
              actionType: item.action_type,
              allowedFields: allowedFields,
            },
          ],
        },
      ]);

      // Fetch the ID of the recently added action
      const resourceAction = await resourceActionRepository.findBy(['id'], { actionName: item.action_name });
      const resourceActionId = resourceAction.id;

      // Assign to roles
      const roleNames = item.role.split(','); // Assuming roles are comma-separated

      for (const roleName of roleNames) {
        const roleObj = await roleManagementService.getRoleByRoleName(roleName);

        await roleManagementService.assignResourceToRole({
          roleId: roleObj.id,
          resources: [resourceActionId],
        });
      }
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Data created');
  }).timeout(5000000);

  /* start  Admin role permission - For admin module */
  /*For admin module */
  it('Seed Admin Module Data', async () => {
    const startTime = performance.now();
    const adminModuleService = services('adminModuleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['admin_module_db']);

    let adminModuleList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.name = data.name;
      data.icon = data.icon;
      data.redirect_link = data.redirectLink;
      data.order = data.order;
      data.record_status = data.record_status;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      adminModuleList.push(data);
    }
    try {
      await adminModuleService.bulkCreateAdminModule(adminModuleList);
    } catch (err) {
      logger.error('err------>', err);
    }
  }).timeout(3000);
  /*For sub module */
  it('Seed Sub Module Data', async () => {
    const startTime = performance.now();
    const adminSubmoduleService = services('adminSubmoduleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['admin_submodule_db']);

    let adminSubmoduleList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.name = data.name;
      data.icon = data.icon;
      data.redirect_link = data.redirectLink;
      data.record_status = data.record_status;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      adminSubmoduleList.push(data);
    }
    try {
      await adminSubmoduleService.bulkCreateAdminSubmodule(adminSubmoduleList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Admin Role Permission Modules User Data created');
  }).timeout(3000);
  /*For module submodule */
  it('Seed Module Submodule Data', async () => {
    const startTime = performance.now();
    const adminModuleSubmoduleService = services('adminModuleSubmoduleService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['admin_module_submodule_db']);

    let adminModuleSubmoduleList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.admin_module_id = data.adminModuleId;
      data.admin_submodule_id = data.adminSubmoduleId;
      data.record_status = data.record_status;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      adminModuleSubmoduleList.push(data);
    }
    try {
      console.log('adminModuleSubmoduleList', adminModuleSubmoduleList);
      await adminModuleSubmoduleService.bulkCreateAdminModuleSubmodule(adminModuleSubmoduleList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Admin Role Permission Modules User Data created');
  }).timeout(3000);
  /*For Role permission */
  it('Seed Role Permission Data', async () => {
    const startTime = performance.now();
    const adminPanelPermissionService = services('adminPanelPermissionService');
    const fileName = 'meta_entities.xlsx';
    const filePath = path.join(__dirname, '/../../resources/' + fileName);
    let workbook = xlsx.readFile(`${filePath}`);
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets['admin_panel_permission_db']);

    let adminPanelPermissionList = [];
    for (let data of sheetData) {
      data.id = data.id;
      data.role_id = data.roleId;
      data.admin_module_id = data.adminModuleId;
      data.admin_submodule_id = data.adminSubmoduleId;
      data.can_view = data.canView;
      data.can_create = data.canCreate;
      data.can_update = data.canUpdate;
      data.can_delete = data.canDelete;
      data.record_status = data.record_status;
      data.created_at = new Date(Math.round((data.created_at - 25569) * 86400 * 1000));
      data.updated_at = new Date(Math.round((data.updated_at - 25569) * 86400 * 1000));
      adminPanelPermissionList.push(data);
    }
    try {
      await adminPanelPermissionService.bulkCreateAdminPanelPermission(adminPanelPermissionList);
    } catch (err) {
      logger.error('err------>', err);
    }

    const endTime = performance.now();
    logger.info(`Time took to import safe :: ${endTime - startTime} milliseconds`);
    logger.info('Seed Admin Role Permission Modules User Data created');
  }).timeout(3000);
});
