const { services, repositories, logger, database, constants } = require('../factory');

describe('Sync DB', () => {
  it('Database Migration', async () => {
    // this.timeout(5000);
    await database.sequelize.query('SET FOREIGN_KEY_CHECKS = 0;', { raw: true });
    await database.sequelize.sync({ force: true });
    await database.sequelize.query('SET FOREIGN_KEY_CHECKS = 1;', { raw: true });
    await logger.info('Tables of mysql dynamo created');
  }).timeout(100000);
});
